/*---------------------------- section 1 --------------------------------------*/
/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 1 - Sales & Customer
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T1-00-Reset.sql
 Version       : 1.0 (prepared 2026-11-14)
 Purpose       : Remove ALL Team 1 Stage 8 mock data (24 tables) and reseed their
                 IDENTITY columns, so Team 1 generation can be repeated safely.
 Run Order     : 0 - TEST ENVIRONMENT ONLY; run before Team 1 generation.
 Prerequisites : 1. Connect to the TEST copy of the database (no USE statement).
                 2. Type the TEST database name in @ConfirmDb below, or set
                    SESSION_CONTEXT 'T1_Reset_DB' to that exact database name.
                 3. Review the external-FK guard output. If another team's rows
                    reference any Team 1 table, this script stops without deleting.
                 4. Team 2 data (core.Product, marketing.Promotion, etc.) are NOT
                    deleted by this script. Team 1's references to them are removed.
 Seed/Config   : none
 Date          : 2026-11-14
 Notes         : child tables are deleted before parents; no TRUNCATE; no FK,
                 CHECK constraint, or trigger is disabled; all work is transactional.
                 Self-referencing hierarchy links are nulled inside the transaction
                 before deletion. IDENTITY is reseeded only if it had a value.
============================================================================= */
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* Safety: explicitly confirm the TEST database. */
DECLARE @ConfirmDb sysname = N'FoodDistributionDB';  -- <- enter TEST DB name, e.g. N'FoodDistributionDB_S8'
IF @ConfirmDb = N''
    SET @ConfirmDb = ISNULL(CONVERT(sysname, SESSION_CONTEXT(N'T1_Reset_DB')), N'');
IF @ConfirmDb = N'' OR @ConfirmDb <> DB_NAME()
    THROW 51900, N'STOP: Reset not confirmed for this database. Type the TEST database name in @ConfirmDb (or set SESSION_CONTEXT T1_Reset_DB); nothing was deleted.', 1;

PRINT CONCAT(N'Reset confirmation accepted for database: ', DB_NAME());

/* All 24 Team 1 tables validated against the Team 1 Stage 6/8 object inventory. */
DECLARE @T TABLE (Ord int PRIMARY KEY, Table_Name nvarchar(261) NOT NULL UNIQUE);
INSERT @T (Ord, Table_Name) VALUES
 ( 1, N'sales.ReturnRequest'),
 ( 2, N'sales.CustomerFeedback'),
 ( 3, N'sales.Payment'),
 ( 4, N'sales.InvoiceItem'),
 ( 5, N'sales.Invoice'),
 ( 6, N'sales.SalesOrderItem'),
 ( 7, N'sales.SalesOrder'),
 ( 8, N'sales.Contract'),
 ( 9, N'sales.Commission'),
 (10, N'sales.SalesTarget'),
 (11, N'sales.SalesForecast'),
 (12, N'sales.SalesOpportunity'),
 (13, N'sales.CustomerInteraction'),
 (14, N'sales.Lead'),
 (15, N'core.Customer'),
 (16, N'core.Salesperson'),
 (17, N'core.Branch'),
 (18, N'core.Calendar'),
 (19, N'ref.City'),
 (20, N'ref.SalesRegion'),
 (21, N'ref.SalesTerritory'),
 (22, N'ref.CustomerSegment'),
 (23, N'ref.SalesChannel'),
 (24, N'ref.Province');

DECLARE @Missing nvarchar(max) = N'';
SELECT @Missing = @Missing + CASE WHEN @Missing = N'' THEN N'' ELSE N', ' END + Table_Name
FROM @T WHERE OBJECT_ID(Table_Name, N'U') IS NULL;
IF @Missing <> N''
BEGIN
    PRINT CONCAT(N'STOP: Required Team 1 tables missing: ', @Missing);
    THROW 51901, N'STOP: One or more required Team 1 tables are missing; nothing was deleted.', 1;
END;

/*
 Guard against rows owned by another team/application that reference a Team 1
 parent table. Internal Team 1 foreign keys are excluded. The check is data-aware:
 an FK definition alone does not block the reset; only an actual referencing row does.
*/
DECLARE
    @ChildSchema sysname, @ChildTable sysname,
    @ParentSchema sysname, @ParentTable sysname,
    @JoinPredicate nvarchar(max), @GuardSql nvarchar(max),
    @HasExternalRows bit, @FkName sysname;

DECLARE fk_guard CURSOR LOCAL FAST_FORWARD FOR
SELECT
    cs.name, ct.name, ps.name, pt.name, fk.name,
    STRING_AGG(CONVERT(nvarchar(max), N'c.' + QUOTENAME(cc.name) + N' = p.' + QUOTENAME(pc.name)), N' AND ')
        WITHIN GROUP (ORDER BY fkc.constraint_column_id)
FROM sys.foreign_keys fk
JOIN sys.tables ct ON ct.object_id = fk.parent_object_id
JOIN sys.schemas cs ON cs.schema_id = ct.schema_id
JOIN sys.tables pt ON pt.object_id = fk.referenced_object_id
JOIN sys.schemas ps ON ps.schema_id = pt.schema_id
JOIN sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
JOIN sys.columns cc ON cc.object_id = fkc.parent_object_id AND cc.column_id = fkc.parent_column_id
JOIN sys.columns pc ON pc.object_id = fkc.referenced_object_id AND pc.column_id = fkc.referenced_column_id
WHERE fk.referenced_object_id IN (SELECT OBJECT_ID(Table_Name) FROM @T)
  AND fk.parent_object_id NOT IN (SELECT OBJECT_ID(Table_Name) FROM @T)
GROUP BY cs.name, ct.name, ps.name, pt.name, fk.name;

OPEN fk_guard;
FETCH NEXT FROM fk_guard INTO @ChildSchema, @ChildTable, @ParentSchema, @ParentTable, @FkName, @JoinPredicate;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @HasExternalRows = 0;
    SET @GuardSql = N'IF EXISTS (SELECT 1 FROM ' + QUOTENAME(@ChildSchema) + N'.' + QUOTENAME(@ChildTable) + N' AS c'
        + N' INNER JOIN ' + QUOTENAME(@ParentSchema) + N'.' + QUOTENAME(@ParentTable) + N' AS p ON '
        + @JoinPredicate + N') SET @Found = 1;';
    EXEC sys.sp_executesql @GuardSql, N'@Found bit OUTPUT', @Found = @HasExternalRows OUTPUT;
    IF @HasExternalRows = 1
    BEGIN
        PRINT CONCAT(N'STOP: external rows found in ', QUOTENAME(@ChildSchema), N'.', QUOTENAME(@ChildTable),
                     N' through FK ', @FkName, N' referencing ', QUOTENAME(@ParentSchema), N'.', QUOTENAME(@ParentTable), N'.');
        CLOSE fk_guard;
        DEALLOCATE fk_guard;
        THROW 51902, N'STOP: Another table/team has rows referencing Team 1 data. Resolve the dependency first; nothing was deleted.', 1;
    END;
    FETCH NEXT FROM fk_guard INTO @ChildSchema, @ChildTable, @ParentSchema, @ParentTable, @FkName, @JoinPredicate;
END;
CLOSE fk_guard;
DEALLOCATE fk_guard;

PRINT N'External-reference guard passed. Beginning transactional Team 1 reset.';

DECLARE @Ord int = 1, @Tbl nvarchar(261), @Sql nvarchar(max), @Rows int;
BEGIN TRY
    BEGIN TRANSACTION;

    /* Break only intra-Team-1 self-references; constraints remain enabled. */
    UPDATE ref.City SET Parent_City_ID = NULL WHERE Parent_City_ID IS NOT NULL;
    PRINT CONCAT(N'Cleared self-parent links in ref.City: ', @@ROWCOUNT);

    UPDATE ref.SalesRegion SET Parent_Sales_Region_ID = NULL WHERE Parent_Sales_Region_ID IS NOT NULL;
    PRINT CONCAT(N'Cleared self-parent links in ref.SalesRegion: ', @@ROWCOUNT);

    UPDATE core.Salesperson SET Manager_Salesperson_ID = NULL WHERE Manager_Salesperson_ID IS NOT NULL;
    PRINT CONCAT(N'Cleared manager links in core.Salesperson: ', @@ROWCOUNT);

    WHILE @Ord <= 24
    BEGIN
        SELECT @Tbl = Table_Name FROM @T WHERE Ord = @Ord;
        SET @Rows = 0;
        SET @Sql = N'DELETE FROM ' + QUOTENAME(PARSENAME(@Tbl, 2)) + N'.' + QUOTENAME(PARSENAME(@Tbl, 1)) + N'; SET @N = @@ROWCOUNT;';
        EXEC sys.sp_executesql @Sql, N'@N int OUTPUT', @N = @Rows OUTPUT;
        PRINT CONCAT(N'Deleted ', @Rows, N' rows from ', @Tbl);
        SET @Ord += 1;
    END;

    /* Reseed only identity columns that have previously generated a value. */
    DECLARE @IdentityTable nvarchar(517);
    DECLARE id_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT QUOTENAME(OBJECT_SCHEMA_NAME(ic.object_id)) + N'.' + QUOTENAME(OBJECT_NAME(ic.object_id))
        FROM sys.identity_columns ic
        JOIN @T t ON OBJECT_ID(t.Table_Name) = ic.object_id
        WHERE ic.last_value IS NOT NULL
        ORDER BY t.Ord;
    OPEN id_cursor;
    FETCH NEXT FROM id_cursor INTO @IdentityTable;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Sql = N'DBCC CHECKIDENT (' + QUOTENAME(@IdentityTable, '''') + N', RESEED, 0) WITH NO_INFOMSGS;';
        EXEC sys.sp_executesql @Sql;
        PRINT CONCAT(N'Reseeded identity: ', @IdentityTable);
        FETCH NEXT FROM id_cursor INTO @IdentityTable;
    END;
    CLOSE id_cursor;
    DEALLOCATE id_cursor;

    /* Final empty-table assertion; failure rolls back deletes and reseeds. */
    DECLARE @Remaining nvarchar(max) = N'';
    DECLARE @CheckTable nvarchar(261);
    DECLARE check_cursor CURSOR LOCAL FAST_FORWARD FOR SELECT Table_Name FROM @T ORDER BY Ord;
    OPEN check_cursor;
    FETCH NEXT FROM check_cursor INTO @CheckTable;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Sql = N'IF EXISTS (SELECT 1 FROM ' + QUOTENAME(PARSENAME(@CheckTable, 2)) + N'.' + QUOTENAME(PARSENAME(@CheckTable, 1))
                 + N') SET @Found = 1;';
        SET @HasExternalRows = 0;
        EXEC sys.sp_executesql @Sql, N'@Found bit OUTPUT', @Found = @HasExternalRows OUTPUT;
        IF @HasExternalRows = 1 SET @Remaining = @Remaining + CASE WHEN @Remaining = N'' THEN N'' ELSE N', ' END + @CheckTable;
        FETCH NEXT FROM check_cursor INTO @CheckTable;
    END;
    CLOSE check_cursor;
    DEALLOCATE check_cursor;

    IF @Remaining <> N''
    BEGIN
        PRINT CONCAT(N'Final assertion failed; non-empty tables: ', @Remaining);
        THROW 51903, N'Team 1 reset verification failed; transaction will be rolled back.', 1;
    END;

    COMMIT TRANSACTION;
    PRINT N'Team 1 reset completed: all 24 tables are empty; eligible IDENTITY columns reseeded.';
    PRINT N'Team 2 tables and rows were not deleted or modified.';
END TRY
BEGIN CATCH
    IF CURSOR_STATUS('local', 'id_cursor') >= 0
    BEGIN
        CLOSE id_cursor;
        DEALLOCATE id_cursor;
    END
    ELSE IF CURSOR_STATUS('local', 'id_cursor') = -1
        DEALLOCATE id_cursor;

    IF CURSOR_STATUS('local', 'check_cursor') >= 0
    BEGIN
        CLOSE check_cursor;
        DEALLOCATE check_cursor;
    END
    ELSE IF CURSOR_STATUS('local', 'check_cursor') = -1
        DEALLOCATE check_cursor;
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    PRINT CONCAT(N'08-03-T1-00-Reset FAILED (transaction rolled back where possible). Error ', ERROR_NUMBER(),
                 N' | Line ', ERROR_LINE(), N': ', ERROR_MESSAGE());
    THROW;
END CATCH;
GO


/*---------------------------- section 2 --------------------------------------*/
/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.8: SinaSepasi, #196)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T2-00-Reset.sql
 Version       : 1.1 (1.1, PM review 2026-11-07: no USE statement; runs only after the target database
                 name is typed in @ConfirmDb below, or set as SESSION_CONTEXT 'T2_Reset_DB')
 Purpose       : Remove ALL Team 2 mock data (24 tables) and reseed their IDENTITY columns,
                 so the Team 2 load can be repeated on a clean base (re-run policy, Q17).
 Run Order     : 0 - TEST ENVIRONMENT ONLY
 Prerequisites : 1. Connect to the TEST copy of the database (the script has no USE statement).
                 2. Type that database name in @ConfirmDb (line "DECLARE @ConfirmDb" below), or run
                    EXEC sp_set_session_context N'T2_Reset_DB', N'<test database name>'; first.
                    If the name is empty or differs from DB_NAME(), the script stops and deletes nothing.
                 3. No Team 1 row references core.Product or marketing.Promotion
                    (Contract, SalesOrder, SalesOrderItem, InvoiceItem, CustomerFeedback, SalesTarget).
                    If Team 1 data exists the script stops and changes nothing.
 Seed/Config   : none
 Date          : 2026-11-07
 Notes         : deletes child tables first (reverse FK order); no TRUNCATE (FKs), no constraint or
                 trigger is disabled; reseed only for tables that ever had a row, so the next row is 1.
                 Test log 2026-11-07: run on (localdb)\Stage7Test, database FoodDistributionDB_S8.
============================================================================= */
SET NOCOUNT ON;
SET XACT_ABORT ON;

-- Safety: the test database name must be confirmed explicitly (protects a production copy).
DECLARE @ConfirmDb sysname = N'FoodDistributionDB';   -- <- type the TEST database name here, e.g. N'FoodDistributionDB_S8'
IF @ConfirmDb = N'' SET @ConfirmDb = ISNULL(CONVERT(sysname, SESSION_CONTEXT(N'T2_Reset_DB')), N'');
IF @ConfirmDb = N'' OR @ConfirmDb <> DB_NAME()
    THROW 50900, N'STOP: Reset not confirmed for this database. Type the TEST database name in @ConfirmDb (or set SESSION_CONTEXT T2_Reset_DB); nothing was deleted.', 1;
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50901, N'STOP: wrong database (Team 2 tables not found); nothing was deleted.', 1;
PRINT CONCAT(N'Reset confirmed for database ', DB_NAME());

IF EXISTS (SELECT 1 FROM sales.SalesOrderItem) OR EXISTS (SELECT 1 FROM sales.InvoiceItem)
   OR EXISTS (SELECT 1 FROM sales.Contract WHERE Product_ID IS NOT NULL)
   OR EXISTS (SELECT 1 FROM sales.CustomerFeedback WHERE Product_ID IS NOT NULL)
   OR EXISTS (SELECT 1 FROM sales.SalesTarget WHERE Product_ID IS NOT NULL)
   OR EXISTS (SELECT 1 FROM sales.SalesOrder WHERE Promotion_ID IS NOT NULL)
    THROW 50902, N'STOP: Team 1 rows reference core.Product or marketing.Promotion. Reset Team 1 data first; nothing was deleted.', 1;

DECLARE @T TABLE (Ord int PRIMARY KEY, Table_Name sysname NOT NULL);
INSERT @T VALUES
 ( 1, N'marketing.MarketPrice'),            ( 2, N'marketing.CompetitorProduct'),   ( 3, N'marketing.Competitor'),
 ( 4, N'marketing.ResearchResult'),         ( 5, N'marketing.MarketSurvey'),        ( 6, N'marketing.MarketResearch'),
 ( 7, N'marketing.ProductPrice'),           ( 8, N'marketing.Promotion'),           ( 9, N'marketing.CampaignResult'),
 (10, N'marketing.CampaignCost'),           (11, N'marketing.CampaignBudget'),      (12, N'marketing.MarketingCampaignAudience'),
 (13, N'marketing.MarketingCampaignChannel'),(14, N'marketing.MarketingCampaign'),  (15, N'core.SKU'),
 (16, N'core.Product'),                     (17, N'ref.Package'),                   (18, N'ref.ProductCategory'),
 (19, N'marketing.MarketSegment'),          (20, N'marketing.Market'),              (21, N'marketing.BrandActivity'),
 (22, N'marketing.CampaignAudience'),       (23, N'marketing.CampaignChannel'),     (24, N'core.Brand');

DECLARE @Ord int = 1, @Tbl sysname, @Sql nvarchar(max), @Rows int;
BEGIN TRY
    BEGIN TRANSACTION;
    WHILE @Ord <= 24
    BEGIN
        SELECT @Tbl = Table_Name FROM @T WHERE Ord = @Ord;
        IF @Tbl = N'ref.ProductCategory'
        BEGIN
            -- self reference: children first
            DELETE FROM ref.ProductCategory WHERE Parent_Category_ID IS NOT NULL;
            SET @Rows = @@ROWCOUNT;
            DELETE FROM ref.ProductCategory;
            SET @Rows += @@ROWCOUNT;
        END
        ELSE
        BEGIN
            SET @Sql = N'DELETE FROM ' + @Tbl + N';';
            EXEC sp_executesql @Sql;
            SET @Rows = @@ROWCOUNT;
        END
        PRINT CONCAT(N'Deleted ', @Rows, N' rows from ', @Tbl);
        SET @Ord += 1;
    END;

    -- reseed IDENTITY so the next generated value is 1 (only where a value was ever generated)
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT QUOTENAME(OBJECT_SCHEMA_NAME(ic.object_id)) + N'.' + QUOTENAME(OBJECT_NAME(ic.object_id))
        FROM sys.identity_columns ic
        JOIN @T t ON OBJECT_ID(t.Table_Name) = ic.object_id
        WHERE ic.last_value IS NOT NULL;
    OPEN c; FETCH NEXT FROM c INTO @Tbl;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DBCC CHECKIDENT (@Tbl, RESEED, 0) WITH NO_INFOMSGS;
        FETCH NEXT FROM c INTO @Tbl;
    END;
    CLOSE c; DEALLOCATE c;

    COMMIT TRANSACTION;
    PRINT N'Team 2 reset completed: 24 tables empty, IDENTITY reseeded.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    PRINT CONCAT(N'08-03-T2-00-Reset FAILED (rolled back). Error ', ERROR_NUMBER(), N': ', ERROR_MESSAGE());
    THROW;
END CATCH;
GO
