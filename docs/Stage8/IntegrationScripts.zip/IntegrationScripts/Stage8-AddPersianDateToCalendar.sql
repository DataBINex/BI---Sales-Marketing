﻿
USE [FoodDistributionDB];
GO

/*========================================================
  Step 1: Validate Persian calendar conversion
========================================================*/

IF FORMAT(
    CAST('2025-03-21' AS DATE),
    'yyyyMMdd',
    'fa-IR'
) <> '14040101'
BEGIN
    THROW 50001,
    'Persian calendar conversion is not working correctly on this SQL Server.',
    1;
END;
GO

/*========================================================
  Step 2: Add new columns (if they do not exist)
========================================================*/

IF COL_LENGTH('core.Calendar', 'DateKey') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [DateKey] INT NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianYear') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianYear] INT NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianMonth') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianMonth] INT NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianMonthName') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianMonthName] NVARCHAR(20) NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianDay') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianDay] INT NULL;
GO

/*========================================================
  Step 3: Populate new columns
========================================================*/

UPDATE C
SET
    C.DateKey =
        YEAR(C.Calendar_Date) * 10000
        + MONTH(C.Calendar_Date) * 100
        + DAY(C.Calendar_Date),

    C.PersianYear = P.PersianYear,

    C.PersianMonth = P.PersianMonth,

    C.PersianMonthName =
        CASE P.PersianMonth
            WHEN 1  THEN N'فروردین'
            WHEN 2  THEN N'اردیبهشت'
            WHEN 3  THEN N'خرداد'
            WHEN 4  THEN N'تیر'
            WHEN 5  THEN N'مرداد'
            WHEN 6  THEN N'شهریور'
            WHEN 7  THEN N'مهر'
            WHEN 8  THEN N'آبان'
            WHEN 9  THEN N'آذر'
            WHEN 10 THEN N'دی'
            WHEN 11 THEN N'بهمن'
            WHEN 12 THEN N'اسفند'
        END,

    C.PersianDay = P.PersianDay

FROM [core].[Calendar] AS C

CROSS APPLY
(
    SELECT FORMAT(
        C.Calendar_Date,
        'yyyyMMdd',
        'fa-IR'
    ) AS PersianDate
) AS F

CROSS APPLY
(
    SELECT
        TRY_CONVERT(INT, SUBSTRING(F.PersianDate, 1, 4))
            AS PersianYear,

        TRY_CONVERT(INT, SUBSTRING(F.PersianDate, 5, 2))
            AS PersianMonth,

        TRY_CONVERT(INT, SUBSTRING(F.PersianDate, 7, 2))
            AS PersianDay
) AS P;

GO

/*========================================================
  Step 4: Validate converted data
========================================================*/

IF EXISTS
(
    SELECT 1
    FROM [core].[Calendar]
    WHERE PersianYear IS NULL
       OR PersianMonth NOT BETWEEN 1 AND 12
       OR PersianDay NOT BETWEEN 1 AND 31
       OR PersianMonthName IS NULL
       OR DateKey IS NULL
)
BEGIN
    THROW 50002,
    'Some calendar records were not converted correctly.',
    1;
END;
GO

/*========================================================
  Step 5: Change columns to NOT NULL
========================================================*/

ALTER TABLE [core].[Calendar]
ALTER COLUMN [DateKey] INT NOT NULL;

ALTER TABLE [core].[Calendar]
ALTER COLUMN [PersianYear] INT NOT NULL;

ALTER TABLE [core].[Calendar]
ALTER COLUMN [PersianMonth] INT NOT NULL;

ALTER TABLE [core].[Calendar]
ALTER COLUMN [PersianMonthName] NVARCHAR(20) NOT NULL;

ALTER TABLE [core].[Calendar]
ALTER COLUMN [PersianDay] INT NOT NULL;
GO

/*========================================================
  Step 6: Add unique index for DateKey
========================================================*/

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'UX_Calendar_DateKey'
      AND object_id = OBJECT_ID('core.Calendar')
)
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX [UX_Calendar_DateKey]
    ON [core].[Calendar] ([DateKey]);
END;
GO

/*========================================================
  Step 7: Final result
========================================================*/

SELECT
*
FROM [core].[Calendar]
ORDER BY Calendar_Date;
GO
