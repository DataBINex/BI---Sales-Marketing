﻿/* =============================================================================
 Project/Stage : BI---Sales-Marketing / Stage 8 - Team 2 (Issue #195 / 8.7)
 Script        : 08-05-T2-05-Promotion-Price-Checks.sql
 Version       : 1.0        Created: 2026-11-03
 Purpose       : QC for marketing.ProductPrice and marketing.Promotion (guide Q01-Q07, Q12, Q13 + extras)
 Prerequisite  : 08-03-T2-05-Promotion-Price.sql executed. Read-only: makes no change.
 Output        : Test_ID | Table_Name | Definition | Rows_Checked | Error_Count | Sample_Error_IDs | Result
============================================================================= */
SET NOCOUNT ON;
DECLARE @FromDate date = '2019-03-21', @ToDate date = '2027-03-20', @AsOfDate date = '2027-03-20';
DECLARE @MaxPct decimal(5,2) = 25.00, @Currency char(3) = 'IRR';
DECLARE @CampaignPurpose nvarchar(30) = N'Marketing';

CREATE TABLE #R (Ord int IDENTITY, Test_ID nvarchar(30), Table_Name nvarchar(40), Definition nvarchar(200),
                 Rows_Checked bigint, Error_Count bigint, Sample_Error_IDs nvarchar(200));

-- Q01 row counts
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q01', N'marketing.ProductPrice', N'Row count > 0 (compare with load log)', COUNT_BIG(*), CASE WHEN COUNT_BIG(*) = 0 THEN 1 ELSE 0 END, CAST(COUNT_BIG(*) AS nvarchar(20)) FROM marketing.ProductPrice;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q01', N'marketing.Promotion', N'Row count > 0 (compare with load log)', COUNT_BIG(*), CASE WHEN COUNT_BIG(*) = 0 THEN 1 ELSE 0 END, CAST(COUNT_BIG(*) AS nvarchar(20)) FROM marketing.Promotion;

-- Q02 uniqueness
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q02', N'marketing.Promotion', N'Promotion_Code unique, not NULL/empty', (SELECT COUNT_BIG(*) FROM marketing.Promotion),
       COUNT_BIG(*), (SELECT STRING_AGG(Promotion_Code, ',') FROM (SELECT TOP 5 Promotion_Code FROM marketing.Promotion GROUP BY Promotion_Code HAVING COUNT(*) > 1) z)
FROM (SELECT Promotion_Code FROM marketing.Promotion GROUP BY Promotion_Code HAVING COUNT(*) > 1) d;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q02', N'marketing.Promotion', N'Promotion_Name unique (mock rule T2-S8-08)', (SELECT COUNT_BIG(*) FROM marketing.Promotion),
       COUNT_BIG(*), (SELECT STRING_AGG(Promotion_Name, ',') FROM (SELECT TOP 3 Promotion_Name FROM marketing.Promotion GROUP BY Promotion_Name HAVING COUNT(*) > 1) z)
FROM (SELECT Promotion_Name FROM marketing.Promotion GROUP BY Promotion_Name HAVING COUNT(*) > 1) d;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q02', N'marketing.ProductPrice', N'No duplicate (SKU_ID, Price_Type, Effective_From)', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice),
       COUNT_BIG(*), (SELECT STRING_AGG(CAST(SKU_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 SKU_ID FROM marketing.ProductPrice GROUP BY SKU_ID, Price_Type, Effective_From HAVING COUNT(*) > 1) z)
FROM (SELECT 1 AS x FROM marketing.ProductPrice GROUP BY SKU_ID, Price_Type, Effective_From HAVING COUNT(*) > 1) d;

-- Q03 FK
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q03', N'marketing.ProductPrice', N'SKU_ID exists in core.SKU', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Product_Price_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 pp.Product_Price_ID FROM marketing.ProductPrice pp LEFT JOIN core.SKU s ON s.SKU_ID = pp.SKU_ID WHERE s.SKU_ID IS NULL) z)
FROM marketing.ProductPrice pp LEFT JOIN core.SKU s ON s.SKU_ID = pp.SKU_ID WHERE s.SKU_ID IS NULL;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q03', N'marketing.Promotion', N'Marketing_Campaign_ID (when present) exists', (SELECT COUNT_BIG(*) FROM marketing.Promotion), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Promotion_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 p.Promotion_ID FROM marketing.Promotion p LEFT JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = p.Marketing_Campaign_ID WHERE p.Marketing_Campaign_ID IS NOT NULL AND c.Marketing_Campaign_ID IS NULL) z)
FROM marketing.Promotion p LEFT JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = p.Marketing_Campaign_ID
WHERE p.Marketing_Campaign_ID IS NOT NULL AND c.Marketing_Campaign_ID IS NULL;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q03', N'core.SKU', N'Every SKU has at least one ProductPrice', (SELECT COUNT_BIG(*) FROM core.SKU), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(SKU_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 s.SKU_ID FROM core.SKU s WHERE NOT EXISTS (SELECT 1 FROM marketing.ProductPrice pp WHERE pp.SKU_ID = s.SKU_ID)) z)
FROM core.SKU s WHERE NOT EXISTS (SELECT 1 FROM marketing.ProductPrice pp WHERE pp.SKU_ID = s.SKU_ID);

-- Q04 date range
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q04', N'marketing.Promotion', N'Start/End inside @FromDate..@ToDate', (SELECT COUNT_BIG(*) FROM marketing.Promotion), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Promotion_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Promotion_ID FROM marketing.Promotion WHERE Start_Date < @FromDate OR End_Date > @ToDate) z)
FROM marketing.Promotion WHERE Start_Date < @FromDate OR End_Date > @ToDate;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q04', N'marketing.ProductPrice', N'Effective_From <= @ToDate; Effective_To <= @ToDate; no period before @FromDate', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Product_Price_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Product_Price_ID FROM marketing.ProductPrice WHERE Effective_From > @ToDate OR Effective_To > @ToDate OR Effective_From < @FromDate) z)
FROM marketing.ProductPrice WHERE Effective_From > @ToDate OR Effective_To > @ToDate OR Effective_From < @FromDate;

-- Q06 numeric domain
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q06', N'marketing.ProductPrice', N'Unit_Price > 0 and Currency = IRR', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Product_Price_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Product_Price_ID FROM marketing.ProductPrice WHERE Unit_Price <= 0 OR Currency <> @Currency) z)
FROM marketing.ProductPrice WHERE Unit_Price <= 0 OR Currency <> @Currency;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q06', N'marketing.Promotion', N'Discount type allowed; percentage in (0, cap]; fixed > 0 with Currency = IRR; percentage has no currency', (SELECT COUNT_BIG(*) FROM marketing.Promotion), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Promotion_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Promotion_ID FROM marketing.Promotion WHERE Discount_Type NOT IN (N'Percentage', N'Fixed Amount') OR Discount_Value <= 0 OR (Discount_Type = N'Percentage' AND (Discount_Value > @MaxPct OR Currency IS NOT NULL)) OR (Discount_Type = N'Fixed Amount' AND ISNULL(Currency, '') <> @Currency)) z)
FROM marketing.Promotion
WHERE Discount_Type NOT IN (N'Percentage', N'Fixed Amount') OR Discount_Value <= 0
   OR (Discount_Type = N'Percentage' AND (Discount_Value > @MaxPct OR Currency IS NOT NULL))
   OR (Discount_Type = N'Fixed Amount' AND ISNULL(Currency, '') <> @Currency);

-- Q07 temporal consistency
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q07', N'marketing.Promotion', N'Start_Date <= End_Date', (SELECT COUNT_BIG(*) FROM marketing.Promotion), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Promotion_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Promotion_ID FROM marketing.Promotion WHERE Start_Date > End_Date) z)
FROM marketing.Promotion WHERE Start_Date > End_Date;
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q07', N'marketing.Promotion', N'Promotion_Status consistent with dates at @AsOfDate (Expired/Planned/Active)', (SELECT COUNT_BIG(*) FROM marketing.Promotion), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Promotion_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Promotion_ID FROM marketing.Promotion WHERE (End_Date < @AsOfDate AND Promotion_Status <> N'Expired') OR (Start_Date > @AsOfDate AND Promotion_Status <> N'Planned') OR (Start_Date <= @AsOfDate AND End_Date >= @AsOfDate AND Promotion_Status <> N'Active')) z)
FROM marketing.Promotion
WHERE (End_Date < @AsOfDate AND Promotion_Status <> N'Expired') OR (Start_Date > @AsOfDate AND Promotion_Status <> N'Planned')
   OR (Start_Date <= @AsOfDate AND End_Date >= @AsOfDate AND Promotion_Status <> N'Active');

-- Q12 price validity: overlap, gap, first period, open-ended last period, margin
;WITH o AS (
    SELECT a.Product_Price_ID FROM marketing.ProductPrice a JOIN marketing.ProductPrice b
      ON a.SKU_ID = b.SKU_ID AND a.Price_Type = b.Price_Type AND a.Product_Price_ID < b.Product_Price_ID
     AND a.Effective_From <= ISNULL(b.Effective_To, '9999-12-31') AND b.Effective_From <= ISNULL(a.Effective_To, '9999-12-31'))
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q12-overlap', N'marketing.ProductPrice', N'No overlapping periods per SKU x Price_Type', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Product_Price_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Product_Price_ID FROM o) z) FROM o;

;WITH w AS (
    SELECT Product_Price_ID, SKU_ID, Price_Type, Effective_To,
           LEAD(Effective_From) OVER (PARTITION BY SKU_ID, Price_Type ORDER BY Effective_From) AS Next_From
    FROM marketing.ProductPrice),
g AS (SELECT * FROM w WHERE (Next_From IS NOT NULL AND (Effective_To IS NULL OR DATEADD(DAY, 1, Effective_To) <> Next_From)))
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q12-gap', N'marketing.ProductPrice', N'No gaps between consecutive periods', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Product_Price_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Product_Price_ID FROM g) z) FROM g;

;WITH f AS (
    SELECT pp.SKU_ID, pp.Price_Type, MIN(pp.Effective_From) AS First_From,
           SUM(CASE WHEN pp.Effective_To IS NULL THEN 1 ELSE 0 END) AS Open_Cnt
    FROM marketing.ProductPrice pp GROUP BY pp.SKU_ID, pp.Price_Type),
e AS (
    SELECT f.SKU_ID FROM f JOIN core.SKU s ON s.SKU_ID = f.SKU_ID JOIN core.Product p ON p.Product_ID = s.Product_ID
    WHERE f.First_From <> CASE WHEN p.Launch_Date > @FromDate THEN p.Launch_Date ELSE @FromDate END OR f.Open_Cnt <> 1)
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q12-coverage', N'marketing.ProductPrice', N'First period = max(Launch_Date,@FromDate); exactly one open-ended last period (=> price on every day)', (SELECT COUNT_BIG(*) FROM f), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(SKU_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 SKU_ID FROM e) z) FROM e;

INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q12-margin', N'marketing.ProductPrice', N'Unit_Price >= SKU.Standard_Cost', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Product_Price_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 pp.Product_Price_ID FROM marketing.ProductPrice pp JOIN core.SKU s ON s.SKU_ID = pp.SKU_ID WHERE pp.Unit_Price < s.Standard_Cost) z)
FROM marketing.ProductPrice pp JOIN core.SKU s ON s.SKU_ID = pp.SKU_ID WHERE pp.Unit_Price < s.Standard_Cost;

INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q12-trend', N'marketing.ProductPrice', N'Price never falls between consecutive periods (gradual rises)', (SELECT COUNT_BIG(*) FROM marketing.ProductPrice), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Product_Price_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 Product_Price_ID FROM (SELECT Product_Price_ID, Unit_Price, LAG(Unit_Price) OVER (PARTITION BY SKU_ID, Price_Type ORDER BY Effective_From) AS Prev FROM marketing.ProductPrice) t WHERE Prev IS NOT NULL AND Unit_Price < Prev) z)
FROM (SELECT Unit_Price, LAG(Unit_Price) OVER (PARTITION BY SKU_ID, Price_Type ORDER BY Effective_From) AS Prev FROM marketing.ProductPrice) t
WHERE Prev IS NOT NULL AND Unit_Price < Prev;

-- Q13 promotion inside its campaign period
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q13', N'marketing.Promotion', N'Promotion period inside the linked campaign period', (SELECT COUNT_BIG(*) FROM marketing.Promotion WHERE Marketing_Campaign_ID IS NOT NULL), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Promotion_ID AS nvarchar(20)), ',') FROM (SELECT TOP 5 p.Promotion_ID FROM marketing.Promotion p JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = p.Marketing_Campaign_ID WHERE p.Start_Date < c.Start_Date OR p.End_Date > ISNULL(c.End_Date, @ToDate)) z)
FROM marketing.Promotion p JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = p.Marketing_Campaign_ID
WHERE p.Start_Date < c.Start_Date OR p.End_Date > ISNULL(c.End_Date, @ToDate);

-- Q15 distribution sanity (informational thresholds: >=25 promotions/year at full scale is checked by volume, not here)
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q15', N'marketing.Promotion', N'Every year of the range has at least one promotion', (SELECT COUNT_BIG(*) FROM marketing.Promotion), COUNT_BIG(*),
       (SELECT STRING_AGG(CAST(Yr AS nvarchar(10)), ',') FROM (SELECT y.Yr FROM (SELECT TOP (DATEDIFF(YEAR, @FromDate, DATEADD(DAY,1,@ToDate))) YEAR(@FromDate) + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Yr FROM sys.all_objects) y WHERE NOT EXISTS (SELECT 1 FROM marketing.Promotion p WHERE p.Start_Date >= DATEFROMPARTS(y.Yr, MONTH(@FromDate), DAY(@FromDate)) AND p.Start_Date < DATEFROMPARTS(y.Yr + 1, MONTH(@FromDate), DAY(@FromDate)))) m)
FROM (SELECT y.Yr FROM (SELECT TOP (DATEDIFF(YEAR, @FromDate, DATEADD(DAY,1,@ToDate))) YEAR(@FromDate) + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Yr FROM sys.all_objects) y WHERE NOT EXISTS (SELECT 1 FROM marketing.Promotion p WHERE p.Start_Date >= DATEFROMPARTS(y.Yr, MONTH(@FromDate), DAY(@FromDate)) AND p.Start_Date < DATEFROMPARTS(y.Yr + 1, MONTH(@FromDate), DAY(@FromDate)))) m;

-- Q16 privacy: no URLs/phones/emails stored in these tables (names are generic Persian festival names)
INSERT #R (Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs)
SELECT N'Q16', N'marketing.Promotion', N'No @, http or digit-only phone-like pattern in Promotion_Name', (SELECT COUNT_BIG(*) FROM marketing.Promotion), COUNT_BIG(*), NULL
FROM marketing.Promotion WHERE Promotion_Name LIKE N'%@%' OR Promotion_Name LIKE N'%http%' OR Promotion_Name LIKE N'%09[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]%';

SELECT Test_ID, Table_Name, Definition, Rows_Checked, Error_Count, Sample_Error_IDs,
       CASE WHEN Error_Count = 0 THEN 'Pass' ELSE 'Fail' END AS Result
FROM #R ORDER BY Ord;
