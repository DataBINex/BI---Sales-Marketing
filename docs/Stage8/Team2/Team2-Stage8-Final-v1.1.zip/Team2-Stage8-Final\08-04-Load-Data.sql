/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.8: SinaSepasi, #196)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-04-Load-Data.sql
 Version       : 1.2 (1.1: header completed with environment, error logging and test result;
                 1.2, PM review 2026-11-07: the database name is set ONCE here (:setvar DbName); the
                 generator scripts have no USE statement any more; the log prints the database name)
 Purpose       : Run the whole Team 2 generation chain in the approved order, in ONE session,
                 with one Scale setting, and print the load log (Q18).
 Environment   : SQL Server 2022 (Developer / Express / LocalDB), database restored from the Stage 7
                 FoodDistributionDB.bak (48 empty tables). Tested on LocalDB 2022 (16.0), instance
                 (localdb)\Stage7Test, database copy FoodDistributionDB_S8, i.e. with
                 -v DbName="FoodDistributionDB_S8" (the first log line shows the database used).
 Error logging : every generator runs in TRY/CATCH with XACT_ABORT ON; on error it rolls back its own
                 transaction, PRINTs the error number, line and message and re-throws, and
                 :on error exit stops the chain. Keep the console output as the run log, e.g.
                 sqlcmd -S <server> -E -b -v DbName="<database>" Scale="1.00" ScriptDir="<folder>" -i 08-04-Load-Data.sql -o 08-04-Load-Log.txt
                 Row counts per table (input / inserted / updated / rejected) are in #T2LoadLog and
                 in the result set at the end of this file.
 Test result   : see 08-07 report and 08-06-Data-Quality-Report.xlsx (run of 2026-11-07, data v1.1).
 Run Order     : after the Team 2 tables are empty (fresh restore of FoodDistributionDB.bak, or
                 08-03-Data-Generation-Scripts\08-03-T2-00-Reset.sql in a TEST environment).
                 Team 1 scripts that reference Product / SKU / ProductPrice / Promotion run AFTER this.
 Prerequisites : SQLCMD mode (SSMS: Query > SQLCMD Mode, or sqlcmd -i).
                 Set ScriptDir to the folder that holds the 08-03-T2-*.sql files.
 Seed/Config   : DbName (target database), Scale 0.10 (test) or 1.00 (full); Seed 20261031 inside
                 every script (08-03-T2-Settings.txt).
 Date          : 2026-11-07
 Run policy    : every generator stops (THROW, nothing inserted) if its target tables are not empty;
                 each generator inserts in its own transaction; :on error exit stops the chain at the
                 first failure. Repeat run = Reset + this file with the same Scale -> same content (Q17).
 Order         : 01 Brand/Channel/Audience/BrandActivity -> 02 Market/Segment -> 03 Category/Package/
                 Product/SKU -> 04 Campaign (+bridges, budget, cost, result) -> 05 ProductPrice/Promotion
                 -> 06 Research/Survey/Result -> 07 Competitor/CompetitorProduct/MarketPrice
============================================================================= */
:setvar DbName "FoodDistributionDB"
:setvar Scale "0.10"
:setvar ScriptDir "C:\FoodDistributionDB\Stage8\08-03-Data-Generation-Scripts"
:on error exit

USE [$(DbName)];
GO
SET NOCOUNT ON;
PRINT CONCAT(N'Database = ', DB_NAME(), N' | Server = ', @@SERVERNAME);
EXEC sp_set_session_context N'T2_Scale', $(Scale);
DROP TABLE IF EXISTS #T2LoadLog;
CREATE TABLE #T2LoadLog (
    Log_ID        int IDENTITY(1,1) PRIMARY KEY,
    Script_Name   nvarchar(60)  NOT NULL,
    Table_Name    nvarchar(128) NOT NULL,
    Input_Rows    int           NOT NULL,
    Inserted_Rows int           NOT NULL,
    Updated_Rows  int           NOT NULL DEFAULT 0,
    Rejected_Rows AS (Input_Rows - Inserted_Rows),
    Logged_At     datetime2(0)  NOT NULL DEFAULT SYSDATETIME()   -- run time of the load (log only, not data)
);
PRINT CONCAT(N'Team 2 load started | Scale = ', CONVERT(nvarchar(10), SESSION_CONTEXT(N'T2_Scale')));
GO

:r $(ScriptDir)\08-03-T2-01-Brand-Channel-Audience.sql
GO
:r $(ScriptDir)\08-03-T2-02-Market.sql
GO
:r $(ScriptDir)\08-03-T2-03-Product-Catalog.sql
GO
:r $(ScriptDir)\08-03-T2-04-Campaign.sql
GO
:r $(ScriptDir)\08-03-T2-05-Promotion-Price.sql
GO
:r $(ScriptDir)\08-03-T2-06-Market-Research.sql
GO
:r $(ScriptDir)\08-03-T2-07-Competition-Market-Price.sql
GO

/* ---------------- Load log (Q18) ---------------- */
SET NOCOUNT ON;
-- every generator writes its rows to #T2LoadLog; the table counts below are read from the database
;WITH t AS (
    SELECT v.Ord, v.Script_Name, v.Table_Name, p.Row_Count
    FROM (VALUES
        ( 1, N'08-03-T2-01', N'core.Brand'),                     ( 2, N'08-03-T2-01', N'marketing.CampaignChannel'),
        ( 3, N'08-03-T2-01', N'marketing.CampaignAudience'),     ( 4, N'08-03-T2-01', N'marketing.BrandActivity'),
        ( 5, N'08-03-T2-02', N'marketing.Market'),               ( 6, N'08-03-T2-02', N'marketing.MarketSegment'),
        ( 7, N'08-03-T2-03', N'ref.ProductCategory'),            ( 8, N'08-03-T2-03', N'ref.Package'),
        ( 9, N'08-03-T2-03', N'core.Product'),                   (10, N'08-03-T2-03', N'core.SKU'),
        (11, N'08-03-T2-04', N'marketing.MarketingCampaign'),    (12, N'08-03-T2-04', N'marketing.MarketingCampaignChannel'),
        (13, N'08-03-T2-04', N'marketing.MarketingCampaignAudience'), (14, N'08-03-T2-04', N'marketing.CampaignBudget'),
        (15, N'08-03-T2-04', N'marketing.CampaignCost'),         (16, N'08-03-T2-04', N'marketing.CampaignResult'),
        (17, N'08-03-T2-05', N'marketing.ProductPrice'),         (18, N'08-03-T2-05', N'marketing.Promotion'),
        (19, N'08-03-T2-06', N'marketing.MarketResearch'),       (20, N'08-03-T2-06', N'marketing.MarketSurvey'),
        (21, N'08-03-T2-06', N'marketing.ResearchResult'),       (22, N'08-03-T2-07', N'marketing.Competitor'),
        (23, N'08-03-T2-07', N'marketing.CompetitorProduct'),    (24, N'08-03-T2-07', N'marketing.MarketPrice')) v(Ord, Script_Name, Table_Name)
    CROSS APPLY (SELECT SUM(ps.row_count) AS Row_Count FROM sys.dm_db_partition_stats ps
                 WHERE ps.object_id = OBJECT_ID(v.Table_Name) AND ps.index_id IN (0, 1)) p)
SELECT t.Ord, t.Script_Name, t.Table_Name, t.Row_Count AS Rows_In_Table,
       l.Input_Rows, l.Inserted_Rows, l.Updated_Rows, l.Rejected_Rows,
       CASE WHEN l.Inserted_Rows IS NULL THEN N'logged by script PRINT'
            WHEN l.Inserted_Rows = t.Row_Count AND l.Rejected_Rows = 0 THEN N'OK' ELSE N'CHECK' END AS Log_Status
FROM t LEFT JOIN #T2LoadLog l ON l.Table_Name = t.Table_Name
ORDER BY t.Ord;

PRINT CONCAT(N'Team 2 load finished | Scale = ', CONVERT(nvarchar(10), SESSION_CONTEXT(N'T2_Scale')),
             N' | next: 08-05-Data-Quality-Checks.sql in the same session (Q18 uses #T2LoadLog)');
GO
