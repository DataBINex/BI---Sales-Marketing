/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.4 / #192; written by SinaSepasi in 8.8 / #196
                 because no file was delivered for 8.4)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T2-06-Market-Research.sql
 Version       : 1.1 (PM review 2026-11-07: Shamsi years from the fixed 1 Farvardin mapping #ShY instead of
                 DATEADD(YEAR) from 2019-03-21; no USE statement; DataVersion MockData_v1.1)
 Purpose       : Generate market research projects, their surveys and their results.
 Data nature   : TEMPLATE-BASED. Result_Summary / Recommendation texts come from fixed templates with
                 random percentages ({A} {B} {C}); they are NOT computed from respondent data (the model
                 has no respondent table). Use them for narrative / demo only, not as survey statistics.
 Run Order     : 6 (after 02 Market)
 Prerequisites : marketing.Market and marketing.MarketSegment loaded (02).
                 The 3 target tables must be EMPTY (clean only with 08-03-T2-00-Reset.sql).
 Seed/Config   : Seed 20261031 | Scale from SESSION_CONTEXT 'T2_Scale' (default 0.10) | IRR
 Date          : 2026-11-04
 Tables        : marketing.MarketResearch, marketing.MarketSurvey, marketing.ResearchResult
 Rules         : - 5 research projects per Shamsi year (40 in total); the 10% run keeps the projects
                   with the smallest hash.
                 - Research_Type: Customer Survey, Competitor Analysis, Price Study, Product Test,
                   Segmentation, Brand Health; duration depends on the type (14..120 days).
                 - Research_Status at @AsOfDate: Completed (End_Date set), InProgress (End_Date NULL,
                   planned end after @AsOfDate), Cancelled (~6% of older projects, End_Date NULL).
                 - MKT-07 (Export, Inactive) is used only for projects that end before 2024-03-20.
                 - Surveys lie inside the research period and use a segment of the SAME market
                   (T2-S8-07) or no segment (whole market); inactive segments only before 2024-03-20.
                 - Sample_Size depends on the method; B2B markets (Foodservice, Wholesale,
                   Institutional) use smaller samples.
                 - Results only for Completed research (1..3 findings; the last one on End_Date).
                 - Research_Cost = 1398 base cost x cumulative inflation index (same rates as 05).
 Notes         : No schema change, no IDENTITY_INSERT; parents looked up by Market_Code / Segment_Code;
                 Research_Title ends with the business key [MR-yyyy-n] (T2-S8-08).
                 Responsible_Person holds a role / unit name, not a person name (shared contract 6).
                 Inflation index is computed with decimal only (no EXP/LOG float, guide section 4).
============================================================================= */
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #RInfl, #RIdx, #RType, #RTxt, #RPerson, #R, #S, #RR, #ShY;

DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10);
DECLARE @FromDate    date         = '2019-03-21';
DECLARE @ToDate      date         = '2027-03-20';
DECLARE @AsOfDate    date         = '2027-03-20';

DECLARE @Currency      char(3) = 'IRR';
DECLARE @NYears        int     = 8;
DECLARE @PerYear       int     = 5;
DECLARE @CancelPct     int     = 6;
DECLARE @ExportEnd     date    = '2024-03-20';   -- MKT-07 activity only before this date
DECLARE @Rows_R int = 0, @Rows_S int = 0, @Rows_RR int = 0;

IF EXISTS (SELECT 1 FROM marketing.MarketResearch) OR EXISTS (SELECT 1 FROM marketing.MarketSurvey) OR EXISTS (SELECT 1 FROM marketing.ResearchResult)
    THROW 50601, N'STOP: research tables already have rows. Clean only with 08-03-T2-00-Reset.sql.', 1;
IF (SELECT COUNT(*) FROM marketing.Market WHERE Market_Code LIKE N'MKT-0[1-8]') < 8
    THROW 50602, N'STOP: marketing.Market (MKT-01..08) is missing. Run 08-03-T2-02 first.', 1;

BEGIN TRY
------------------------------------------------------------------------------
-- 1. Reference lists
------------------------------------------------------------------------------
CREATE TABLE #RInfl (Yr int PRIMARY KEY, Rate decimal(6,4) NOT NULL);
INSERT #RInfl VALUES (2019,0.3500),(2020,0.3600),(2021,0.4200),(2022,0.4500),(2023,0.4200),
                     (2024,0.3200),(2025,0.3800),(2026,0.3500),(2027,0.3500);
CREATE TABLE #RIdx (Month_Start date PRIMARY KEY, Idx decimal(18,6) NOT NULL);
;WITH m AS (   -- decimal only (no EXP/LOG float): Idx(next month) = Idx(month) x (1 + annual rate / 12)
    SELECT DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1) AS Month_Start, CAST(1 AS decimal(18,6)) AS Idx
    UNION ALL
    SELECT DATEADD(MONTH, 1, m.Month_Start), CAST(m.Idx * (1 + i.Rate / 12) AS decimal(18,6))
    FROM m JOIN #RInfl i ON i.Yr = YEAR(m.Month_Start)
    WHERE DATEADD(MONTH, 1, m.Month_Start) <= DATEFROMPARTS(YEAR(@ToDate), MONTH(@ToDate), 1))
INSERT #RIdx (Month_Start, Idx)
SELECT Month_Start, Idx FROM m OPTION (MAXRECURSION 200);

-- Shamsi years 1398..1405: Gregorian date of 1 Farvardin (checked with .NET PersianCalendar;
-- same list in 04, 05, 08-05 and 08-03-T2-Settings.txt). K = 8 (1406) only closes 1405.
CREATE TABLE #ShY (K int PRIMARY KEY, Shamsi_Year int NOT NULL, YS date NOT NULL, YE date NOT NULL);
INSERT #ShY (K, Shamsi_Year, YS, YE)
SELECT x.K, 1398 + x.K, x.YS, x.YE
FROM (SELECT v.K, CAST(v.YS AS date) AS YS, DATEADD(DAY, -1, CAST(LEAD(v.YS) OVER (ORDER BY v.K) AS date)) AS YE
      FROM (VALUES (0,'2019-03-21'),(1,'2020-03-20'),(2,'2021-03-21'),(3,'2022-03-21'),(4,'2023-03-21'),
                   (5,'2024-03-20'),(6,'2025-03-21'),(7,'2026-03-21'),(8,'2027-03-21')) v(K, YS)) x
WHERE x.K < 8;
IF (SELECT MIN(YS) FROM #ShY) <> @FromDate OR (SELECT MAX(YE) FROM #ShY) <> @ToDate
    THROW 50609, N'Internal error: Shamsi year mapping does not match @FromDate / @ToDate.', 1;

-- research types: duration (days), base cost (million IRR at 1398), number of surveys
CREATE TABLE #RType (T int PRIMARY KEY, Research_Type nvarchar(30) NOT NULL, Title_FA nvarchar(80) NOT NULL,
                     Dur_Min int NOT NULL, Dur_Rng int NOT NULL, Cost_Min int NOT NULL, Cost_Rng int NOT NULL,
                     Sv_Min int NOT NULL, Sv_Rng int NOT NULL);
INSERT #RType VALUES
 (1, N'Customer Survey',     N'پیمایش رضایت و نیاز مشتریان', 30, 46, 300, 600, 2, 3),
 (2, N'Competitor Analysis', N'تحلیل رقبا',                   20, 41, 150, 350, 0, 2),
 (3, N'Price Study',         N'مطالعه قیمت و حساسیت قیمتی',   14, 32, 100, 200, 1, 2),
 (4, N'Product Test',        N'آزمون محصول',                  30, 61, 400, 800, 1, 3),
 (5, N'Segmentation',        N'بخش‌بندی بازار',               45, 76, 500,1000, 2, 3),
 (6, N'Brand Health',        N'سنجش سلامت برند',              30, 31, 300, 500, 2, 2);

-- result templates: {M} market name, {A} 55..85, {B} 15..45, {C} 5..20
CREATE TABLE #RTxt (T int NOT NULL, N int NOT NULL, Result_Title nvarchar(200) NOT NULL, Result_Summary nvarchar(2000) NOT NULL,
                    Recommendation nvarchar(2000) NULL, Opportunity nvarchar(500) NULL, PRIMARY KEY (T, N));
INSERT #RTxt VALUES
 (1,1,N'رضایت کلی مشتریان {M}', N'میانگین رضایت مشتریان {M} از کیفیت و دسترسی محصولات {A} درصد برآورد شد؛ مهم‌ترین دلیل نارضایتی تأخیر در تأمین کالا بود.', N'برنامه تأمین و پخش این بازار بازبینی و زمان تحویل کوتاه‌تر شود.', N'جذب مشتریان ناراضی رقبا با تضمین زمان تحویل'),
 (1,2,N'نیازهای برآورده‌نشده', N'{B} درصد پاسخ‌دهندگان در {M} بسته‌بندی کوچک‌تر و اقتصادی‌تر را ترجیح دادند.', N'تعریف SKU با بسته‌بندی کوچک‌تر برای این بازار بررسی شود.', N'بسته‌بندی اقتصادی برای خانوارهای کم‌جمعیت'),
 (1,3,N'کانال خرید ترجیحی', N'{A} درصد خرید پاسخ‌دهندگان {M} از فروشگاه حضوری و بقیه از کانال آنلاین انجام می‌شود؛ سهم آنلاین {C} واحد درصد نسبت به سال قبل بیشتر شده است.', N'بودجه کانال آنلاین در کمپین‌های بعدی افزایش یابد.', NULL),
 (2,1,N'جایگاه رقابتی در {M}', N'سه رقیب اصلی {A} درصد قفسه فروشگاه‌های نمونه {M} را در اختیار دارند و سهم ما حدود {B} درصد است.', N'حضور در قفسه با قرارداد نمایش ویژه در فروشگاه‌های کلیدی تقویت شود.', N'فروشگاه‌هایی که رقیب در آن‌ها حضور ضعیف دارد'),
 (2,2,N'تحرکات قیمتی رقبا', N'رقبا در دوره تحقیق به‌طور میانگین {C} درصد تخفیف دوره‌ای ارائه کردند و فاصله قیمتی آن‌ها با ما کمتر شد.', N'تقویم تخفیف با تقویم رقبا هماهنگ و از تخفیف عمومی پرهیز شود.', NULL),
 (2,3,N'محصولات جدید رقبا', N'در {M} چند محصول جدید رقبا در گروه‌های پرفروش عرضه شد که {B} درصد فروشگاه‌های نمونه آن‌ها را موجود داشتند.', N'زمان معرفی محصولات مشابه در برنامه توسعه محصول جلو آورده شود.', N'گروه‌هایی که رقیب هنوز محصول ندارد'),
 (3,1,N'حساسیت قیمتی مشتریان {M}', N'با افزایش {C} درصدی قیمت، {B} درصد پاسخ‌دهندگان به برند ارزان‌تر روی می‌آورند.', N'افزایش قیمت در این بازار مرحله‌ای و همراه با پیشنهاد ارزش انجام شود.', NULL),
 (3,2,N'شکاف قیمت با رقبا', N'قیمت قفسه محصولات ما در {M} به‌طور میانگین {C} درصد با میانگین رقبا فاصله دارد.', N'قیمت فهرست با شاخص قیمت رقبا هر فصل بازبینی شود.', N'بازتعریف قیمت در گروه‌هایی که فاصله زیاد است'),
 (3,3,N'آستانه پذیرش قیمت', N'{A} درصد مشتریان {M} قیمت فعلی را منصفانه دانستند.', NULL, NULL),
 (4,1,N'پذیرش محصول آزمایشی', N'{A} درصد شرکت‌کنندگان آزمون در {M} محصول را خوب یا خیلی خوب ارزیابی کردند.', N'محصول با اصلاح جزئی طعم به مرحله عرضه برود.', N'عرضه محصول جدید در بازار هدف'),
 (4,2,N'قصد خرید', N'{B} درصد شرکت‌کنندگان گفتند محصول را در خرید بعدی انتخاب می‌کنند.', N'معرفی محصول همراه با نمونه رایگان در فروشگاه انجام شود.', NULL),
 (4,3,N'بسته‌بندی و برچسب', N'بسته‌بندی از نظر {A} درصد شرکت‌کنندگان جذاب بود ولی اطلاعات تغذیه‌ای به‌اندازه کافی خوانا نبود.', N'برچسب تغذیه‌ای خواناتر و بزرگ‌تر طراحی شود.', NULL),
 (5,1,N'بخش‌های اصلی {M}', N'سه بخش اصلی مشتری در {M} شناسایی شد که بزرگ‌ترین آن‌ها {B} درصد حجم خرید را دارد.', N'برنامه بازاریابی جداگانه برای بخش بزرگ‌تر تعریف شود.', N'بخش رشدیابنده با وفاداری کم به برند'),
 (5,2,N'رفتار خرید بخش‌ها', N'بخش حساس به قیمت {A} درصد خرید خود را در دوره‌های تخفیف انجام می‌دهد.', N'تخفیف هدفمند فقط برای این بخش ارائه شود.', NULL),
 (5,3,N'ارزش بخش‌ها', N'بخش ممتاز با {C} درصد تعداد مشتریان، سهم بیشتری از سود دارد.', N'خدمات ویژه و محصولات ممتاز برای این بخش توسعه یابد.', N'محصولات ممتاز با حاشیه سود بالاتر'),
 (6,1,N'آگاهی از برند در {M}', N'آگاهی بدون کمک از برندهای شرکت در {M} {B} درصد و با کمک {A} درصد اندازه‌گیری شد.', N'تبلیغات یادآور در کانال‌های پربازدید ادامه یابد.', NULL),
 (6,2,N'تصویر ذهنی برند', N'ویژگی «کیفیت ثابت» با {A} درصد بیشترین ارتباط را با برند داشت.', N'پیام کمپین‌ها بر کیفیت ثابت متمرکز شود.', N'تمایز برند بر پایه کیفیت'),
 (6,3,N'وفاداری به برند', N'{B} درصد مشتریان در شش ماه گذشته فقط از برند ما خرید کرده‌اند.', N'برنامه وفاداری برای مشتریان تکراری تقویت شود.', NULL);

CREATE TABLE #RPerson (P int PRIMARY KEY, Person nvarchar(150) NOT NULL);
-- roles / units only, no person names (shared contract section 6)
INSERT #RPerson VALUES (0,N'مدیر واحد تحقیقات بازار'),(1,N'کارشناس ارشد تحقیقات بازار'),(2,N'کارشناس تحقیقات مشتری'),
                       (3,N'کارشناس تحلیل رقبا'),(4,N'کارشناس قیمت‌گذاری'),(5,N'کارشناس مدیریت محصول'),
                       (6,N'کارشناس راهبرد برند'),(7,N'کارشناس تحلیل داده بازاریابی');

------------------------------------------------------------------------------
-- 2. Research skeleton
------------------------------------------------------------------------------
CREATE TABLE #R (Code nvarchar(20) PRIMARY KEY, K int NOT NULL, J int NOT NULL, T int NOT NULL, Market_ID int NULL, Market_Code nvarchar(30) NULL,
                 Market_Name nvarchar(150) NULL, Market_Type nvarchar(50) NULL, YS date NOT NULL, YE date NOT NULL, Dur int NOT NULL,
                 Start_Date date NULL, Plan_End date NULL, End_Date date NULL, Status nvarchar(30) NULL, Title nvarchar(200) NULL,
                 Person nvarchar(150) NULL, Cost decimal(18,2) NULL, Market_Research_ID int NULL);

;WITH y AS (SELECT TOP (@NYears) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS K FROM sys.all_objects),
j AS (SELECT TOP (@PerYear) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS J FROM sys.all_objects),
s AS (SELECT y.K, j.J, CONCAT(N'MR-', 1398 + y.K, N'-', j.J) AS Code FROM y CROSS JOIN j),
r AS (SELECT s.*, ROW_NUMBER() OVER (ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', s.Code, N'|0|sel')))), s.Code) AS Sel_No,
             COUNT(*) OVER () AS N_All,
             1 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', s.Code, N'|0|type')))) % 6 AS T
      FROM s)
INSERT #R (Code, K, J, T, YS, YE, Dur)
SELECT r.Code, r.K, r.J, r.T, sy.YS, sy.YE,          -- v1.1: real Shamsi year (#ShY)
       t.Dur_Min + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|0|dur')))) % t.Dur_Rng
FROM r JOIN #RType t ON t.T = r.T
JOIN #ShY sy ON sy.K = r.K
WHERE r.Sel_No <= CASE WHEN @Scale >= 1 THEN r.N_All ELSE CEILING(r.N_All * @Scale) END;

-- start: slot J of the year spreads projects over the year (about every 73 days) + offset
UPDATE #R SET Start_Date = DATEADD(DAY, (J - 1) * 73 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', Code, N'|0|start')))) % 50, YS);
UPDATE #R SET Plan_End = DATEADD(DAY, Dur - 1, Start_Date);

-- market: weighted pick; MKT-07 only if the project ends before @ExportEnd
;WITH cand AS (
    SELECT r.Code, m.Market_ID, m.Market_Code, m.Market_Name, m.Market_Type,
           ROW_NUMBER() OVER (PARTITION BY r.Code ORDER BY
               (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|', m.Market_Code, N'|mkt')))) % 1000 + 1)
               * CASE m.Market_Code WHEN N'MKT-01' THEN 3 WHEN N'MKT-02' THEN 4 WHEN N'MKT-03' THEN 3 WHEN N'MKT-07' THEN 1 ELSE 2 END DESC,
               m.Market_Code) AS Rn
    FROM #R r
    JOIN marketing.Market m ON m.Market_Code LIKE N'MKT-0[1-8]'
                           AND (m.Market_Status = N'Active' OR r.Plan_End < @ExportEnd))
UPDATE r SET Market_ID = c.Market_ID, Market_Code = c.Market_Code, Market_Name = c.Market_Name, Market_Type = c.Market_Type
FROM #R r JOIN cand c ON c.Code = r.Code AND c.Rn = 1;

-- status, title, person, cost
UPDATE r SET
    Status = CASE WHEN h.HC % 100 < @CancelPct AND r.Plan_End < DATEADD(YEAR, -1, @AsOfDate) THEN N'Cancelled'
                  WHEN r.Plan_End >= @AsOfDate THEN N'InProgress'
                  ELSE N'Completed' END,
    Title  = CONCAT(t.Title_FA, N' - ', r.Market_Name, N' ', 1398 + r.K, N' [', r.Code, N']'),
    Person = p.Person,
    Cost   = CAST(ROUND((t.Cost_Min + h.HB % t.Cost_Rng) * 1000000.0 * ix.Idx, -6) AS decimal(18,2))
FROM #R r
JOIN #RType t ON t.T = r.T
JOIN #RIdx ix ON ix.Month_Start = DATEFROMPARTS(YEAR(r.Start_Date), MONTH(r.Start_Date), 1)
CROSS APPLY (SELECT CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|0|cancel')))) AS HC,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|0|cost')))) AS HB,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|0|person')))) % 8 AS HP) h
JOIN #RPerson p ON p.P = h.HP;

UPDATE #R SET End_Date = CASE WHEN Status = N'Completed' THEN Plan_End END,
              Cost = CASE WHEN Status = N'Cancelled' THEN ROUND(Cost * 0.3, -6) ELSE Cost END;   -- cancelled: spent part only

------------------------------------------------------------------------------
-- 3. Surveys
------------------------------------------------------------------------------
CREATE TABLE #S (Code nvarchar(20) NOT NULL, N int NOT NULL, Market_Segment_ID int NULL, Segment_Name nvarchar(150) NULL,
                 Survey_Date date NOT NULL, Survey_Method nvarchar(30) NOT NULL, Sample_Size int NOT NULL,
                 Survey_Status nvarchar(30) NOT NULL, Survey_Title nvarchar(200) NULL, PRIMARY KEY (Code, N));
;WITH n AS (SELECT TOP (5) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS N FROM sys.all_objects),
base AS (
    SELECT r.Code, r.T, r.Market_ID, r.Market_Code, r.Market_Name, r.Market_Type, r.Start_Date, r.Status, n.N,
           t.Sv_Min + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|0|nsv')))) % t.Sv_Rng AS N_Sv,
           -- surveys run in the first 80% of the period; cancelled projects stop after 30%; in-progress ones before @AsOfDate
           CASE WHEN r.Status = N'Cancelled' THEN DATEDIFF(DAY, r.Start_Date, r.Plan_End) * 3 / 10
                WHEN r.Status = N'InProgress' THEN CASE WHEN DATEDIFF(DAY, r.Start_Date, @AsOfDate) < DATEDIFF(DAY, r.Start_Date, r.Plan_End) * 8 / 10
                                                        THEN DATEDIFF(DAY, r.Start_Date, @AsOfDate) ELSE DATEDIFF(DAY, r.Start_Date, r.Plan_End) * 8 / 10 END
                ELSE DATEDIFF(DAY, r.Start_Date, r.Plan_End) * 8 / 10 END AS Span
    FROM #R r JOIN #RType t ON t.T = r.T CROSS JOIN n),
sv AS (
    SELECT b.*,
           DATEADD(DAY, (b.N - 1) * (b.Span + 1) / NULLIF(b.N_Sv, 0) + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', b.Code, N'|', b.N, N'|sdate')))) % (CASE WHEN (b.Span + 1) / NULLIF(b.N_Sv, 0) > 0 THEN (b.Span + 1) / NULLIF(b.N_Sv, 0) ELSE 1 END), b.Start_Date) AS Survey_Date,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', b.Code, N'|', b.N, N'|method')))) % 100 AS HM,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', b.Code, N'|', b.N, N'|size')))) AS HS
    FROM base b WHERE b.N <= b.N_Sv),
mt AS (
    SELECT sv.*,
           CASE WHEN sv.Market_Type = N'Online' THEN CASE WHEN sv.HM < 70 THEN N'Online' ELSE N'Phone' END
                WHEN sv.T = 3 THEN CASE WHEN sv.HM < 60 THEN N'Store Intercept' ELSE N'Phone' END
                WHEN sv.T = 4 THEN CASE WHEN sv.HM < 55 THEN N'Focus Group' ELSE N'Face-to-Face' END
                WHEN sv.Market_Type IN (N'Foodservice', N'Wholesale', N'Institutional', N'Export') THEN CASE WHEN sv.HM < 60 THEN N'Phone' ELSE N'Face-to-Face' END
                ELSE CASE WHEN sv.HM < 35 THEN N'Online' WHEN sv.HM < 60 THEN N'Phone' WHEN sv.HM < 85 THEN N'Face-to-Face' ELSE N'Store Intercept' END END AS Method
    FROM sv)
INSERT #S (Code, N, Survey_Date, Survey_Method, Sample_Size, Survey_Status)
SELECT mt.Code, mt.N, mt.Survey_Date, mt.Method,
       CASE WHEN mt.Method = N'Focus Group' THEN 6 + mt.HS % 35
            ELSE CEILING(CASE mt.Method WHEN N'Online' THEN 300 + mt.HS % 1201 WHEN N'Phone' THEN 200 + mt.HS % 601
                                        WHEN N'Face-to-Face' THEN 150 + mt.HS % 451 ELSE 100 + mt.HS % 301 END
                         * CASE WHEN mt.Market_Type IN (N'Foodservice', N'Wholesale', N'Institutional', N'Export') THEN 0.15 ELSE 1.0 END) END,
       CASE WHEN mt.Status = N'Cancelled' THEN N'Cancelled'
            WHEN mt.Status = N'InProgress' AND mt.Survey_Date > DATEADD(DAY, -10, @AsOfDate) THEN N'InProgress'
            ELSE N'Completed' END
FROM mt;

-- segment of the same market (T2-S8-07); ~20% of surveys cover the whole market (NULL)
;WITH cand AS (
    SELECT s.Code, s.N, sg.Market_Segment_ID, sg.Segment_Name,
           ROW_NUMBER() OVER (PARTITION BY s.Code, s.N ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
               CONCAT(@Seed, N'|MR|', s.Code, N'|', s.N, N'|', sg.Segment_Code, N'|seg')))), sg.Segment_Code) AS Rn
    FROM #S s
    JOIN #R r ON r.Code = s.Code
    JOIN marketing.MarketSegment sg ON sg.Market_ID = r.Market_ID AND (sg.Segment_Status = N'Active' OR s.Survey_Date < @ExportEnd)
    WHERE CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', s.Code, N'|', s.N, N'|nullseg')))) % 100 >= 20)
UPDATE s SET Market_Segment_ID = c.Market_Segment_ID, Segment_Name = c.Segment_Name
FROM #S s JOIN cand c ON c.Code = s.Code AND c.N = s.N AND c.Rn = 1;

UPDATE s SET Survey_Title = CONCAT(CASE s.Survey_Method WHEN N'Online' THEN N'پرسشنامه آنلاین' WHEN N'Phone' THEN N'مصاحبه تلفنی'
                                        WHEN N'Face-to-Face' THEN N'مصاحبه حضوری' WHEN N'Focus Group' THEN N'گروه کانونی' ELSE N'رهگیری در فروشگاه' END,
                                   N' - ', ISNULL(s.Segment_Name, r.Market_Name), N' [', s.Code, N'-S', s.N, N']')
FROM #S s JOIN #R r ON r.Code = s.Code;

------------------------------------------------------------------------------
-- 4. Results (completed research only)
------------------------------------------------------------------------------
CREATE TABLE #RR (Code nvarchar(20) NOT NULL, N int NOT NULL, Result_Title nvarchar(200) NOT NULL, Result_Summary nvarchar(2000) NOT NULL,
                  Result_Date date NOT NULL, Recommendation nvarchar(2000) NULL, Opportunity nvarchar(500) NULL, PRIMARY KEY (Code, N));
;WITH n AS (SELECT TOP (3) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS N FROM sys.all_objects),
b AS (
    SELECT r.Code, r.T, r.Market_Name, r.Start_Date, r.End_Date, n.N,
           1 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|0|nres')))) % 3 AS N_Res,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|0|tpl')))) % 3 AS Tpl0,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MR|', r.Code, N'|', n.N, N'|num')))) AS HN
    FROM #R r CROSS JOIN n
    WHERE r.Status = N'Completed')
INSERT #RR (Code, N, Result_Title, Result_Summary, Result_Date, Recommendation, Opportunity)
SELECT b.Code, b.N,
       REPLACE(x.Result_Title, N'{M}', b.Market_Name),
       REPLACE(REPLACE(REPLACE(REPLACE(x.Result_Summary, N'{M}', b.Market_Name),
               N'{A}', CONVERT(nvarchar(10), 55 + b.HN % 31)), N'{B}', CONVERT(nvarchar(10), 15 + (b.HN / 100) % 31)), N'{C}', CONVERT(nvarchar(10), 5 + (b.HN / 10000) % 16)),
       CASE WHEN b.N = b.N_Res THEN b.End_Date
            ELSE DATEADD(DAY, DATEDIFF(DAY, b.Start_Date, b.End_Date) * b.N / b.N_Res, b.Start_Date) END,
       x.Recommendation, x.Opportunity
FROM b JOIN #RTxt x ON x.T = b.T AND x.N = (b.Tpl0 + b.N - 1) % 3 + 1
WHERE b.N <= b.N_Res;

------------------------------------------------------------------------------
-- 5. Load
------------------------------------------------------------------------------
BEGIN TRANSACTION;

INSERT marketing.MarketResearch (Market_ID, Research_Title, Research_Type, Start_Date, End_Date, Research_Status, Responsible_Person, Research_Cost, Currency)
SELECT r.Market_ID, r.Title, t.Research_Type, r.Start_Date, r.End_Date, r.Status, r.Person, r.Cost, @Currency
FROM #R r JOIN #RType t ON t.T = r.T
ORDER BY r.Start_Date, r.Code;
SET @Rows_R = @@ROWCOUNT;

UPDATE r SET Market_Research_ID = mr.Market_Research_ID
FROM #R r JOIN marketing.MarketResearch mr ON mr.Research_Title = r.Title;
IF EXISTS (SELECT 1 FROM #R WHERE Market_Research_ID IS NULL)
    THROW 50610, N'Internal error: research key lookup failed.', 1;

INSERT marketing.MarketSurvey (Market_Research_ID, Market_Segment_ID, Survey_Title, Survey_Date, Survey_Method, Sample_Size, Survey_Status)
SELECT r.Market_Research_ID, s.Market_Segment_ID, s.Survey_Title, s.Survey_Date, s.Survey_Method, s.Sample_Size, s.Survey_Status
FROM #S s JOIN #R r ON r.Code = s.Code
ORDER BY s.Survey_Date, s.Code, s.N;
SET @Rows_S = @@ROWCOUNT;

INSERT marketing.ResearchResult (Market_Research_ID, Result_Title, Result_Summary, Result_Date, Recommendation, Opportunity_Identified)
SELECT r.Market_Research_ID, x.Result_Title, x.Result_Summary, x.Result_Date, x.Recommendation, x.Opportunity
FROM #RR x JOIN #R r ON r.Code = x.Code
ORDER BY x.Result_Date, x.Code, x.N;
SET @Rows_RR = @@ROWCOUNT;

COMMIT TRANSACTION;

IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
    INSERT #T2LoadLog (Script_Name, Table_Name, Input_Rows, Inserted_Rows)
    VALUES (N'08-03-T2-06', N'marketing.MarketResearch', @Rows_R, @Rows_R),
           (N'08-03-T2-06', N'marketing.MarketSurvey', @Rows_S, @Rows_S),
           (N'08-03-T2-06', N'marketing.ResearchResult', @Rows_RR, @Rows_RR);

PRINT CONCAT(N'08-03-T2-06-Market-Research | ', @DataVersion, N' | Seed=', @Seed, N' | Scale=', @Scale);
PRINT CONCAT(N'marketing.MarketResearch : ', @Rows_R);
PRINT CONCAT(N'marketing.MarketSurvey   : ', @Rows_S);
PRINT CONCAT(N'marketing.ResearchResult : ', @Rows_RR);

SELECT mr.Market_Research_ID, m.Market_Code, mr.Research_Type, mr.Start_Date, mr.End_Date, mr.Research_Status, mr.Research_Cost,
       (SELECT COUNT(*) FROM marketing.MarketSurvey s WHERE s.Market_Research_ID = mr.Market_Research_ID) AS Surveys,
       (SELECT COUNT(*) FROM marketing.ResearchResult x WHERE x.Market_Research_ID = mr.Market_Research_ID) AS Results
FROM marketing.MarketResearch mr JOIN marketing.Market m ON m.Market_ID = mr.Market_ID
ORDER BY mr.Start_Date;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    PRINT CONCAT(N'08-03-T2-06-Market-Research FAILED (rolled back). Error ', ERROR_NUMBER(), N' line ', ERROR_LINE(), N': ', ERROR_MESSAGE());
    THROW;
END CATCH;
GO
