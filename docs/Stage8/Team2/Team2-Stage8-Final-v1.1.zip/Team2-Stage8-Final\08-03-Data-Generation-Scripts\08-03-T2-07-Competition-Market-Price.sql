/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.5 / #193; written by SinaSepasi in 8.8 / #196
                 because no file was delivered for 8.5)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T2-07-Competition-Market-Price.sql
 Version       : 1.1 (PM review 2026-11-07: independent competitor prices, see "Changes in 1.1")
 Purpose       : Generate competitors, competitor products and monthly market price observations
                 for our products and competitor products.
 Data nature   : SYNTHETIC BENCHMARK. Competitor prices are built from the category cost (the 1398
                 base Standard_Cost of our SKUs in that leaf = market input cost), each competitor's own
                 price index, markup tier and repricing cycle - NOT from our list prices. Our own
                 observations are a PRICE MONITORING SAMPLE (first product of every leaf + ~20% of the
                 other active products), not all products; price KPIs describe this sample.
 Run Order     : 7 (last Team 2 script; after 02 Market, 03 Product-Catalog, 05 Promotion-Price)
 Prerequisites : marketing.Market (02); ref.ProductCategory, core.Product, core.SKU (03);
                 marketing.ProductPrice (05). The 3 target tables must be EMPTY.
 Seed/Config   : Seed 20261031 | Scale from SESSION_CONTEXT 'T2_Scale' (default 0.10) | IRR
 Date          : 2026-11-04
 Tables        : marketing.Competitor, marketing.CompetitorProduct, marketing.MarketPrice
 Rules         : - 15 fictional competitors (13 Active, 2 Inactive with an exit date); not scaled.
                 - CompetitorProduct.Category = ref.ProductCategory.Category_Name of a LEAF category in
                   which we sell (ISS-T2-KPI-10); full run 2..5 per leaf, 10% run 1..2 per leaf.
                 - Every leaf category is watched in 3 markets (active markets only); each observed
                   item is priced once a month (day 4..19, 10:00) in 2..3 of them.
                 - Our observed products: the first product of every leaf + ~20% of the others
                   (Active products only), from the month after launch.
                 - Our shelf price = list price of the base SKU (marketing.ProductPrice, Standard, valid
                   on that day) x market factor x noise 0.97..1.03.
                 - Competitor shelf price (v1.1) = leaf base cost x competitor index at its last repricing
                   month x markup of its price tier x position drift x product variant factor x market
                   factor (x0.95 in the competitor's home market) x noise 0.97..1.03.
                   Tiers (price level on the leaf base cost): Discount 1.01..1.07, Mid 1.17..1.26, Premium 1.46..1.58.
                   Competitor index: monthly synthetic inflation x pass-through 0.90..1.20 (our list prices
                   follow the same synthetic inflation, so the gap comes from markup, pass-through, cycle and drift).
                   Repricing every 3..6 months (own cycle), so the gap to our price moves over time.
                   Position drift -10%..+12% over the 8 years (e.g. a premium dairy competitor that
                   becomes cheaper, a mid competitor that moves up).
                   Inactive competitors stop at their exit date.
                 - Exactly one of Product_ID / Competitor_Product_ID is filled (CHECK).
 Notes         : No schema change, no IDENTITY_INSERT; parents looked up by Market_Code / Category_Code /
                 Product_Code. Competitor names are fictional (no real company is meant).
                 Inflation index is computed with decimal only (no EXP/LOG float, guide section 4).
 Changes in 1.1: 1. Competitor prices no longer derived from our list prices (1.0: average list price of
                    our base SKUs x 0.88..1.12, which pulled the price index to ~99%); see rule above.
                 2. Competitor product variant factor follows its name (ممتاز 1.12, اقتصادی 0.85,
                    خانواده 0.95, ویژه 1.03, طلایی 1.10, x0.95..1.05).
                 3. Coverage of the monitoring sample is printed at the end and tested in 08-05 (Q15).
                 4. No USE statement (database chosen in 08-04); DataVersion MockData_v1.1.
============================================================================= */
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #KInfl, #KIdx, #Comp, #CompFocus, #MktF, #Leaf, #Watch, #CP, #Own, #Mon, #MP, #CIdxK;

DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10);
DECLARE @FromDate    date         = '2019-03-21';
DECLARE @ToDate      date         = '2027-03-20';
DECLARE @AsOfDate    date         = '2027-03-20';
DECLARE @Currency    char(3)      = 'IRR';
DECLARE @PriceType   nvarchar(30) = N'Standard';
DECLARE @Rows_K int = 0, @Rows_KP int = 0, @Rows_MP int = 0;

IF EXISTS (SELECT 1 FROM marketing.Competitor) OR EXISTS (SELECT 1 FROM marketing.CompetitorProduct) OR EXISTS (SELECT 1 FROM marketing.MarketPrice)
    THROW 50701, N'STOP: competitor / market price tables already have rows. Clean only with 08-03-T2-00-Reset.sql.', 1;
IF NOT EXISTS (SELECT 1 FROM core.Product) OR NOT EXISTS (SELECT 1 FROM marketing.ProductPrice)
    THROW 50702, N'STOP: core.Product or marketing.ProductPrice is empty. Run 08-03-T2-03 and 08-03-T2-05 first.', 1;
IF (SELECT COUNT(*) FROM marketing.Market WHERE Market_Code LIKE N'MKT-0[1-8]') < 8
    THROW 50703, N'STOP: marketing.Market (MKT-01..08) is missing. Run 08-03-T2-02 first.', 1;

BEGIN TRY
------------------------------------------------------------------------------
-- 1. Reference lists
------------------------------------------------------------------------------
CREATE TABLE #KInfl (Yr int PRIMARY KEY, Rate decimal(6,4) NOT NULL);
INSERT #KInfl VALUES (2019,0.3500),(2020,0.3600),(2021,0.4200),(2022,0.4500),(2023,0.4200),
                     (2024,0.3200),(2025,0.3800),(2026,0.3500),(2027,0.3500);
CREATE TABLE #KIdx (Month_Start date PRIMARY KEY, Idx decimal(18,6) NOT NULL);
;WITH m AS (   -- decimal only (no EXP/LOG float): Idx(next month) = Idx(month) x (1 + annual rate / 12)
    SELECT DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1) AS Month_Start, CAST(1 AS decimal(18,6)) AS Idx
    UNION ALL
    SELECT DATEADD(MONTH, 1, m.Month_Start), CAST(m.Idx * (1 + i.Rate / 12) AS decimal(18,6))
    FROM m JOIN #KInfl i ON i.Yr = YEAR(m.Month_Start)
    WHERE DATEADD(MONTH, 1, m.Month_Start) <= DATEFROMPARTS(YEAR(@ToDate), MONTH(@ToDate), 1))
INSERT #KIdx (Month_Start, Idx)
SELECT Month_Start, Idx FROM m OPTION (MAXRECURSION 200);

-- competitors (fictional)
-- v1.1 pricing profile per competitor (generator settings, not stored in the database):
--   Tier / Markup on the leaf base cost / Pass-through of inflation / repricing Cycle (months) / Drift over 8 years
CREATE TABLE #Comp (C int PRIMARY KEY, Short_Name nvarchar(60) NOT NULL, Competitor_Name nvarchar(150) NOT NULL, Competitor_Type nvarchar(30) NOT NULL,
                    Market_Code nvarchar(30) NULL, Competitor_Status nvarchar(30) NOT NULL, Exit_Date date NULL, Competitor_ID int NULL,
                    Tier nvarchar(10) NULL, Markup decimal(5,3) NULL, PT decimal(5,3) NULL, Cycle int NULL, Drift decimal(5,3) NULL);
INSERT #Comp (C, Short_Name, Competitor_Name, Competitor_Type, Market_Code, Competitor_Status, Exit_Date, Tier, Markup, PT, Cycle, Drift) VALUES
 ( 1, N'زرین‌کشت',    N'صنایع غذایی زرین‌کشت آریا',      N'Direct',     N'MKT-01', N'Active',   NULL,         N'Premium', 1.460, 1.050, 4,  0.050),
 ( 2, N'سپیددانه',    N'شرکت سپیددانه پارس',            N'Direct',     N'MKT-05', N'Active',   NULL,         N'Discount',1.040, 0.950, 3, -0.040),
 ( 3, N'کوهسارنوش',   N'نوشیدنی‌سازی کوهسارنوش',        N'Direct',     N'MKT-02', N'Active',   NULL,         N'Mid',     1.210, 1.100, 5,  0.100),
 ( 4, N'شهدینه',      N'گروه تولیدی شهدینه',            N'Indirect',   N'MKT-03', N'Active',   NULL,         N'Discount',1.070, 0.900, 6,  0.000),
 ( 5, N'لبن‌ناز',     N'فرآورده‌های لبنی لبن‌ناز',       N'Direct',     N'MKT-02', N'Active',   NULL,         N'Premium', 1.500, 1.000, 4, -0.100),
 ( 6, N'دلچین',       N'صنایع غذایی دلچین',             N'Direct',     N'MKT-04', N'Active',   NULL,         N'Mid',     1.240, 1.000, 3, -0.060),
 ( 7, N'برکت‌پویان',  N'شرکت پروتئین برکت‌پویان',        N'Direct',     N'MKT-04', N'Active',   NULL,         N'Mid',     1.190, 1.150, 4,  0.040),
 ( 8, N'آرین‌سرد',    N'منجمدات آرین‌سرد',              N'Direct',     N'MKT-05', N'Active',   NULL,         N'Discount',1.030, 1.050, 5,  0.080),
 ( 9, N'خوشه‌طلا',    N'خشکبار خوشه‌طلا',               N'Direct',     N'MKT-01', N'Active',   NULL,         N'Premium', 1.530, 0.950, 6,  0.000),
 (10, N'نیک‌آوند',    N'گروه بازرگانی نیک‌آوند',         N'Indirect',   NULL,      N'Active',   NULL,         N'Discount',1.010, 1.000, 3, -0.020),
 (11, N'مهتاب‌پاک',   N'محصولات بهداشتی مهتاب‌پاک',      N'Direct',     N'MKT-02', N'Active',   NULL,         N'Mid',     1.260, 0.900, 4,  0.020),
 (12, N'سیمین‌شو',    N'شوینده‌سازی سیمین‌شو',           N'Direct',     N'MKT-01', N'Active',   NULL,         N'Discount',1.050, 1.100, 5, -0.050),
 (13, N'تازه‌پاک',    N'شرکت تازه‌پاک البرز',           N'Substitute', N'MKT-03', N'Active',   NULL,         N'Mid',     1.170, 1.200, 4,  0.120),
 (14, N'آوای‌مزرعه',  N'فرآورده‌های طبیعی آوای مزرعه',  N'Substitute', N'MKT-08', N'Inactive', '2025-09-22', N'Premium', 1.580, 1.000, 6, -0.080),
 (15, N'رهنورد',      N'پخش سراسری رهنورد',             N'Indirect',   N'MKT-07', N'Inactive', '2024-03-19', N'Discount',1.020, 0.950, 3,  0.000);

-- v1.1 competitor price index per month (decimal only): Idx(next) = Idx x (1 + rate/12 x pass-through)
CREATE TABLE #CIdxK (C int NOT NULL, Month_Start date NOT NULL, Idx decimal(18,6) NOT NULL, PRIMARY KEY (C, Month_Start));
;WITH m AS (
    SELECT k.C, k.PT, DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1) AS Month_Start, CAST(1 AS decimal(18,6)) AS Idx
    FROM #Comp k
    UNION ALL
    SELECT m.C, m.PT, DATEADD(MONTH, 1, m.Month_Start), CAST(m.Idx * (1 + i.Rate / 12 * m.PT) AS decimal(18,6))
    FROM m JOIN #KInfl i ON i.Yr = YEAR(m.Month_Start)
    WHERE DATEADD(MONTH, 1, m.Month_Start) <= DATEFROMPARTS(YEAR(@ToDate), MONTH(@ToDate), 1))
INSERT #CIdxK (C, Month_Start, Idx)
SELECT C, Month_Start, Idx FROM m OPTION (MAXRECURSION 200);

-- level-1 focus of each competitor (Category_Code of ref.ProductCategory)
CREATE TABLE #CompFocus (C int NOT NULL, Parent_Code nvarchar(30) NOT NULL, PRIMARY KEY (C, Parent_Code));
INSERT #CompFocus VALUES (1,N'CAT-001'),(1,N'CAT-009'),(2,N'CAT-001'),(3,N'CAT-002'),(4,N'CAT-002'),(4,N'CAT-005'),
                         (5,N'CAT-003'),(6,N'CAT-003'),(6,N'CAT-008'),(7,N'CAT-004'),(8,N'CAT-008'),(8,N'CAT-004'),
                         (9,N'CAT-005'),(10,N'CAT-005'),(10,N'CAT-001'),(11,N'CAT-006'),(12,N'CAT-007'),(13,N'CAT-007'),
                         (13,N'CAT-006'),(14,N'CAT-003'),(14,N'CAT-001'),(15,N'CAT-009'),(15,N'CAT-002');

-- market price factor (shelf price vs list price) and price source
CREATE TABLE #MktF (Market_ID int PRIMARY KEY, Market_Code nvarchar(30) NOT NULL, F decimal(5,3) NOT NULL);
INSERT #MktF (Market_ID, Market_Code, F)
SELECT m.Market_ID, m.Market_Code, v.F
FROM marketing.Market m
JOIN (VALUES (N'MKT-01',1.080),(N'MKT-02',1.030),(N'MKT-03',1.000),(N'MKT-04',0.970),
             (N'MKT-05',0.900),(N'MKT-06',0.930),(N'MKT-08',1.120)) v(Market_Code, F) ON v.Market_Code = m.Market_Code
WHERE m.Market_Status = N'Active';

-- leaf categories in which we sell
CREATE TABLE #Leaf (Product_Category_ID int PRIMARY KEY, Category_Code nvarchar(30) NOT NULL, Category_Name nvarchar(150) NOT NULL,
                    Parent_Code nvarchar(30) NOT NULL, Avg_Cost decimal(18,2) NOT NULL);
INSERT #Leaf
SELECT pc.Product_Category_ID, pc.Category_Code, pc.Category_Name, pp.Category_Code,
       AVG(bs.Standard_Cost)
FROM ref.ProductCategory pc
JOIN ref.ProductCategory pp ON pp.Product_Category_ID = pc.Parent_Category_ID
JOIN core.Product p ON p.Product_Category_ID = pc.Product_Category_ID
CROSS APPLY (SELECT TOP (1) s.Standard_Cost FROM core.SKU s WHERE s.Product_ID = p.Product_ID ORDER BY s.SKU_Code) bs
GROUP BY pc.Product_Category_ID, pc.Category_Code, pc.Category_Name, pp.Category_Code;

-- 3 watched markets per leaf
CREATE TABLE #Watch (Product_Category_ID int NOT NULL, Market_ID int NOT NULL, Wn int NOT NULL, PRIMARY KEY (Product_Category_ID, Market_ID));
INSERT #Watch
SELECT x.Product_Category_ID, x.Market_ID, x.Rn
FROM (SELECT l.Product_Category_ID, f.Market_ID,
             ROW_NUMBER() OVER (PARTITION BY l.Product_Category_ID ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                 CONCAT(@Seed, N'|MP|', l.Category_Code, N'|', f.Market_Code, N'|watch')))), f.Market_Code) AS Rn
      FROM #Leaf l CROSS JOIN #MktF f) x
WHERE x.Rn <= 3;

-- months 2019-04 .. 2027-03 (observation day 4..19 is always inside the range)
CREATE TABLE #Mon (Month_Start date PRIMARY KEY, Idx decimal(18,6) NOT NULL);
INSERT #Mon SELECT Month_Start, Idx FROM #KIdx WHERE Month_Start >= DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1));

------------------------------------------------------------------------------
-- 2. Competitor products
------------------------------------------------------------------------------
CREATE TABLE #CP (CPK nvarchar(40) PRIMARY KEY, C int NOT NULL, Product_Category_ID int NOT NULL, Name nvarchar(200) NOT NULL,
                  Category_Name nvarchar(150) NOT NULL, Factor decimal(5,3) NOT NULL, Competitor_Product_ID int NULL);
;WITH n AS (SELECT TOP (5) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS N FROM sys.all_objects),
cnt AS (
    SELECT l.*, CASE WHEN @Scale >= 1
                     THEN 2 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', l.Category_Code, N'|0|ncp')))) % 4
                     ELSE 1 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', l.Category_Code, N'|0|ncp')))) % 2 END AS N_CP
    FROM #Leaf l),
cc AS (
    SELECT l.Product_Category_ID, f.C,
           ROW_NUMBER() OVER (PARTITION BY l.Product_Category_ID ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
               CONCAT(@Seed, N'|MP|', l.Category_Code, N'|', f.C, N'|cc')))), f.C) - 1 AS Ci,
           COUNT(*) OVER (PARTITION BY l.Product_Category_ID) AS N_C
    FROM #Leaf l JOIN #CompFocus f ON f.Parent_Code = l.Parent_Code)
INSERT #CP (CPK, C, Product_Category_ID, Name, Category_Name, Factor)
SELECT CONCAT(cnt.Category_Code, N'-', n.N), cc.C, cnt.Product_Category_ID,
       CONCAT(cnt.Category_Name, N' ', CHOOSE(n.N, N'ممتاز', N'اقتصادی', N'خانواده', N'ویژه', N'طلایی'), N' ', k.Short_Name),
       cnt.Category_Name,
       -- v1.1 variant factor follows the product name x 0.95..1.05
       CHOOSE(n.N, 1.12, 0.85, 0.95, 1.03, 1.10)
       * (0.95 + (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', cnt.Category_Code, N'|', n.N, N'|cf')))) % 11) / 100.0)
FROM cnt
JOIN n ON n.N <= cnt.N_CP
JOIN cc ON cc.Product_Category_ID = cnt.Product_Category_ID AND cc.Ci = (n.N - 1) % cc.N_C
JOIN #Comp k ON k.C = cc.C;

------------------------------------------------------------------------------
-- 3. Our observed products (base SKU = first SKU_Code of the product)
------------------------------------------------------------------------------
CREATE TABLE #Own (Product_ID int PRIMARY KEY, Product_Code nvarchar(30) NOT NULL, Product_Category_ID int NOT NULL, Base_SKU_ID int NOT NULL,
                   First_Month date NOT NULL, Last_Day date NOT NULL);
;WITH p AS (
    SELECT p.Product_ID, p.Product_Code, p.Product_Category_ID, p.Launch_Date, b.Brand_End_Date,
           (SELECT TOP (1) s.SKU_ID FROM core.SKU s WHERE s.Product_ID = p.Product_ID ORDER BY s.SKU_Code) AS Base_SKU_ID,
           ROW_NUMBER() OVER (PARTITION BY p.Product_Category_ID ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
               CONCAT(@Seed, N'|MP|', p.Product_Code, N'|0|own')))), p.Product_Code) AS Rn,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', p.Product_Code, N'|0|ownpct')))) % 100 AS HP
    FROM core.Product p JOIN core.Brand b ON b.Brand_ID = p.Brand_ID
    WHERE p.Product_Status = N'Active')
INSERT #Own (Product_ID, Product_Code, Product_Category_ID, Base_SKU_ID, First_Month, Last_Day)
SELECT Product_ID, Product_Code, Product_Category_ID, Base_SKU_ID,
       CASE WHEN Launch_Date < @FromDate THEN DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1))
            ELSE DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(Launch_Date), MONTH(Launch_Date), 1)) END,
       CASE WHEN Brand_End_Date IS NOT NULL AND Brand_End_Date < @ToDate THEN Brand_End_Date ELSE @ToDate END
FROM p
WHERE Base_SKU_ID IS NOT NULL AND (Rn = 1 OR HP < 20);

------------------------------------------------------------------------------
-- 4. Monthly observations
------------------------------------------------------------------------------
CREATE TABLE #MP (Product_ID int NULL, CPK nvarchar(40) NULL, Market_ID int NOT NULL, Price_Date datetime2(0) NOT NULL,
                  Price_Value decimal(18,2) NOT NULL, Price_Source nvarchar(100) NOT NULL);

-- 4.1 our products
;WITH obs AS (
    SELECT o.Product_ID, o.Product_Code, o.Base_SKU_ID, w.Market_ID, mf.Market_Code, mf.F, mo.Month_Start,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', o.Product_Code, N'|', mf.Market_Code, N'|', mo.Month_Start, N'|d')))) AS HD,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', o.Product_Code, N'|', mf.Market_Code, N'|', mo.Month_Start, N'|v')))) AS HV,
           2 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', o.Product_Code, N'|0|nmk')))) % 2 AS N_Mk,
           w.Wn
    FROM #Own o
    JOIN #Watch w ON w.Product_Category_ID = o.Product_Category_ID
    JOIN #MktF mf ON mf.Market_ID = w.Market_ID
    JOIN #Mon mo ON mo.Month_Start >= o.First_Month),
d AS (
    SELECT obs.*, DATEADD(HOUR, 10, CAST(DATEADD(DAY, 3 + obs.HD % 16, obs.Month_Start) AS datetime2(0))) AS PDate
    FROM obs WHERE obs.Wn <= obs.N_Mk)
INSERT #MP (Product_ID, CPK, Market_ID, Price_Date, Price_Value, Price_Source)
SELECT d.Product_ID, NULL, d.Market_ID, d.PDate,
       CASE WHEN v.Raw >= 10000 THEN ROUND(v.Raw, -2) ELSE ROUND(v.Raw, -1) END,
       CASE WHEN d.Market_Code = N'MKT-03' THEN N'Online Store' WHEN d.Market_Code = N'MKT-05' THEN N'Distributor Report'
            WHEN d.HD % 2 = 0 THEN N'Field Visit' ELSE N'Retail Audit' END
FROM d
JOIN marketing.ProductPrice pp ON pp.SKU_ID = d.Base_SKU_ID AND pp.Price_Type = @PriceType
                              AND pp.Effective_From <= CAST(d.PDate AS date) AND (pp.Effective_To IS NULL OR pp.Effective_To >= CAST(d.PDate AS date))
JOIN #Own o ON o.Product_ID = d.Product_ID
CROSS APPLY (SELECT pp.Unit_Price * d.F * (0.97 + (d.HV % 61) / 1000.0) AS Raw) v
WHERE CAST(d.PDate AS date) <= o.Last_Day;

-- 4.2 competitor products (v1.1): independent of our list prices
--     price = leaf base cost x competitor index at its last repricing month x tier markup x drift
--             x variant factor x market factor (x0.95 in its home market) x noise
;WITH ref AS (
    SELECT cp.CPK, mo.Month_Start,
           l.Avg_Cost * ci.Idx * k.Markup
           * (1 + k.Drift * DATEDIFF(MONTH, DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1), mo.Month_Start) / 96.0) AS Ref_Price
    FROM #CP cp
    JOIN #Comp k ON k.C = cp.C
    JOIN #Leaf l ON l.Product_Category_ID = cp.Product_Category_ID
    CROSS JOIN #Mon mo
    CROSS APPLY (SELECT DATEADD(MONTH, -((DATEDIFF(MONTH, DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1), mo.Month_Start)
                                          + k.C) % k.Cycle), mo.Month_Start) AS Rep_Month) rp      -- last repricing month
    JOIN #CIdxK ci ON ci.C = k.C
                  AND ci.Month_Start = CASE WHEN rp.Rep_Month < DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1)
                                            THEN DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1) ELSE rp.Rep_Month END),
obs AS (
    SELECT cp.CPK, cp.Factor, w.Market_ID, mf.Market_Code,
           mf.F * CASE WHEN mf.Market_Code = k.Market_Code THEN 0.95 ELSE 1.00 END AS F,
           r.Month_Start, r.Ref_Price, k.Exit_Date,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', cp.CPK, N'|', mf.Market_Code, N'|', r.Month_Start, N'|d')))) AS HD,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', cp.CPK, N'|', mf.Market_Code, N'|', r.Month_Start, N'|v')))) AS HV,
           2 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|MP|', cp.CPK, N'|0|nmk')))) % 2 AS N_Mk,
           ROW_NUMBER() OVER (PARTITION BY cp.CPK, r.Month_Start ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
               CONCAT(@Seed, N'|MP|', cp.CPK, N'|', mf.Market_Code, N'|cpm')))), mf.Market_Code) AS Wn
    FROM #CP cp
    JOIN #Comp k ON k.C = cp.C
    JOIN #Watch w ON w.Product_Category_ID = cp.Product_Category_ID
    JOIN #MktF mf ON mf.Market_ID = w.Market_ID
    JOIN ref r ON r.CPK = cp.CPK),
d AS (
    SELECT obs.*, DATEADD(HOUR, 10, CAST(DATEADD(DAY, 3 + obs.HD % 16, obs.Month_Start) AS datetime2(0))) AS PDate
    FROM obs WHERE obs.Wn <= obs.N_Mk)
INSERT #MP (Product_ID, CPK, Market_ID, Price_Date, Price_Value, Price_Source)
SELECT NULL, d.CPK, d.Market_ID, d.PDate,
       CASE WHEN v.Raw >= 10000 THEN ROUND(v.Raw, -2) ELSE ROUND(v.Raw, -1) END,
       CASE WHEN d.Market_Code = N'MKT-03' THEN N'Online Store' WHEN d.Market_Code = N'MKT-05' THEN N'Distributor Report'
            WHEN d.HD % 2 = 0 THEN N'Field Visit' ELSE N'Retail Audit' END
FROM d
CROSS APPLY (SELECT d.Ref_Price * d.Factor * d.F * (0.97 + (d.HV % 61) / 1000.0) AS Raw) v
WHERE d.Exit_Date IS NULL OR CAST(d.PDate AS date) <= d.Exit_Date;

------------------------------------------------------------------------------
-- 5. Load
------------------------------------------------------------------------------
BEGIN TRANSACTION;

INSERT marketing.Competitor (Competitor_Name, Competitor_Type, Market_ID, Competitor_Status)
SELECT k.Competitor_Name, k.Competitor_Type, m.Market_ID, k.Competitor_Status
FROM #Comp k LEFT JOIN marketing.Market m ON m.Market_Code = k.Market_Code
ORDER BY k.C;
SET @Rows_K = @@ROWCOUNT;
UPDATE k SET Competitor_ID = c.Competitor_ID FROM #Comp k JOIN marketing.Competitor c ON c.Competitor_Name = k.Competitor_Name;

INSERT marketing.CompetitorProduct (Competitor_ID, Competitor_Product_Name, Category)
SELECT k.Competitor_ID, cp.Name, cp.Category_Name
FROM #CP cp JOIN #Comp k ON k.C = cp.C
ORDER BY k.C, cp.CPK;
SET @Rows_KP = @@ROWCOUNT;
UPDATE cp SET Competitor_Product_ID = x.Competitor_Product_ID
FROM #CP cp JOIN #Comp k ON k.C = cp.C
JOIN marketing.CompetitorProduct x ON x.Competitor_ID = k.Competitor_ID AND x.Competitor_Product_Name = cp.Name;
IF EXISTS (SELECT 1 FROM #CP WHERE Competitor_Product_ID IS NULL) OR EXISTS (SELECT 1 FROM #Comp WHERE Competitor_ID IS NULL)
    THROW 50710, N'Internal error: competitor key lookup failed.', 1;

INSERT marketing.MarketPrice (Product_ID, Competitor_Product_ID, Market_ID, Price_Date, Price_Value, Currency, Price_Source)
SELECT mp.Product_ID, cp.Competitor_Product_ID, mp.Market_ID, mp.Price_Date, mp.Price_Value, @Currency, mp.Price_Source
FROM #MP mp LEFT JOIN #CP cp ON cp.CPK = mp.CPK
ORDER BY mp.Price_Date, mp.Market_ID, mp.Product_ID, cp.Competitor_Product_ID;
SET @Rows_MP = @@ROWCOUNT;

COMMIT TRANSACTION;

IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
    INSERT #T2LoadLog (Script_Name, Table_Name, Input_Rows, Inserted_Rows)
    VALUES (N'08-03-T2-07', N'marketing.Competitor', @Rows_K, @Rows_K),
           (N'08-03-T2-07', N'marketing.CompetitorProduct', @Rows_KP, @Rows_KP),
           (N'08-03-T2-07', N'marketing.MarketPrice', @Rows_MP, @Rows_MP);

PRINT CONCAT(N'08-03-T2-07-Competition-Market-Price | ', @DataVersion, N' | Seed=', @Seed, N' | Scale=', @Scale);
PRINT CONCAT(N'marketing.Competitor        : ', @Rows_K);
PRINT CONCAT(N'marketing.CompetitorProduct : ', @Rows_KP);
DECLARE @Rows_Own int = (SELECT COUNT(*) FROM #MP WHERE Product_ID IS NOT NULL);
PRINT CONCAT(N'marketing.MarketPrice       : ', @Rows_MP, N' (own products: ', @Rows_Own, N')');
-- v1.1: coverage of the price monitoring sample
DECLARE @Cov_Own int = (SELECT COUNT(*) FROM #Own),
        @Cov_Act int = (SELECT COUNT(*) FROM core.Product WHERE Product_Status = N'Active'),
        @Cov_Cat int = (SELECT COUNT(DISTINCT Product_Category_ID) FROM #Own),
        @Cov_Leaf int = (SELECT COUNT(*) FROM #Leaf),
        @Cov_Mkt int = (SELECT COUNT(DISTINCT Market_ID) FROM #MP);
PRINT CONCAT(N'Price monitoring sample     : ', @Cov_Own, N' of ', @Cov_Act, N' active products; ',
             @Cov_Cat, N' of ', @Cov_Leaf, N' leaf categories; ', @Cov_Mkt, N' markets');
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    PRINT CONCAT(N'08-03-T2-07-Competition-Market-Price FAILED (rolled back). Error ', ERROR_NUMBER(), N' line ', ERROR_LINE(), N': ', ERROR_MESSAGE());
    THROW;
END CATCH;
GO
