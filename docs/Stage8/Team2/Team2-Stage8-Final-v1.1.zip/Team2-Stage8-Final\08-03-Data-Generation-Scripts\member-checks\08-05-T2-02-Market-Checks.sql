/*=============================================================================
  Project      : Food Distribution BI (Sales & Marketing Dashboard)
  Stage        : 8 - Mock Data Design (Data Quality Checks)
  Team / Owner : Team 2 - Product & Marketing
  Database     : FoodDistributionDB  (SQL Server 2022)
  Script       : 08-05-T2-02-Market-Checks.sql
  Version      : 1.0   (MockData_v1.1_Seed20261031)
  Date         : 2026-11-01
  Purpose      : QC for marketing.Market and marketing.MarketSegment
                 (Q01-Q07, Q16, Q17 + Market-specific business rules R-01..R-05).
  Run Order    : after 08-03-T2-02-Market.sql. Read-only on user tables
                 (only temp tables are created).
  Prerequisites: the two tables exist; the load script has been run.
  Output       : Test_ID | Table_Name | Definition | Rows_Checked | Error_Count |
                 Sample_Error_IDs | Result (Pass / Fail / N/A)
  Notes        : Q03-C1..C4 check the child tables owned by 8.4 / 8.5; while
                 they are still empty they pass with 0 rows checked.
                 Q17: after the first accepted run, paste the printed
                 fingerprint into @ExpectedFingerprint; later runs must Pass.
=============================================================================*/
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;

DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = 0.10;          -- reference tables are always full; expected counts do not depend on it
DECLARE @FromDate    date         = '2019-03-21';  -- 1398/01/01
DECLARE @ToDate      date         = '2027-03-20';  -- 1405/12/29
DECLARE @AsOfDate    date         = '2027-03-20';

-- approved volume (guide section 7: markets ~8, segments ~24, 2..4 per market)
DECLARE @MarketMin    int = 6,  @MarketMax    int = 10;
DECLARE @SegMin       int = 18, @SegMax       int = 32;
DECLARE @PerMarketMin int = 2,  @PerMarketMax int = 4;
DECLARE @ExpectedFingerprint char(64) = NULL;      -- Q17: paste the accepted run's fingerprint here

SET NOCOUNT ON;

DECLARE @nM bigint = (SELECT COUNT_BIG(*) FROM marketing.Market);
DECLARE @nS bigint = (SELECT COUNT_BIG(*) FROM marketing.MarketSegment);
DECLARE @nR bigint = (SELECT COUNT_BIG(*) FROM marketing.MarketResearch);
DECLARE @nP bigint = (SELECT COUNT_BIG(*) FROM marketing.MarketPrice);
DECLARE @nC bigint = (SELECT COUNT_BIG(*) FROM marketing.Competitor);
DECLARE @nV bigint = (SELECT COUNT_BIG(*) FROM marketing.MarketSurvey);

IF OBJECT_ID(N'tempdb..#T') IS NOT NULL DROP TABLE #T;
IF OBJECT_ID(N'tempdb..#E') IS NOT NULL DROP TABLE #E;
CREATE TABLE #T (Seq int IDENTITY(1,1) PRIMARY KEY, Test_ID nvarchar(20) NOT NULL, Table_Name nvarchar(60) NOT NULL,
                 Definition nvarchar(300) NOT NULL, Rows_Checked bigint NULL, Applicable bit NOT NULL);
CREATE TABLE #E (Test_ID nvarchar(20) NOT NULL, Err_Key nvarchar(100) NOT NULL);

/*------------------------------ test catalogue ------------------------------*/
INSERT #T (Test_ID, Table_Name, Definition, Rows_Checked, Applicable) VALUES
 (N'Q01-M',  N'marketing.Market',        N'Row count within the approved volume (6..10, plan ~8)', @nM, 1),
 (N'Q01-S',  N'marketing.MarketSegment', N'Row count within the approved volume (18..32, plan ~24)', @nS, 1),
 (N'Q02-M1', N'marketing.Market',        N'Market_ID is not NULL and not duplicated', @nM, 1),
 (N'Q02-M2', N'marketing.Market',        N'Market_Code is not NULL / empty and is unique', @nM, 1),
 (N'Q02-M3', N'marketing.Market',        N'Market_Code follows the pattern MKT-nn', @nM, 1),
 (N'Q02-M4', N'marketing.Market',        N'Market_Name is unique', @nM, 1),
 (N'Q02-S1', N'marketing.MarketSegment', N'Market_Segment_ID is not NULL and not duplicated', @nS, 1),
 (N'Q02-S2', N'marketing.MarketSegment', N'Segment_Code is not NULL / empty and is unique in the WHOLE table', @nS, 1),
 (N'Q02-S3', N'marketing.MarketSegment', N'Segment_Code follows SEG-nn-nn and nn equals the parent market number', @nS, 1),
 (N'Q02-S4', N'marketing.MarketSegment', N'Segment_Name is unique inside its market', @nS, 1),
 (N'Q03-S1', N'marketing.MarketSegment', N'No orphan Market_ID (FK to marketing.Market)', @nS, 1),
 (N'Q03-C1', N'marketing.MarketResearch', N'No orphan Market_ID (child of Market)', @nR, 1),
 (N'Q03-C2', N'marketing.MarketPrice',    N'No orphan Market_ID (child of Market)', @nP, 1),
 (N'Q03-C3', N'marketing.Competitor',     N'No orphan Market_ID when not NULL (child of Market)', @nC, 1),
 (N'Q03-C4', N'marketing.MarketSurvey',   N'No orphan Market_Segment_ID when not NULL (child of MarketSegment)', @nV, 1),
 (N'Q04',    N'marketing.Market / MarketSegment', N'Date range - no date column in these tables', NULL, 0),
 (N'Q05',    N'marketing.Market / MarketSegment', N'Calendar coverage - not applicable', NULL, 0),
 (N'Q06-M1', N'marketing.Market',        N'Market_Status in (Active, Inactive)', @nM, 1),
 (N'Q06-M2', N'marketing.Market',        N'Market_Type is NULL or in the provisional list (see ISS-T2-MKT-01)', @nM, 1),
 (N'Q06-M3', N'marketing.Market',        N'Market_Name / Market_Description are not blank', @nM, 1),
 (N'Q06-S1', N'marketing.MarketSegment', N'Segmentation_Basis in (Behavioral, Demographic, Geographic)', @nS, 1),
 (N'Q06-S2', N'marketing.MarketSegment', N'Segment_Status in (Active, Inactive)', @nS, 1),
 (N'Q06-S3', N'marketing.MarketSegment', N'Segment_Name / Segment_Description are not blank', @nS, 1),
 (N'Q07',    N'marketing.Market / MarketSegment', N'Temporal consistency - no date column in these tables', NULL, 0),
 (N'R-01',   N'marketing.Market',        N'Every market has at least 1 segment', @nM, 1),
 (N'R-02',   N'marketing.Market',        N'Segments per market between 2 and 4', @nM, 1),
 (N'R-03',   N'marketing.Market',        N'Every Active market has at least 2 Active segments', @nM, 1),
 (N'R-04',   N'marketing.MarketSegment', N'An Inactive market has no Active segment', @nS, 1),
 (N'R-05',   N'marketing.Market',        N'At least one Active market exists', @nM, 1),
 (N'Q16-M',  N'marketing.Market',        N'Privacy: no e-mail, URL or phone-like digit run in text columns', @nM, 1),
 (N'Q16-S',  N'marketing.MarketSegment', N'Privacy: no e-mail, URL or phone-like digit run in text columns', @nS, 1),
 (N'Q17',    N'marketing.Market + MarketSegment', N'Repeatability: content fingerprint equals @ExpectedFingerprint (N/A until it is set)', @nM + @nS,
              CASE WHEN @ExpectedFingerprint IS NULL THEN 0 ELSE 1 END);

/*------------------------------ Q01 ----------------------------------------*/
INSERT #E SELECT N'Q01-M', N'count=' + CONVERT(nvarchar(20), @nM) WHERE @nM NOT BETWEEN @MarketMin AND @MarketMax;
INSERT #E SELECT N'Q01-S', N'count=' + CONVERT(nvarchar(20), @nS) WHERE @nS NOT BETWEEN @SegMin AND @SegMax;

/*------------------------------ Q02 ----------------------------------------*/
INSERT #E SELECT N'Q02-M1', ISNULL(CONVERT(nvarchar(50), Market_ID), N'NULL')
FROM marketing.Market GROUP BY Market_ID HAVING COUNT(*) > 1 OR Market_ID IS NULL;

INSERT #E SELECT N'Q02-M2', ISNULL(Market_Code, N'NULL')
FROM marketing.Market GROUP BY Market_Code
HAVING COUNT(*) > 1 OR Market_Code IS NULL OR LEN(LTRIM(RTRIM(Market_Code))) = 0;

INSERT #E SELECT N'Q02-M3', Market_Code FROM marketing.Market WHERE Market_Code NOT LIKE N'MKT-[0-9][0-9]';

INSERT #E SELECT N'Q02-M4', Market_Name FROM marketing.Market GROUP BY Market_Name HAVING COUNT(*) > 1;

INSERT #E SELECT N'Q02-S1', ISNULL(CONVERT(nvarchar(50), Market_Segment_ID), N'NULL')
FROM marketing.MarketSegment GROUP BY Market_Segment_ID HAVING COUNT(*) > 1 OR Market_Segment_ID IS NULL;

INSERT #E SELECT N'Q02-S2', ISNULL(Segment_Code, N'NULL')
FROM marketing.MarketSegment GROUP BY Segment_Code
HAVING COUNT(*) > 1 OR Segment_Code IS NULL OR LEN(LTRIM(RTRIM(Segment_Code))) = 0;

INSERT #E SELECT N'Q02-S3', s.Segment_Code
FROM marketing.MarketSegment s
JOIN marketing.Market m ON m.Market_ID = s.Market_ID
WHERE s.Segment_Code NOT LIKE N'SEG-[0-9][0-9]-[0-9][0-9]'
   OR SUBSTRING(s.Segment_Code, 5, 2) <> RIGHT(m.Market_Code, 2);

INSERT #E SELECT N'Q02-S4', s.Segment_Code
FROM marketing.MarketSegment s
JOIN (SELECT Market_ID, Segment_Name FROM marketing.MarketSegment GROUP BY Market_ID, Segment_Name HAVING COUNT(*) > 1) d
  ON d.Market_ID = s.Market_ID AND d.Segment_Name = s.Segment_Name;

/*------------------------------ Q03 ----------------------------------------*/
INSERT #E SELECT N'Q03-S1', CONVERT(nvarchar(50), s.Market_Segment_ID)
FROM marketing.MarketSegment s LEFT JOIN marketing.Market m ON m.Market_ID = s.Market_ID
WHERE m.Market_ID IS NULL;

INSERT #E SELECT N'Q03-C1', CONVERT(nvarchar(50), r.Market_Research_ID)
FROM marketing.MarketResearch r LEFT JOIN marketing.Market m ON m.Market_ID = r.Market_ID
WHERE m.Market_ID IS NULL;

INSERT #E SELECT N'Q03-C2', CONVERT(nvarchar(50), p.Market_Price_ID)
FROM marketing.MarketPrice p LEFT JOIN marketing.Market m ON m.Market_ID = p.Market_ID
WHERE m.Market_ID IS NULL;

INSERT #E SELECT N'Q03-C3', CONVERT(nvarchar(50), c.Competitor_ID)
FROM marketing.Competitor c LEFT JOIN marketing.Market m ON m.Market_ID = c.Market_ID
WHERE c.Market_ID IS NOT NULL AND m.Market_ID IS NULL;

INSERT #E SELECT N'Q03-C4', CONVERT(nvarchar(50), v.Market_Survey_ID)
FROM marketing.MarketSurvey v LEFT JOIN marketing.MarketSegment s ON s.Market_Segment_ID = v.Market_Segment_ID
WHERE v.Market_Segment_ID IS NOT NULL AND s.Market_Segment_ID IS NULL;

/*------------------------------ Q06 ----------------------------------------*/
INSERT #E SELECT N'Q06-M1', Market_Code FROM marketing.Market
WHERE Market_Status IS NULL OR Market_Status NOT IN (N'Active', N'Inactive');

INSERT #E SELECT N'Q06-M2', Market_Code FROM marketing.Market
WHERE Market_Type IS NOT NULL
  AND Market_Type NOT IN (N'Retail', N'Online', N'Foodservice', N'Wholesale', N'Institutional', N'Export', N'Specialty');

INSERT #E SELECT N'Q06-M3', Market_Code FROM marketing.Market
WHERE LEN(LTRIM(RTRIM(Market_Name))) = 0 OR (Market_Description IS NOT NULL AND LEN(LTRIM(RTRIM(Market_Description))) = 0);

INSERT #E SELECT N'Q06-S1', Segment_Code FROM marketing.MarketSegment
WHERE Segmentation_Basis IS NULL OR Segmentation_Basis NOT IN (N'Behavioral', N'Demographic', N'Geographic');

INSERT #E SELECT N'Q06-S2', Segment_Code FROM marketing.MarketSegment
WHERE Segment_Status IS NULL OR Segment_Status NOT IN (N'Active', N'Inactive');

INSERT #E SELECT N'Q06-S3', Segment_Code FROM marketing.MarketSegment
WHERE LEN(LTRIM(RTRIM(Segment_Name))) = 0 OR (Segment_Description IS NOT NULL AND LEN(LTRIM(RTRIM(Segment_Description))) = 0);

/*------------------------------ business rules -----------------------------*/
INSERT #E SELECT N'R-01', m.Market_Code FROM marketing.Market m
WHERE NOT EXISTS (SELECT 1 FROM marketing.MarketSegment s WHERE s.Market_ID = m.Market_ID);

INSERT #E SELECT N'R-02', m.Market_Code FROM marketing.Market m
WHERE (SELECT COUNT(*) FROM marketing.MarketSegment s WHERE s.Market_ID = m.Market_ID) NOT BETWEEN @PerMarketMin AND @PerMarketMax;

INSERT #E SELECT N'R-03', m.Market_Code FROM marketing.Market m
WHERE m.Market_Status = N'Active'
  AND (SELECT COUNT(*) FROM marketing.MarketSegment s WHERE s.Market_ID = m.Market_ID AND s.Segment_Status = N'Active') < 2;

INSERT #E SELECT N'R-04', s.Segment_Code
FROM marketing.MarketSegment s JOIN marketing.Market m ON m.Market_ID = s.Market_ID
WHERE m.Market_Status = N'Inactive' AND s.Segment_Status = N'Active';

INSERT #E SELECT N'R-05', N'no Active market'
WHERE NOT EXISTS (SELECT 1 FROM marketing.Market WHERE Market_Status = N'Active');

/*------------------------------ Q16 privacy --------------------------------*/
INSERT #E SELECT N'Q16-M', Market_Code FROM marketing.Market
WHERE CONCAT(Market_Name, N' ', Market_Description) LIKE N'%@%'
   OR CONCAT(Market_Name, N' ', Market_Description) LIKE N'%http%'
   OR CONCAT(Market_Name, N' ', Market_Description) LIKE N'%www.%'
   OR CONCAT(Market_Name, N' ', Market_Description) LIKE N'%[0-9][0-9][0-9][0-9][0-9][0-9][0-9]%'
   OR CONCAT(Market_Name, N' ', Market_Description) LIKE N'%[۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹]%';

INSERT #E SELECT N'Q16-S', Segment_Code FROM marketing.MarketSegment
WHERE CONCAT(Segment_Name, N' ', Segment_Description) LIKE N'%@%'
   OR CONCAT(Segment_Name, N' ', Segment_Description) LIKE N'%http%'
   OR CONCAT(Segment_Name, N' ', Segment_Description) LIKE N'%www.%'
   OR CONCAT(Segment_Name, N' ', Segment_Description) LIKE N'%[0-9][0-9][0-9][0-9][0-9][0-9][0-9]%'
   OR CONCAT(Segment_Name, N' ', Segment_Description) LIKE N'%[۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹][۰۱۲۳۴۵۶۷۸۹]%';

/*------------------------------ Q17 fingerprint ----------------------------*/
DECLARE @FP char(64) =
    CONVERT(char(64), HASHBYTES('SHA2_256',
        (SELECT STRING_AGG(CONCAT_WS(N'|', m.Market_Code, m.Market_Name, m.Market_Type, m.Market_Status,
                                     s.Segment_Code, s.Segment_Name, s.Segmentation_Basis, s.Segment_Status), N';')
                WITHIN GROUP (ORDER BY s.Segment_Code)
         FROM marketing.Market m JOIN marketing.MarketSegment s ON s.Market_ID = m.Market_ID)), 2);

INSERT #E SELECT N'Q17', N'fingerprint differs' WHERE @ExpectedFingerprint IS NOT NULL AND @ExpectedFingerprint <> @FP;

/*------------------------------ report -------------------------------------*/
PRINT N'08-05-T2-02-Market-Checks.sql | ' + @DataVersion + N' | Seed=' + CONVERT(nvarchar(20), @Seed)
    + N' | Scale=' + CONVERT(nvarchar(10), @Scale) + N' | Fingerprint=' + @FP;

SELECT t.Test_ID, t.Table_Name, t.Definition,
       t.Rows_Checked,
       CASE WHEN t.Applicable = 0 THEN NULL ELSE ISNULL(e.Cnt, 0) END AS Error_Count,
       CASE WHEN t.Test_ID = N'Q17' THEN @FP ELSE e.Smp END            AS Sample_Error_IDs,
       CASE WHEN t.Applicable = 0 THEN N'N/A'
            WHEN ISNULL(e.Cnt, 0) = 0 THEN N'Pass' ELSE N'Fail' END   AS Result
FROM #T t
OUTER APPLY (SELECT COUNT_BIG(*) AS Cnt,
                    (SELECT STRING_AGG(k.Err_Key, N', ') FROM (SELECT TOP (5) Err_Key FROM #E WHERE Test_ID = t.Test_ID ORDER BY Err_Key) k) AS Smp
             FROM #E WHERE Test_ID = t.Test_ID) e
ORDER BY t.Seq;

SELECT SUM(CASE WHEN x.Applicable = 1 AND ISNULL(x.Cnt, 0) > 0 THEN 1 ELSE 0 END) AS Failed_Tests,
       SUM(CASE WHEN x.Applicable = 1 AND ISNULL(x.Cnt, 0) = 0 THEN 1 ELSE 0 END) AS Passed_Tests,
       SUM(CASE WHEN x.Applicable = 0 THEN 1 ELSE 0 END)                         AS Not_Applicable
FROM (SELECT t.Applicable, (SELECT COUNT_BIG(*) FROM #E e WHERE e.Test_ID = t.Test_ID) AS Cnt FROM #T t) x;

DROP TABLE #E;
DROP TABLE #T;
GO
