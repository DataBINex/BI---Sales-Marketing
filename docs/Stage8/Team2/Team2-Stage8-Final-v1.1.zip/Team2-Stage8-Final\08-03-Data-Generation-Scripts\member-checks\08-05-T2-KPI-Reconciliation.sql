/*=============================================================================
  Project      : Food Distribution BI (Sales & Marketing Dashboard)
  Stage        : 8 - Mock Data Design (Q14 - KPI reconciliation)
  Team / Owner : Team 2 - Product & Marketing
  Database     : FoodDistributionDB  (SQL Server 2022)
  Script       : 08-05-T2-KPI-Reconciliation.sql
  Version      : 1.0   (MockData_v1.1_Seed20261031)
  Date         : 2026-11-01
  Purpose      : For every priority KPI that can be computed from Team 2 tables,
                 one independent query on the RAW tables (no views / helper
                 objects of the generators) -> value, comparison with the
                 acceptable range, Pass / Fail / Info / No_Data.
  Run Order    : after ALL Team 2 load scripts (8.2 - 8.5) are loaded and their
                 own Checks pass. Read-only (temp tables only).
  How to run   : 1) 10% data : keep @Scale = 0.10 and @RunLabel = 'Scale_0.10'
                 2) full data: set @Scale = 1.00 and @RunLabel = 'Scale_1.00'
                 Save both result sets in 08-06-Data-Quality-Report.xlsx and
                 compare them (ratio KPIs should be close; count KPIs scale).
  Source       : Project KPIs.xlsx - sheets "پشتیبانی فروش و بازاریابی"
                 (SSM-KPI-xx), "تحقیقات بازار" (MR-xx-xxx) and the pricing rows
                 of "فروش آنلاین" (ONL-03, ONL-04).
  Ranges       : Range_Source = Sheet    -> the target written in the KPI sheet
                                 Plan    -> guide section 7 volumes
                                 Proposed-> sanity range proposed by Team 2; the
                                            project manager must approve it (it
                                            is NOT a business target).
  KPIs NOT computable from Team 2 tables (listed in the Issue Log, ISS-T2-KPI-xx):
    SSM-KPI-13, 14, 16, 25-30, 32 ; MR-01-003, 01-005, 02-002..006, 03-001..006,
    04-002, 04-003, 04-007, 05-002..004, 06-*, 07-*, 08-*, 09-*, 10-*, 11-*.
    SSM-KPI-01..07, 21-24, 26, 27 belong to Team 1; SSM-KPI-20 needs
    SalesOrder.Promotion_ID (integration stage).
  Determinism  : no NEWID / RAND / GETDATE; same data -> same output.
=============================================================================*/
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;

/*------------------------------ common settings ---------------------------*/
DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = 0.10;          -- 0.10 = 10% test, 1.00 = full
DECLARE @FromDate    date         = '2019-03-21';  -- 1398/01/01
DECLARE @ToDate      date         = '2027-03-20';  -- 1405/12/29
DECLARE @AsOfDate    date         = '2027-03-20';  -- status reference date (until T2-S8-04)

/*------------------------------ script-local ------------------------------*/
DECLARE @RunLabel     nvarchar(30) = N'Scale_0.10';  -- label written beside every result
DECLARE @Currency     char(3)      = 'IRR';          -- T2-S8-05
-- status literals: PROVISIONAL until the Allowed-Values sheet (D-07) is confirmed
DECLARE @Active       nvarchar(30) = N'Active';
DECLARE @Completed    nvarchar(30) = N'Completed';
DECLARE @Cancelled    nvarchar(30) = N'Cancelled';
-- CampaignResult.Metric_Name vocabulary: to be fixed by the 8.4 generator (ISS-T2-KPI-06)
DECLARE @MetricReach   nvarchar(100) = N'Audience_Reached';
DECLARE @MetricConv    nvarchar(100) = N'Conversions';
DECLARE @MetricNewCust nvarchar(100) = N'New_Customers';
DECLARE @MetricRevenue nvarchar(100) = N'Attributed_Revenue';
-- volume ranges follow @Scale only for tables that 08-02 marks "under @scale"; set to 0 if not
DECLARE @CampaignScaled bit = 1;
DECLARE @ResearchScaled bit = 1;
DECLARE @CampScale decimal(5,2) = CASE WHEN @CampaignScaled = 1 THEN @Scale ELSE 1.00 END;
DECLARE @ResScale  decimal(5,2) = CASE WHEN @ResearchScaled = 1 THEN @Scale ELSE 1.00 END;
DECLARE @YearsInPeriod int = 8;                      -- 1398 .. 1405

SET NOCOUNT ON;

IF OBJECT_ID(N'tempdb..#KPI') IS NOT NULL DROP TABLE #KPI;
IF OBJECT_ID(N'tempdb..#PG')  IS NOT NULL DROP TABLE #PG;
CREATE TABLE #KPI
(
    Seq          int IDENTITY(1,1) PRIMARY KEY,
    KPI_ID       nvarchar(30)   NOT NULL,
    KPI_Title    nvarchar(200)  NOT NULL,
    Priority     nvarchar(20)   NOT NULL,
    Formula      nvarchar(500)  NOT NULL,
    Numerator    decimal(28,4)  NULL,
    Denominator  decimal(28,4)  NULL,
    Result       decimal(28,4)  NULL,
    Unit         nvarchar(20)   NOT NULL,
    Accept_Min   decimal(28,4)  NULL,
    Accept_Max   decimal(28,4)  NULL,
    Range_Source nvarchar(20)   NOT NULL,
    Note         nvarchar(400)  NULL
);

/*================================ PRODUCT ==================================*/
-- SSM-KPI-08  complete product information (active products)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-08', N'درصد محصولات دارای اطلاعات کامل', N'P1',
       N'(active products with Description, Launch_Date, Weight, Tax_Rate and >=1 SKU / active products) x 100',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', 98, NULL, N'Sheet',
       N'Description and Weight are not guaranteed by the shared contract - the Product generator must fill them or this KPI fails.'
FROM (SELECT
        num = CAST((SELECT COUNT_BIG(*) FROM core.Product p
                    WHERE p.Product_Status = @Active AND p.Launch_Date IS NOT NULL AND p.Tax_Rate IS NOT NULL
                      AND p.Weight IS NOT NULL AND p.Product_Description IS NOT NULL
                      AND EXISTS (SELECT 1 FROM core.SKU k WHERE k.Product_ID = p.Product_ID)) AS decimal(28,4)),
        den = CAST((SELECT COUNT_BIG(*) FROM core.Product p WHERE p.Product_Status = @Active) AS decimal(28,4))) x;

-- SSM-KPI-09  active and sellable products
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-09', N'درصد محصولات فعال و قابل فروش', N'P1',
       N'(active products having >=1 active SKU / all products) x 100',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', 50, 95, N'Proposed',
       N'Sheet target is "equal to approved plan" - no number exists; range is a sanity range.'
FROM (SELECT
        num = CAST((SELECT COUNT_BIG(*) FROM core.Product p
                    WHERE p.Product_Status = @Active
                      AND EXISTS (SELECT 1 FROM core.SKU k WHERE k.Product_ID = p.Product_ID AND k.SKU_Status = @Active)) AS decimal(28,4)),
        den = CAST((SELECT COUNT_BIG(*) FROM core.Product) AS decimal(28,4))) x;

-- ONL-03  number of active products (count)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'ONL-03', N'تعداد محصولات فعال', N'P1',
       N'COUNT(products with Product_Status = Active and >=1 active SKU)',
       x.num, NULL, x.num, N'count', NULL, NULL, N'Plan',
       N'Sheet target is "equal to approved plan"; guide section 7 expects 100-500 products in total.'
FROM (SELECT num = CAST((SELECT COUNT_BIG(*) FROM core.Product p
                         WHERE p.Product_Status = @Active
                           AND EXISTS (SELECT 1 FROM core.SKU k WHERE k.Product_ID = p.Product_ID AND k.SKU_Status = @Active)) AS decimal(28,4))) x;

-- SSM-KPI-10  product data error rate
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-10', N'نرخ خطای اطلاعات محصول', N'P1',
       N'(products with NULL Launch_Date/Tax_Rate, Tax_Rate outside 0..100, no SKU, or Active with Launch_Date after @AsOfDate / all products) x 100',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', NULL, 2, N'Sheet', NULL
FROM (SELECT
        num = CAST((SELECT COUNT_BIG(*) FROM core.Product p
                    WHERE p.Launch_Date IS NULL OR p.Tax_Rate IS NULL OR p.Tax_Rate < 0 OR p.Tax_Rate > 100
                       OR NOT EXISTS (SELECT 1 FROM core.SKU k WHERE k.Product_ID = p.Product_ID)
                       OR (p.Product_Status = @Active AND p.Launch_Date > @AsOfDate)) AS decimal(28,4)),
        den = CAST((SELECT COUNT_BIG(*) FROM core.Product) AS decimal(28,4))) x;

-- SSM-KPI-31  completeness of key data (Team 2 core entities)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-31', N'درصد کامل‌بودن داده‌های کلیدی (تیم ۲)', N'P1',
       N'(rows with all key fields / rows) x 100 over Product, SKU, Brand, MarketingCampaign, MarketResearch',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', 98, NULL, N'Sheet',
       N'Key fields: Product(Launch_Date,Tax_Rate) SKU(Barcode) Brand(Brand_Start_Date) Campaign(End_Date when Completed) Research(End_Date when Completed).'
FROM (SELECT num = CAST(SUM(u.ok) AS decimal(28,4)), den = CAST(COUNT_BIG(*) AS decimal(28,4))
      FROM (
            SELECT CASE WHEN Launch_Date IS NOT NULL AND Tax_Rate IS NOT NULL THEN 1 ELSE 0 END AS ok FROM core.Product
            UNION ALL
            SELECT CASE WHEN Barcode IS NOT NULL THEN 1 ELSE 0 END FROM core.SKU
            UNION ALL
            SELECT CASE WHEN Brand_Start_Date IS NOT NULL THEN 1 ELSE 0 END FROM core.Brand
            UNION ALL
            SELECT CASE WHEN Campaign_Status = @Completed AND End_Date IS NULL THEN 0 ELSE 1 END FROM marketing.MarketingCampaign
            UNION ALL
            SELECT CASE WHEN Research_Status = @Completed AND End_Date IS NULL THEN 0 ELSE 1 END FROM marketing.MarketResearch
           ) u) x;

-- SSM-KPI-12 (proxy)  price coverage of active SKUs at @AsOfDate
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-12 (proxy)', N'دقت قیمت‌گذاری - جایگزین: پوشش قیمت معتبر', N'P2-Proxy',
       N'(active SKUs with exactly one active price valid at @AsOfDate in @Currency / active SKUs) x 100',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', 99, NULL, N'Sheet',
       N'PROXY only: the model has no "approved price list" to compare with (ISS-T2-KPI-05).'
FROM (SELECT
        num = CAST((SELECT COUNT_BIG(*) FROM core.SKU k
                    WHERE k.SKU_Status = @Active
                      AND (SELECT COUNT(*) FROM marketing.ProductPrice pp
                           WHERE pp.SKU_ID = k.SKU_ID AND pp.Price_Status = @Active AND pp.Currency = @Currency
                             AND pp.Effective_From <= @AsOfDate
                             AND (pp.Effective_To IS NULL OR pp.Effective_To >= @AsOfDate)) = 1) AS decimal(28,4)),
        den = CAST((SELECT COUNT_BIG(*) FROM core.SKU k WHERE k.SKU_Status = @Active) AS decimal(28,4))) x;

/*============================ MARKET / SEGMENT =============================*/
-- MR-02-001  identified target markets
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-02-001', N'تعداد بازارهای هدف شناسایی‌شده', N'P1',
       N'COUNT(Market with code, name and Market_Status = Active)',
       x.num, NULL, x.num, N'count', 5, 12, N'Plan',
       N'Guide section 7: ~8 markets. Reference table - not scaled.'
FROM (SELECT num = CAST((SELECT COUNT_BIG(*) FROM marketing.Market
                         WHERE Market_Status = @Active AND Market_Code IS NOT NULL AND Market_Name IS NOT NULL) AS decimal(28,4))) x;

-- MR-05-001  identified customer segments
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-05-001', N'تعداد بخش‌های مشتری شناسایی‌شده', N'P1',
       N'COUNT(MarketSegment Active whose Market is Active)',
       x.num, NULL, x.num, N'count', 15, 40, N'Plan',
       N'Guide section 7: ~24 segments (2-4 per market). Reference table - not scaled.'
FROM (SELECT num = CAST((SELECT COUNT_BIG(*) FROM marketing.MarketSegment s
                         JOIN marketing.Market m ON m.Market_ID = s.Market_ID
                         WHERE s.Segment_Status = @Active AND m.Market_Status = @Active) AS decimal(28,4))) x;

/*============================== COMPETITORS ================================*/
-- MR-04-001  active competitors
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-04-001', N'تعداد رقبا', N'P1',
       N'COUNT(Competitor with Competitor_Status = Active)',
       x.num, NULL, x.num, N'count', 3, 40, N'Proposed', N'Sheet target is "market monitoring" - no number.'
FROM (SELECT num = CAST((SELECT COUNT_BIG(*) FROM marketing.Competitor WHERE Competitor_Status = @Active) AS decimal(28,4))) x;

-- MR-04-006  competitor product diversity index
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-04-006', N'شاخص تنوع محصول رقبا', N'P1',
       N'(competitor products of Active competitors / active company products) x 100',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', 30, 400, N'Proposed', NULL
FROM (SELECT
        num = CAST((SELECT COUNT_BIG(*) FROM marketing.CompetitorProduct cp
                    JOIN marketing.Competitor c ON c.Competitor_ID = cp.Competitor_ID
                    WHERE c.Competitor_Status = @Active) AS decimal(28,4)),
        den = CAST((SELECT COUNT_BIG(*) FROM core.Product WHERE Product_Status = @Active) AS decimal(28,4))) x;

-- price groups: (market, category, month) with both company and competitor prices in @Currency
SELECT c.Market_ID, c.Cat, c.Month_Start, c.Avg_Price AS Company_Avg, k.Avg_Price AS Competitor_Avg
INTO   #PG
FROM  (SELECT mp.Market_ID, pc.Category_Name AS Cat,
              DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1) AS Month_Start,
              AVG(mp.Price_Value) AS Avg_Price
       FROM marketing.MarketPrice mp
       JOIN core.Product p            ON p.Product_ID = mp.Product_ID
       JOIN ref.ProductCategory pc    ON pc.Product_Category_ID = p.Product_Category_ID
       WHERE mp.Currency = @Currency
       GROUP BY mp.Market_ID, pc.Category_Name, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1)) c
JOIN  (SELECT mp.Market_ID, cp.Category AS Cat,
              DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1) AS Month_Start,
              AVG(mp.Price_Value) AS Avg_Price
       FROM marketing.MarketPrice mp
       JOIN marketing.CompetitorProduct cp ON cp.Competitor_Product_ID = mp.Competitor_Product_ID
       WHERE mp.Currency = @Currency
       GROUP BY mp.Market_ID, cp.Category, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1)) k
  ON k.Market_ID = c.Market_ID AND k.Cat = c.Cat AND k.Month_Start = c.Month_Start
WHERE k.Avg_Price > 0;

-- MR-04-004  price index vs competitors
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-04-004', N'شاخص قیمت نسبت به رقبا', N'P1',
       N'AVG over (market, category, month) of 100 x company avg price / competitor avg price; Numerator = sum of indexes, Denominator = number of groups',
       x.num, x.den, CASE WHEN x.den > 0 THEN x.num / x.den END, N'%', 80, 130, N'Proposed',
       N'Join key is category TEXT: CompetitorProduct.Category must equal ref.ProductCategory.Category_Name (design rule for the 8.5 generator - ISS-T2-KPI-10).'
FROM (SELECT num = CAST(ISNULL(SUM(100.0 * Company_Avg / Competitor_Avg), 0) AS decimal(28,4)),
             den = CAST(COUNT_BIG(*) AS decimal(28,4))
      FROM #PG) x;

-- MR-04-005  price gap (absolute, IRR)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-04-005 (IRR)', N'شکاف قیمت با رقبا - مطلق', N'P1',
       N'AVG over (market, category, month) of company avg price - competitor avg price',
       x.num, x.den, CASE WHEN x.den > 0 THEN x.num / x.den END, N'IRR', NULL, NULL, N'Sheet', N'Sheet target: "within allowed range" - informational.'
FROM (SELECT num = CAST(ISNULL(SUM(Company_Avg - Competitor_Avg), 0) AS decimal(28,4)),
             den = CAST(COUNT_BIG(*) AS decimal(28,4))
      FROM #PG) x;

-- MR-04-005  price gap (percent)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-04-005 (%)', N'شکاف قیمت با رقبا - درصدی', N'P1',
       N'AVG over groups of 100 x (company - competitor) / competitor',
       x.num, x.den, CASE WHEN x.den > 0 THEN x.num / x.den END, N'%', -30, 30, N'Proposed', NULL
FROM (SELECT num = CAST(ISNULL(SUM(100.0 * (Company_Avg - Competitor_Avg) / Competitor_Avg), 0) AS decimal(28,4)),
             den = CAST(COUNT_BIG(*) AS decimal(28,4))
      FROM #PG) x;

/*================================ RESEARCH =================================*/
-- MR-01-001  research plan execution
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-01-001', N'درصد تحقق برنامه تحقیقات بازار', N'P1',
       N'(research with Research_Status = Completed / research started on or before @AsOfDate and not Cancelled) x 100',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', 90, NULL, N'Sheet',
       N'No separate "planned projects" entity exists; denominator is the non-cancelled projects (ISS-T2-KPI-04).'
FROM (SELECT
        num = CAST((SELECT COUNT_BIG(*) FROM marketing.MarketResearch WHERE Research_Status = @Completed) AS decimal(28,4)),
        den = CAST((SELECT COUNT_BIG(*) FROM marketing.MarketResearch
                    WHERE Research_Status <> @Cancelled AND Start_Date <= @AsOfDate) AS decimal(28,4))) x;

-- MR-01-002  completed research (count in the whole period)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-01-002', N'تعداد تحقیقات بازار انجام‌شده', N'P1',
       N'COUNT(research Completed with End_Date between @FromDate and @ToDate)',
       x.num, NULL, x.num, N'count', 16 * @ResScale, 48 * @ResScale, N'Plan',
       N'Guide section 7: a few studies per year (2-6) x 8 years; range multiplied by @Scale when research is under @scale.'
FROM (SELECT num = CAST((SELECT COUNT_BIG(*) FROM marketing.MarketResearch
                         WHERE Research_Status = @Completed AND End_Date BETWEEN @FromDate AND @ToDate) AS decimal(28,4))) x;

-- MR-01-004  average research duration
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'MR-01-004', N'میانگین مدت اجرای تحقیق', N'P1',
       N'SUM(days from Start_Date to End_Date) / COUNT(Completed research)',
       x.num, x.den, CASE WHEN x.den > 0 THEN x.num / x.den END, N'days', 7, 180, N'Proposed', NULL
FROM (SELECT num = CAST(ISNULL(SUM(CAST(DATEDIFF(day, Start_Date, End_Date) AS bigint)), 0) AS decimal(28,4)),
             den = CAST(COUNT_BIG(*) AS decimal(28,4))
      FROM marketing.MarketResearch
      WHERE Research_Status = @Completed AND End_Date IS NOT NULL) x;

/*================================ CAMPAIGNS ================================*/
-- SSM-KPI-15  campaigns executed per year (partial: no approved calendar)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-15', N'تعداد کمپین‌های اجراشده (میانگین سالانه)', N'P2-Partial',
       N'COUNT(campaigns Completed or Active, Start_Date in period) / 8 years',
       x.num, CAST(@YearsInPeriod AS decimal(28,4)), x.num / @YearsInPeriod, N'per year', 5 * @CampScale, 20 * @CampScale, N'Plan',
       N'Guide section 7: 5-20 campaigns per year. No approved calendar exists, so "as planned" cannot be tested (ISS-T2-KPI-09).'
FROM (SELECT num = CAST((SELECT COUNT_BIG(*) FROM marketing.MarketingCampaign
                         WHERE Campaign_Status IN (@Completed, @Active) AND Start_Date BETWEEN @FromDate AND @ToDate) AS decimal(28,4))) x;

-- SSM-KPI-17  campaign conversion rate (needs the metric vocabulary)
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-17', N'نرخ تبدیل کمپین', N'P2-Conditional',
       N'(SUM Metric_Value of @MetricConv / SUM Metric_Value of @MetricReach) x 100',
       x.num, x.den, CASE WHEN x.den > 0 THEN 100.0 * x.num / x.den END, N'%', 0.5, 25, N'Proposed',
       N'No_Data until CampaignResult carries these metric names (ISS-T2-KPI-06).'
FROM (SELECT
        num = CAST((SELECT SUM(Metric_Value) FROM marketing.CampaignResult WHERE Metric_Name = @MetricConv) AS decimal(28,4)),
        den = CAST((SELECT SUM(Metric_Value) FROM marketing.CampaignResult WHERE Metric_Name = @MetricReach) AS decimal(28,4))) x;

-- SSM-KPI-18  cost per acquired customer
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-18', N'هزینه جذب هر مشتری از کمپین', N'P2-Conditional',
       N'SUM(Actual_Spent in @Currency of campaigns that report @MetricNewCust) / SUM(@MetricNewCust)',
       x.num, x.den, CASE WHEN x.den > 0 THEN x.num / x.den END, N'IRR/customer', NULL, NULL, N'Sheet',
       N'Sheet target: "at most the approved budget per campaign" - tested per campaign in Q13, shown here as information.'
FROM (SELECT
        num = CAST((SELECT SUM(cc.Actual_Spent) FROM marketing.CampaignCost cc
                    WHERE cc.Currency = @Currency
                      AND cc.Marketing_Campaign_ID IN (SELECT Marketing_Campaign_ID FROM marketing.CampaignResult WHERE Metric_Name = @MetricNewCust)) AS decimal(28,4)),
        den = CAST((SELECT SUM(Metric_Value) FROM marketing.CampaignResult WHERE Metric_Name = @MetricNewCust) AS decimal(28,4))) x;

-- SSM-KPI-19  campaign ROI
INSERT #KPI (KPI_ID, KPI_Title, Priority, Formula, Numerator, Denominator, Result, Unit, Accept_Min, Accept_Max, Range_Source, Note)
SELECT N'SSM-KPI-19', N'بازگشت سرمایه کمپین (ROI)', N'P2-Conditional',
       N'((SUM @MetricRevenue - SUM Actual_Spent of the same campaigns) / SUM Actual_Spent) x 100; Numerator = revenue - cost, Denominator = cost',
       x.rev - x.cost, x.cost, CASE WHEN x.cost > 0 THEN 100.0 * (x.rev - x.cost) / x.cost END, N'%', 0, 500, N'Proposed',
       N'Sheet target: "positive and equal to the campaign goal". Attributed_Revenue is assumed to be in @Currency (ISS-T2-KPI-06).'
FROM (SELECT
        rev  = CAST((SELECT SUM(Metric_Value) FROM marketing.CampaignResult WHERE Metric_Name = @MetricRevenue) AS decimal(28,4)),
        cost = CAST((SELECT SUM(cc.Actual_Spent) FROM marketing.CampaignCost cc
                     WHERE cc.Currency = @Currency
                       AND cc.Marketing_Campaign_ID IN (SELECT Marketing_Campaign_ID FROM marketing.CampaignResult WHERE Metric_Name = @MetricRevenue)) AS decimal(28,4))) x;

/*================================= report ==================================*/
PRINT N'08-05-T2-KPI-Reconciliation.sql | ' + @DataVersion + N' | Seed=' + CONVERT(nvarchar(20), @Seed)
    + N' | Scale=' + CONVERT(nvarchar(10), @Scale) + N' | Run=' + @RunLabel + N' | AsOf=' + CONVERT(nvarchar(10), @AsOfDate, 23);

SELECT k.KPI_ID, k.KPI_Title, k.Priority, k.Formula, k.Numerator, k.Denominator, k.Result, k.Unit,
       k.Accept_Min, k.Accept_Max, k.Range_Source,
       CASE WHEN k.Result IS NULL THEN N'No_Data'
            WHEN k.Accept_Min IS NULL AND k.Accept_Max IS NULL THEN N'Info'
            WHEN (k.Accept_Min IS NULL OR k.Result >= k.Accept_Min) AND (k.Accept_Max IS NULL OR k.Result <= k.Accept_Max) THEN N'Pass'
            ELSE N'Fail' END AS Status,
       @RunLabel AS Run_Label, @DataVersion AS Data_Version, k.Note
FROM #KPI k
ORDER BY k.Seq;

SELECT CASE WHEN k.Result IS NULL THEN N'No_Data'
            WHEN k.Accept_Min IS NULL AND k.Accept_Max IS NULL THEN N'Info'
            WHEN (k.Accept_Min IS NULL OR k.Result >= k.Accept_Min) AND (k.Accept_Max IS NULL OR k.Result <= k.Accept_Max) THEN N'Pass'
            ELSE N'Fail' END AS Status,
       COUNT(*) AS KPI_Count
FROM #KPI k
GROUP BY CASE WHEN k.Result IS NULL THEN N'No_Data'
              WHEN k.Accept_Min IS NULL AND k.Accept_Max IS NULL THEN N'Info'
              WHEN (k.Accept_Min IS NULL OR k.Result >= k.Accept_Min) AND (k.Accept_Max IS NULL OR k.Result <= k.Accept_Max) THEN N'Pass'
              ELSE N'Fail' END;

DROP TABLE #PG;
DROP TABLE #KPI;
GO
