/*
Project: FoodDistributionDB - Synthetic Data Generation
Stage: 8 - Mock Data
Team/Owner: Team 2 - Product & Marketing
Database: FoodDistributionDB
Version: 1.1 (author: Sahar-Sayyah, #191; integration v1.1: SinaSepasi, #196)
Script: 08-03-T2-01-Brand-Channel-Audience.sql
Purpose: Load core.Brand, marketing.CampaignChannel, marketing.CampaignAudience, marketing.BrandActivity
Run Order: 1 (no prerequisite)
Prerequisites: FoodDistributionDB restored from FoodDistributionDB.bak; the four tables are empty
Seed/Configuration: settings block below; @Scale comes from SESSION_CONTEXT('T2_Scale') set by 08-04-Load-Data.sql (default 0.10)
Date: 2026-11-04 (static text; the script never reads the clock)
Tables: core.Brand 10, marketing.CampaignChannel 8, marketing.CampaignAudience 10, marketing.BrandActivity 480 (48 at 10%)

Integration changes v1.1 (behaviour of the member's v1.0 is kept otherwise):
  1. @Scale is read from the session (one setting for the whole Team 2 load).
  2. Activity_Type hash uses bigint (int could be negative and skewed the type mix to the ELSE branch).
  3. The 10% sample takes Brand x Year groups in hash order, so it covers several brands
     (v1.0 took the first 9 groups = one brand only).
  4. Activity_End_Date is always filled for activities that started on or before @AsOfDate and
     Activity_Status follows the dates: Completed (end < @AsOfDate), InProgress, Planned (start > @AsOfDate).
     Activity_Result is filled only for Completed activities.
  5. A row is written to #T2LoadLog when the loader created it (Q18).
  6. Temp tables are dropped at the start, so a second run in the same session works.
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #BrandMap, #ChannelMap, #ActivityRows;

DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10); -- 0.10 trial; 1.00 full
DECLARE @FromDate    date         = '2019-03-21';
DECLARE @ToDate      date         = '2027-03-20';
DECLARE @AsOfDate    date         = '2027-03-20';

DECLARE @ExpectedFullActivityRows int = 480;
DECLARE @ActivityRowsTarget int;
DECLARE @GroupCountTarget int;

IF @Scale NOT IN (0.10, 1.00)
    THROW 51001, 'Scale must be 0.10 or 1.00 for this delivery.', 1;

IF @FromDate > @ToDate OR @AsOfDate < @FromDate OR @AsOfDate > @ToDate
    THROW 51002, 'Invalid date configuration.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    /* Fail-safe rerun policy. Brand is shared, so only reserved Team 2
       business keys are checked there; no shared Brand rows are deleted. */
    IF EXISTS (SELECT 1 FROM marketing.CampaignChannel)
        THROW 51003, 'marketing.CampaignChannel is not empty. Stop; use the approved Stage 8 reset process.', 1;

    IF EXISTS (SELECT 1 FROM marketing.CampaignAudience)
        THROW 51004, 'marketing.CampaignAudience is not empty. Stop; use the approved Stage 8 reset process.', 1;

    IF EXISTS (SELECT 1 FROM marketing.BrandActivity)
        THROW 51005, 'marketing.BrandActivity is not empty. Stop; use the approved Stage 8 reset process.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM core.Brand
        WHERE Brand_Code LIKE N'T2S8BR%'
    )
        THROW 51006, 'Reserved Team 2 Brand_Code values already exist in core.Brand. Stop to prevent duplicate/partial load.', 1;

    /* Guard against business-key/name collisions with Team 1/shared data. */
    IF EXISTS
    (
        SELECT 1
        FROM core.Brand
        WHERE Brand_Status = N'Active'
          AND Brand_Name IN
          (N'آذرخش‌نما', N'باران‌دانه', N'چکادین', N'درفام', N'روشناک',
           N'سپهرآوا', N'فرازین', N'کاردیس', N'ماندگارک', N'نوبهارک')
    )
        THROW 51007, 'A proposed fictional active Brand_Name already exists in shared core.Brand. Review the shared master before loading.', 1;

    /* 1) Shared master: Brand. No IDENTITY_INSERT; SQL Server creates IDs. */
    INSERT INTO core.Brand
    (
        Brand_Name, Brand_Code, Brand_Type, Brand_Status,
        Brand_Start_Date, Brand_End_Date, Brand_Owner,
        Brand_Positioning, Target_Market, Target_Segment, Brand_Tagline,
        Brand_Logo_URL, Brand_Website, Brand_Country
    )
    VALUES
    (N'آذرخش‌نما', N'T2S8BR001', N'Master',      N'Active',   '2017-04-01', NULL,         N'واحد راهبرد برند', N'برند نوآور با تمرکز بر کیفیت پایدار', N'بازار داخلی', N'سازمان‌های متوسط', N'کیفیت در هر گام', N'https://example.com/brand/t2s8br001/logo', N'https://example.com/brand/t2s8br001', 'IR'),
    (N'باران‌دانه', N'T2S8BR002', N'ProductBrand',N'Active',  '2018-02-15', NULL,         N'واحد مدیریت محصول', N'برند کاربردی با تأکید بر سادگی', N'بازار داخلی', N'خانوارها', N'سادگی برای زندگی روزمره', N'https://example.com/brand/t2s8br002/logo', N'https://example.com/brand/t2s8br002', 'IR'),
    (N'چکادین',     N'T2S8BR003', N'SubBrand',    N'Active',  '2018-07-01', NULL,         N'واحد راهبرد برند', N'برند تخصصی در رده ممتاز', N'بازار منطقه‌ای', N'مشتریان ممتاز', N'انتخابی فراتر از انتظار', N'https://example.com/brand/t2s8br003/logo', N'https://example.com/brand/t2s8br003', 'IR'),
    (N'درفام',      N'T2S8BR004', N'ProductBrand',N'Active',  '2019-01-10', NULL,         N'واحد مدیریت محصول', N'برند قابل اتکا برای مصرف روزانه', N'بازار داخلی', N'خانوارها', N'همراه انتخاب‌های روزانه', N'https://example.com/brand/t2s8br004/logo', N'https://example.com/brand/t2s8br004', 'IR'),
    (N'روشناک',     N'T2S8BR005', N'Master',      N'Active',  '2017-11-20', NULL,         N'واحد راهبرد برند', N'برند با هویت روشن و قابل اعتماد', N'بازار داخلی', N'مشتریان وفادار', N'اعتماد، روشن و ماندگار', N'https://example.com/brand/t2s8br005/logo', N'https://example.com/brand/t2s8br005', 'IR'),
    (N'سپهرآوا',    N'T2S8BR006', N'SubBrand',    N'Active',  '2018-05-05', NULL,         N'واحد ارتباطات بازاریابی', N'برند پویا با رویکرد ارتباطی', N'بازار منطقه‌ای', N'جوانان و خانواده‌ها', N'صدای تازه یک انتخاب خوب', N'https://example.com/brand/t2s8br006/logo', N'https://example.com/brand/t2s8br006', 'IR'),
    (N'فرازین',     N'T2S8BR007', N'ProductBrand',N'Active',  '2019-03-01', NULL,         N'واحد مدیریت محصول', N'برند عملکردمحور و اقتصادی', N'بازار داخلی', N'مشتریان ارزش‌محور', N'عملکرد مناسب، انتخاب هوشمند', N'https://example.com/brand/t2s8br007/logo', N'https://example.com/brand/t2s8br007', 'IR'),
    (N'کاردیس',     N'T2S8BR008', N'Master',      N'Active',  '2017-08-12', NULL,         N'واحد راهبرد برند', N'برند متمایز با تمرکز بر دوام', N'بازار داخلی', N'سازمان‌های متوسط', N'دوام در انتخاب', N'https://example.com/brand/t2s8br008/logo', N'https://example.com/brand/t2s8br008', 'IR'),
    (N'ماندگارک',   N'T2S8BR009', N'SubBrand',    N'Inactive','2018-09-01', '2026-12-31', N'واحد مدیریت محصول', N'برند سابق با سابقه فعالیت مستند', N'بازار داخلی', N'مشتریان قدیمی', N'خاطره یک انتخاب', N'https://example.com/brand/t2s8br009/logo', N'https://example.com/brand/t2s8br009', 'IR'),
    (N'نوبهارک',    N'T2S8BR010', N'ProductBrand',N'Inactive','2018-12-01', '2026-12-31', N'واحد مدیریت محصول', N'برند سابق در سبد آزمایشی', N'بازار منطقه‌ای', N'مشتریان ارزش‌محور', N'آغاز یک تجربه تازه', N'https://example.com/brand/t2s8br010/logo', N'https://example.com/brand/t2s8br010', 'IR');

    PRINT CONCAT(N'Inserted core.Brand rows: ', @@ROWCOUNT);

    /* 2) Reference/master: CampaignChannel. */
    INSERT INTO marketing.CampaignChannel
        (Channel_Name, Channel_Type, Channel_Description, Channel_Status)
    VALUES
    (N'وب‌سایت محتوایی', N'Digital', N'محتوا و معرفی برند در وب‌سایت آزمایشی', N'Active'),
    (N'شبکه اجتماعی تصویری', N'Social', N'انتشار محتوای تصویری در بستر ساختگی', N'Active'),
    (N'رسانه پیامکی آزمایشی', N'Direct', N'ارتباط مستقیم با مخاطبان رضایت‌داده فرضی؛ بدون شماره واقعی', N'Active'),
    (N'رویداد حضوری نمونه', N'Event', N'رویداد ساختگی در فضای نمایشگاهی فرضی', N'Active'),
    (N'خبرنامه الکترونیکی', N'Email', N'خبرنامه با نشانی‌های آزمایشی و بدون ایمیل واقعی', N'Active'),
    (N'رسانه محیطی نمونه', N'Outdoor', N'جایگاه تبلیغاتی فرضی و غیرقابل انتساب', N'Active'),
    (N'همکاری محتوایی', N'Partner', N'همکاری با ناشر یا شریک کاملاً ساختگی', N'Active'),
    (N'کانال آرشیوی قدیمی', N'Legacy', N'کانال غیرفعال برای سناریوهای تاریخی', N'Inactive');

    PRINT CONCAT(N'Inserted marketing.CampaignChannel rows: ', @@ROWCOUNT);

    /* 3) Reference/master: CampaignAudience. */
    INSERT INTO marketing.CampaignAudience
        (Audience_Name, Audience_Type, Audience_Description, Audience_Status,
         Age_Range, Gender, Geographic_Location)
    VALUES
    (N'خانوارهای شهری', N'Consumer', N'خانوارهای شهری در داده ساختگی', N'Active', N'25-54', N'All', N'Urban-IR'),
    (N'جوانان آغاز مسیر', N'Consumer', N'مخاطبان جوان در مرحله آغاز خرید', N'Active', N'18-24', N'All', N'National-IR'),
    (N'مشتریان ارزش‌محور', N'Consumer', N'مخاطبان حساس به ارزش خرید', N'Active', N'25-44', N'All', N'National-IR'),
    (N'مشتریان ممتاز', N'Consumer', N'مخاطبان بخش ممتاز بازار', N'Active', N'35-64', N'All', N'Metro-IR'),
    (N'خریداران سازمانی', N'Business', N'سازمان‌های کوچک و متوسط ساختگی', N'Active', N'25-64', N'All', N'National-IR'),
    (N'خانواده‌های نوپا', N'Consumer', N'خانواده‌های در حال شکل‌گیری', N'Active', N'25-39', N'All', N'Urban-IR'),
    (N'مشتریان وفادار', N'Loyalty', N'مخاطبان دارای سابقه تعامل فرضی', N'Active', N'30-59', N'All', N'National-IR'),
    (N'علاقه‌مندان تخصصی', N'Interest', N'مخاطبان علاقه‌مند به گروه تخصصی محصول', N'Active', N'20-49', N'All', N'Metro-IR'),
    (N'مخاطبان عمومی آرشیوی', N'Consumer', N'گروه قدیمی برای داده تاریخی', N'Inactive', N'18-64', N'All', N'National-IR'),
    (N'خریداران آزمایشی سابق', N'Business', N'گروه آزمایشی غیرفعال', N'Inactive', N'25-64', N'All', N'Regional-IR');

    PRINT CONCAT(N'Inserted marketing.CampaignAudience rows: ', @@ROWCOUNT);

    /* Resolve generated Brand_ID values through the stable business key. */
    CREATE TABLE #BrandMap
    (
        Brand_ID int NOT NULL PRIMARY KEY,
        Brand_Code nvarchar(30) NOT NULL UNIQUE,
        Brand_Start_Date date NOT NULL,
        Brand_End_Date date NULL,
        Brand_Status nvarchar(30) NOT NULL
    );

    INSERT INTO #BrandMap (Brand_ID, Brand_Code, Brand_Start_Date, Brand_End_Date, Brand_Status)
    SELECT Brand_ID, Brand_Code, Brand_Start_Date, Brand_End_Date, Brand_Status
    FROM core.Brand
    WHERE Brand_Code LIKE N'T2S8BR%'
      AND Brand_Code IN
          (N'T2S8BR001',N'T2S8BR002',N'T2S8BR003',N'T2S8BR004',N'T2S8BR005',
           N'T2S8BR006',N'T2S8BR007',N'T2S8BR008',N'T2S8BR009',N'T2S8BR010');

    IF (SELECT COUNT(*) FROM #BrandMap) <> 10
        THROW 51008, 'Could not resolve exactly 10 inserted Team 2 brands.', 1;

    CREATE TABLE #ChannelMap
    (
        Channel_No int NOT NULL PRIMARY KEY,
        Channel_Name nvarchar(150) NOT NULL UNIQUE
    );

    INSERT INTO #ChannelMap (Channel_No, Channel_Name)
    SELECT ROW_NUMBER() OVER (ORDER BY Channel_Name), Channel_Name
    FROM marketing.CampaignChannel;

    /* Brand x Year is the BrandActivity parent grain for the generator. */
    ;WITH Years AS
    (
        SELECT v.Year_Number
        FROM (VALUES (2019),(2020),(2021),(2022),(2023),(2024),(2025),(2026),(2027)) v(Year_Number)
    ),
    BrandYearRaw AS
    (
        SELECT
            b.Brand_ID,
            b.Brand_Code,
            y.Year_Number,
            CASE WHEN DATEFROMPARTS(y.Year_Number,1,1) < @FromDate
                 THEN @FromDate ELSE DATEFROMPARTS(y.Year_Number,1,1) END AS Group_Start_Date,
            CASE
                WHEN b.Brand_End_Date IS NOT NULL AND b.Brand_End_Date < @ToDate
                     AND b.Brand_End_Date < DATEFROMPARTS(y.Year_Number,12,31)
                    THEN b.Brand_End_Date
                WHEN DATEFROMPARTS(y.Year_Number,12,31) > @ToDate
                    THEN @ToDate
                ELSE DATEFROMPARTS(y.Year_Number,12,31)
            END AS Group_End_Date
        FROM #BrandMap b
        CROSS JOIN Years y
        WHERE DATEFROMPARTS(y.Year_Number,1,1) <= @ToDate
          AND DATEFROMPARTS(y.Year_Number,12,31) >= @FromDate
          AND (b.Brand_End_Date IS NULL OR b.Brand_End_Date >= DATEFROMPARTS(y.Year_Number,1,1))
    ),
    BrandYear AS
    (
        SELECT *,
               ROW_NUMBER() OVER (ORDER BY Brand_Code, Year_Number) AS Group_No
        FROM BrandYearRaw
        WHERE Group_Start_Date <= Group_End_Date
    )
    SELECT
        Brand_ID, Brand_Code, Year_Number, Group_Start_Date, Group_End_Date, Group_No
    INTO #BrandYear
    FROM BrandYear;

    DECLARE @FullGroupCount int = (SELECT COUNT(*) FROM #BrandYear);
    SET @GroupCountTarget = CEILING(@FullGroupCount * @Scale);
    SET @ActivityRowsTarget = CEILING(@ExpectedFullActivityRows * @Scale);

    IF @GroupCountTarget < 1 OR @ActivityRowsTarget < @GroupCountTarget * 3
        THROW 51009, 'Scale cannot preserve the 3-8 activity-per-represented-brand-year grain.', 1;

    /* Allocate 3-8 rows per represented Brand x Year group.
       The specified target gives 48 rows across 9 groups at 10%,
       and 480 rows across all 88 groups at 100%. */
    ;WITH SelectedGroups AS
    (
        SELECT TOP (@GroupCountTarget) *
        FROM #BrandYear
        ORDER BY CASE WHEN @Scale >= 1.00 THEN 0
                      ELSE CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                           CONCAT(@Seed, N'|', Brand_Code, N'|', Year_Number, N'|sample')))) END,
                 Group_No
    ),
    GroupCounts AS
    (
        SELECT *,
               ROW_NUMBER() OVER (ORDER BY Group_No) AS Sel_No,
               @ActivityRowsTarget / @GroupCountTarget AS Base_Count,
               @ActivityRowsTarget % @GroupCountTarget AS Remainder_Count
        FROM SelectedGroups
    )
    SELECT
        Brand_ID, Brand_Code, Year_Number, Group_Start_Date, Group_End_Date,
        Group_No,
        Base_Count + CASE WHEN Sel_No <= Remainder_Count THEN 1 ELSE 0 END AS Activity_Count
    INTO #SelectedGroups
    FROM GroupCounts;

    CREATE TABLE #ActivityRows
    (
        Brand_ID int NOT NULL,
        Brand_Code nvarchar(30) NOT NULL,
        Year_Number int NOT NULL,
        Group_No int NOT NULL,
        Activity_No int NOT NULL,
        Group_Start_Date date NOT NULL,
        Group_End_Date date NOT NULL
    );

    INSERT INTO #ActivityRows
        (Brand_ID, Brand_Code, Year_Number, Group_No, Activity_No, Group_Start_Date, Group_End_Date)
    SELECT
        g.Brand_ID, g.Brand_Code, g.Year_Number, g.Group_No, n.Activity_No,
        g.Group_Start_Date, g.Group_End_Date
    FROM #SelectedGroups g
    CROSS JOIN (VALUES (1),(2),(3),(4),(5),(6),(7),(8)) n(Activity_No)
    WHERE n.Activity_No <= g.Activity_Count;

    /* 4) Transactional/event table: BrandActivity. */
    INSERT INTO marketing.BrandActivity
    (
        Brand_ID, Activity_Type, Activity_Title, Activity_Description,
        Activity_Start_Date, Activity_End_Date, Activity_Channel,
        Activity_Status, Activity_Owner, Activity_Cost, Currency, Activity_Result
    )
    SELECT
        a.Brand_ID,
        CASE CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
             CONCAT(@Seed, N'|', a.Brand_Code, N'|', a.Year_Number, N'|', a.Activity_No, N'|type')))) % 6
            WHEN 0 THEN N'PublicRelations'
            WHEN 1 THEN N'VisualIdentity'
            WHEN 2 THEN N'Event'
            WHEN 3 THEN N'ContentMarketing'
            WHEN 4 THEN N'Sponsorship'
            ELSE N'MarketActivation'
        END,
        CONCAT(N'فعالیت ', a.Activity_No, N' برند ', a.Brand_Code, N' - ', a.Year_Number),
        CASE a.Activity_No % 4
            WHEN 0 THEN N'اجرای برنامه محتوایی و پایش بازخورد مخاطبان در سناریوی ساختگی.'
            WHEN 1 THEN N'به‌روزرسانی دارایی‌های هویت بصری و اقلام ارتباطی آزمایشی.'
            WHEN 2 THEN N'برگزاری رویداد نمونه و ثبت خروجی‌های قابل ارزیابی.'
            ELSE N'اجرای برنامه ارتباطات برند و ارزیابی شاخص‌های عملکرد فرضی.'
        END,
        d.Activity_Start_Date,
        CASE WHEN d.Activity_Start_Date > @AsOfDate THEN NULL ELSE e.Activity_End_Date END,
        ch.Channel_Name,
        CASE WHEN d.Activity_Start_Date > @AsOfDate THEN N'Planned'
             WHEN e.Activity_End_Date >= @AsOfDate THEN N'InProgress'
             ELSE N'Completed'
        END,
        CASE a.Activity_No % 4
            WHEN 0 THEN N'واحد ارتباطات بازاریابی'
            WHEN 1 THEN N'واحد راهبرد برند'
            WHEN 2 THEN N'واحد مدیریت محصول'
            ELSE N'واحد تحقیقات بازار'
        END,
        CAST(2500000 + (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
             CONCAT(@Seed, N'|', a.Brand_Code, N'|', a.Year_Number, N'|', a.Activity_No, N'|cost')))) % 45000000)
             AS decimal(18,2)),
        'IRR',
        CASE WHEN e.Activity_End_Date < @AsOfDate
             THEN N'خروجی نمونه ثبت شد؛ شاخص‌های واقعی کسب‌وکار در این داده وجود ندارند.' END
    FROM #ActivityRows a
    CROSS APPLY
    (
        SELECT
            DATEADD(day,
                CONVERT(int, CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                    CONCAT(@Seed, N'|', a.Brand_Code, N'|', a.Year_Number, N'|', a.Activity_No, N'|date'))))
                    % (DATEDIFF(day, a.Group_Start_Date, a.Group_End_Date) + 1)),
                a.Group_Start_Date) AS Activity_Start_Date
    ) d
    CROSS APPLY
    (
        SELECT CASE WHEN DATEADD(day, CASE a.Activity_No % 3 WHEN 0 THEN 0 WHEN 1 THEN 7 ELSE 14 END,
                                 d.Activity_Start_Date) > a.Group_End_Date
                    THEN a.Group_End_Date
                    ELSE DATEADD(day, CASE a.Activity_No % 3 WHEN 0 THEN 0 WHEN 1 THEN 7 ELSE 14 END,
                                 d.Activity_Start_Date) END AS Activity_End_Date
    ) e
    CROSS APPLY
    (
        SELECT Channel_Name
        FROM #ChannelMap
        WHERE Channel_No =
            1 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                CONCAT(@Seed, N'|', a.Brand_Code, N'|', a.Year_Number, N'|', a.Activity_No, N'|channel')))) % 8
    ) ch;

    DECLARE @InsertedActivityRows int = @@ROWCOUNT;

    IF @InsertedActivityRows <> @ActivityRowsTarget
        THROW 51010, 'Inserted BrandActivity row count does not match the configured target.', 1;

    /* Post-insert business-rule guardrails inside the transaction. */
    IF EXISTS
    (
        SELECT 1
        FROM marketing.BrandActivity ba
        JOIN core.Brand b ON b.Brand_ID = ba.Brand_ID
        WHERE ba.Activity_Start_Date < b.Brand_Start_Date
           OR (b.Brand_End_Date IS NOT NULL AND ba.Activity_Start_Date > b.Brand_End_Date)
           OR (ba.Activity_End_Date IS NOT NULL AND ba.Activity_End_Date < ba.Activity_Start_Date)
           OR ba.Activity_Cost < 0
           OR ba.Currency <> 'IRR'
    )
        THROW 51011, 'BrandActivity business-rule validation failed; transaction will roll back.', 1;

    PRINT CONCAT(N'Inserted marketing.BrandActivity rows: ', @InsertedActivityRows);
    PRINT CONCAT(N'DataVersion: ', @DataVersion, N'; Seed: ', @Seed,
                 N'; Scale: ', @Scale, N'; Activity target: ', @ActivityRowsTarget);

    COMMIT TRANSACTION;
    IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
        INSERT #T2LoadLog (Script_Name, Table_Name, Input_Rows, Inserted_Rows)
        SELECT N'08-03-T2-01', t.Table_Name, t.Cnt, t.Cnt
        FROM (VALUES (N'core.Brand', (SELECT COUNT(*) FROM core.Brand)),
                     (N'marketing.CampaignChannel', (SELECT COUNT(*) FROM marketing.CampaignChannel)),
                     (N'marketing.CampaignAudience', (SELECT COUNT(*) FROM marketing.CampaignAudience)),
                     (N'marketing.BrandActivity', @InsertedActivityRows)) t(Table_Name, Cnt);
    PRINT N'Stage 8 Team 2 Brand/Channel/Audience/BrandActivity load completed successfully.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    DECLARE @ErrorMessage nvarchar(4000) = ERROR_MESSAGE();
    DECLARE @ErrorNumber int = ERROR_NUMBER();
    PRINT CONCAT(N'Load failed. Error ', @ErrorNumber, N': ', @ErrorMessage);
    THROW;
END CATCH;
GO
