/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.8: SinaSepasi, #196)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-05-Data-Quality-Checks.sql
 Version       : 1.2 (1.1: Q16 test for owner / responsible columns = role or unit names;
                 1.2, PM review 2026-11-07: Shamsi years from the fixed 1 Farvardin mapping #ShY; new tests
                 Q06 fixed-amount cap 25% of the reference price, Q12 base SKU = smallest pack, Q15 code
                 year = Shamsi year of the start date, Q15 price monitoring sample covers every leaf;
                 new Info rows: sample coverage, ROI / conversion by campaign type, ROI spread, price
                 position spread; no USE statement. Info rows only REPORT values - no target range is
                 added to make data pass. Q14 ranges are sanity ranges, not business targets.)
 Purpose       : Quality checks Q01..Q18 of the guide for the 24 Team 2 tables (merged from the members'
                 Checks files + new checks for 8.2, 8.4, 8.5). Read only: nothing is changed.
 Run Order     : after 08-04-Load-Data.sql, preferably in the SAME session (Q18 reads #T2LoadLog).
 Prerequisites : Team 2 load finished. Scale is read from SESSION_CONTEXT 'T2_Scale' (default 0.10).
 Seed/Config   : Seed 20261031 | MockData_v1.1_Seed20261031 | range 2019-03-21..2027-03-20 | IRR
 Date          : 2026-11-04
 Output        : 1) Test_ID | Table | Definition | Rows_Checked | Error_Count | Sample_Error_IDs | Result |
                    Owner | Run_At    (Result: Pass / Fail / Info / N/A)
                 2) summary by result   3) content fingerprint per table (Q17, compare two runs)
 Notes         : Q05 (calendar) and Q08..Q11 (order / invoice / payment / return) belong to Team 1
                 tables and are N/A here. Q14 is also covered in detail by 08-05-T2-KPI-Reconciliation.sql.
============================================================================= */
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;
SET NOCOUNT ON;
DROP TABLE IF EXISTS #QDef, #QE, #QOwner, #ShY;

DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10);
DECLARE @FromDate    date         = '2019-03-21';
DECLARE @ToDate      date         = '2027-03-20';
DECLARE @AsOfDate    date         = '2027-03-20';
DECLARE @RunAt       datetime2(0) = SYSDATETIME();   -- run time of the check (report only)

CREATE TABLE #QDef (Seq int IDENTITY(1,1) PRIMARY KEY, Test_ID nvarchar(10) NOT NULL, Table_Name nvarchar(128) NOT NULL,
                    Definition nvarchar(400) NOT NULL, Chk nvarchar(max) NOT NULL, Err nvarchar(max) NULL,
                    Kind nvarchar(10) NOT NULL DEFAULT N'Test',            -- Test | Info | N/A
                    Rows_Checked bigint NULL, Error_Count bigint NULL, Exec_Error nvarchar(400) NULL);
CREATE TABLE #QE (Seq int NOT NULL, Err_Key nvarchar(400) NOT NULL);
-- Shamsi years 1398..1405: Gregorian date of 1 Farvardin (same list as the generators 04, 05, 06)
CREATE TABLE #ShY (K int PRIMARY KEY, Shamsi_Year int NOT NULL, YS date NOT NULL, YE date NOT NULL);
INSERT #ShY (K, Shamsi_Year, YS, YE)
SELECT x.K, 1398 + x.K, x.YS, x.YE
FROM (SELECT v.K, CAST(v.YS AS date) AS YS, DATEADD(DAY, -1, CAST(LEAD(v.YS) OVER (ORDER BY v.K) AS date)) AS YE
      FROM (VALUES (0,'2019-03-21'),(1,'2020-03-20'),(2,'2021-03-21'),(3,'2022-03-21'),(4,'2023-03-21'),
                   (5,'2024-03-20'),(6,'2025-03-21'),(7,'2026-03-21'),(8,'2027-03-21')) v(K, YS)) x
WHERE x.K < 8;
CREATE TABLE #QOwner (Table_Name nvarchar(128) PRIMARY KEY, Owner nvarchar(60) NOT NULL);
INSERT #QOwner VALUES
 (N'core.Brand',N'8.3 Sahar-Sayyah'),(N'marketing.CampaignChannel',N'8.3 Sahar-Sayyah'),(N'marketing.CampaignAudience',N'8.3 Sahar-Sayyah'),
 (N'marketing.BrandActivity',N'8.3 Sahar-Sayyah'),(N'marketing.Market',N'8.6 Sosamimi'),(N'marketing.MarketSegment',N'8.6 Sosamimi'),
 (N'ref.ProductCategory',N'8.1 atieht'),(N'ref.Package',N'8.1 atieht'),(N'core.Product',N'8.1 atieht'),(N'core.SKU',N'8.1 atieht'),
 (N'marketing.MarketingCampaign',N'8.2 (by 8.8 SinaSepasi)'),(N'marketing.MarketingCampaignChannel',N'8.2 (by 8.8 SinaSepasi)'),
 (N'marketing.MarketingCampaignAudience',N'8.2 (by 8.8 SinaSepasi)'),(N'marketing.CampaignBudget',N'8.2 (by 8.8 SinaSepasi)'),
 (N'marketing.CampaignCost',N'8.2 (by 8.8 SinaSepasi)'),(N'marketing.CampaignResult',N'8.2 (by 8.8 SinaSepasi)'),
 (N'marketing.ProductPrice',N'8.7 M-Jafarian88'),(N'marketing.Promotion',N'8.7 M-Jafarian88'),
 (N'marketing.MarketResearch',N'8.4 (by 8.8 SinaSepasi)'),(N'marketing.MarketSurvey',N'8.4 (by 8.8 SinaSepasi)'),
 (N'marketing.ResearchResult',N'8.4 (by 8.8 SinaSepasi)'),(N'marketing.Competitor',N'8.5 (by 8.8 SinaSepasi)'),
 (N'marketing.CompetitorProduct',N'8.5 (by 8.8 SinaSepasi)'),(N'marketing.MarketPrice',N'8.5 (by 8.8 SinaSepasi)');

/* -----------------------------------------------------------------------------
   Test definitions. Chk = FROM-clause of the checked rows; Err = query that returns ONE
   column (the key of every bad row). Parameters available: @FromDate @ToDate @AsOfDate @Scale
----------------------------------------------------------------------------- */
-- Q01 row counts vs approved volume (min..max at 10% | at 100%), see 08-02-Data-Generation-Plan.xlsx
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err)
SELECT N'Q01', v.T, CONCAT(N'Row count within plan: 10% = ', v.a, N'..', v.b, N'; 100% = ', v.c, N'..', v.d), v.T,
       CONCAT(N'SELECT CONCAT(N''rows='', COUNT_BIG(*)) FROM ', v.T, N' HAVING COUNT_BIG(*) NOT BETWEEN CASE WHEN @Scale >= 1 THEN ', v.c,
              N' ELSE ', v.a, N' END AND CASE WHEN @Scale >= 1 THEN ', v.d, N' ELSE ', v.b, N' END')
FROM (VALUES (N'core.Brand',10,10,10,10), (N'marketing.CampaignChannel',8,8,8,8), (N'marketing.CampaignAudience',10,10,10,10),
             (N'marketing.BrandActivity',48,48,480,480), (N'marketing.Market',8,8,8,8), (N'marketing.MarketSegment',24,24,24,24),
             (N'ref.ProductCategory',35,35,35,35), (N'ref.Package',12,12,12,12), (N'core.Product',20,20,200,200), (N'core.SKU',30,50,300,500),
             (N'marketing.MarketingCampaign',10,10,92,92), (N'marketing.MarketingCampaignChannel',18,45,180,370),
             (N'marketing.MarketingCampaignAudience',12,32,140,280), (N'marketing.CampaignBudget',18,45,180,370),
             (N'marketing.CampaignCost',100,300,1200,2200), (N'marketing.CampaignResult',200,450,2400,3800),
             (N'marketing.ProductPrice',400,900,4500,8000), (N'marketing.Promotion',32,32,320,320),
             (N'marketing.MarketResearch',4,4,40,40), (N'marketing.MarketSurvey',1,20,60,120), (N'marketing.ResearchResult',1,15,50,110),
             (N'marketing.Competitor',15,15,15,15), (N'marketing.CompetitorProduct',15,45,60,130), (N'marketing.MarketPrice',5000,10000,20000,35000)) v(T,a,b,c,d);

-- Q02 primary / business keys unique
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err)
SELECT N'Q02', v.T, CONCAT(N'Unique in data: ', v.K), v.T,
       CONCAT(N'SELECT CONCAT_WS(N''/'', ', v.K, N', NULL) FROM ', v.T, N' GROUP BY ', v.K, N' HAVING COUNT(*) > 1')
FROM (VALUES (N'core.Brand',N'Brand_Code'), (N'core.Brand',N'Brand_Name'), (N'marketing.CampaignChannel',N'Channel_Name'),
             (N'marketing.CampaignAudience',N'Audience_Name'), (N'marketing.BrandActivity',N'Brand_ID, Activity_Title, Activity_Start_Date'),
             (N'marketing.Market',N'Market_Code'), (N'marketing.MarketSegment',N'Segment_Code'),
             (N'ref.ProductCategory',N'Category_Code'), (N'ref.Package',N'Package_Code'), (N'core.Product',N'Product_Code'),
             (N'core.Product',N'Brand_ID, Product_Name'), (N'core.SKU',N'SKU_Code'), (N'core.SKU',N'Barcode'),
             (N'marketing.MarketingCampaign',N'Campaign_Name'), (N'marketing.CampaignBudget',N'Marketing_Campaign_ID, Campaign_Channel_ID'),
             (N'marketing.CampaignCost',N'Marketing_Campaign_ID, Campaign_Channel_ID, Cost_Date'),
             (N'marketing.CampaignResult',N'Marketing_Campaign_ID, Metric_Name, Measurement_Date'),
             (N'marketing.ProductPrice',N'SKU_ID, Price_Type, Effective_From'), (N'marketing.Promotion',N'Promotion_Code'),
             (N'marketing.MarketResearch',N'Research_Title'), (N'marketing.MarketSurvey',N'Survey_Title'),
             (N'marketing.ResearchResult',N'Market_Research_ID, Result_Title'),
             (N'marketing.Competitor',N'Competitor_Name'), (N'marketing.CompetitorProduct',N'Competitor_ID, Competitor_Product_Name'),
             (N'marketing.MarketPrice',N'Market_ID, Product_ID, Competitor_Product_ID, Price_Date')) v(T, K);

-- Q03 orphan FKs and business relations
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q03',N'core.Product',N'Brand exists and category is a LEAF (level 2) category',N'core.Product',
  N'SELECT p.Product_Code FROM core.Product p LEFT JOIN core.Brand b ON b.Brand_ID = p.Brand_ID LEFT JOIN ref.ProductCategory c ON c.Product_Category_ID = p.Product_Category_ID WHERE b.Brand_ID IS NULL OR c.Category_Level <> 2 OR c.Product_Category_ID IS NULL'),
 (N'Q03',N'core.Product',N'Every product has at least one SKU',N'core.Product',
  N'SELECT p.Product_Code FROM core.Product p WHERE NOT EXISTS (SELECT 1 FROM core.SKU s WHERE s.Product_ID = p.Product_ID)'),
 (N'Q03',N'core.SKU',N'Product and Package exist',N'core.SKU',
  N'SELECT s.SKU_Code FROM core.SKU s LEFT JOIN core.Product p ON p.Product_ID = s.Product_ID LEFT JOIN ref.Package k ON k.Package_ID = s.Package_ID WHERE p.Product_ID IS NULL OR k.Package_ID IS NULL'),
 (N'Q03',N'marketing.BrandActivity',N'Brand exists',N'marketing.BrandActivity',
  N'SELECT a.Brand_Activity_ID FROM marketing.BrandActivity a LEFT JOIN core.Brand b ON b.Brand_ID = a.Brand_ID WHERE b.Brand_ID IS NULL'),
 (N'Q03',N'marketing.MarketSegment',N'Market exists',N'marketing.MarketSegment',
  N'SELECT s.Segment_Code FROM marketing.MarketSegment s LEFT JOIN marketing.Market m ON m.Market_ID = s.Market_ID WHERE m.Market_ID IS NULL'),
 (N'Q03',N'marketing.MarketingCampaign',N'Brand campaign has a Brand_ID; Marketing campaign has none',N'marketing.MarketingCampaign',
  N'SELECT Marketing_Campaign_ID FROM marketing.MarketingCampaign WHERE (Campaign_Purpose = N''Brand'' AND Brand_ID IS NULL) OR (Campaign_Purpose = N''Marketing'' AND Brand_ID IS NOT NULL)'),
 (N'Q03',N'marketing.MarketingCampaign',N'Every campaign has at least one channel and one audience',N'marketing.MarketingCampaign',
  N'SELECT c.Marketing_Campaign_ID FROM marketing.MarketingCampaign c WHERE NOT EXISTS (SELECT 1 FROM marketing.MarketingCampaignChannel x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) OR NOT EXISTS (SELECT 1 FROM marketing.MarketingCampaignAudience x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID)'),
 (N'Q03',N'marketing.CampaignBudget',N'Budget row has one row per campaign x linked channel (no missing budget)',N'marketing.MarketingCampaignChannel',
  N'SELECT CONCAT(x.Marketing_Campaign_ID, N''-'', x.Campaign_Channel_ID) FROM marketing.MarketingCampaignChannel x WHERE NOT EXISTS (SELECT 1 FROM marketing.CampaignBudget b WHERE b.Marketing_Campaign_ID = x.Marketing_Campaign_ID AND b.Campaign_Channel_ID = x.Campaign_Channel_ID)'),
 (N'Q03',N'marketing.CampaignCost',N'Cost channel has a budget for the same campaign',N'marketing.CampaignCost',
  N'SELECT c.Campaign_Cost_ID FROM marketing.CampaignCost c WHERE NOT EXISTS (SELECT 1 FROM marketing.CampaignBudget b WHERE b.Marketing_Campaign_ID = c.Marketing_Campaign_ID AND b.Campaign_Channel_ID = c.Campaign_Channel_ID)'),
 (N'Q03',N'marketing.Promotion',N'Linked campaign has Purpose Marketing and is not Cancelled',N'marketing.Promotion WHERE Marketing_Campaign_ID IS NOT NULL',
  N'SELECT p.Promotion_Code FROM marketing.Promotion p JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = p.Marketing_Campaign_ID WHERE c.Campaign_Purpose <> N''Marketing'' OR c.Campaign_Status = N''Cancelled'''),
 (N'Q03',N'marketing.MarketSurvey',N'Survey segment belongs to the market of its research (T2-S8-07)',N'marketing.MarketSurvey WHERE Market_Segment_ID IS NOT NULL',
  N'SELECT s.Survey_Title FROM marketing.MarketSurvey s JOIN marketing.MarketResearch r ON r.Market_Research_ID = s.Market_Research_ID JOIN marketing.MarketSegment g ON g.Market_Segment_ID = s.Market_Segment_ID WHERE g.Market_ID <> r.Market_ID'),
 (N'Q03',N'marketing.CompetitorProduct',N'Category text equals a leaf ref.ProductCategory.Category_Name (ISS-T2-KPI-10)',N'marketing.CompetitorProduct',
  N'SELECT cp.Competitor_Product_Name FROM marketing.CompetitorProduct cp WHERE NOT EXISTS (SELECT 1 FROM ref.ProductCategory c WHERE c.Category_Level = 2 AND c.Category_Name = cp.Category)'),
 (N'Q03',N'marketing.MarketPrice',N'Exactly one of Product_ID / Competitor_Product_ID; Market exists',N'marketing.MarketPrice',
  N'SELECT mp.Market_Price_ID FROM marketing.MarketPrice mp LEFT JOIN marketing.Market m ON m.Market_ID = mp.Market_ID WHERE m.Market_ID IS NULL OR (mp.Product_ID IS NULL AND mp.Competitor_Product_ID IS NULL) OR (mp.Product_ID IS NOT NULL AND mp.Competitor_Product_ID IS NOT NULL)');

-- Q04 dates inside the approved range (documented exceptions shown as Info)
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q04',N'marketing.MarketingCampaign',N'Start/End inside range',N'marketing.MarketingCampaign',
  N'SELECT Marketing_Campaign_ID FROM marketing.MarketingCampaign WHERE Start_Date NOT BETWEEN @FromDate AND @ToDate OR End_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.CampaignBudget',N'Approval_Date inside range',N'marketing.CampaignBudget',
  N'SELECT Campaign_Budget_ID FROM marketing.CampaignBudget WHERE Approval_Date NOT BETWEEN @FromDate AND @ToDate OR Approval_Date IS NULL'),
 (N'Q04',N'marketing.CampaignCost',N'Cost_Date inside range',N'marketing.CampaignCost',
  N'SELECT Campaign_Cost_ID FROM marketing.CampaignCost WHERE Cost_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.CampaignResult',N'Measurement_Date inside range',N'marketing.CampaignResult',
  N'SELECT Campaign_Result_ID FROM marketing.CampaignResult WHERE Measurement_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.ProductPrice',N'Effective_From/To inside range',N'marketing.ProductPrice',
  N'SELECT Product_Price_ID FROM marketing.ProductPrice WHERE Effective_From NOT BETWEEN @FromDate AND @ToDate OR Effective_To NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.Promotion',N'Start/End inside range',N'marketing.Promotion',
  N'SELECT Promotion_Code FROM marketing.Promotion WHERE Start_Date NOT BETWEEN @FromDate AND @ToDate OR End_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.BrandActivity',N'Activity dates inside range',N'marketing.BrandActivity',
  N'SELECT Brand_Activity_ID FROM marketing.BrandActivity WHERE Activity_Start_Date NOT BETWEEN @FromDate AND @ToDate OR Activity_End_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.MarketResearch',N'Start/End inside range',N'marketing.MarketResearch',
  N'SELECT Market_Research_ID FROM marketing.MarketResearch WHERE Start_Date NOT BETWEEN @FromDate AND @ToDate OR End_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.MarketSurvey',N'Survey_Date inside range',N'marketing.MarketSurvey',
  N'SELECT Market_Survey_ID FROM marketing.MarketSurvey WHERE Survey_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.ResearchResult',N'Result_Date inside range',N'marketing.ResearchResult',
  N'SELECT Research_Result_ID FROM marketing.ResearchResult WHERE Result_Date NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'marketing.MarketPrice',N'Price_Date inside range',N'marketing.MarketPrice',
  N'SELECT Market_Price_ID FROM marketing.MarketPrice WHERE CAST(Price_Date AS date) NOT BETWEEN @FromDate AND @ToDate'),
 (N'Q04',N'core.Product',N'Launch_Date between 1393/01/01 (2014-03-21) and @ToDate',N'core.Product',
  N'SELECT Product_Code FROM core.Product WHERE Launch_Date IS NULL OR Launch_Date NOT BETWEEN ''2014-03-21'' AND @ToDate'),
 (N'Q04',N'core.Brand',N'Brand_End_Date (if any) inside range',N'core.Brand',
  N'SELECT Brand_Code FROM core.Brand WHERE Brand_End_Date NOT BETWEEN @FromDate AND @ToDate');
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
 (N'Q04',N'core.Product',N'Documented exception T2-S8-09: products launched before 1398/01/01 (master attribute)',N'core.Product',
  N'SELECT Product_Code FROM core.Product WHERE Launch_Date < @FromDate', N'Info'),
 (N'Q04',N'core.Brand',N'Documented exception: Brand_Start_Date before 1398/01/01 (brands existed before the period)',N'core.Brand',
  N'SELECT Brand_Code FROM core.Brand WHERE Brand_Start_Date < @FromDate', N'Info');

-- Q05 calendar: not a Team 2 table
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
 (N'Q05',N'-',N'Calendar coverage: no date dimension in the Team 2 scope (Team 1 / shared)',N'(SELECT 1 AS x) q',NULL,N'N/A');

-- Q06 numeric domains
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q06',N'core.Product',N'Tax_Rate 0..100, Weight > 0',N'core.Product',
  N'SELECT Product_Code FROM core.Product WHERE Tax_Rate NOT BETWEEN 0 AND 100 OR Tax_Rate IS NULL OR Weight <= 0'),
 (N'Q06',N'core.SKU',N'Standard_Cost > 0 in IRR; Barcode 13 digits with valid EAN-13 check digit',N'core.SKU',
  N'SELECT SKU_Code FROM core.SKU s WHERE Standard_Cost IS NULL OR Standard_Cost <= 0 OR ISNULL(Currency, N''IRR'') <> N''IRR'' OR Barcode IS NULL OR LEN(Barcode) <> 13 OR Barcode LIKE N''%[^0-9]%''
     OR CONVERT(int, RIGHT(Barcode, 1)) <> (10 - ((CONVERT(int, SUBSTRING(Barcode,1,1)) + CONVERT(int, SUBSTRING(Barcode,3,1)) + CONVERT(int, SUBSTRING(Barcode,5,1)) + CONVERT(int, SUBSTRING(Barcode,7,1)) + CONVERT(int, SUBSTRING(Barcode,9,1)) + CONVERT(int, SUBSTRING(Barcode,11,1))
         + 3 * (CONVERT(int, SUBSTRING(Barcode,2,1)) + CONVERT(int, SUBSTRING(Barcode,4,1)) + CONVERT(int, SUBSTRING(Barcode,6,1)) + CONVERT(int, SUBSTRING(Barcode,8,1)) + CONVERT(int, SUBSTRING(Barcode,10,1)) + CONVERT(int, SUBSTRING(Barcode,12,1)))) % 10)) % 10'),
 (N'Q06',N'marketing.ProductPrice',N'Unit_Price > 0, IRR, and not below the SKU Standard_Cost',N'marketing.ProductPrice',
  N'SELECT pp.Product_Price_ID FROM marketing.ProductPrice pp JOIN core.SKU s ON s.SKU_ID = pp.SKU_ID WHERE pp.Unit_Price <= 0 OR pp.Unit_Price < s.Standard_Cost OR pp.Currency <> N''IRR'''),
 (N'Q06',N'marketing.Promotion',N'Percentage 0..25 without currency; Fixed Amount > 0 in IRR',N'marketing.Promotion',
  N'SELECT Promotion_Code FROM marketing.Promotion WHERE (Discount_Type = N''Percentage'' AND (Discount_Value <= 0 OR Discount_Value > 25 OR Currency IS NOT NULL)) OR (Discount_Type = N''Fixed Amount'' AND (Discount_Value <= 0 OR ISNULL(Currency, N'''') <> N''IRR'')) OR Discount_Type NOT IN (N''Percentage'', N''Fixed Amount'')'),
 (N'Q06',N'marketing.CampaignBudget',N'Total_Allocated_Amount > 0 in IRR',N'marketing.CampaignBudget',
  N'SELECT Campaign_Budget_ID FROM marketing.CampaignBudget WHERE Total_Allocated_Amount <= 0 OR Currency <> N''IRR'''),
 (N'Q06',N'marketing.CampaignCost',N'Actual_Spent >= 0 in IRR',N'marketing.CampaignCost',
  N'SELECT Campaign_Cost_ID FROM marketing.CampaignCost WHERE Actual_Spent < 0 OR Currency <> N''IRR'''),
 (N'Q06',N'marketing.CampaignResult',N'Metric_Value >= 0; Brand_Awareness_Pct 0..100; counts are whole numbers',N'marketing.CampaignResult',
  N'SELECT Campaign_Result_ID FROM marketing.CampaignResult WHERE Metric_Value < 0 OR (Metric_Name = N''Brand_Awareness_Pct'' AND Metric_Value > 100) OR (Metric_Name IN (N''Impressions'', N''Audience_Reached'', N''Conversions'', N''New_Customers'') AND Metric_Value <> FLOOR(Metric_Value))'),
 (N'Q06',N'marketing.MarketResearch',N'Research_Cost >= 0 with currency IRR',N'marketing.MarketResearch',
  N'SELECT Market_Research_ID FROM marketing.MarketResearch WHERE Research_Cost < 0 OR (Research_Cost IS NOT NULL AND ISNULL(Currency, N'''') <> N''IRR'')'),
 (N'Q06',N'marketing.MarketSurvey',N'Sample_Size > 0; Focus Group 6..40',N'marketing.MarketSurvey',
  N'SELECT Market_Survey_ID FROM marketing.MarketSurvey WHERE Sample_Size <= 0 OR (Survey_Method = N''Focus Group'' AND Sample_Size NOT BETWEEN 6 AND 40)'),
 (N'Q06',N'marketing.MarketPrice',N'Price_Value > 0 in IRR',N'marketing.MarketPrice',
  N'SELECT Market_Price_ID FROM marketing.MarketPrice WHERE Price_Value <= 0 OR Currency <> N''IRR'''),
 (N'Q06',N'marketing.BrandActivity',N'Activity_Cost >= 0 with currency',N'marketing.BrandActivity',
  N'SELECT Brand_Activity_ID FROM marketing.BrandActivity WHERE Activity_Cost < 0 OR (Activity_Cost IS NOT NULL AND Currency IS NULL)');

-- Q07 temporal order and status consistency
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q07',N'marketing.MarketingCampaign',N'Status follows dates: Completed has End < @AsOfDate; Active has End NULL or >= @AsOfDate; Planned starts after @AsOfDate',N'marketing.MarketingCampaign',
  N'SELECT Marketing_Campaign_ID FROM marketing.MarketingCampaign WHERE End_Date < Start_Date OR (Campaign_Status = N''Completed'' AND (End_Date IS NULL OR End_Date >= @AsOfDate)) OR (Campaign_Status = N''Active'' AND (Start_Date > @AsOfDate OR End_Date < @AsOfDate)) OR (Campaign_Status = N''Planned'' AND Start_Date <= @AsOfDate) OR Campaign_Status NOT IN (N''Completed'', N''Active'', N''Planned'', N''Cancelled'')'),
 (N'Q07',N'marketing.MarketingCampaign',N'Brand campaign lies inside the active dates of its brand',N'marketing.MarketingCampaign WHERE Campaign_Purpose = N''Brand''',
  N'SELECT c.Marketing_Campaign_ID FROM marketing.MarketingCampaign c JOIN core.Brand b ON b.Brand_ID = c.Brand_ID WHERE c.Start_Date < b.Brand_Start_Date OR (b.Brand_End_Date IS NOT NULL AND ISNULL(c.End_Date, @ToDate) > b.Brand_End_Date)'),
 (N'Q07',N'marketing.CampaignBudget',N'Approval_Date on or before campaign Start_Date',N'marketing.CampaignBudget',
  N'SELECT b.Campaign_Budget_ID FROM marketing.CampaignBudget b JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = b.Marketing_Campaign_ID WHERE b.Approval_Date > c.Start_Date'),
 (N'Q07',N'marketing.CampaignCost',N'Cost_Date inside the campaign period (open end = @AsOfDate)',N'marketing.CampaignCost',
  N'SELECT x.Campaign_Cost_ID FROM marketing.CampaignCost x JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = x.Marketing_Campaign_ID WHERE x.Cost_Date < c.Start_Date OR x.Cost_Date > ISNULL(c.End_Date, @AsOfDate) OR x.Cost_Date > @AsOfDate'),
 (N'Q07',N'marketing.CampaignResult',N'Measurement_Date inside the campaign period (open end = @AsOfDate)',N'marketing.CampaignResult',
  N'SELECT x.Campaign_Result_ID FROM marketing.CampaignResult x JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = x.Marketing_Campaign_ID WHERE x.Measurement_Date < c.Start_Date OR x.Measurement_Date > ISNULL(c.End_Date, @AsOfDate) OR x.Measurement_Date > @AsOfDate'),
 (N'Q07',N'marketing.Promotion',N'Linked promotion inside its campaign; status follows dates (Expired/Active/Planned)',N'marketing.Promotion',
  N'SELECT p.Promotion_Code FROM marketing.Promotion p LEFT JOIN marketing.MarketingCampaign c ON c.Marketing_Campaign_ID = p.Marketing_Campaign_ID WHERE p.End_Date < p.Start_Date OR (c.Marketing_Campaign_ID IS NOT NULL AND (p.Start_Date < c.Start_Date OR p.End_Date > ISNULL(c.End_Date, @ToDate))) OR (p.Promotion_Status = N''Expired'' AND p.End_Date >= @AsOfDate) OR (p.Promotion_Status = N''Planned'' AND p.Start_Date <= @AsOfDate) OR (p.Promotion_Status = N''Active'' AND (p.Start_Date > @AsOfDate OR p.End_Date < @AsOfDate))'),
 (N'Q07',N'core.Product',N'Created <= Launch; Updated >= Created; launch not before brand start',N'core.Product',
  N'SELECT p.Product_Code FROM core.Product p JOIN core.Brand b ON b.Brand_ID = p.Brand_ID WHERE CAST(p.Product_Created_Date AS date) > p.Launch_Date OR p.Product_Updated_Date < p.Product_Created_Date OR p.Launch_Date < b.Brand_Start_Date'),
 (N'Q07',N'marketing.BrandActivity',N'Start <= End; activity inside brand dates; Completed ends before @AsOfDate',N'marketing.BrandActivity',
  N'SELECT a.Brand_Activity_ID FROM marketing.BrandActivity a JOIN core.Brand b ON b.Brand_ID = a.Brand_ID WHERE a.Activity_End_Date < a.Activity_Start_Date OR a.Activity_Start_Date < b.Brand_Start_Date OR a.Activity_Start_Date > ISNULL(b.Brand_End_Date, @ToDate) OR (a.Activity_Status = N''Completed'' AND (a.Activity_End_Date IS NULL OR a.Activity_End_Date >= @AsOfDate))'),
 (N'Q07',N'marketing.MarketResearch',N'Completed has End_Date < @AsOfDate; InProgress / Cancelled have End_Date NULL; MKT-07 only before 2024-03-20',N'marketing.MarketResearch',
  N'SELECT r.Market_Research_ID FROM marketing.MarketResearch r JOIN marketing.Market m ON m.Market_ID = r.Market_ID WHERE (r.Research_Status = N''Completed'' AND (r.End_Date IS NULL OR r.End_Date >= @AsOfDate)) OR (r.Research_Status IN (N''InProgress'', N''Cancelled'') AND r.End_Date IS NOT NULL) OR r.Research_Status NOT IN (N''Completed'', N''InProgress'', N''Cancelled'', N''Planned'') OR (m.Market_Status = N''Inactive'' AND ISNULL(r.End_Date, @AsOfDate) >= ''2024-03-20'')'),
 (N'Q07',N'marketing.MarketSurvey',N'Survey_Date inside its research period (open end = @AsOfDate)',N'marketing.MarketSurvey',
  N'SELECT s.Market_Survey_ID FROM marketing.MarketSurvey s JOIN marketing.MarketResearch r ON r.Market_Research_ID = s.Market_Research_ID WHERE s.Survey_Date < r.Start_Date OR s.Survey_Date > ISNULL(r.End_Date, @AsOfDate)'),
 (N'Q07',N'marketing.ResearchResult',N'Results only for Completed research, Result_Date inside the research period',N'marketing.ResearchResult',
  N'SELECT x.Research_Result_ID FROM marketing.ResearchResult x JOIN marketing.MarketResearch r ON r.Market_Research_ID = x.Market_Research_ID WHERE r.Research_Status <> N''Completed'' OR x.Result_Date < r.Start_Date OR x.Result_Date > r.End_Date'),
 (N'Q07',N'marketing.MarketPrice',N'Own product observed only after its launch; inactive competitors have no price in the last 6 months',N'marketing.MarketPrice',
  N'SELECT mp.Market_Price_ID FROM marketing.MarketPrice mp LEFT JOIN core.Product p ON p.Product_ID = mp.Product_ID LEFT JOIN marketing.CompetitorProduct cp ON cp.Competitor_Product_ID = mp.Competitor_Product_ID LEFT JOIN marketing.Competitor k ON k.Competitor_ID = cp.Competitor_ID WHERE CAST(mp.Price_Date AS date) < p.Launch_Date OR (k.Competitor_Status = N''Inactive'' AND mp.Price_Date >= DATEADD(MONTH, -6, @AsOfDate))');

-- Q08..Q11 Team 1 scope
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
 (N'Q08',N'-',N'Order/Item reconciliation: Team 1 tables (sales.SalesOrder*)',N'(SELECT 1 AS x) q',NULL,N'N/A'),
 (N'Q09',N'-',N'Invoice reconciliation: Team 1 tables',N'(SELECT 1 AS x) q',NULL,N'N/A'),
 (N'Q10',N'-',N'Payment reconciliation: Team 1 tables',N'(SELECT 1 AS x) q',NULL,N'N/A'),
 (N'Q11',N'-',N'Return reconciliation: Team 1 tables',N'(SELECT 1 AS x) q',NULL,N'N/A');

-- Q12 price validity
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q12',N'marketing.ProductPrice',N'No overlapping periods per SKU x Price_Type',N'marketing.ProductPrice',
  N'SELECT a.Product_Price_ID FROM marketing.ProductPrice a JOIN marketing.ProductPrice b ON b.SKU_ID = a.SKU_ID AND b.Price_Type = a.Price_Type AND b.Product_Price_ID <> a.Product_Price_ID AND b.Effective_From <= ISNULL(a.Effective_To, ''9999-12-31'') AND a.Effective_From <= ISNULL(b.Effective_To, ''9999-12-31'')'),
 (N'Q12',N'marketing.ProductPrice',N'No gap: next period starts the day after the previous one ends; only the last period is open',N'marketing.ProductPrice',
  N'SELECT q.Product_Price_ID FROM (SELECT Product_Price_ID, Effective_To, LEAD(Effective_From) OVER (PARTITION BY SKU_ID, Price_Type ORDER BY Effective_From) AS Next_From FROM marketing.ProductPrice) q WHERE (q.Next_From IS NOT NULL AND (q.Effective_To IS NULL OR q.Next_From <> DATEADD(DAY, 1, q.Effective_To))) OR (q.Next_From IS NULL AND q.Effective_To IS NOT NULL)'),
 (N'Q12',N'marketing.ProductPrice',N'Price status: closed period = Expired; open period = Active (active SKU) or Inactive',N'marketing.ProductPrice',
  N'SELECT pp.Product_Price_ID FROM marketing.ProductPrice pp JOIN core.SKU s ON s.SKU_ID = pp.SKU_ID WHERE (pp.Effective_To IS NOT NULL AND pp.Price_Status <> N''Expired'') OR (pp.Effective_To IS NULL AND pp.Price_Status <> CASE WHEN s.SKU_Status = N''Active'' THEN N''Active'' ELSE N''Inactive'' END)'),
 (N'Q12',N'core.SKU',N'Every SKU has exactly one Standard price valid on @AsOfDate and a price from max(launch, @FromDate)',N'core.SKU',
  N'SELECT s.SKU_Code FROM core.SKU s JOIN core.Product p ON p.Product_ID = s.Product_ID WHERE (SELECT COUNT(*) FROM marketing.ProductPrice pp WHERE pp.SKU_ID = s.SKU_ID AND pp.Price_Type = N''Standard'' AND pp.Effective_From <= @AsOfDate AND ISNULL(pp.Effective_To, @AsOfDate) >= @AsOfDate) <> 1 OR NOT EXISTS (SELECT 1 FROM marketing.ProductPrice pp WHERE pp.SKU_ID = s.SKU_ID AND pp.Effective_From = CASE WHEN p.Launch_Date > @FromDate THEN p.Launch_Date ELSE @FromDate END)'),
 (N'Q12',N'marketing.MarketPrice',N'Own product observation has a valid list price (base SKU) on Price_Date',N'marketing.MarketPrice WHERE Product_ID IS NOT NULL',
  N'SELECT mp.Market_Price_ID FROM marketing.MarketPrice mp WHERE mp.Product_ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM core.SKU s JOIN marketing.ProductPrice pp ON pp.SKU_ID = s.SKU_ID WHERE s.Product_ID = mp.Product_ID AND pp.Effective_From <= CAST(mp.Price_Date AS date) AND ISNULL(pp.Effective_To, @ToDate) >= CAST(mp.Price_Date AS date))');

-- v1.2 (PM review): discount cap for every type; base SKU used by Team 1 = smallest pack
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q06',N'marketing.Promotion',N'Fixed Amount <= 25% of the reference price = 25th percentile of the Standard list prices valid on Start_Date (cap for every discount type, T2-S8-11)',N'marketing.Promotion WHERE Discount_Type = N''Fixed Amount''',
  N'SELECT p.Promotion_Code FROM marketing.Promotion p OUTER APPLY (SELECT TOP (1) PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY pp.Unit_Price) OVER () AS P25 FROM marketing.ProductPrice pp WHERE pp.Price_Type = N''Standard'' AND pp.Effective_From <= p.Start_Date AND (pp.Effective_To IS NULL OR pp.Effective_To >= p.Start_Date)) r WHERE p.Discount_Type = N''Fixed Amount'' AND (r.P25 IS NULL OR p.Discount_Value > 0.25 * r.P25)'),
 (N'Q12',N'core.SKU',N'Base SKU of a product (lowest SKU_Code, used for the Team 1 price) is its smallest pack (minimum SKU.Weight); SalesOrderItem.Quantity = number of base-SKU packs',N'core.Product',
  N'SELECT p.Product_Code FROM core.Product p CROSS APPLY (SELECT TOP (1) s.Weight FROM core.SKU s WHERE s.Product_ID = p.Product_ID ORDER BY s.SKU_Code) b WHERE b.Weight > (SELECT MIN(s.Weight) FROM core.SKU s WHERE s.Product_ID = p.Product_ID)');

-- Q13 campaign reconciliation
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q13',N'marketing.CampaignCost',N'Total cost of a campaign <= 125% of its budget (overrun scenario max 125%)',N'marketing.MarketingCampaign',
  N'SELECT c.Marketing_Campaign_ID FROM marketing.MarketingCampaign c CROSS APPLY (SELECT SUM(Total_Allocated_Amount) AS B FROM marketing.CampaignBudget b WHERE b.Marketing_Campaign_ID = c.Marketing_Campaign_ID) b CROSS APPLY (SELECT SUM(Actual_Spent) AS S FROM marketing.CampaignCost x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) s WHERE s.S > 1.25 * b.B'),
 (N'Q13',N'marketing.CampaignCost',N'Cancelled / Planned campaigns have no cost and no result; Completed / Active have both',N'marketing.MarketingCampaign',
  N'SELECT c.Marketing_Campaign_ID FROM marketing.MarketingCampaign c WHERE (c.Campaign_Status IN (N''Cancelled'', N''Planned'') AND (EXISTS (SELECT 1 FROM marketing.CampaignCost x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) OR EXISTS (SELECT 1 FROM marketing.CampaignResult x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID))) OR (c.Campaign_Status IN (N''Completed'', N''Active'') AND (NOT EXISTS (SELECT 1 FROM marketing.CampaignCost x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) OR NOT EXISTS (SELECT 1 FROM marketing.CampaignResult x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID)))'),
 (N'Q13',N'marketing.CampaignResult',N'Metric_Name in the approved list (ISS-T2-KPI-06)',N'marketing.CampaignResult',
  N'SELECT Campaign_Result_ID FROM marketing.CampaignResult WHERE Metric_Name NOT IN (N''Impressions'', N''Audience_Reached'', N''Conversions'', N''New_Customers'', N''Attributed_Revenue'', N''Brand_Awareness_Pct'')'),
 (N'Q13',N'marketing.CampaignResult',N'Weekly grain: the 5 core metrics on every measurement date; Impressions >= Audience_Reached >= Conversions >= New_Customers',N'marketing.CampaignResult WHERE Metric_Name <> N''Brand_Awareness_Pct''',
  N'SELECT CONCAT(Marketing_Campaign_ID, N''@'', Measurement_Date) FROM (SELECT Marketing_Campaign_ID, Measurement_Date, COUNT(*) AS N, MAX(CASE WHEN Metric_Name = N''Impressions'' THEN Metric_Value END) AS I, MAX(CASE WHEN Metric_Name = N''Audience_Reached'' THEN Metric_Value END) AS R, MAX(CASE WHEN Metric_Name = N''Conversions'' THEN Metric_Value END) AS C, MAX(CASE WHEN Metric_Name = N''New_Customers'' THEN Metric_Value END) AS NC FROM marketing.CampaignResult WHERE Metric_Name <> N''Brand_Awareness_Pct'' GROUP BY Marketing_Campaign_ID, Measurement_Date) q WHERE q.N <> 5 OR NOT (q.I >= q.R AND q.R >= q.C AND q.C >= q.NC)'),
 (N'Q13',N'marketing.CampaignResult',N'Measurement dates of a campaign are at most 7 days apart (weekly grain)',N'marketing.CampaignResult',
  N'SELECT CONCAT(q.Marketing_Campaign_ID, N''@'', q.Measurement_Date) FROM (SELECT Marketing_Campaign_ID, Measurement_Date, LAG(Measurement_Date) OVER (PARTITION BY Marketing_Campaign_ID ORDER BY Measurement_Date) AS Prev_Date FROM (SELECT DISTINCT Marketing_Campaign_ID, Measurement_Date FROM marketing.CampaignResult WHERE Metric_Name = N''Impressions'') d) q WHERE DATEDIFF(DAY, q.Prev_Date, q.Measurement_Date) > 7'),
 (N'Q13',N'marketing.CampaignBudget',N'Budget approved before the campaign start, for every linked channel (see Q03, Q07)',N'marketing.CampaignBudget',
  N'SELECT Campaign_Budget_ID FROM marketing.CampaignBudget WHERE Approval_Date IS NULL');
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
 (N'Q13',N'marketing.CampaignCost',N'Scenario: campaigns that spent more than 104% of budget (planned ~6%)',N'marketing.MarketingCampaign',
  N'SELECT c.Marketing_Campaign_ID FROM marketing.MarketingCampaign c CROSS APPLY (SELECT SUM(Total_Allocated_Amount) AS B FROM marketing.CampaignBudget b WHERE b.Marketing_Campaign_ID = c.Marketing_Campaign_ID) b CROSS APPLY (SELECT SUM(Actual_Spent) AS S FROM marketing.CampaignCost x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) s WHERE s.S > 1.04 * b.B', N'Info');

-- Q14 KPI reconciliation (independent recalculation of priority KPIs from raw rows)
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q14',N'marketing.CampaignResult',N'SSM-KPI-17 conversion rate = SUM(Conversions) / SUM(Audience_Reached) x 100 within sanity range 0.5..25% (formula-driven KPI, not a business target)',N'marketing.CampaignResult',
  N'SELECT CONCAT(N''rate='', CONVERT(decimal(9,2), 100.0 * SUM(CASE WHEN Metric_Name = N''Conversions'' THEN Metric_Value END) / NULLIF(SUM(CASE WHEN Metric_Name = N''Audience_Reached'' THEN Metric_Value END), 0))) FROM marketing.CampaignResult HAVING ISNULL(100.0 * SUM(CASE WHEN Metric_Name = N''Conversions'' THEN Metric_Value END) / NULLIF(SUM(CASE WHEN Metric_Name = N''Audience_Reached'' THEN Metric_Value END), 0), -1) NOT BETWEEN 0.5 AND 25'),
 (N'Q14',N'marketing.CampaignCost',N'SSM-KPI-19 ROI = (Attributed_Revenue - cost) / cost x 100 within sanity range 0..500% (formula-driven KPI, not a business target)',N'marketing.CampaignCost',
  N'SELECT CONCAT(N''roi='', CONVERT(decimal(9,2), q.ROI)) FROM (SELECT 100.0 * ((SELECT SUM(Metric_Value) FROM marketing.CampaignResult WHERE Metric_Name = N''Attributed_Revenue'') - SUM(Actual_Spent)) / NULLIF(SUM(Actual_Spent), 0) AS ROI FROM marketing.CampaignCost) q WHERE ISNULL(q.ROI, -1) NOT BETWEEN 0 AND 500'),
 (N'Q14',N'marketing.MarketResearch',N'MR-01-001 research completion = Completed / (started, not Cancelled) >= 90%',N'marketing.MarketResearch',
  N'SELECT CONCAT(N''pct='', CONVERT(decimal(9,2), q.P)) FROM (SELECT 100.0 * SUM(CASE WHEN Research_Status = N''Completed'' THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN Research_Status <> N''Cancelled'' AND Start_Date <= @AsOfDate THEN 1 ELSE 0 END), 0) AS P FROM marketing.MarketResearch) q WHERE ISNULL(q.P, -1) < 90'),
 (N'Q14',N'marketing.MarketPrice',N'MR-04-004 price index vs competitors (market x category x month) within sanity range 80..130 (synthetic benchmark on the monitoring sample)',N'marketing.MarketPrice',
  N'SELECT CONCAT(N''index='', CONVERT(decimal(9,2), AVG(100.0 * c.P / k.P))) FROM (SELECT mp.Market_ID, pc.Category_Name AS Cat, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1) AS M, AVG(mp.Price_Value) AS P FROM marketing.MarketPrice mp JOIN core.Product p ON p.Product_ID = mp.Product_ID JOIN ref.ProductCategory pc ON pc.Product_Category_ID = p.Product_Category_ID GROUP BY mp.Market_ID, pc.Category_Name, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1)) c JOIN (SELECT mp.Market_ID, cp.Category AS Cat, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1) AS M, AVG(mp.Price_Value) AS P FROM marketing.MarketPrice mp JOIN marketing.CompetitorProduct cp ON cp.Competitor_Product_ID = mp.Competitor_Product_ID GROUP BY mp.Market_ID, cp.Category, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1)) k ON k.Market_ID = c.Market_ID AND k.Cat = c.Cat AND k.M = c.M HAVING ISNULL(AVG(100.0 * c.P / k.P), -1) NOT BETWEEN 80 AND 130');

-- Q15 distribution sanity
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q15',N'marketing.MarketingCampaign',N'Every Shamsi year 1398..1405 has campaigns: 5..20 at 100%; at 10% the total is 10 (checked in Q01)',N'marketing.MarketingCampaign',
  N'SELECT CONCAT(y.Shamsi_Year, N'':'', COUNT(c.Marketing_Campaign_ID)) FROM #ShY y LEFT JOIN marketing.MarketingCampaign c ON c.Start_Date BETWEEN y.YS AND y.YE GROUP BY y.Shamsi_Year HAVING @Scale >= 1 AND COUNT(c.Marketing_Campaign_ID) NOT BETWEEN 5 AND 20'),
 (N'Q15',N'marketing.Promotion',N'Promotions per Shamsi year = 40 (100%) / 4 (10%)',N'marketing.Promotion',
  N'SELECT CONCAT(1398 + y.K, N'':'', COUNT(p.Promotion_ID)) FROM (SELECT TOP (8) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS K FROM sys.all_objects) y LEFT JOIN marketing.Promotion p ON p.Promotion_Code LIKE CONCAT(N''PRM-'', 1398 + y.K, N''-%'') GROUP BY y.K HAVING COUNT(p.Promotion_ID) <> CASE WHEN @Scale >= 1 THEN 40 ELSE 4 END'),
 (N'Q15',N'marketing.MarketPrice',N'Every month 2019-04..2027-03 has own and competitor observations',N'marketing.MarketPrice',
  N'SELECT CONVERT(char(7), m.M, 120) FROM (SELECT TOP (96) DATEADD(MONTH, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), ''2019-03-01'') AS M FROM sys.all_objects) m WHERE NOT EXISTS (SELECT 1 FROM marketing.MarketPrice mp WHERE mp.Product_ID IS NOT NULL AND mp.Price_Date >= m.M AND mp.Price_Date < DATEADD(MONTH, 1, m.M)) OR NOT EXISTS (SELECT 1 FROM marketing.MarketPrice mp WHERE mp.Competitor_Product_ID IS NOT NULL AND mp.Price_Date >= m.M AND mp.Price_Date < DATEADD(MONTH, 1, m.M))'),
 (N'Q15',N'core.Product',N'Brand share of products <= 25% and (100%) every brand has products',N'core.Brand',
  N'SELECT b.Brand_Code FROM core.Brand b OUTER APPLY (SELECT COUNT(*) AS N FROM core.Product p WHERE p.Brand_ID = b.Brand_ID) x WHERE x.N > 0.25 * (SELECT COUNT(*) FROM core.Product) OR (@Scale >= 1 AND x.N = 0)'),
 (N'Q15',N'core.Product',N'Every leaf category has products (100% only)',N'ref.ProductCategory WHERE Category_Level = 2',
  N'SELECT c.Category_Code FROM ref.ProductCategory c WHERE @Scale >= 1 AND c.Category_Level = 2 AND NOT EXISTS (SELECT 1 FROM core.Product p WHERE p.Product_Category_ID = c.Product_Category_ID)'),
 (N'Q15',N'marketing.MarketingCampaignChannel',N'Every active channel is used by at least one campaign (100% only)',N'marketing.CampaignChannel',
  N'SELECT ch.Channel_Name FROM marketing.CampaignChannel ch WHERE @Scale >= 1 AND ch.Channel_Status = N''Active'' AND NOT EXISTS (SELECT 1 FROM marketing.MarketingCampaignChannel x WHERE x.Campaign_Channel_ID = ch.Campaign_Channel_ID)'),
 (N'Q15',N'marketing.MarketResearch',N'Research spread: every Shamsi year has research projects (100% only)',N'marketing.MarketResearch',
  N'SELECT CONCAT(y.Shamsi_Year, N'':0'') FROM #ShY y WHERE @Scale >= 1 AND NOT EXISTS (SELECT 1 FROM marketing.MarketResearch r WHERE r.Start_Date BETWEEN y.YS AND y.YE)'),
 (N'Q15',N'marketing.MarketingCampaign; marketing.Promotion; marketing.MarketResearch',N'Shamsi year in the business key [CMP-yyyy] / PRM-yyyy / [MR-yyyy] = Shamsi year of Start_Date (1 Farvardin mapping, not DATEADD(YEAR))',
  N'(SELECT 1 AS x FROM marketing.MarketingCampaign UNION ALL SELECT 1 FROM marketing.Promotion UNION ALL SELECT 1 FROM marketing.MarketResearch) q',
  N'SELECT t.K FROM (
      SELECT CONCAT(N''Campaign:'', Marketing_Campaign_ID) AS K, TRY_CONVERT(int, SUBSTRING(Campaign_Name, CHARINDEX(N''[CMP-'', Campaign_Name) + 5, 4)) AS Yr, Start_Date FROM marketing.MarketingCampaign
      UNION ALL SELECT Promotion_Code, TRY_CONVERT(int, SUBSTRING(Promotion_Code, 5, 4)), Start_Date FROM marketing.Promotion
      UNION ALL SELECT CONCAT(N''Research:'', Market_Research_ID), TRY_CONVERT(int, SUBSTRING(Research_Title, CHARINDEX(N''[MR-'', Research_Title) + 4, 4)), Start_Date FROM marketing.MarketResearch) t
    LEFT JOIN #ShY y ON t.Start_Date BETWEEN y.YS AND y.YE
    WHERE t.Yr IS NULL OR y.Shamsi_Year IS NULL OR t.Yr <> y.Shamsi_Year'),
 (N'Q15',N'marketing.MarketPrice',N'Price monitoring sample: every leaf category with an active product has own-product AND competitor observations',N'ref.ProductCategory WHERE Category_Level = 2',
  N'SELECT c.Category_Code FROM ref.ProductCategory c WHERE c.Category_Level = 2 AND EXISTS (SELECT 1 FROM core.Product p WHERE p.Product_Category_ID = c.Product_Category_ID AND p.Product_Status = N''Active'') AND (NOT EXISTS (SELECT 1 FROM marketing.MarketPrice mp JOIN core.Product p ON p.Product_ID = mp.Product_ID WHERE p.Product_Category_ID = c.Product_Category_ID) OR NOT EXISTS (SELECT 1 FROM marketing.MarketPrice mp JOIN marketing.CompetitorProduct cp ON cp.Competitor_Product_ID = mp.Competitor_Product_ID WHERE cp.Category = c.Category_Name))');

-- Q15 Info rows (v1.2): they only REPORT the values (one line), no target range
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
 (N'Q15',N'marketing.MarketPrice',N'Coverage of the price monitoring sample (active products, leaf categories, markets, products per month)',N'marketing.MarketPrice',
  N'SELECT CONCAT(N''products '', o.NP, N''/'', a.NA, N'' ('', CONVERT(decimal(5,1), 100.0 * o.NP / NULLIF(a.NA, 0)), N''%); leaf categories '', o.NC, N''/'', a.NL, N''; markets '', o.NM, N''; own products per month '', mm.MinP, N''..'', mm.MaxP) FROM (SELECT COUNT(DISTINCT mp.Product_ID) AS NP, COUNT(DISTINCT p.Product_Category_ID) AS NC, COUNT(DISTINCT mp.Market_ID) AS NM FROM marketing.MarketPrice mp JOIN core.Product p ON p.Product_ID = mp.Product_ID) o CROSS JOIN (SELECT (SELECT COUNT(*) FROM core.Product WHERE Product_Status = N''Active'') AS NA, (SELECT COUNT(DISTINCT Product_Category_ID) FROM core.Product WHERE Product_Status = N''Active'') AS NL) a CROSS JOIN (SELECT MIN(N) AS MinP, MAX(N) AS MaxP FROM (SELECT COUNT(DISTINCT Product_ID) AS N FROM marketing.MarketPrice WHERE Product_ID IS NOT NULL GROUP BY DATEFROMPARTS(YEAR(Price_Date), MONTH(Price_Date), 1)) x) mm', N'Info'),
 (N'Q15',N'marketing.CampaignResult',N'Campaign ROI % and conversion rate % by Campaign_Type (formula-driven synthetic data, report only)',N'marketing.MarketingCampaign',
  N'SELECT STRING_AGG(CONCAT(q.Campaign_Type, N'': ROI '', CONVERT(decimal(9,1), 100.0 * (q.Rev - q.Cost) / NULLIF(q.Cost, 0)), N''% CR '', CONVERT(decimal(9,2), 100.0 * q.Conv / NULLIF(q.Reach, 0)), N''%''), N''; '') WITHIN GROUP (ORDER BY q.Campaign_Type) FROM (SELECT c.Campaign_Type, SUM(r.Rev) AS Rev, SUM(k.Cost) AS Cost, SUM(r.Conv) AS Conv, SUM(r.Reach) AS Reach FROM marketing.MarketingCampaign c CROSS APPLY (SELECT SUM(Actual_Spent) AS Cost FROM marketing.CampaignCost x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) k CROSS APPLY (SELECT SUM(CASE WHEN Metric_Name = N''Attributed_Revenue'' THEN Metric_Value END) AS Rev, SUM(CASE WHEN Metric_Name = N''Conversions'' THEN Metric_Value END) AS Conv, SUM(CASE WHEN Metric_Name = N''Audience_Reached'' THEN Metric_Value END) AS Reach FROM marketing.CampaignResult x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) r WHERE k.Cost > 0 GROUP BY c.Campaign_Type) q', N'Info'),
 (N'Q15',N'marketing.CampaignResult',N'Spread of campaign ROI (campaigns with cost): negative / 0-100% / 100-300% / above 300%',N'marketing.MarketingCampaign',
  N'SELECT CONCAT(N''ROI<0: '', SUM(CASE WHEN q.ROI < 0 THEN 1 ELSE 0 END), N''; 0-100%: '', SUM(CASE WHEN q.ROI >= 0 AND q.ROI < 100 THEN 1 ELSE 0 END), N''; 100-300%: '', SUM(CASE WHEN q.ROI >= 100 AND q.ROI < 300 THEN 1 ELSE 0 END), N''; >=300%: '', SUM(CASE WHEN q.ROI >= 300 THEN 1 ELSE 0 END), N''; min '', CONVERT(decimal(9,1), MIN(q.ROI)), N''% max '', CONVERT(decimal(9,1), MAX(q.ROI)), N''%'') FROM (SELECT 100.0 * (r.Rev - k.Cost) / k.Cost AS ROI FROM marketing.MarketingCampaign c CROSS APPLY (SELECT SUM(Actual_Spent) AS Cost FROM marketing.CampaignCost x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID) k CROSS APPLY (SELECT SUM(Metric_Value) AS Rev FROM marketing.CampaignResult x WHERE x.Marketing_Campaign_ID = c.Marketing_Campaign_ID AND x.Metric_Name = N''Attributed_Revenue'') r WHERE k.Cost > 0) q', N'Info'),
 (N'Q15',N'marketing.MarketPrice',N'Price position spread (market x category x month groups): we are cheaper (<95), at parity (95-105), more expensive (>105); index min..max',N'marketing.MarketPrice',
  N'SELECT CONCAT(N''groups '', COUNT(*), N''; <95: '', SUM(CASE WHEN g.I < 95 THEN 1 ELSE 0 END), N''; 95-105: '', SUM(CASE WHEN g.I BETWEEN 95 AND 105 THEN 1 ELSE 0 END), N''; >105: '', SUM(CASE WHEN g.I > 105 THEN 1 ELSE 0 END), N''; index '', CONVERT(decimal(9,1), MIN(g.I)), N''..'', CONVERT(decimal(9,1), MAX(g.I))) FROM (SELECT 100.0 * c.P / k.P AS I FROM (SELECT mp.Market_ID, pc.Category_Name AS Cat, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1) AS M, AVG(mp.Price_Value) AS P FROM marketing.MarketPrice mp JOIN core.Product p ON p.Product_ID = mp.Product_ID JOIN ref.ProductCategory pc ON pc.Product_Category_ID = p.Product_Category_ID GROUP BY mp.Market_ID, pc.Category_Name, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1)) c JOIN (SELECT mp.Market_ID, cp.Category AS Cat, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1) AS M, AVG(mp.Price_Value) AS P FROM marketing.MarketPrice mp JOIN marketing.CompetitorProduct cp ON cp.Competitor_Product_ID = mp.Competitor_Product_ID GROUP BY mp.Market_ID, cp.Category, DATEFROMPARTS(YEAR(mp.Price_Date), MONTH(mp.Price_Date), 1)) k ON k.Market_ID = c.Market_ID AND k.Cat = c.Cat AND k.M = c.M) g', N'Info');

-- Q16 privacy: no e-mail, URL or phone number in any Team 2 text column
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q16',N'(all Team 2 text columns)',N'No e-mail (@), URL (http/www) or phone-like number (10+ digits outside barcode) in text columns',
  N'(SELECT 1 AS x FROM core.Brand UNION ALL SELECT 1 FROM marketing.CampaignChannel UNION ALL SELECT 1 FROM marketing.CampaignAudience UNION ALL SELECT 1 FROM marketing.BrandActivity UNION ALL SELECT 1 FROM core.Product UNION ALL SELECT 1 FROM marketing.MarketingCampaign UNION ALL SELECT 1 FROM marketing.Promotion UNION ALL SELECT 1 FROM marketing.MarketResearch UNION ALL SELECT 1 FROM marketing.MarketSurvey UNION ALL SELECT 1 FROM marketing.ResearchResult UNION ALL SELECT 1 FROM marketing.Competitor UNION ALL SELECT 1 FROM marketing.MarketSegment) q',
  N'SELECT t.K FROM (
      SELECT CONCAT(N''Brand:'', Brand_Code) AS K, Brand_Name AS Txt FROM core.Brand
      UNION ALL SELECT CONCAT(N''Channel:'', Campaign_Channel_ID), CONCAT_WS(N'' '', Channel_Name, Channel_Description) FROM marketing.CampaignChannel
      UNION ALL SELECT CONCAT(N''Audience:'', Campaign_Audience_ID), CONCAT_WS(N'' '', Audience_Name, Audience_Description, Geographic_Location) FROM marketing.CampaignAudience
      UNION ALL SELECT CONCAT(N''Activity:'', Brand_Activity_ID), CONCAT_WS(N'' '', Activity_Title, Activity_Description, Activity_Owner, Activity_Result) FROM marketing.BrandActivity
      UNION ALL SELECT CONCAT(N''Product:'', Product_Code), CONCAT_WS(N'' '', Product_Name, Product_Description) FROM core.Product
      UNION ALL SELECT CONCAT(N''Campaign:'', Marketing_Campaign_ID), CONCAT_WS(N'' '', Campaign_Name, Campaign_Objective) FROM marketing.MarketingCampaign
      UNION ALL SELECT CONCAT(N''Promotion:'', Promotion_Code), Promotion_Name FROM marketing.Promotion
      UNION ALL SELECT CONCAT(N''Research:'', Market_Research_ID), CONCAT_WS(N'' '', Research_Title, Responsible_Person) FROM marketing.MarketResearch
      UNION ALL SELECT CONCAT(N''Survey:'', Market_Survey_ID), Survey_Title FROM marketing.MarketSurvey
      UNION ALL SELECT CONCAT(N''Result:'', Research_Result_ID), CONCAT_WS(N'' '', Result_Title, Result_Summary, Recommendation, Opportunity_Identified) FROM marketing.ResearchResult
      UNION ALL SELECT CONCAT(N''Competitor:'', Competitor_ID), Competitor_Name FROM marketing.Competitor
      UNION ALL SELECT CONCAT(N''Segment:'', Segment_Code), CONCAT_WS(N'' '', Segment_Name, Segment_Description) FROM marketing.MarketSegment) t
    WHERE t.Txt LIKE N''%@%'' OR t.Txt LIKE N''%http%'' OR t.Txt LIKE N''%www.%'' OR t.Txt LIKE N''%[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]%''');
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
 (N'Q16',N'core.Brand; marketing.BrandActivity; marketing.MarketResearch',N'Owner / responsible columns hold a unit or role (starts with واحد / مدیر / کارشناس), never a person name (shared contract 6)',
  N'(SELECT 1 AS x FROM core.Brand UNION ALL SELECT 1 FROM marketing.BrandActivity UNION ALL SELECT 1 FROM marketing.MarketResearch) q',
  N'SELECT t.K FROM (
      SELECT CONCAT(N''Brand:'', Brand_Code) AS K, Brand_Owner AS V FROM core.Brand
      UNION ALL SELECT CONCAT(N''Activity:'', Brand_Activity_ID), Activity_Owner FROM marketing.BrandActivity
      UNION ALL SELECT CONCAT(N''Research:'', Market_Research_ID), Responsible_Person FROM marketing.MarketResearch) t
    WHERE t.V IS NOT NULL AND t.V NOT LIKE N''واحد %'' AND t.V NOT LIKE N''مدیر %'' AND t.V NOT LIKE N''کارشناس %''');
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
 (N'Q16',N'(design)',N'All brand, competitor, person and place names are fictional; Brand_Owner / Activity_Owner / Responsible_Person hold unit or role names, not person names; no customer or contact data is generated by Team 2',N'(SELECT 1 AS x) q',NULL,N'Info');

-- Q18 load log (needs #T2LoadLog of 08-04 in the same session)
IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
    INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err) VALUES
     (N'Q18',N'(all Team 2 tables)',N'Every table has a load-log row with Inserted = rows in table and Rejected = 0',N'#T2LoadLog',
      N'SELECT v.T FROM (VALUES (N''core.Brand''),(N''marketing.CampaignChannel''),(N''marketing.CampaignAudience''),(N''marketing.BrandActivity''),(N''marketing.Market''),(N''marketing.MarketSegment''),(N''ref.ProductCategory''),(N''ref.Package''),(N''core.Product''),(N''core.SKU''),(N''marketing.MarketingCampaign''),(N''marketing.MarketingCampaignChannel''),(N''marketing.MarketingCampaignAudience''),(N''marketing.CampaignBudget''),(N''marketing.CampaignCost''),(N''marketing.CampaignResult''),(N''marketing.ProductPrice''),(N''marketing.Promotion''),(N''marketing.MarketResearch''),(N''marketing.MarketSurvey''),(N''marketing.ResearchResult''),(N''marketing.Competitor''),(N''marketing.CompetitorProduct''),(N''marketing.MarketPrice'')) v(T) OUTER APPLY (SELECT SUM(Inserted_Rows) AS Ins, SUM(Input_Rows - Inserted_Rows) AS Rej FROM #T2LoadLog l WHERE l.Table_Name = v.T) l OUTER APPLY (SELECT SUM(ps.row_count) AS N FROM sys.dm_db_partition_stats ps WHERE ps.object_id = OBJECT_ID(v.T) AND ps.index_id IN (0, 1)) p WHERE l.Ins IS NULL OR l.Ins <> p.N OR l.Rej <> 0');
ELSE
    INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
     (N'Q18',N'(all Team 2 tables)',N'Load log: run this file in the same session as 08-04-Load-Data.sql to compare #T2LoadLog with the tables',N'(SELECT 1 AS x) q',NULL,N'N/A');

-- Q17 repeatability: fingerprint below; Info row
INSERT #QDef (Test_ID, Table_Name, Definition, Chk, Err, Kind) VALUES
 (N'Q17',N'(all Team 2 tables)',N'Repeatability: content fingerprint (SHA2-256 per table, result set 3) must be equal for two runs with the same Seed and Scale',N'(SELECT 1 AS x) q',NULL,N'Info');

/* -----------------------------------------------------------------------------
   Run the tests
----------------------------------------------------------------------------- */
DECLARE @Seq int = 1, @Max int = (SELECT MAX(Seq) FROM #QDef), @Chk nvarchar(max), @Err nvarchar(max), @Sql nvarchar(max), @N bigint;
DECLARE @Params nvarchar(200) = N'@FromDate date, @ToDate date, @AsOfDate date, @Scale decimal(5,2), @Seq int, @N bigint OUTPUT';
WHILE @Seq <= @Max
BEGIN
    SELECT @Chk = Chk, @Err = Err FROM #QDef WHERE Seq = @Seq;
    BEGIN TRY
        SET @Sql = N'SELECT @N = COUNT_BIG(*) FROM ' + @Chk + N';';
        EXEC sp_executesql @Sql, @Params, @FromDate, @ToDate, @AsOfDate, @Scale, @Seq, @N OUTPUT;
        UPDATE #QDef SET Rows_Checked = @N WHERE Seq = @Seq;
        IF @Err IS NOT NULL
        BEGIN
            SET @Sql = N'INSERT #QE (Seq, Err_Key) SELECT @Seq, CONVERT(nvarchar(400), q.k) FROM (' + @Err + N') q(k);';
            EXEC sp_executesql @Sql, @Params, @FromDate, @ToDate, @AsOfDate, @Scale, @Seq, @N OUTPUT;
        END
    END TRY
    BEGIN CATCH
        UPDATE #QDef SET Exec_Error = LEFT(ERROR_MESSAGE(), 400) WHERE Seq = @Seq;
    END CATCH;
    SET @Seq += 1;
END;

UPDATE d SET Error_Count = ISNULL(e.N, 0)
FROM #QDef d LEFT JOIN (SELECT Seq, COUNT_BIG(*) AS N FROM #QE GROUP BY Seq) e ON e.Seq = d.Seq;

/* -----------------------------------------------------------------------------
   Report
----------------------------------------------------------------------------- */
PRINT CONCAT(N'08-05-Data-Quality-Checks | ', @DataVersion, N' | Scale = ', @Scale, N' | AsOf = ', CONVERT(char(10), @AsOfDate, 23));

SELECT d.Test_ID, d.Table_Name, d.Definition, d.Rows_Checked, d.Error_Count,
       ISNULL((SELECT STRING_AGG(x.Err_Key, N', ') FROM (SELECT TOP (5) Err_Key FROM #QE e WHERE e.Seq = d.Seq ORDER BY Err_Key) x), N'') AS Sample_Error_IDs,
       CASE WHEN d.Exec_Error IS NOT NULL THEN N'Fail'
            WHEN d.Kind IN (N'Info', N'N/A') THEN d.Kind
            WHEN d.Error_Count = 0 THEN N'Pass' ELSE N'Fail' END AS Result,
       ISNULL(o.Owner, N'8.8 SinaSepasi') AS Owner,
       CONVERT(char(19), @RunAt, 120) AS Run_At,
       CONCAT(N'Scale ', @Scale) AS Run_Label,
       d.Exec_Error
FROM #QDef d LEFT JOIN #QOwner o ON o.Table_Name = d.Table_Name
ORDER BY d.Test_ID, d.Seq;

SELECT CASE WHEN d.Exec_Error IS NOT NULL THEN N'Fail' WHEN d.Kind IN (N'Info', N'N/A') THEN d.Kind
            WHEN d.Error_Count = 0 THEN N'Pass' ELSE N'Fail' END AS Result, COUNT(*) AS Tests
FROM #QDef d
GROUP BY CASE WHEN d.Exec_Error IS NOT NULL THEN N'Fail' WHEN d.Kind IN (N'Info', N'N/A') THEN d.Kind
              WHEN d.Error_Count = 0 THEN N'Pass' ELSE N'Fail' END;

/* Q17 content fingerprint: all columns of every row, ordered by the primary key */
DECLARE @FP TABLE (Ord int, Table_Name nvarchar(128), Row_Count bigint, Fingerprint char(64));
DECLARE @T nvarchar(128), @Pk sysname, @Ord int = 1, @Rows bigint, @Hash varbinary(32);
DECLARE @L TABLE (Ord int PRIMARY KEY, T nvarchar(128));
INSERT @L VALUES (1,N'core.Brand'),(2,N'marketing.CampaignChannel'),(3,N'marketing.CampaignAudience'),(4,N'marketing.BrandActivity'),
                 (5,N'marketing.Market'),(6,N'marketing.MarketSegment'),(7,N'ref.ProductCategory'),(8,N'ref.Package'),(9,N'core.Product'),
                 (10,N'core.SKU'),(11,N'marketing.MarketingCampaign'),(12,N'marketing.MarketingCampaignChannel'),(13,N'marketing.MarketingCampaignAudience'),
                 (14,N'marketing.CampaignBudget'),(15,N'marketing.CampaignCost'),(16,N'marketing.CampaignResult'),(17,N'marketing.ProductPrice'),
                 (18,N'marketing.Promotion'),(19,N'marketing.MarketResearch'),(20,N'marketing.MarketSurvey'),(21,N'marketing.ResearchResult'),
                 (22,N'marketing.Competitor'),(23,N'marketing.CompetitorProduct'),(24,N'marketing.MarketPrice');
WHILE @Ord <= 24
BEGIN
    SELECT @T = T FROM @L WHERE Ord = @Ord;
    SELECT @Pk = STRING_AGG(QUOTENAME(c.name), N', ') WITHIN GROUP (ORDER BY ic.key_ordinal)
    FROM sys.indexes i JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
    WHERE i.object_id = OBJECT_ID(@T) AND i.is_primary_key = 1;
    SET @Sql = N'SELECT @Rows = COUNT_BIG(*), @Hash = HASHBYTES(''SHA2_256'', (SELECT * FROM ' + @T + N' ORDER BY ' + @Pk + N' FOR JSON PATH, INCLUDE_NULL_VALUES)) FROM ' + @T + N';';
    EXEC sp_executesql @Sql, N'@Rows bigint OUTPUT, @Hash varbinary(32) OUTPUT', @Rows OUTPUT, @Hash OUTPUT;
    INSERT @FP VALUES (@Ord, @T, @Rows, CONVERT(char(64), @Hash, 2));
    SET @Ord += 1;
END;
SELECT Ord, Table_Name, Row_Count, Fingerprint FROM @FP ORDER BY Ord;
GO
