/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.2 / #190; written by SinaSepasi in 8.8 / #196
                 because no file was delivered for 8.2)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T2-04-Campaign.sql
 Version       : 1.1 (PM review 2026-11-07, see "Changes in 1.1" below)
 Purpose       : Generate marketing campaigns and their channel / audience links, budgets,
                 weekly costs and weekly results.
 Data nature   : FORMULA-DRIVEN SYNTHETIC DATA. Campaign results are derived from the generator
                 formulas (Revenue = weekly spend x ROAS; Conversions = Revenue / order value;
                 Audience_Reached = Conversions / conversion rate; Impressions = reach x frequency;
                 New_Customers = share of conversions). KPIs such as conversion rate, ROI and CAC
                 are therefore NOT independent of the generator: a KPI in range only shows that the
                 synthetic data follows the designed scenario, not a business result.
 Run Order     : 4 (after 01 Brand-Channel-Audience and 03 Product-Catalog; before 05 Promotion-Price)
 Prerequisites : core.Brand, marketing.CampaignChannel, marketing.CampaignAudience loaded (01);
                 core.Product loaded (03, used for product-launch campaigns).
                 The 6 target tables must be EMPTY (clean only with 08-03-T2-00-Reset.sql).
 Seed/Config   : Seed 20261031 | Scale from SESSION_CONTEXT 'T2_Scale' (default 0.10) | IRR
 Date          : 2026-11-04
 Tables        : marketing.MarketingCampaign, marketing.MarketingCampaignChannel,
                 marketing.MarketingCampaignAudience, marketing.CampaignBudget,
                 marketing.CampaignCost, marketing.CampaignResult
 Rules         : - Shamsi year k (k = 0..7, 1398..1405) has 8 + k campaign slots (92 in total);
                   the 10% run keeps the slots with the smallest hash (same rules, fewer rows).
                 - Occasions: Nowruz (from Esfand), Ramadan, summer, school opening, Yalda, autumn
                   sale + brand awareness, product launch (linked to a real Launch_Date), online
                   and loyalty campaigns.
                 - Campaign_Purpose = Brand (Brand_ID inside the brand's active dates) for brand and
                   launch campaigns, otherwise Marketing (Brand_ID NULL).
                 - Status at @AsOfDate: Completed / Active / Cancelled (~5% of older campaigns).
                   The loyalty programme of the last year is open-ended (End_Date NULL, Active).
                 - Campaign_Name ends with the business key [CMP-yyyy-nn] (the table has no code column).
                 - Channels 1-4 and audiences 1-3 by campaign type; inactive (legacy) channel and
                   audiences only for campaigns that start before 2021-03-21.
                 - Budget per campaign x channel, approved 7-30 days before the start; amounts are
                   1398 base amounts x cumulative inflation index (same rates as script 05).
                 - Weekly cost per channel, total 80%-104% of budget (overrun 110%-125% for ~6%);
                   Cancelled campaigns have budget only (no cost, no result).
                 - Weekly results (flow values of that week, not cumulative):
                   Impressions >= Audience_Reached >= Conversions >= New_Customers, Attributed_Revenue
                   (IRR); Brand campaigns also have Brand_Awareness_Pct at the start and at the end.
 Notes         : No schema change, no IDENTITY_INSERT, no trigger/constraint disabled; parents are
                 looked up by business key (Channel_Type, Audience_Type, Brand_Code, Product_Code).
                 Inflation index is computed with decimal only (no EXP/LOG float, guide section 4).
 Changes in 1.1: 1. Shamsi years come from a fixed mapping of 1 Farvardin (#ShY, checked with .NET
                    PersianCalendar): 1399 and 1403 start on 20 March, the others on 21 March
                    (1.0 used DATEADD(YEAR) from 2019-03-21, one day off in some years).
                 2. Performance scenarios instead of one formula: every campaign gets a tier
                    Loss 15% / Low 25% / Mid 45% / High 15% (ROAS 0.45-0.85 / 1.0-1.8 / 1.8-3.5 /
                    3.5-6.0), multiplied by a campaign-type factor (BrandAwareness 0.55 ..
                    Loyalty 1.20), the budget-weighted channel factor (Outdoor 0.65 .. Email 1.25)
                    and the audience factor (Interest 0.90 .. Loyalty 1.25). Loss campaigns are
                    capped at ROAS 0.85 so that, with the weekly noise (max x1.15), their FINAL
                    revenue stays below their actual cost (checked, error 50414). Brand and launch
                    campaigns can lose money without being in the Loss tier.
                 3. Conversion rate depends on campaign type (0.8% brand .. 7% loyalty), tier and
                    campaign (x0.75..1.25); order value is higher for Business audiences (x2.5);
                    frequency and new-customer share depend on the type.
                 4. No USE statement (database chosen in 08-04); DataVersion MockData_v1.1.
============================================================================= */
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;
SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #CInfl, #CIdx, #ShY, #Tpl, #ChW, #AuW, #RmzAnchor, #C, #CC, #CA, #CB, #CW, #CCost, #CRes, #TypF, #ChF, #AuF;

------------------------------------------------------------------------------
-- 1. Settings
------------------------------------------------------------------------------
DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10);
DECLARE @FromDate    date         = '2019-03-21';  -- 1398/01/01
DECLARE @ToDate      date         = '2027-03-20';  -- 1405/12/29
DECLARE @AsOfDate    date         = '2027-03-20';  -- status reference date (T2-S8-04)

DECLARE @Currency      char(3) = 'IRR';
DECLARE @NYears        int     = 8;
DECLARE @SlotsYear0    int     = 8;               -- slots in 1398; +1 every year
DECLARE @CancelPct     int     = 5;               -- % of older campaigns cancelled
DECLARE @OverrunPct    int     = 6;               -- % of campaigns that spend above budget
DECLARE @LossPct       int     = 15;              -- % of campaigns in the Loss tier (final revenue < cost)
DECLARE @LowPct        int     = 25;              -- % Low tier  (ROAS 1.0..1.8 before factors)
DECLARE @MidPct        int     = 45;              -- % Mid tier  (ROAS 1.8..3.5); the rest (15%) High (3.5..6.0)
DECLARE @LegacyCutoff  date    = '2021-03-21';    -- inactive channel/audience only before this date
DECLARE @Rows_MC int = 0, @Rows_CH int = 0, @Rows_AU int = 0, @Rows_B int = 0, @Rows_C int = 0, @Rows_R int = 0;

------------------------------------------------------------------------------
-- 2. Guards
------------------------------------------------------------------------------
IF EXISTS (SELECT 1 FROM marketing.MarketingCampaign) OR EXISTS (SELECT 1 FROM marketing.MarketingCampaignChannel)
   OR EXISTS (SELECT 1 FROM marketing.MarketingCampaignAudience) OR EXISTS (SELECT 1 FROM marketing.CampaignBudget)
   OR EXISTS (SELECT 1 FROM marketing.CampaignCost) OR EXISTS (SELECT 1 FROM marketing.CampaignResult)
    THROW 50401, N'STOP: campaign tables already have rows. Clean only with 08-03-T2-00-Reset.sql.', 1;
IF NOT EXISTS (SELECT 1 FROM core.Brand WHERE Brand_Code LIKE N'T2S8BR%')
    THROW 50402, N'STOP: core.Brand is empty. Run 08-03-T2-01 first.', 1;
IF NOT EXISTS (SELECT 1 FROM marketing.CampaignChannel WHERE Channel_Status = N'Active')
   OR NOT EXISTS (SELECT 1 FROM marketing.CampaignAudience WHERE Audience_Status = N'Active')
    THROW 50403, N'STOP: no active CampaignChannel / CampaignAudience. Run 08-03-T2-01 first.', 1;
IF NOT EXISTS (SELECT 1 FROM core.Product)
    PRINT N'WARNING: core.Product is empty - launch campaigns fall back to brand-only campaigns.';

BEGIN TRY
------------------------------------------------------------------------------
-- 3. Reference lists
------------------------------------------------------------------------------
-- 3.1 inflation index (same annual rates as 08-03-T2-05, 1.0000 in 1398/01)
CREATE TABLE #CInfl (Yr int PRIMARY KEY, Rate decimal(6,4) NOT NULL);
INSERT #CInfl VALUES (2019,0.3500),(2020,0.3600),(2021,0.4200),(2022,0.4500),(2023,0.4200),
                     (2024,0.3200),(2025,0.3800),(2026,0.3500),(2027,0.3500);
CREATE TABLE #CIdx (Month_Start date PRIMARY KEY, Idx decimal(18,6) NOT NULL);
;WITH m AS (   -- decimal only (no EXP/LOG float): Idx(next month) = Idx(month) x (1 + annual rate / 12)
    SELECT DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1) AS Month_Start, CAST(1 AS decimal(18,6)) AS Idx
    UNION ALL
    SELECT DATEADD(MONTH, 1, m.Month_Start), CAST(m.Idx * (1 + i.Rate / 12) AS decimal(18,6))
    FROM m JOIN #CInfl i ON i.Yr = YEAR(m.Month_Start)
    WHERE DATEADD(MONTH, 1, m.Month_Start) <= DATEFROMPARTS(YEAR(@ToDate), MONTH(@ToDate), 1))
INSERT #CIdx (Month_Start, Idx)
SELECT Month_Start, Idx FROM m OPTION (MAXRECURSION 200);

-- 3.1b Shamsi years 1398..1405: Gregorian date of 1 Farvardin (checked with .NET PersianCalendar;
--      same list in 05, 06, 08-05 and 08-03-T2-Settings.txt). K = 8 (1406) only closes 1405.
CREATE TABLE #ShY (K int PRIMARY KEY, Shamsi_Year int NOT NULL, YS date NOT NULL, YE date NOT NULL);
INSERT #ShY (K, Shamsi_Year, YS, YE)
SELECT x.K, 1398 + x.K, x.YS, x.YE
FROM (SELECT v.K, CAST(v.YS AS date) AS YS, DATEADD(DAY, -1, CAST(LEAD(v.YS) OVER (ORDER BY v.K) AS date)) AS YE
      FROM (VALUES (0,'2019-03-21'),(1,'2020-03-20'),(2,'2021-03-21'),(3,'2022-03-21'),(4,'2023-03-21'),
                   (5,'2024-03-20'),(6,'2025-03-21'),(7,'2026-03-21'),(8,'2027-03-21')) v(K, YS)) x
WHERE x.K < 8;
IF (SELECT MIN(YS) FROM #ShY) <> @FromDate OR (SELECT MAX(YE) FROM #ShY) <> @ToDate
    THROW 50409, N'Internal error: Shamsi year mapping does not match @FromDate / @ToDate.', 1;

-- 3.1c performance factors (v1.1): campaign type, channel, audience
CREATE TABLE #TypF (Campaign_Type nvarchar(30) PRIMARY KEY, Roas_F decimal(5,3) NOT NULL, Cr_Base decimal(6,4) NOT NULL,
                    Fq_Min int NOT NULL, Fq_Rng int NOT NULL, Nc_Min int NOT NULL, Nc_Rng int NOT NULL);
INSERT #TypF VALUES   -- ROAS factor | base conversion rate | frequency x100 | new-customer share %
 (N'Promotional',   1.150, 0.0450, 250, 251, 10, 21),
 (N'Seasonal',      1.100, 0.0350, 250, 301, 10, 21),
 (N'Digital',       1.050, 0.0220, 200, 201, 15, 21),
 (N'Loyalty',       1.200, 0.0700, 150, 151,  3,  8),
 (N'ProductLaunch', 0.750, 0.0200, 300, 301, 25, 21),
 (N'BrandAwareness',0.550, 0.0080, 400, 401, 25, 21);
CREATE TABLE #ChF (Channel_Type nvarchar(50) PRIMARY KEY, F decimal(5,3) NOT NULL);
INSERT #ChF VALUES (N'Digital',1.100),(N'Social',0.950),(N'Direct',1.200),(N'Event',0.750),
                   (N'Email',1.250),(N'Outdoor',0.650),(N'Partner',1.000),(N'Legacy',0.800);
CREATE TABLE #AuF (Audience_Type nvarchar(50) PRIMARY KEY, F decimal(5,3) NOT NULL, Aov_F decimal(5,2) NOT NULL);
INSERT #AuF VALUES (N'Consumer',1.000,1.00),(N'Business',1.100,2.50),(N'Loyalty',1.250,1.00),(N'Interest',0.900,1.00);

-- 3.2 slot templates: slot J of every year (year k uses J = 1 .. 8 + k)
CREATE TABLE #Tpl (J int PRIMARY KEY, Tcode char(3) NOT NULL, Campaign_Type nvarchar(30) NOT NULL, Purpose nvarchar(30) NOT NULL,
                   Name_FA nvarchar(60) NOT NULL, Dur_Min int NOT NULL, Dur_Rng int NOT NULL,
                   Base_Min int NOT NULL, Base_Rng int NOT NULL,          -- budget in million IRR at 1398 prices
                   Ch_Min int NOT NULL, Ch_Rng int NOT NULL, Au_Min int NOT NULL, Au_Rng int NOT NULL,
                   Objective nvarchar(500) NOT NULL);
INSERT #Tpl VALUES
 ( 1,'NWR',N'Seasonal',      N'Marketing',N'کمپین نوروز',           28,13, 2500,3500, 3,2, 2,2, N'افزایش فروش سبد کالای نوروزی و جذب مشتری جدید پیش از تعطیلات نوروز'),
 ( 2,'RMZ',N'Seasonal',      N'Marketing',N'کمپین ماه رمضان',       30, 8, 2500,3500, 3,2, 2,2, N'افزایش فروش اقلام پرمصرف ماه رمضان مانند روغن، برنج، خرما و حبوبات و حفظ سهم بازار'),
 ( 3,'SUM',N'Promotional',   N'Marketing',N'کمپین فروش تابستانه',   30,16, 1500,2500, 2,2, 1,3, N'تحریک تقاضای تابستانی با پیشنهاد قیمتی برای نوشیدنی‌ها، لبنیات و تنقلات'),
 ( 4,'SCH',N'Seasonal',      N'Marketing',N'کمپین بازگشایی مدارس',  21,10, 2500,3500, 3,2, 2,2, N'معرفی سبد خرید بازگشایی مدارس و افزایش فروش محصولات صبحانه و میان‌وعده'),
 ( 5,'BRD',N'BrandAwareness',N'Brand',    N'کمپین آگاهی از برند',   45,46, 3000,5000, 2,3, 1,3, N'افزایش آگاهی و شناخت مخاطب از برند و بهبود جایگاه آن نسبت به رقبا'),
 ( 6,'YLD',N'Seasonal',      N'Marketing',N'کمپین شب یلدا',         18, 4, 2500,3500, 3,2, 2,2, N'افزایش فروش آجیل، خشکبار و شیرینی در آستانه شب یلدا'),
 ( 7,'DIG',N'Digital',       N'Marketing',N'کمپین فروش آنلاین',     20,21,  800,1200, 2,2, 1,3, N'افزایش تعامل و فروش از کانال‌های دیجیتال و فروشگاه آنلاین'),
 ( 8,'LCH',N'ProductLaunch', N'Brand',    N'کمپین معرفی محصول',     30,31, 2000,3000, 2,3, 1,3, N'معرفی محصول جدید به بازار و رساندن آن به فروشگاه‌ها و مصرف‌کنندگان هدف'),
 ( 9,'LOY',N'Loyalty',       N'Marketing',N'برنامه وفاداری مشتریان',90,31, 1000,1500, 1,2, 1,2, N'افزایش خرید تکراری و حفظ مشتریان وفادار با برنامه امتیاز و پیشنهاد اختصاصی'),
 (10,'BRD',N'BrandAwareness',N'Brand',    N'کمپین آگاهی از برند',   45,46, 3000,5000, 2,3, 1,3, N'افزایش آگاهی و شناخت مخاطب از برند و بهبود جایگاه آن نسبت به رقبا'),
 (11,'DIG',N'Digital',       N'Marketing',N'کمپین فروش آنلاین',     20,21,  800,1200, 2,2, 1,3, N'افزایش تعامل و فروش از کانال‌های دیجیتال و فروشگاه آنلاین'),
 (12,'PRM',N'Promotional',   N'Marketing',N'کمپین حراج پاییزه',     21,15, 1500,2500, 2,2, 1,3, N'افزایش گردش کالا و کاهش موجودی فصل با حراج پاییزه در فروشگاه‌های زنجیره‌ای'),
 (13,'LCH',N'ProductLaunch', N'Brand',    N'کمپین معرفی محصول',     30,31, 2000,3000, 2,3, 1,3, N'معرفی محصول جدید به بازار و رساندن آن به فروشگاه‌ها و مصرف‌کنندگان هدف'),
 (14,'BRD',N'BrandAwareness',N'Brand',    N'کمپین آگاهی از برند',   45,46, 3000,5000, 2,3, 1,3, N'افزایش آگاهی و شناخت مخاطب از برند و بهبود جایگاه آن نسبت به رقبا'),
 (15,'DIG',N'Digital',       N'Marketing',N'کمپین فروش آنلاین',     20,21,  800,1200, 2,2, 1,3, N'افزایش تعامل و فروش از کانال‌های دیجیتال و فروشگاه آنلاین');

-- 3.3 channel weight by campaign type x Channel_Type (0 = never used)
CREATE TABLE #ChW (Campaign_Type nvarchar(30) NOT NULL, Channel_Type nvarchar(50) NOT NULL, W int NOT NULL, PRIMARY KEY (Campaign_Type, Channel_Type));
INSERT #ChW
SELECT v.Campaign_Type, c.Channel_Type, c.W
FROM (VALUES (N'Seasonal',3,3,3,1,2,3,2,1), (N'BrandAwareness',2,3,0,2,1,4,2,1), (N'ProductLaunch',2,3,1,4,1,2,2,0),
             (N'Promotional',2,2,4,0,3,1,1,1), (N'Digital',4,4,0,0,3,0,1,0), (N'Loyalty',1,1,4,1,4,0,0,1))
     v(Campaign_Type, wDig, wSoc, wDir, wEvt, wEml, wOut, wPar, wLeg)
CROSS APPLY (VALUES (N'Digital',v.wDig),(N'Social',v.wSoc),(N'Direct',v.wDir),(N'Event',v.wEvt),
                    (N'Email',v.wEml),(N'Outdoor',v.wOut),(N'Partner',v.wPar),(N'Legacy',v.wLeg)) c(Channel_Type, W);

-- 3.4 audience weight by campaign type x Audience_Type
CREATE TABLE #AuW (Campaign_Type nvarchar(30) NOT NULL, Audience_Type nvarchar(50) NOT NULL, W int NOT NULL, PRIMARY KEY (Campaign_Type, Audience_Type));
INSERT #AuW
SELECT v.Campaign_Type, a.Audience_Type, a.W
FROM (VALUES (N'Seasonal',3,2,1,1), (N'BrandAwareness',3,0,1,2), (N'ProductLaunch',2,1,1,3),
             (N'Promotional',3,2,2,0), (N'Digital',3,0,1,2), (N'Loyalty',0,1,5,0)) v(Campaign_Type, wCon, wBus, wLoy, wInt)
CROSS APPLY (VALUES (N'Consumer',v.wCon),(N'Business',v.wBus),(N'Loyalty',v.wLoy),(N'Interest',v.wInt)) a(Audience_Type, W);

-- 3.5 approximate first day of Ramadan inside Shamsi year k (same anchors as script 05)
CREATE TABLE #RmzAnchor (K int PRIMARY KEY, Anchor date NOT NULL);
INSERT #RmzAnchor VALUES (0,'2019-05-06'),(1,'2020-04-24'),(2,'2021-04-13'),(3,'2022-04-02'),
                         (4,'2023-03-23'),(5,'2025-03-01'),(6,'2026-02-18'),(7,'2027-02-08');

------------------------------------------------------------------------------
-- 4. Campaign skeleton
------------------------------------------------------------------------------
CREATE TABLE #C (
    Code nvarchar(20) NOT NULL PRIMARY KEY, K int NOT NULL, J int NOT NULL, Tcode char(3) NOT NULL,
    Campaign_Type nvarchar(30) NOT NULL, Purpose nvarchar(30) NOT NULL, Name_FA nvarchar(60) NOT NULL,
    YS date NOT NULL, YE date NOT NULL, Dur int NULL, Start_Date date NULL, End_Date date NULL,
    Brand_ID int NULL, Brand_Name nvarchar(150) NULL, Product_Name nvarchar(150) NULL,
    Status nvarchar(30) NULL, Campaign_Name nvarchar(150) NULL, Objective nvarchar(500) NULL,
    Marketing_Campaign_ID int NULL, Budget_Total decimal(18,2) NULL, Spend_Ratio decimal(6,4) NULL,
    ROAS decimal(6,3) NULL, Plan_End date NULL,
    Perf_Tier nvarchar(10) NULL, Cr decimal(8,5) NULL, Aov_F decimal(5,2) NULL);   -- v1.1 scenario columns (not loaded)

;WITH y AS (SELECT TOP (@NYears) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS K FROM sys.all_objects),
all_slots AS (
    SELECT y.K, t.J, CONCAT(N'CMP-', 1398 + y.K, N'-', RIGHT(CONCAT(N'0', t.J), 2)) AS Code
    FROM y JOIN #Tpl t ON t.J <= @SlotsYear0 + y.K),
ranked AS (
    SELECT s.*, ROW_NUMBER() OVER (ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', s.Code, N'|0|sel')))), s.Code) AS Sel_No,
           COUNT(*) OVER () AS N_All
    FROM all_slots s)
INSERT #C (Code, K, J, Tcode, Campaign_Type, Purpose, Name_FA, YS, YE, Objective)
SELECT r.Code, r.K, r.J, t.Tcode, t.Campaign_Type, t.Purpose, t.Name_FA,
       sy.YS, sy.YE,                                   -- v1.1: real Shamsi year (#ShY)
       t.Objective
FROM ranked r JOIN #Tpl t ON t.J = r.J
JOIN #ShY sy ON sy.K = r.K
WHERE r.Sel_No <= CASE WHEN @Scale >= 1 THEN r.N_All ELSE CEILING(r.N_All * @Scale) END;

-- 4.1 dates by occasion
UPDATE c SET Dur = d.Dur,
             Start_Date = s.S
FROM #C c
JOIN #Tpl t ON t.J = c.J
LEFT JOIN #RmzAnchor ra ON ra.K = c.K
CROSS APPLY (SELECT CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|dur')))) AS HD,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|off')))) AS HO) h
CROSS APPLY (SELECT t.Dur_Min + h.HD % t.Dur_Rng AS Dur) d
CROSS APPLY (SELECT CASE c.Tcode
        WHEN 'NWR' THEN DATEADD(DAY, 335 + h.HO % 8, c.YS)                                  -- from early Esfand
        WHEN 'RMZ' THEN DATEADD(DAY, -7 + h.HO % 4, ra.Anchor)
        WHEN 'SUM' THEN DATEADD(DAY, h.HO % 10, DATEFROMPARTS(YEAR(c.YS), 6, 22))
        WHEN 'SCH' THEN DATEADD(DAY, h.HO % 8,  DATEFROMPARTS(YEAR(c.YS), 8, 25))
        WHEN 'YLD' THEN DATEADD(DAY, h.HO % 5,  DATEFROMPARTS(YEAR(c.YS), 12, 1))
        WHEN 'PRM' THEN DATEADD(DAY, h.HO % 10, DATEFROMPARTS(YEAR(c.YS), 10, 20))
        ELSE DATEADD(DAY, 15 + h.HO % (DATEDIFF(DAY, c.YS, c.YE) - 15 - d.Dur), c.YS) END AS S) s;

-- 4.2 launch campaigns: linked to a product launched in that year (brand of the product)
;WITH cand AS (
    SELECT c.Code, p.Product_Name, p.Launch_Date, b.Brand_ID, b.Brand_Name,
           ROW_NUMBER() OVER (PARTITION BY c.Code ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                CONCAT(@Seed, N'|CMP|', c.Code, N'|', p.Product_Code, N'|lch')))), p.Product_Code) AS Rn
    FROM #C c
    JOIN core.Product p ON p.Launch_Date BETWEEN DATEADD(DAY, 7, c.YS) AND DATEADD(DAY, -c.Dur, c.YE)
    JOIN core.Brand b   ON b.Brand_ID = p.Brand_ID
    WHERE c.Tcode = 'LCH'
      AND (b.Brand_End_Date IS NULL OR b.Brand_End_Date >= DATEADD(DAY, c.Dur, p.Launch_Date))
      AND NOT EXISTS (SELECT 1 FROM #C c2 WHERE c2.K = c.K AND c2.Tcode = 'LCH' AND c2.J < c.J)   -- 1st launch slot of the year
    UNION ALL
    SELECT c.Code, p.Product_Name, p.Launch_Date, b.Brand_ID, b.Brand_Name,
           ROW_NUMBER() OVER (PARTITION BY c.Code ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                CONCAT(@Seed, N'|CMP|', c.Code, N'|', p.Product_Code, N'|lch')))), p.Product_Code) + 1 AS Rn
    FROM #C c
    JOIN core.Product p ON p.Launch_Date BETWEEN DATEADD(DAY, 7, c.YS) AND DATEADD(DAY, -c.Dur, c.YE)
    JOIN core.Brand b   ON b.Brand_ID = p.Brand_ID
    WHERE c.Tcode = 'LCH'
      AND (b.Brand_End_Date IS NULL OR b.Brand_End_Date >= DATEADD(DAY, c.Dur, p.Launch_Date))
      AND EXISTS (SELECT 1 FROM #C c2 WHERE c2.K = c.K AND c2.Tcode = 'LCH' AND c2.J < c.J)       -- 2nd launch slot: another product
)
UPDATE c SET Product_Name = x.Product_Name, Brand_ID = x.Brand_ID, Brand_Name = x.Brand_Name,
             Start_Date = DATEADD(DAY, -7 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|lof')))) % 8, x.Launch_Date)
FROM #C c JOIN cand x ON x.Code = c.Code AND x.Rn = CASE WHEN EXISTS (SELECT 1 FROM #C c2 WHERE c2.K = c.K AND c2.Tcode = 'LCH' AND c2.J < c.J) THEN 2 ELSE 1 END;

-- 4.3 start inside the Shamsi year (e.g. Ramadan 1402 starts on 1402/01/03); end date
--     (loyalty programme of the last year stays open-ended)
UPDATE #C SET Start_Date = YS WHERE Start_Date < YS;
UPDATE #C SET End_Date = CASE WHEN Tcode = 'LOY' AND K = @NYears - 1 THEN NULL
                              WHEN DATEADD(DAY, Dur - 1, Start_Date) > @ToDate THEN @ToDate
                              ELSE DATEADD(DAY, Dur - 1, Start_Date) END,
              Plan_End = DATEADD(DAY, CASE WHEN Tcode = 'LOY' AND K = @NYears - 1 THEN 364 ELSE Dur - 1 END, Start_Date);

-- 4.4 brand for brand campaigns without a product (brand active during the whole campaign)
;WITH cand AS (
    SELECT c.Code, b.Brand_ID, b.Brand_Name,
           ROW_NUMBER() OVER (PARTITION BY c.Code ORDER BY CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
               CONCAT(@Seed, N'|CMP|', c.Code, N'|', b.Brand_Code, N'|brand')))), b.Brand_Code) AS Rn
    FROM #C c
    JOIN core.Brand b ON b.Brand_Code LIKE N'T2S8BR%'
                     AND b.Brand_Start_Date <= c.Start_Date
                     AND (b.Brand_End_Date IS NULL OR b.Brand_End_Date >= ISNULL(c.End_Date, @ToDate))
    WHERE c.Purpose = N'Brand' AND c.Brand_ID IS NULL)
UPDATE c SET Brand_ID = x.Brand_ID, Brand_Name = x.Brand_Name
FROM #C c JOIN cand x ON x.Code = c.Code AND x.Rn = 1;

IF EXISTS (SELECT 1 FROM #C WHERE Purpose = N'Brand' AND Brand_ID IS NULL)
    THROW 50410, N'Internal error: a Brand campaign has no active brand.', 1;

-- 4.5 status, name, money parameters
UPDATE c SET
    Status = CASE WHEN h.HC % 100 < @CancelPct AND c.End_Date < DATEADD(MONTH, -6, @AsOfDate) THEN N'Cancelled'
                  WHEN c.Start_Date > @AsOfDate THEN N'Planned'
                  WHEN c.End_Date IS NULL OR c.End_Date >= @AsOfDate THEN N'Active'
                  ELSE N'Completed' END,
    Campaign_Name = CONCAT(c.Name_FA,
                           CASE WHEN c.Product_Name IS NOT NULL THEN N' ' + c.Product_Name
                                WHEN c.Brand_Name IS NOT NULL THEN N' ' + c.Brand_Name ELSE N'' END,
                           N' ', CASE WHEN c.Tcode = 'NWR' THEN 1399 + c.K ELSE 1398 + c.K END,
                           N' [', c.Code, N']'),
    Budget_Total = CAST((t.Base_Min + h.HB % t.Base_Rng) * 1000000.0 * ix.Idx AS decimal(18,2)),
    Spend_Ratio  = CASE WHEN h.HO % 100 < @OverrunPct THEN 1.10 + (h.HR % 16) / 100.0 ELSE 0.80 + (h.HR % 25) / 100.0 END,
    -- v1.1: tier and base ROAS; channel / audience / type factors are applied in section 6b
    Perf_Tier    = CASE WHEN h.HW % 100 < @LossPct THEN N'Loss' WHEN h.HW % 100 < @LossPct + @LowPct THEN N'Low'
                        WHEN h.HW % 100 < @LossPct + @LowPct + @MidPct THEN N'Mid' ELSE N'High' END,
    ROAS         = CASE WHEN h.HW % 100 < @LossPct                     THEN 0.45 + (h.HQ % 41) / 100.0    -- 0.45..0.85
                        WHEN h.HW % 100 < @LossPct + @LowPct           THEN 1.00 + (h.HQ % 81) / 100.0    -- 1.00..1.80
                        WHEN h.HW % 100 < @LossPct + @LowPct + @MidPct THEN 1.80 + (h.HQ % 171) / 100.0   -- 1.80..3.50
                        ELSE 3.50 + (h.HQ % 251) / 100.0 END                                             -- 3.50..6.00
FROM #C c
JOIN #Tpl t ON t.J = c.J
JOIN #CIdx ix ON ix.Month_Start = DATEFROMPARTS(YEAR(c.Start_Date), MONTH(c.Start_Date), 1)
CROSS APPLY (SELECT CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|cancel')))) AS HC,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|budget')))) AS HB,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|overrun')))) AS HO,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|ratio')))) AS HR,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|weak')))) AS HW,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|roas')))) AS HQ) h;

------------------------------------------------------------------------------
-- 5. Channel and audience links
------------------------------------------------------------------------------
CREATE TABLE #CC (Code nvarchar(20) NOT NULL, Campaign_Channel_ID int NOT NULL, Share_W int NOT NULL, PRIMARY KEY (Code, Campaign_Channel_ID));
;WITH cand AS (
    SELECT c.Code, ch.Campaign_Channel_ID, w.W,
           ROW_NUMBER() OVER (PARTITION BY c.Code ORDER BY
               (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|', ch.Channel_Type, N'|ch')))) % 1000 + 1) * w.W DESC,
               ch.Channel_Type) AS Rn,
           t.Ch_Min + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|nch')))) % t.Ch_Rng AS N_Ch,
           1 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|', ch.Channel_Type, N'|share')))) % 10 AS HS
    FROM #C c
    JOIN #Tpl t ON t.J = c.J
    JOIN #ChW w ON w.Campaign_Type = c.Campaign_Type AND w.W > 0
    JOIN marketing.CampaignChannel ch ON ch.Channel_Type = w.Channel_Type
    WHERE ch.Channel_Status = N'Active' OR c.Start_Date < @LegacyCutoff)
INSERT #CC (Code, Campaign_Channel_ID, Share_W)
SELECT Code, Campaign_Channel_ID, HS * W FROM cand WHERE Rn <= N_Ch;

CREATE TABLE #CA (Code nvarchar(20) NOT NULL, Campaign_Audience_ID int NOT NULL, PRIMARY KEY (Code, Campaign_Audience_ID));
;WITH cand AS (
    SELECT c.Code, au.Campaign_Audience_ID,
           ROW_NUMBER() OVER (PARTITION BY c.Code ORDER BY
               (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|', au.Audience_Name, N'|au')))) % 1000 + 1) * w.W DESC,
               au.Audience_Name) AS Rn,
           t.Au_Min + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|nau')))) % t.Au_Rng AS N_Au
    FROM #C c
    JOIN #Tpl t ON t.J = c.J
    JOIN #AuW w ON w.Campaign_Type = c.Campaign_Type AND w.W > 0
    JOIN marketing.CampaignAudience au ON au.Audience_Type = w.Audience_Type
    WHERE au.Audience_Status = N'Active' OR c.Start_Date < @LegacyCutoff)
INSERT #CA (Code, Campaign_Audience_ID)
SELECT Code, Campaign_Audience_ID FROM cand WHERE Rn <= N_Au;

IF EXISTS (SELECT 1 FROM #C c WHERE NOT EXISTS (SELECT 1 FROM #CC x WHERE x.Code = c.Code)
                                 OR NOT EXISTS (SELECT 1 FROM #CA x WHERE x.Code = c.Code))
    THROW 50411, N'Internal error: a campaign has no channel or no audience.', 1;

------------------------------------------------------------------------------
-- 6. Budget per campaign x channel
------------------------------------------------------------------------------
CREATE TABLE #CB (Code nvarchar(20) NOT NULL, Campaign_Channel_ID int NOT NULL, Amount decimal(18,2) NOT NULL, Approval_Date date NOT NULL,
                  PRIMARY KEY (Code, Campaign_Channel_ID));
INSERT #CB (Code, Campaign_Channel_ID, Amount, Approval_Date)
SELECT x.Code, x.Campaign_Channel_ID,
       CASE WHEN ROUND(c.Budget_Total * x.Share_W / s.Sum_W, -6) < 1000000 THEN 1000000 ELSE ROUND(c.Budget_Total * x.Share_W / s.Sum_W, -6) END,
       CASE WHEN DATEADD(DAY, -(7 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|appr')))) % 24), c.Start_Date) < @FromDate
            THEN @FromDate
            ELSE DATEADD(DAY, -(7 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|appr')))) % 24), c.Start_Date) END
FROM #CC x
JOIN #C c ON c.Code = x.Code
JOIN (SELECT Code, CAST(SUM(Share_W) AS decimal(18,4)) AS Sum_W FROM #CC GROUP BY Code) s ON s.Code = x.Code;

------------------------------------------------------------------------------
-- 6b. v1.1 performance per campaign: tier ROAS x type x channel mix x audience mix
------------------------------------------------------------------------------
;WITH chm AS (   -- budget-weighted channel factor
    SELECT b.Code, SUM(b.Amount * f.F) / SUM(b.Amount) AS Ch_F
    FROM #CB b
    JOIN marketing.CampaignChannel ch ON ch.Campaign_Channel_ID = b.Campaign_Channel_ID
    JOIN #ChF f ON f.Channel_Type = ch.Channel_Type
    GROUP BY b.Code),
aum AS (         -- average audience factor; order value factor of the most valuable audience
    SELECT a.Code, AVG(f.F) AS Au_F, MAX(f.Aov_F) AS Aov_F
    FROM #CA a
    JOIN marketing.CampaignAudience au ON au.Campaign_Audience_ID = a.Campaign_Audience_ID
    JOIN #AuF f ON f.Audience_Type = au.Audience_Type
    GROUP BY a.Code)
UPDATE c SET
    ROAS  = CAST(CASE WHEN c.Perf_Tier = N'Loss' AND c.ROAS * tf.Roas_F * chm.Ch_F * aum.Au_F > 0.85 THEN 0.85
                      ELSE c.ROAS * tf.Roas_F * chm.Ch_F * aum.Au_F END AS decimal(6,3)),
    Cr    = CAST(tf.Cr_Base
                 * CASE c.Perf_Tier WHEN N'Loss' THEN 0.60 WHEN N'Low' THEN 0.85 WHEN N'Mid' THEN 1.00 ELSE 1.30 END
                 * (0.75 + (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|crc')))) % 51) / 100.0)
                 AS decimal(8,5)),
    Aov_F = aum.Aov_F
FROM #C c
JOIN #TypF tf ON tf.Campaign_Type = c.Campaign_Type
JOIN chm ON chm.Code = c.Code
JOIN aum ON aum.Code = c.Code;

------------------------------------------------------------------------------
-- 7. Weeks, weekly cost per channel
------------------------------------------------------------------------------
CREATE TABLE #CW (Code nvarchar(20) NOT NULL, W int NOT NULL, Wk_Start date NOT NULL, Wk_End date NOT NULL, PRIMARY KEY (Code, W));
;WITH n AS (SELECT TOP (60) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS W FROM sys.all_objects)
INSERT #CW (Code, W, Wk_Start, Wk_End)
SELECT c.Code, n.W, DATEADD(DAY, 7 * n.W, c.Start_Date),
       CASE WHEN DATEADD(DAY, 7 * n.W + 6, c.Start_Date) > p.PEnd THEN p.PEnd ELSE DATEADD(DAY, 7 * n.W + 6, c.Start_Date) END
FROM #C c
CROSS APPLY (SELECT CASE WHEN c.End_Date IS NULL OR c.End_Date > @AsOfDate THEN @AsOfDate ELSE c.End_Date END AS PEnd) p
JOIN n ON DATEADD(DAY, 7 * n.W, c.Start_Date) <= p.PEnd
WHERE c.Status IN (N'Completed', N'Active');

CREATE TABLE #CCost (Code nvarchar(20) NOT NULL, Campaign_Channel_ID int NOT NULL, W int NOT NULL, Cost_Date date NOT NULL,
                     Amount decimal(18,2) NOT NULL, PRIMARY KEY (Code, Campaign_Channel_ID, W));
;WITH tgt AS (   -- what each channel spends until @AsOfDate
    SELECT b.Code, b.Campaign_Channel_ID,
           ROUND(b.Amount * c.Spend_Ratio *
                 CASE WHEN DATEDIFF(DAY, c.Start_Date, mx.Last_End) + 1 >= DATEDIFF(DAY, c.Start_Date, c.Plan_End) + 1 THEN 1.0
                      ELSE (DATEDIFF(DAY, c.Start_Date, mx.Last_End) + 1) * 1.0 / (DATEDIFF(DAY, c.Start_Date, c.Plan_End) + 1) END, -3) AS Target
    FROM #CB b
    JOIN #C c ON c.Code = b.Code
    JOIN (SELECT Code, MAX(Wk_End) AS Last_End FROM #CW GROUP BY Code) mx ON mx.Code = b.Code),
raw AS (
    SELECT t.Code, t.Campaign_Channel_ID, w.W, w.Wk_End, t.Target,
           (50 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', t.Code, N'|', t.Campaign_Channel_ID, N'|', w.W, N'|cw')))) % 101)
           * (DATEDIFF(DAY, w.Wk_Start, w.Wk_End) + 1) AS Wt
    FROM tgt t JOIN #CW w ON w.Code = t.Code),
r2 AS (
    SELECT r.*, ROUND(r.Target * r.Wt / SUM(r.Wt * 1.0) OVER (PARTITION BY r.Code, r.Campaign_Channel_ID), -3) AS Amt,
           ROW_NUMBER() OVER (PARTITION BY r.Code, r.Campaign_Channel_ID ORDER BY r.W DESC) AS RevNo
    FROM raw r)
INSERT #CCost (Code, Campaign_Channel_ID, W, Cost_Date, Amount)
SELECT Code, Campaign_Channel_ID, W, Wk_End,
       CASE WHEN RevNo = 1
            THEN Target - (SUM(Amt) OVER (PARTITION BY Code, Campaign_Channel_ID) - Amt)   -- last row takes the rounding rest
            ELSE Amt END
FROM r2;

IF EXISTS (SELECT 1 FROM #CCost WHERE Amount < 0)
    THROW 50412, N'Internal error: negative weekly cost.', 1;

------------------------------------------------------------------------------
-- 8. Weekly results (flow values of the week)
------------------------------------------------------------------------------
CREATE TABLE #CRes (Code nvarchar(20) NOT NULL, Metric_Name nvarchar(100) NOT NULL, Measurement_Date date NOT NULL, Metric_Value decimal(18,4) NOT NULL,
                    PRIMARY KEY (Code, Metric_Name, Measurement_Date));
;WITH wk AS (
    SELECT w.Code, w.W, w.Wk_Start, w.Wk_End, c.ROAS, c.Cr, c.Aov_F, tf.Fq_Min, tf.Fq_Rng, tf.Nc_Min, tf.Nc_Rng,
           SUM(x.Amount) AS Spend, ix.Idx
    FROM #CW w
    JOIN #C c ON c.Code = w.Code
    JOIN #TypF tf ON tf.Campaign_Type = c.Campaign_Type
    JOIN #CCost x ON x.Code = w.Code AND x.W = w.W
    JOIN #CIdx ix ON ix.Month_Start = DATEFROMPARTS(YEAR(w.Wk_Start), MONTH(w.Wk_Start), 1)
    GROUP BY w.Code, w.W, w.Wk_Start, w.Wk_End, c.ROAS, c.Cr, c.Aov_F, tf.Fq_Min, tf.Fq_Rng, tf.Nc_Min, tf.Nc_Rng, ix.Idx),
h AS (
    SELECT wk.*,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', wk.Code, N'|', wk.W, N'|rf')))) AS HF,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', wk.Code, N'|', wk.W, N'|aov')))) AS HA,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', wk.Code, N'|', wk.W, N'|cr')))) AS HC,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', wk.Code, N'|', wk.W, N'|fq')))) AS HQ,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', wk.Code, N'|', wk.W, N'|nc')))) AS HN
    FROM wk),
m1 AS (
    SELECT h.Code, h.Wk_End,
           ROUND(h.Spend * h.ROAS * (0.85 + (h.HF % 31) / 100.0), -3) AS Revenue,
           (400000 + h.HA % 800001) * h.Idx * h.Aov_F AS AOV,               -- order value per conversion (B2B x2.5)
           h.Cr * (0.85 + (h.HC % 31) / 100.0) AS Conv_Rate,                 -- v1.1: campaign rate x weekly noise
           (h.Fq_Min + h.HQ % h.Fq_Rng) / 100.0 AS Freq,                      -- v1.1: by campaign type
           (h.Nc_Min + h.HN % h.Nc_Rng) / 100.0 AS New_Share                  -- v1.1: by campaign type
    FROM h),
m2 AS (
    SELECT m1.*, FLOOR(m1.Revenue / m1.AOV) AS Conv FROM m1),
m3 AS (
    SELECT m2.*, CEILING(m2.Conv / m2.Conv_Rate) + 50 AS Reach FROM m2)
INSERT #CRes (Code, Metric_Name, Measurement_Date, Metric_Value)
SELECT m3.Code, v.Metric_Name, m3.Wk_End, v.Val
FROM m3
CROSS APPLY (VALUES (N'Impressions',        CEILING(m3.Reach * m3.Freq)),
                    (N'Audience_Reached',   m3.Reach),
                    (N'Conversions',        m3.Conv),
                    (N'New_Customers',      FLOOR(m3.Conv * m3.New_Share)),
                    (N'Attributed_Revenue', m3.Revenue)) v(Metric_Name, Val);

-- v1.1: a Loss-tier campaign must end with revenue below its actual cost (PM review, final values)
IF EXISTS (SELECT 1 FROM #C c
           WHERE c.Perf_Tier = N'Loss'
             AND (SELECT SUM(r.Metric_Value) FROM #CRes r WHERE r.Code = c.Code AND r.Metric_Name = N'Attributed_Revenue')
                 >= (SELECT SUM(x.Amount) FROM #CCost x WHERE x.Code = c.Code))
    THROW 50414, N'Internal error: a Loss-tier campaign has final revenue >= actual cost.', 1;

-- brand awareness survey of brand campaigns: baseline at the start, result at the end (completed only)
INSERT #CRes (Code, Metric_Name, Measurement_Date, Metric_Value)
SELECT c.Code, N'Brand_Awareness_Pct', c.Start_Date, CAST(12 + h.HB % 3301 / 100.0 AS decimal(18,4))
FROM #C c
CROSS APPLY (SELECT CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|aw0')))) AS HB) h
WHERE c.Purpose = N'Brand' AND c.Status IN (N'Completed', N'Active')
UNION ALL
SELECT c.Code, N'Brand_Awareness_Pct', c.End_Date,
       CAST(12 + h.HB % 3301 / 100.0 + (150 + h.HU % 751) / 100.0 AS decimal(18,4))
FROM #C c
CROSS APPLY (SELECT CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|aw0')))) AS HB,
                    CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|CMP|', c.Code, N'|1|aw1')))) AS HU) h
WHERE c.Purpose = N'Brand' AND c.Status = N'Completed';

------------------------------------------------------------------------------
-- 9. Load (one transaction)
------------------------------------------------------------------------------
BEGIN TRANSACTION;

INSERT marketing.MarketingCampaign (Brand_ID, Campaign_Name, Campaign_Type, Campaign_Purpose, Campaign_Objective, Start_Date, End_Date, Campaign_Status)
SELECT CASE WHEN Purpose = N'Brand' THEN Brand_ID END, Campaign_Name, Campaign_Type, Purpose, Objective, Start_Date, End_Date, Status
FROM #C ORDER BY Start_Date, Code;
SET @Rows_MC = @@ROWCOUNT;

UPDATE c SET Marketing_Campaign_ID = mc.Marketing_Campaign_ID
FROM #C c JOIN marketing.MarketingCampaign mc ON mc.Campaign_Name = c.Campaign_Name;
IF EXISTS (SELECT 1 FROM #C WHERE Marketing_Campaign_ID IS NULL)
    THROW 50413, N'Internal error: campaign key lookup failed.', 1;

INSERT marketing.MarketingCampaignChannel (Marketing_Campaign_ID, Campaign_Channel_ID)
SELECT c.Marketing_Campaign_ID, x.Campaign_Channel_ID FROM #CC x JOIN #C c ON c.Code = x.Code
ORDER BY c.Marketing_Campaign_ID, x.Campaign_Channel_ID;
SET @Rows_CH = @@ROWCOUNT;

INSERT marketing.MarketingCampaignAudience (Marketing_Campaign_ID, Campaign_Audience_ID)
SELECT c.Marketing_Campaign_ID, x.Campaign_Audience_ID FROM #CA x JOIN #C c ON c.Code = x.Code
ORDER BY c.Marketing_Campaign_ID, x.Campaign_Audience_ID;
SET @Rows_AU = @@ROWCOUNT;

INSERT marketing.CampaignBudget (Marketing_Campaign_ID, Campaign_Channel_ID, Total_Allocated_Amount, Currency, Approval_Date)
SELECT c.Marketing_Campaign_ID, x.Campaign_Channel_ID, x.Amount, @Currency, x.Approval_Date FROM #CB x JOIN #C c ON c.Code = x.Code
ORDER BY c.Marketing_Campaign_ID, x.Campaign_Channel_ID;
SET @Rows_B = @@ROWCOUNT;

INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date)
SELECT c.Marketing_Campaign_ID, x.Campaign_Channel_ID, x.Amount, @Currency, x.Cost_Date FROM #CCost x JOIN #C c ON c.Code = x.Code
ORDER BY c.Marketing_Campaign_ID, x.Cost_Date, x.Campaign_Channel_ID;
SET @Rows_C = @@ROWCOUNT;

INSERT marketing.CampaignResult (Marketing_Campaign_ID, Metric_Name, Metric_Value, Measurement_Date)
SELECT c.Marketing_Campaign_ID, x.Metric_Name, x.Metric_Value, x.Measurement_Date FROM #CRes x JOIN #C c ON c.Code = x.Code
ORDER BY c.Marketing_Campaign_ID, x.Measurement_Date, x.Metric_Name;
SET @Rows_R = @@ROWCOUNT;

COMMIT TRANSACTION;

IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
    INSERT #T2LoadLog (Script_Name, Table_Name, Input_Rows, Inserted_Rows)
    VALUES (N'08-03-T2-04', N'marketing.MarketingCampaign', @Rows_MC, @Rows_MC),
           (N'08-03-T2-04', N'marketing.MarketingCampaignChannel', @Rows_CH, @Rows_CH),
           (N'08-03-T2-04', N'marketing.MarketingCampaignAudience', @Rows_AU, @Rows_AU),
           (N'08-03-T2-04', N'marketing.CampaignBudget', @Rows_B, @Rows_B),
           (N'08-03-T2-04', N'marketing.CampaignCost', @Rows_C, @Rows_C),
           (N'08-03-T2-04', N'marketing.CampaignResult', @Rows_R, @Rows_R);

PRINT CONCAT(N'08-03-T2-04-Campaign | ', @DataVersion, N' | Seed=', @Seed, N' | Scale=', @Scale);
PRINT CONCAT(N'marketing.MarketingCampaign         : ', @Rows_MC);
PRINT CONCAT(N'marketing.MarketingCampaignChannel  : ', @Rows_CH);
PRINT CONCAT(N'marketing.MarketingCampaignAudience : ', @Rows_AU);
PRINT CONCAT(N'marketing.CampaignBudget            : ', @Rows_B);
PRINT CONCAT(N'marketing.CampaignCost              : ', @Rows_C);
PRINT CONCAT(N'marketing.CampaignResult            : ', @Rows_R);

-- v1.1: scenario summary (tiers are generator settings, they are not stored in the database)
SELECT c.Perf_Tier, COUNT(*) AS Campaigns,
       SUM(CASE WHEN rv.Rev < cs.Cost THEN 1 ELSE 0 END) AS Revenue_Below_Cost,
       CAST(MIN(c.ROAS) AS decimal(6,3)) AS Min_ROAS, CAST(MAX(c.ROAS) AS decimal(6,3)) AS Max_ROAS
FROM #C c
CROSS APPLY (SELECT SUM(Amount) AS Cost FROM #CCost x WHERE x.Code = c.Code) cs
CROSS APPLY (SELECT SUM(Metric_Value) AS Rev FROM #CRes r WHERE r.Code = c.Code AND r.Metric_Name = N'Attributed_Revenue') rv
WHERE c.Status IN (N'Completed', N'Active')
GROUP BY c.Perf_Tier ORDER BY MIN(c.ROAS);

SELECT mc.Marketing_Campaign_ID, mc.Campaign_Name, mc.Campaign_Type, mc.Campaign_Purpose, mc.Start_Date, mc.End_Date, mc.Campaign_Status
FROM marketing.MarketingCampaign mc ORDER BY mc.Start_Date;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    PRINT CONCAT(N'08-03-T2-04-Campaign FAILED (rolled back). Error ', ERROR_NUMBER(), N' line ', ERROR_LINE(), N': ', ERROR_MESSAGE());
    THROW;
END CATCH;
GO
