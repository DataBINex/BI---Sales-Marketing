
/*
============================================================
Project       : FoodDistributionDB
Stage         : 8 - Mock Data Design
Team          : Team 2 - Product & Marketing
Sub-issue     : 8.1 - Product Catalog
Owner         : atieht
Database      : FoodDistributionDB
Version       : MockData_v1.1_Seed20261031
Run Order     : 3

Purpose:
    Product Catalog Data Quality Checks

Tables:
    ref.ProductCategory
    ref.Package
    core.Product
    core.SKU

Prerequisite:
    Brand data from Sub-issue 8.3 must be loaded.

Execution:
    Read-only validation. No INSERT, UPDATE or DELETE.
============================================================
*/

-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;

SET NOCOUNT ON;

DECLARE @FromDate date = '2019-03-21';
DECLARE @ToDate   date = '2027-03-20';

------------------------------------------------------------
-- Q01. PRODUCT CODE UNIQUENESS
------------------------------------------------------------

SELECT
    N'Q01' AS Test_ID,
    N'core.Product' AS Table_Name,
    N'Unique Product_Code' AS Test_Definition,
    COUNT_BIG(*) AS Error_Count
FROM
(
    SELECT Product_Code
    FROM core.Product
    GROUP BY Product_Code
    HAVING COUNT(*) > 1
) D;


------------------------------------------------------------
-- Q02. SKU CODE UNIQUENESS
------------------------------------------------------------

SELECT
    N'Q02' AS Test_ID,
    N'core.SKU' AS Table_Name,
    N'Unique SKU_Code' AS Test_Definition,
    COUNT_BIG(*) AS Error_Count
FROM
(
    SELECT SKU_Code
    FROM core.SKU
    GROUP BY SKU_Code
    HAVING COUNT(*) > 1
) D;


------------------------------------------------------------
-- Q03. BARCODE UNIQUENESS
------------------------------------------------------------

SELECT
    N'Q03' AS Test_ID,
    N'core.SKU' AS Table_Name,
    N'Unique non-NULL Barcode' AS Test_Definition,
    COUNT_BIG(*) AS Error_Count
FROM
(
    SELECT Barcode
    FROM core.SKU
    WHERE Barcode IS NOT NULL
    GROUP BY Barcode
    HAVING COUNT(*) > 1
) D;


------------------------------------------------------------
-- Q04. EAN-13 FORMAT AND CHECKSUM
------------------------------------------------------------

SELECT
    S.SKU_ID,
    S.SKU_Code,
    S.Barcode,
    D.Check_Sum
FROM core.SKU S

CROSS APPLY
(
    SELECT
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 1, 1)) AS D1,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 2, 1)) AS D2,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 3, 1)) AS D3,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 4, 1)) AS D4,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 5, 1)) AS D5,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 6, 1)) AS D6,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 7, 1)) AS D7,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 8, 1)) AS D8,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 9, 1)) AS D9,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 10, 1)) AS D10,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 11, 1)) AS D11,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 12, 1)) AS D12,
        TRY_CONVERT(INT, SUBSTRING(S.Barcode, 13, 1)) AS D13
) X

CROSS APPLY
(
    SELECT
        X.D1 + 3 * X.D2 +
        X.D3 + 3 * X.D4 +
        X.D5 + 3 * X.D6 +
        X.D7 + 3 * X.D8 +
        X.D9 + 3 * X.D10 +
        X.D11 + 3 * X.D12 +
        X.D13 AS Check_Sum
) D

WHERE
       S.Barcode IS NULL
    OR LEN(S.Barcode) <> 13
    OR S.Barcode LIKE '%[^0-9]%'
    OR D.Check_Sum IS NULL
    OR D.Check_Sum % 10 <> 0;


------------------------------------------------------------
-- Q05. PRODUCT WITHOUT SKU
------------------------------------------------------------

SELECT
    P.Product_ID,
    P.Product_Code
FROM core.Product P
LEFT JOIN core.SKU S
    ON S.Product_ID = P.Product_ID
WHERE S.SKU_ID IS NULL;


------------------------------------------------------------
-- Q06. SKU WITHOUT PRODUCT
------------------------------------------------------------

SELECT
    S.SKU_ID,
    S.SKU_Code,
    S.Product_ID
FROM core.SKU S
LEFT JOIN core.Product P
    ON P.Product_ID = S.Product_ID
WHERE P.Product_ID IS NULL;


------------------------------------------------------------
-- Q07. PRODUCT ATTRIBUTE VALIDATION
------------------------------------------------------------

SELECT
    P.Product_ID,
    P.Product_Code,
    P.Launch_Date,
    P.Product_Created_Date,
    P.Product_Updated_Date,
    P.Weight,
    P.Tax_Rate
FROM core.Product P
WHERE
       P.Launch_Date IS NULL
    OR P.Product_Created_Date IS NULL
    OR P.Launch_Date > @ToDate
    OR P.Product_Created_Date > @ToDate
    OR (
        P.Product_Updated_Date IS NOT NULL
        AND P.Product_Updated_Date < P.Product_Created_Date
    )
    OR P.Weight IS NULL
    OR P.Weight <= 0
    OR P.Tax_Rate IS NULL
    OR P.Tax_Rate < 0
    OR P.Tax_Rate > 100;


------------------------------------------------------------
-- Q08. SKU ATTRIBUTE VALIDATION
------------------------------------------------------------

SELECT
    S.SKU_ID,
    S.SKU_Code,
    S.Weight,
    S.Standard_Cost,
    S.Currency
FROM core.SKU S
WHERE
       S.Weight IS NULL
    OR S.Weight <= 0
    OR S.Standard_Cost IS NULL
    OR S.Standard_Cost < 0
    OR S.Currency IS NULL
    OR LEN(S.Currency) <> 3
    OR S.Currency <> 'IRR';


------------------------------------------------------------
-- Q09. PRODUCT BRAND AND CATEGORY VALIDATION
------------------------------------------------------------

SELECT
    P.Product_ID,
    P.Product_Code,
    P.Brand_ID,
    P.Product_Category_ID,
    B.Brand_Status,
    C.Category_Level,
    C.Category_Status
FROM core.Product P

LEFT JOIN core.Brand B
    ON B.Brand_ID = P.Brand_ID

LEFT JOIN ref.ProductCategory C
    ON C.Product_Category_ID = P.Product_Category_ID

WHERE
       B.Brand_ID IS NULL
    OR B.Brand_Status IS NULL
    OR B.Brand_Status <> N'Active'
    OR C.Product_Category_ID IS NULL
    OR C.Category_Level IS NULL
    OR C.Category_Level <> 2
    OR C.Category_Status IS NULL
    OR C.Category_Status <> N'Active';


------------------------------------------------------------
-- Q10. SKU PACKAGE VALIDATION
------------------------------------------------------------

SELECT
    S.SKU_ID,
    S.SKU_Code,
    S.Package_ID
FROM core.SKU S
LEFT JOIN ref.Package P
    ON P.Package_ID = S.Package_ID
WHERE P.Package_ID IS NULL;


------------------------------------------------------------
-- Q11. SKU DISTRIBUTION PER PRODUCT
------------------------------------------------------------

WITH SKU_Distribution AS
(
    SELECT
        P.Product_ID,
        P.Product_Code,
        COUNT(S.SKU_ID) AS SKU_Count
    FROM core.Product P
    LEFT JOIN core.SKU S
        ON S.Product_ID = P.Product_ID
    GROUP BY
        P.Product_ID,
        P.Product_Code
)
SELECT
    SKU_Count,
    COUNT(*) AS Product_Count
FROM SKU_Distribution
GROUP BY SKU_Count
ORDER BY SKU_Count;


------------------------------------------------------------
-- Q12. LAUNCH DATE DISTRIBUTION BY YEAR
------------------------------------------------------------

SELECT
    YEAR(Launch_Date) AS Launch_Year,
    COUNT(*) AS Product_Count
FROM core.Product
GROUP BY YEAR(Launch_Date)
ORDER BY Launch_Year;


------------------------------------------------------------
-- Q13. REFERENCE DATA COUNTS
------------------------------------------------------------

SELECT
    N'ref.ProductCategory' AS Table_Name,
    COUNT_BIG(*) AS Row_Count
FROM ref.ProductCategory

UNION ALL

SELECT
    N'ref.Package',
    COUNT_BIG(*)
FROM ref.Package

UNION ALL

SELECT
    N'core.Brand',
    COUNT_BIG(*)
FROM core.Brand

UNION ALL

SELECT
    N'core.Product',
    COUNT_BIG(*)
FROM core.Product

UNION ALL

SELECT
    N'core.SKU',
    COUNT_BIG(*)
FROM core.SKU;


------------------------------------------------------------
-- Q14. CATEGORY LEVEL DISTRIBUTION
------------------------------------------------------------

SELECT
    Category_Level,
    Category_Status,
    COUNT(*) AS Category_Count
FROM ref.ProductCategory
GROUP BY
    Category_Level,
    Category_Status
ORDER BY
    Category_Level,
    Category_Status;


------------------------------------------------------------
-- Q15. PACKAGE LIST
------------------------------------------------------------

SELECT
    Package_ID,
    Package_Code,
    Package_Name
FROM ref.Package
ORDER BY Package_Code;

GO
