﻿/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex)
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing   (Issue #195 / 8.7)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T2-05-Promotion-Price.sql
 Version       : 1.2
 Purpose       : Generate mock data for marketing.ProductPrice and marketing.Promotion
 Run Order     : 5 (Team 2 group)
 Prerequisites : core.SKU and core.Product loaded (8.1); marketing.MarketingCampaign
                 loaded (8.2). Both target tables must be EMPTY (reset only through
                 08-03-T2-00-Reset.sql).
 Seed/Config   : see the settings block below (Seed 20261031, @Scale 0.10 trial / 1.00 full)
 Created       : 2026-11-03
 Tables        : marketing.ProductPrice, marketing.Promotion
 Integration   : v1.1 (SinaSepasi, #196) - author M-Jafarian88; rules of v1.0 are kept, changes:
                 1. @Scale is read from the loader session (SESSION_CONTEXT 'T2_Scale').
                 2. @Mult = 1: the SKU list is already 10% in the pilot, so price periods keep the
                    real 2..6 month rhythm (v1.0 stretched them x10 in the pilot).
                 3. Synthetic annual inflation set to the Iranian range (32%..45%) instead of 6%..10%.
                 4. Standard_Cost of 8.1 is the 1398 base cost, so the first price of a SKU launched
                    later is lifted by the cumulative inflation index of its start month (#Idx);
                    fixed-amount promotion discounts use the same index.
                 5. Row counts are written to #T2LoadLog when the loader created it (Q18).
                 6. Bug fix: category factor CatF was 0.80 + (0.10 x hash) % 5 (up to 5.8, operator
                    precedence); now 0.80 + 0.10 x (hash % 5) = 0.80..1.20 as documented.
                 7. No float: #Idx is computed with decimal only (recursive month by month, no EXP/LOG)
                    and the reference price uses PERCENTILE_DISC instead of PERCENTILE_CONT.
                 v1.2 (PM review 2026-11-07):
                 8. The 25% discount cap applies to EVERY discount type (decision of the team lead):
                    a Fixed Amount is 10/15/20/25% of the promotion's reference price, rounded DOWN
                    to 1,000 IRR. Reference price = 25th percentile (PERCENTILE_DISC) of the Standard
                    list prices valid on the promotion start date (1.1 used the 1398 base cost x index
                    and up to 30%). Checked here (error 50012) and in 08-05 Q06.
                 9. Shamsi years from the fixed mapping #ShY (1 Farvardin; 1399 and 1403 start on
                    20 March) instead of DATEADD(YEAR) from 2019-03-21.
                 10. DataVersion MockData_v1.1.
 Notes         : - No schema change, no trigger/constraint disabled, no IDENTITY_INSERT.
                 - Deterministic: SHA2_256 hash of (@Seed|key|n|purpose); no NEWID/RAND/GETDATE.
                 - Values marked [ASSUMED] have no CHECK in the DDL and no Data Dictionary was
                   available while writing: verify them against the Allowed-Values sheet (D-07).
============================================================================= */
SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #Infl, #Idx, #PriceType, #PP, #Occ, #P, #ShY;   -- v1.1: safe re-run in the same session

------------------------------------------------------------------------------
-- 1. Settings (standard block, identical in every Team 2 script)
------------------------------------------------------------------------------
DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10); -- 0.10 = 10% trial, 1.00 = full run
DECLARE @FromDate    date         = '2019-03-21';  -- 1398/01/01
DECLARE @ToDate      date         = '2027-03-20';  -- 1405/12/29
DECLARE @AsOfDate    date         = '2027-03-20';  -- status reference date (until T2-S8-04)

-- Script-specific settings
DECLARE @Currency        char(3)      = 'IRR';                 -- T2-S8-05
DECLARE @PromoPerYear    int          = 40;                    -- 30..50 per year (full scale)
DECLARE @NYears          int          = DATEDIFF(YEAR, @FromDate, DATEADD(DAY, 1, @ToDate)); -- 8
DECLARE @ShamsiBaseYear  int          = 1398;                  -- only used in Promotion_Code
DECLARE @LinkPct         int          = 60;                    -- % of promotions tied to a campaign
DECLARE @MaxDiscountPct  decimal(5,2) = 25.00;                 -- cap for ALL discount types (v1.2), T2-S8-11
DECLARE @PriceType       nvarchar(30) = N'Standard';           -- [ASSUMED]
DECLARE @PriceActive     nvarchar(30) = N'Active';             -- [ASSUMED] open-ended price of an active SKU
DECLARE @PriceInactive   nvarchar(30) = N'Inactive';           -- [ASSUMED] open-ended price of a non-active SKU
DECLARE @PriceExpired    nvarchar(30) = N'Expired';            -- [ASSUMED] closed period
DECLARE @PromoActive     nvarchar(30) = N'Active';             -- [ASSUMED]
DECLARE @PromoExpired    nvarchar(30) = N'Expired';            -- [ASSUMED]
DECLARE @PromoPlanned    nvarchar(30) = N'Planned';            -- [ASSUMED]
DECLARE @SkuActive       nvarchar(30) = N'Active';             -- [ASSUMED] SKU_Status meaning "active"
DECLARE @CampaignPurpose nvarchar(30) = N'Marketing';          -- allowed by CK_MarketingCampaign_Campaign_Purpose
DECLARE @CampaignExcl    nvarchar(30) = N'Cancelled';          -- [ASSUMED] campaigns never linked

-- Derived (do not edit)
DECLARE @Mult  int = 1;                                         -- price-change interval multiplier (v1.1: always 1)
DECLARE @Msg   nvarchar(400);
DECLARE @RowsPrice int = 0, @RowsPromo int = 0;

------------------------------------------------------------------------------
-- 2. Pre-run guards (re-run policy + parent guarantees)
------------------------------------------------------------------------------
IF EXISTS (SELECT 1 FROM marketing.ProductPrice) OR EXISTS (SELECT 1 FROM marketing.Promotion)
    THROW 50001, N'STOP: marketing.ProductPrice or marketing.Promotion already has rows. Clean only with 08-03-T2-00-Reset.sql.', 1;

IF NOT EXISTS (SELECT 1 FROM core.SKU)
    THROW 50002, N'STOP: core.SKU is empty. Run 8.1 (Product/SKU) first.', 1;

IF EXISTS (SELECT 1 FROM core.SKU s JOIN core.Product p ON p.Product_ID = s.Product_ID WHERE p.Launch_Date IS NULL)
    THROW 50003, N'STOP: some Products have NULL Launch_Date (parent guarantee of 8.1 broken). Return to the Product owner.', 1;

IF EXISTS (SELECT 1 FROM core.SKU WHERE Standard_Cost IS NULL OR Standard_Cost <= 0)
    THROW 50004, N'STOP: some SKUs have NULL/zero Standard_Cost; prices must be above Standard_Cost. Return to the SKU owner.', 1;

IF EXISTS (SELECT 1 FROM core.SKU WHERE Currency IS NOT NULL AND Currency <> @Currency)
    THROW 50005, N'STOP: SKU.Currency differs from the project currency (T2-S8-05).', 1;

IF NOT EXISTS (SELECT 1 FROM marketing.MarketingCampaign)
    PRINT N'WARNING: marketing.MarketingCampaign is empty - all promotions will be generated without a campaign link.';

BEGIN TRY
BEGIN TRAN;

------------------------------------------------------------------------------
-- 3. ProductPrice
--    One chain of consecutive periods per SKU x Price_Type, from
--    max(Launch_Date, @FromDate) to @ToDate, no gaps, last period open-ended.
--    Start price = Standard_Cost x markup (1.10..1.35); every 2..6 months (x @Mult at
--    trial scale) the price rises in proportion to the synthetic annual inflation of
--    that year, scaled by a per-category factor (0.8..1.2) plus a small step.
------------------------------------------------------------------------------
CREATE TABLE #Infl (Yr int NOT NULL PRIMARY KEY, Rate decimal(6,4) NOT NULL);
;WITH y AS (
    SELECT TOP (YEAR(@ToDate) - YEAR(@FromDate) + 12)
           YEAR(@FromDate) - 10 + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Yr
    FROM sys.all_objects
)
INSERT #Infl (Yr, Rate)
SELECT y.Yr, ISNULL(v.Rate, 0.3500)
FROM y
LEFT JOIN (VALUES (2019,0.3500),(2020,0.3600),(2021,0.4200),(2022,0.4500),(2023,0.4200),
                  (2024,0.3200),(2025,0.3800),(2026,0.3500),(2027,0.3500)) v(Yr, Rate)
       ON v.Yr = y.Yr;

-- v1.1: cumulative monthly price index, 1.0000 in 1398/01 (Standard_Cost is the 1398 base cost)
CREATE TABLE #Idx (Month_Start date NOT NULL PRIMARY KEY, Idx decimal(18,6) NOT NULL);
;WITH m AS (   -- decimal only (no EXP/LOG float): Idx(next month) = Idx(month) x (1 + annual rate / 12)
    SELECT DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1) AS Month_Start, CAST(1 AS decimal(18,6)) AS Idx
    UNION ALL
    SELECT DATEADD(MONTH, 1, m.Month_Start), CAST(m.Idx * (1 + i.Rate / 12) AS decimal(18,6))
    FROM m JOIN #Infl i ON i.Yr = YEAR(m.Month_Start)
    WHERE DATEADD(MONTH, 1, m.Month_Start) <= DATEFROMPARTS(YEAR(@ToDate), MONTH(@ToDate), 1))
INSERT #Idx (Month_Start, Idx)
SELECT Month_Start, Idx FROM m OPTION (MAXRECURSION 200);

CREATE TABLE #PriceType (Price_Type nvarchar(30) NOT NULL PRIMARY KEY, Factor decimal(5,3) NOT NULL);
INSERT #PriceType VALUES (@PriceType, 1.000);   -- add more types only after D-07 approves them (Factor must keep price >= cost)

CREATE TABLE #PP (
    SKU_ID int NOT NULL, Price_Type nvarchar(30) NOT NULL, Unit_Price decimal(18,2) NOT NULL,
    Effective_From date NOT NULL, Effective_To date NULL, Price_Status nvarchar(30) NOT NULL,
    SKU_Code nvarchar(30) NOT NULL, K int NOT NULL
);

;WITH base AS (
    SELECT s.SKU_ID, s.SKU_Code, s.SKU_Status, s.Standard_Cost, t.Price_Type, t.Factor,
           CAST(0.80 + 0.10 * ((CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                CONCAT(@Seed, N'|CAT|', p.Product_Category_ID, N'|0|catf'))))) % 5) AS decimal(4,2)) AS CatF,
           CASE WHEN p.Launch_Date > @FromDate THEN p.Launch_Date ELSE @FromDate END AS Start0
    FROM core.SKU s
    JOIN core.Product p ON p.Product_ID = s.Product_ID
    CROSS JOIN #PriceType t
    WHERE p.Launch_Date <= @ToDate
),
per AS (
    SELECT b.SKU_ID, b.SKU_Code, b.SKU_Status, b.Price_Type,
           b.CatF,
           CAST(1 AS int) AS K,
           CAST(b.Start0 AS date) AS Eff_From,
           CAST(DATEADD(MONTH,
                (2 + (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                    CONCAT(@Seed, N'|PP|', b.SKU_Code, N'|', b.Price_Type, N'|1|m')))) % 5)) * @Mult,
                b.Start0) AS date) AS Next_From,
           CAST(b.Standard_Cost * b.Factor * ix.Idx *
                (1.10 + (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                    CONCAT(@Seed, N'|PP|', b.SKU_Code, N'|', b.Price_Type, N'|1|mk')))) % 26) / 100.0)
                AS decimal(28,6)) AS Raw
    FROM base b
    JOIN #Idx ix ON ix.Month_Start = DATEFROMPARTS(YEAR(b.Start0), MONTH(b.Start0), 1)
    UNION ALL
    SELECT x.SKU_ID, x.SKU_Code, x.SKU_Status, x.Price_Type, x.CatF,
           x.K + 1,
           x.Next_From,
           CAST(DATEADD(MONTH,
                (2 + (CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                    CONCAT(@Seed, N'|PP|', x.SKU_Code, N'|', x.Price_Type, N'|', x.K + 1, N'|m')))) % 5)) * @Mult,
                x.Next_From) AS date),
           CAST(x.Raw * (1 + i.Rate * DATEDIFF(MONTH, x.Eff_From, x.Next_From) / 12.0 * x.CatF
                  + 0.01 + 0.02 * ((CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                    CONCAT(@Seed, N'|PP|', x.SKU_Code, N'|', x.Price_Type, N'|', x.K + 1, N'|n')))) % 1000) / 1000.0))
                AS decimal(28,6))
    FROM per x
    JOIN #Infl i ON i.Yr = YEAR(x.Next_From)
    WHERE x.Next_From <= @ToDate
)
INSERT #PP (SKU_ID, Price_Type, Unit_Price, Effective_From, Effective_To, Price_Status, SKU_Code, K)
SELECT SKU_ID, Price_Type,
       CAST(CASE WHEN Raw >= 10000 THEN ROUND(Raw, -2)
                 WHEN Raw >= 1000  THEN ROUND(Raw, -1)
                 ELSE ROUND(Raw, 2) END AS decimal(18,2)),
       Eff_From,
       CASE WHEN Next_From > @ToDate THEN NULL ELSE DATEADD(DAY, -1, Next_From) END,
       CASE WHEN Next_From > @ToDate
            THEN CASE WHEN SKU_Status = @SkuActive THEN @PriceActive ELSE @PriceInactive END
            ELSE @PriceExpired END,
       SKU_Code, K
FROM per
OPTION (MAXRECURSION 400);

INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status)
SELECT SKU_ID, Price_Type, Unit_Price, @Currency, Effective_From, Effective_To, Price_Status
FROM #PP
ORDER BY SKU_Code, Price_Type, K;
SET @RowsPrice = @@ROWCOUNT;

------------------------------------------------------------------------------
-- 4. Promotion
------------------------------------------------------------------------------
-- 4.0 v1.2: Shamsi years 1398..1405, Gregorian date of 1 Farvardin (checked with .NET PersianCalendar;
--     same list in 04, 06, 08-05 and 08-03-T2-Settings.txt). K = 8 (1406) only closes 1405.
CREATE TABLE #ShY (K int PRIMARY KEY, Shamsi_Year int NOT NULL, YS date NOT NULL, YE date NOT NULL);
INSERT #ShY (K, Shamsi_Year, YS, YE)
SELECT x.K, 1398 + x.K, x.YS, x.YE
FROM (SELECT v.K, CAST(v.YS AS date) AS YS, DATEADD(DAY, -1, CAST(LEAD(v.YS) OVER (ORDER BY v.K) AS date)) AS YE
      FROM (VALUES (0,'2019-03-21'),(1,'2020-03-20'),(2,'2021-03-21'),(3,'2022-03-21'),(4,'2023-03-21'),
                   (5,'2024-03-20'),(6,'2025-03-21'),(7,'2026-03-21'),(8,'2027-03-21')) v(K, YS)) x
WHERE x.K < 8;
IF (SELECT MIN(YS) FROM #ShY) <> @FromDate OR (SELECT MAX(YE) FROM #ShY) <> @ToDate OR (SELECT COUNT(*) FROM #ShY) <> @NYears
    THROW 50013, N'Internal error: Shamsi year mapping does not match @FromDate / @ToDate.', 1;

-- 4.1 Occasion anchors per year (Gregorian dates, approximate on purpose - mock data)
CREATE TABLE #Occ (Year_Idx int NOT NULL, Occ char(3) NOT NULL, Occ_FA nvarchar(50) NOT NULL, Anchor date NOT NULL,
                   PRIMARY KEY (Year_Idx, Occ));
INSERT #Occ (Year_Idx, Occ, Occ_FA, Anchor)
SELECT y.K, o.Occ, o.Occ_FA,
       CASE o.Occ
            WHEN 'NWR' THEN DATEADD(DAY, -14, y.YE)                                      -- pre-Nowruz shopping (15 days before next 1 Farvardin)
            WHEN 'RMZ' THEN CASE y.K WHEN 0 THEN CAST('2019-05-06' AS date) WHEN 1 THEN '2020-04-24'
                                     WHEN 2 THEN '2021-04-13' WHEN 3 THEN '2022-04-02' WHEN 4 THEN '2023-03-23'
                                     WHEN 5 THEN '2025-03-01' WHEN 6 THEN '2026-02-18' WHEN 7 THEN '2027-02-08'
                                     ELSE DATEADD(DAY, 60, y.YS) END
            WHEN 'YLD' THEN DATEFROMPARTS(YEAR(@FromDate) + y.K, 12, 10)
            WHEN 'SCH' THEN DATEFROMPARTS(YEAR(@FromDate) + y.K, 9, 5)
            WHEN 'SUM' THEN DATEFROMPARTS(YEAR(@FromDate) + y.K, 6, 21)
            ELSE y.YS END                                                               -- GEN: placed per promotion below
FROM #ShY y
CROSS JOIN (VALUES ('NWR', N'نوروز'), ('RMZ', N'ماه رمضان'), ('YLD', N'شب یلدا'),
                   ('SCH', N'بازگشایی مدارس'), ('SUM', N'تابستانه'), ('GEN', N'ویژه')) o(Occ, Occ_FA);

-- 4.2 Skeleton: one row per promotion (year, slot, occasion)
DECLARE @NPromo int = CONVERT(int, ROUND(@PromoPerYear * @NYears * @Scale, 0));
CREATE TABLE #P (
    I int NOT NULL PRIMARY KEY, Y int NOT NULL, J int NOT NULL, Occ char(3) NOT NULL, Occ_FA nvarchar(50) NOT NULL,
    Code nvarchar(30) NOT NULL, YS date NOT NULL, YE date NOT NULL,
    Start_Date date NULL, End_Date date NULL, Campaign_ID int NULL,
    Discount_Type nvarchar(30) NULL, Discount_Value decimal(18,2) NULL, Cur char(3) NULL,
    Promo_Type nvarchar(30) NULL, Ref_Price decimal(18,2) NULL     -- v1.2: reference price for the fixed-amount cap
);
;WITH n AS (SELECT TOP (@NPromo) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS I
            FROM sys.all_objects a CROSS JOIN sys.all_objects b),
s AS (
    SELECT n.I, (n.I - 1) % @NYears AS Y, (n.I - 1) / @NYears + 1 AS J FROM n
),
sl AS (
    SELECT s.*, ((s.J * 17) % 40) AS Slot FROM s
)
INSERT #P (I, Y, J, Occ, Occ_FA, Code, YS, YE)
SELECT sl.I, sl.Y, sl.J, o.Occ, o.Occ_FA,
       CONCAT(N'PRM-', @ShamsiBaseYear + sl.Y, N'-', RIGHT(CONCAT(N'000', sl.J), 3)),
       sy.YS, sy.YE                                                    -- v1.2: real Shamsi year
FROM sl
JOIN #ShY sy ON sy.K = sl.Y
JOIN #Occ o ON o.Year_Idx = sl.Y
           AND o.Occ = CASE WHEN sl.Slot < 7 THEN 'NWR' WHEN sl.Slot < 15 THEN 'RMZ' WHEN sl.Slot < 21 THEN 'YLD'
                            WHEN sl.Slot < 27 THEN 'SCH' WHEN sl.Slot < 32 THEN 'SUM' ELSE 'GEN' END;

-- 4.3 Dates: anchor +/- offset, duration by occasion, clipped to the year window
;WITH h AS (
    SELECT p.I,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRM|', p.Code, N'|0|off')))) AS HOff,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRM|', p.Code, N'|0|dur')))) AS HDur,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRM|', p.Code, N'|0|gen')))) AS HGen
    FROM #P p
),
d AS (
    SELECT p.I, p.YS, p.YE,
           CASE WHEN p.Occ = 'GEN'
                THEN DATEADD(DAY, h.HGen % CASE WHEN DATEDIFF(DAY, p.YS, p.YE) - 10 > 1 THEN DATEDIFF(DAY, p.YS, p.YE) - 10 ELSE 1 END, p.YS)
                ELSE DATEADD(DAY, (h.HOff % 8) - 3, o.Anchor) END AS S0,
           CASE p.Occ WHEN 'NWR' THEN 14 + h.HDur % 7  WHEN 'RMZ' THEN 10 + h.HDur % 16
                      WHEN 'YLD' THEN 4 + h.HDur % 5   WHEN 'SCH' THEN 10 + h.HDur % 6
                      WHEN 'SUM' THEN 7 + h.HDur % 8   ELSE 3 + h.HDur % 8 END AS Dur
    FROM #P p JOIN h ON h.I = p.I JOIN #Occ o ON o.Year_Idx = p.Y AND o.Occ = p.Occ
),
c AS (
    SELECT d.I,
           CASE WHEN d.S0 < d.YS THEN d.YS WHEN d.S0 > d.YE THEN d.YE ELSE d.S0 END AS S1,
           DATEADD(DAY, d.Dur - 1, d.S0) AS E0, d.YE
    FROM d
)
UPDATE p SET Start_Date = c.S1,
             End_Date   = CASE WHEN c.E0 > c.YE THEN c.YE WHEN c.E0 < c.S1 THEN c.S1 ELSE c.E0 END
FROM #P p JOIN c ON c.I = p.I;

-- 4.4 Optional campaign link: inside the campaign period (promotion is clipped to the overlap, min 3 days)
;WITH cand AS (
    SELECT p.I, mc.Marketing_Campaign_ID,
           CASE WHEN p.Start_Date > mc.Start_Date THEN p.Start_Date ELSE mc.Start_Date END AS S2,
           CASE WHEN p.End_Date < ISNULL(mc.End_Date, @ToDate) THEN p.End_Date ELSE ISNULL(mc.End_Date, @ToDate) END AS E2,
           ROW_NUMBER() OVER (PARTITION BY p.I ORDER BY
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
                   CONCAT(@Seed, N'|PRM|', p.Code, N'|', mc.Campaign_Name, N'|link'))))) AS Rn
    FROM #P p
    JOIN marketing.MarketingCampaign mc
      ON mc.Campaign_Purpose = @CampaignPurpose
     AND mc.Campaign_Status <> @CampaignExcl
     AND mc.Start_Date <= p.End_Date
     AND ISNULL(mc.End_Date, @ToDate) >= p.Start_Date
    WHERE CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256',
              CONCAT(@Seed, N'|PRM|', p.Code, N'|0|linkflag')))) % 100 < @LinkPct
)
UPDATE p SET Campaign_ID = cand.Marketing_Campaign_ID, Start_Date = cand.S2, End_Date = cand.E2
FROM #P p JOIN cand ON cand.I = p.I
WHERE cand.Rn = 1 AND DATEDIFF(DAY, cand.S2, cand.E2) >= 2;

-- 4.5 Discount type/value, promotion type
-- v1.2 reference price of a promotion = 25th percentile of the Standard list prices valid on its start date
--      (PERCENTILE_DISC returns the decimal column value itself; PERCENTILE_CONT returns float, guide section 4)
UPDATE p SET Ref_Price = r.P25
FROM #P p
CROSS APPLY (SELECT TOP (1) PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY pp.Unit_Price) OVER () AS P25
             FROM #PP pp
             WHERE pp.Price_Type = @PriceType AND pp.Effective_From <= p.Start_Date
               AND (pp.Effective_To IS NULL OR pp.Effective_To >= p.Start_Date)) r;

;WITH h AS (
    SELECT p.I,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRM|', p.Code, N'|0|dtype')))) AS HT,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRM|', p.Code, N'|0|dval')))) AS HV,
           CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRM|', p.Code, N'|0|ptype')))) AS HP
    FROM #P p
)
UPDATE p SET
    Discount_Type  = CASE WHEN h.HT % 100 < 70 THEN N'Percentage' ELSE N'Fixed Amount' END,
    Discount_Value = CASE WHEN h.HT % 100 < 70
                          THEN CAST(CHOOSE(1 + h.HV % 7, 5.0, 7.5, 10.0, 12.0, 15.0, 20.0, 25.0) AS decimal(18,2))
                          -- v1.2: 10..25% of the reference price, rounded DOWN to 1,000 IRR (never above the 25% cap)
                          ELSE CAST(FLOOR(p.Ref_Price * CHOOSE(1 + h.HV % 4, 0.10, 0.15, 0.20, 0.25) / 1000) * 1000 AS decimal(18,2)) END,
    Cur            = CASE WHEN h.HT % 100 < 70 THEN NULL ELSE @Currency END,
    Promo_Type     = CASE WHEN p.Occ <> 'GEN' THEN N'Seasonal'                      -- [ASSUMED] D-07
                          WHEN h.HP % 2 = 0   THEN N'Volume' ELSE N'Clearance' END  -- [ASSUMED] D-07
FROM #P p JOIN h ON h.I = p.I;

-- (v1.1 lifted fixed amounts by the price index; v1.2 takes them from the dated reference price above)
IF EXISTS (SELECT 1 FROM #P WHERE Discount_Type = N'Percentage' AND Discount_Value > @MaxDiscountPct)
    THROW 50010, N'Generated percentage discount exceeds the approved cap.', 1;
IF EXISTS (SELECT 1 FROM #P WHERE Discount_Type = N'Fixed Amount'
                              AND (Ref_Price IS NULL OR Discount_Value > Ref_Price * @MaxDiscountPct / 100))
    THROW 50012, N'Generated fixed-amount discount exceeds 25% of the reference price (or no reference price).', 1;
IF EXISTS (SELECT 1 FROM #P WHERE Discount_Value <= 0 OR Start_Date IS NULL OR End_Date < Start_Date)
    THROW 50011, N'Internal generator error in #P (value/date).', 1;

INSERT marketing.Promotion (Marketing_Campaign_ID, Promotion_Code, Promotion_Name, Promotion_Type, Discount_Type,
                            Discount_Value, Currency, Start_Date, End_Date, Promotion_Status)
SELECT Campaign_ID, Code,
       CONCAT(N'جشنواره ', Occ_FA, N' ', @ShamsiBaseYear + Y, N' - شماره ', J),
       Promo_Type, Discount_Type, Discount_Value, Cur, Start_Date, End_Date,
       CASE WHEN End_Date < @AsOfDate THEN @PromoExpired
            WHEN Start_Date > @AsOfDate THEN @PromoPlanned
            ELSE @PromoActive END
FROM #P
ORDER BY Start_Date, Code;
SET @RowsPromo = @@ROWCOUNT;

COMMIT TRAN;

IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
    INSERT #T2LoadLog (Script_Name, Table_Name, Input_Rows, Inserted_Rows)
    VALUES (N'08-03-T2-05', N'marketing.ProductPrice', @RowsPrice, @RowsPrice),
           (N'08-03-T2-05', N'marketing.Promotion', @RowsPromo, @RowsPromo);

------------------------------------------------------------------------------
-- 5. Load log (Q18)
------------------------------------------------------------------------------
PRINT CONCAT(N'DataVersion = ', @DataVersion, N' | Seed = ', @Seed, N' | Scale = ', @Scale, N' | Mult = ', @Mult);
PRINT CONCAT(N'marketing.ProductPrice : inserted ', @RowsPrice, N' rows, rejected 0');
DECLARE @RowsLinked int;
SELECT @RowsLinked = COUNT(*) FROM marketing.Promotion WHERE Marketing_Campaign_ID IS NOT NULL;
PRINT CONCAT(N'marketing.Promotion    : inserted ', @RowsPromo, N' rows, rejected 0 (linked to a campaign: ', @RowsLinked, N')');

-- Promotion list for the issue comment (Team 1 links orders only inside the active period)
SELECT Promotion_Code, Start_Date, End_Date, Discount_Type, Discount_Value, Currency, Promotion_Status
FROM marketing.Promotion
ORDER BY Start_Date, Promotion_Code;

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    PRINT CONCAT(N'ERROR ', ERROR_NUMBER(), N' (line ', ERROR_LINE(), N'): ', ERROR_MESSAGE());
    PRINT N'Transaction rolled back - nothing was inserted.';
    THROW;
END CATCH;
