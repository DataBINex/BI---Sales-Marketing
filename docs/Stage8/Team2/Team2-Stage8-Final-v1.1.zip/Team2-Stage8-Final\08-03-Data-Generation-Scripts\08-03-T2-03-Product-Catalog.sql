/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.1 author: atieht, #189; integration v1.1: SinaSepasi, #196)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T2-03-Product-Catalog.sql
 Version       : 1.1
 Purpose       : Load ref.ProductCategory, ref.Package, core.Product, core.SKU
 Run Order     : 3 (prerequisite: core.Brand from 08-03-T2-01)
 Prerequisites : the four tables are empty; the 10 Team 2 brands T2S8BR001..010 exist
 Seed/Config   : settings block below; @Scale comes from SESSION_CONTEXT('T2_Scale') (default 0.10)
 Date          : 2026-11-04 (static text; the script never reads the clock)
 Tables        : ProductCategory 35, Package 12 (always full); Product 200 / SKU ~380 (20 / ~38 at 10%)

 Integration changes v1.1 (categories, packages and code formats of the member's v1.0 are kept):
   1. v1.0 did not compile (aggregate with an outer reference in the barcode check digit) and its
      barcode base had 10 digits (EAN-13 needs 12 + check digit). The barcode is now
      200000000000 + SKU sequence (prefix 200) with a correct EAN-13 check digit.
   2. Brand and category fit: each brand has a fixed focus (level-1 categories, see @BrandFocus);
      a product is placed only in a leaf of its brand's focus, round robin over those leaves, so
      every leaf category has products in the full run. Brand shares are unbalanced (2.5%..25%).
   3. Realistic names: product stem of the leaf category + brand name; SKU = product + pack size.
      Unit, product type, tax rate, pack weight and package follow the leaf category.
   4. Launch_Date: 55% of products are candidates for a launch before 1398/01/01, but only when the
      brand started at least 365 days before it (full run: 49 of 200; Master attribute, counted
      exception T2-S8-09); the rest during the period; never before Brand_Start_Date. Products of inactive brands are Discontinued.
   5. Product_Created_Date = launch - 15..74 days at 09:00 (deterministic, T2-S8-06);
      Product_Updated_Date >= Product_Created_Date or NULL.
   6. Standard_Cost = cost at base year 1398 (IRR): cost per kg of the leaf x pack weight x brand tier.
      SKU_Status: Inactive for Discontinued products, otherwise Active.
   7. The 10% sample is the first 20 products of the full list (same codes, same values).
   8. Temp table #Prod is dropped at the start (safe second run in the same session).
============================================================================= */
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;

SET NOCOUNT ON;
SET XACT_ABORT ON;
DROP TABLE IF EXISTS #Prod;

DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10); -- 0.10 Test / 1.00 Full
DECLARE @FromDate    date         = '2019-03-21';  -- 1398/01/01
DECLARE @ToDate      date         = '2027-03-20';  -- 1405/12/29
DECLARE @AsOfDate    date         = '2027-03-20';  -- status reference date (T2-S8-04)

DECLARE @FullProducts   int  = 200;
DECLARE @PreRangeLaunch date = '2014-03-21';       -- earliest launch (1393/01/01)
DECLARE @LastLaunch     date = '2026-09-22';       -- last launch, leaves at least 6 months of sales
DECLARE @ProductCount   int  = CONVERT(int, ROUND(@FullProducts * @Scale, 0));

IF @Scale NOT IN (0.10, 1.00)
    THROW 51001, 'Scale must be 0.10 or 1.00.', 1;
IF EXISTS (SELECT 1 FROM ref.ProductCategory) OR EXISTS (SELECT 1 FROM ref.Package)
   OR EXISTS (SELECT 1 FROM core.Product) OR EXISTS (SELECT 1 FROM core.SKU)
    THROW 51003, 'STOP: ProductCategory, Package, Product or SKU already has rows. Clean only with 08-03-T2-00-Reset.sql.', 1;
IF (SELECT COUNT(*) FROM core.Brand WHERE Brand_Code LIKE N'T2S8BR0[01][0-9]' AND Brand_Start_Date IS NOT NULL) < 10
    THROW 51007, 'STOP: the 10 Team 2 brands (T2S8BR001..010) are missing. Run 08-03-T2-01 first.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    ------------------------------------------------------------
    -- 1. PRODUCT CATEGORY (member list, two levels; trigger TR_ProductCategory_Hierarchy checks levels)
    ------------------------------------------------------------
    DECLARE @Categories TABLE (Category_Code nvarchar(30) PRIMARY KEY, Category_Name nvarchar(150),
                               Parent_Code nvarchar(30), Category_Level int, Category_Status nvarchar(30));
    INSERT INTO @Categories VALUES
    (N'CAT-001',N'مواد غذایی',NULL,1,N'Active'), (N'CAT-002',N'نوشیدنی',NULL,1,N'Active'),
    (N'CAT-003',N'لبنیات',NULL,1,N'Active'), (N'CAT-004',N'پروتئینی',NULL,1,N'Active'),
    (N'CAT-005',N'خشکبار و تنقلات',NULL,1,N'Active'), (N'CAT-006',N'بهداشتی',NULL,1,N'Active'),
    (N'CAT-007',N'مواد شوینده',NULL,1,N'Active'), (N'CAT-008',N'محصولات منجمد',NULL,1,N'Active'),
    (N'CAT-009',N'مواد اولیه',NULL,1,N'Active'),
    (N'CAT-010',N'برنج',N'CAT-001',2,N'Active'), (N'CAT-011',N'روغن',N'CAT-001',2,N'Active'),
    (N'CAT-012',N'قند و شکر',N'CAT-001',2,N'Active'), (N'CAT-013',N'حبوبات',N'CAT-001',2,N'Active'),
    (N'CAT-014',N'آرد و غلات',N'CAT-001',2,N'Active'),
    (N'CAT-015',N'آب معدنی',N'CAT-002',2,N'Active'), (N'CAT-016',N'نوشابه',N'CAT-002',2,N'Active'),
    (N'CAT-017',N'آبمیوه',N'CAT-002',2,N'Active'),
    (N'CAT-018',N'شیر',N'CAT-003',2,N'Active'), (N'CAT-019',N'ماست',N'CAT-003',2,N'Active'),
    (N'CAT-020',N'پنیر',N'CAT-003',2,N'Active'), (N'CAT-021',N'کره و خامه',N'CAT-003',2,N'Active'),
    (N'CAT-022',N'گوشت',N'CAT-004',2,N'Active'), (N'CAT-023',N'مرغ',N'CAT-004',2,N'Active'),
    (N'CAT-024',N'ماهی',N'CAT-004',2,N'Active'),
    (N'CAT-025',N'آجیل',N'CAT-005',2,N'Active'), (N'CAT-026',N'بیسکویت',N'CAT-005',2,N'Active'),
    (N'CAT-027',N'شکلات',N'CAT-005',2,N'Active'),
    (N'CAT-028',N'محصولات بهداشت فردی',N'CAT-006',2,N'Active'), (N'CAT-029',N'دستمال کاغذی',N'CAT-006',2,N'Active'),
    (N'CAT-030',N'شوینده لباس',N'CAT-007',2,N'Active'), (N'CAT-031',N'شوینده ظروف',N'CAT-007',2,N'Active'),
    (N'CAT-032',N'سبزیجات منجمد',N'CAT-008',2,N'Active'), (N'CAT-033',N'غذاهای آماده منجمد',N'CAT-008',2,N'Active'),
    (N'CAT-034',N'ادویه',N'CAT-009',2,N'Active'), (N'CAT-035',N'چاشنی',N'CAT-009',2,N'Active');

    DECLARE @CategoryMap TABLE (Category_Code nvarchar(30) PRIMARY KEY, Product_Category_ID int NOT NULL);

    INSERT INTO ref.ProductCategory (Category_Code, Category_Name, Parent_Category_ID, Category_Level, Category_Status)
    OUTPUT INSERTED.Category_Code, INSERTED.Product_Category_ID INTO @CategoryMap
    SELECT Category_Code, Category_Name, NULL, Category_Level, Category_Status
    FROM @Categories WHERE Parent_Code IS NULL
    ORDER BY Category_Code;

    INSERT INTO ref.ProductCategory (Category_Code, Category_Name, Parent_Category_ID, Category_Level, Category_Status)
    OUTPUT INSERTED.Category_Code, INSERTED.Product_Category_ID INTO @CategoryMap
    SELECT C.Category_Code, C.Category_Name, P.Product_Category_ID, C.Category_Level, C.Category_Status
    FROM @Categories C JOIN @CategoryMap P ON P.Category_Code = C.Parent_Code
    ORDER BY C.Category_Code;

    IF (SELECT COUNT(*) FROM @CategoryMap) <> 35
        THROW 51008, 'Category load count mismatch.', 1;

    ------------------------------------------------------------
    -- 2. PACKAGE (member list)
    ------------------------------------------------------------
    INSERT INTO ref.Package (Package_Code, Package_Name, Package_Description)
    VALUES
    (N'PKG-001',N'بسته تکی',N'بسته‌بندی یک واحد مصرفی'), (N'PKG-002',N'بسته چندتایی',N'چند واحد مصرفی در یک بسته'),
    (N'PKG-003',N'کارتن کوچک',N'کارتن تا ۵ کیلوگرم'), (N'PKG-004',N'کارتن متوسط',N'کارتن ۵ تا ۱۵ کیلوگرم'),
    (N'PKG-005',N'کارتن بزرگ',N'کارتن بیش از ۱۵ کیلوگرم یا حجیم'), (N'PKG-006',N'کیسه',N'کیسه پلاستیکی یا کنفی'),
    (N'PKG-007',N'بطری',N'بطری پلاستیکی یا PET'), (N'PKG-008',N'قوطی',N'قوطی فلزی'),
    (N'PKG-009',N'ظرف پلاستیکی',N'ظرف یا سطل پلاستیکی'), (N'PKG-010',N'ظرف شیشه‌ای',N'شیشه یا بانکه'),
    (N'PKG-011',N'پاکت',N'پاکت مقوایی یا تتراپک'), (N'PKG-012',N'بسته صنعتی',N'بسته‌بندی عمده برای مصرف صنعتی و رستورانی');

    ------------------------------------------------------------
    -- 3. Generation rules per leaf category and per brand
    ------------------------------------------------------------
    -- Leaf: 4 product stems, unit, type, tax rate, cost per kg at 1398 (IRR), 3 pack sizes (label, kg, package)
    DECLARE @Leaf TABLE (Category_Code nvarchar(30) PRIMARY KEY, St1 nvarchar(60), St2 nvarchar(60), St3 nvarchar(60), St4 nvarchar(60),
                         UoM nvarchar(20), PType nvarchar(30), Tax decimal(5,2), Cost_Per_Kg decimal(18,2),
                         L1 nvarchar(60), K1 decimal(10,3), P1 nvarchar(30), L2 nvarchar(60), K2 decimal(10,3), P2 nvarchar(30),
                         L3 nvarchar(60), K3 decimal(10,3), P3 nvarchar(30));
    INSERT INTO @Leaf VALUES
    (N'CAT-010',N'برنج طارم',N'برنج هاشمی',N'برنج دانه‌بلند',N'برنج کشت دوم',N'KG',N'Raw',0,120000, N'کیسه ۱ کیلوگرمی',1,N'PKG-006',N'کیسه ۵ کیلوگرمی',5,N'PKG-006',N'کیسه ۱۰ کیلوگرمی',10,N'PKG-006'),
    (N'CAT-011',N'روغن مایع آفتابگردان',N'روغن کانولا',N'روغن سرخ‌کردنی',N'روغن زیتون',N'Liter',N'Processed',0,90000, N'بطری ۸۱۰ گرمی',0.81,N'PKG-007',N'بطری ۱.۵ لیتری',1.35,N'PKG-007',N'قوطی ۴ لیتری',3.6,N'PKG-008'),
    (N'CAT-012',N'شکر سفید',N'قند حبه',N'شکر قهوه‌ای',N'قند شکسته',N'KG',N'Raw',0,50000, N'بسته ۹۰۰ گرمی',0.9,N'PKG-001',N'کیسه ۵ کیلوگرمی',5,N'PKG-006',N'کیسه صنعتی ۵۰ کیلوگرمی',50,N'PKG-012'),
    (N'CAT-013',N'عدس',N'لوبیا چیتی',N'نخود',N'لپه',N'KG',N'Raw',0,120000, N'بسته ۵۰۰ گرمی',0.5,N'PKG-001',N'بسته ۹۰۰ گرمی',0.9,N'PKG-001',N'کیسه ۵ کیلوگرمی',5,N'PKG-006'),
    (N'CAT-014',N'آرد گندم',N'ماکارونی',N'جو پرک',N'رشته آش',N'KG',N'Raw',0,40000, N'بسته ۵۰۰ گرمی',0.5,N'PKG-011',N'کیسه ۲ کیلوگرمی',2,N'PKG-006',N'کیسه صنعتی ۲۵ کیلوگرمی',25,N'PKG-012'),
    (N'CAT-015',N'آب معدنی',N'آب آشامیدنی',N'آب معدنی گازدار',N'آب معدنی کم‌سدیم',N'Liter',N'Packaged',9,8000, N'بطری ۰.۵ لیتری',0.5,N'PKG-007',N'بطری ۱.۵ لیتری',1.5,N'PKG-007',N'بسته ۶ عددی ۱.۵ لیتری',9,N'PKG-002'),
    (N'CAT-016',N'نوشابه کولا',N'نوشابه پرتقالی',N'نوشابه لیمویی',N'ماءالشعیر',N'Liter',N'Packaged',9,25000, N'قوطی ۳۳۰ میلی‌لیتری',0.33,N'PKG-008',N'بطری ۱.۵ لیتری',1.5,N'PKG-007',N'کارتن ۲۴ عددی قوطی',7.92,N'PKG-003'),
    (N'CAT-017',N'آبمیوه پرتقال',N'آبمیوه سیب',N'آبمیوه انبه',N'نکتار هلو',N'Liter',N'Processed',9,60000, N'پاکت ۲۰۰ میلی‌لیتری',0.2,N'PKG-011',N'پاکت ۱ لیتری',1,N'PKG-011',N'بسته ۶ عددی ۱ لیتری',6,N'PKG-002'),
    (N'CAT-018',N'شیر کم‌چرب',N'شیر پرچرب',N'شیر کاکائو',N'شیر بدون لاکتوز',N'Liter',N'Processed',0,40000, N'پاکت ۱ لیتری',1,N'PKG-011',N'بطری ۲ لیتری',2,N'PKG-007',N'کارتن ۱۲ عددی ۱ لیتری',12,N'PKG-004'),
    (N'CAT-019',N'ماست کم‌چرب',N'ماست پرچرب',N'ماست چکیده',N'ماست موسیر',N'KG',N'Processed',0,50000, N'ظرف ۵۰۰ گرمی',0.5,N'PKG-009',N'ظرف ۹۰۰ گرمی',0.9,N'PKG-009',N'ظرف ۲.۵ کیلوگرمی',2.5,N'PKG-009'),
    (N'CAT-020',N'پنیر سفید',N'پنیر لبنه',N'پنیر پیتزا',N'پنیر خامه‌ای',N'KG',N'Processed',9,250000, N'بسته ۴۰۰ گرمی',0.4,N'PKG-001',N'ظرف ۸۰۰ گرمی',0.8,N'PKG-009',N'قوطی ۲ کیلوگرمی',2,N'PKG-008'),
    (N'CAT-021',N'کره حیوانی',N'خامه صبحانه',N'خامه قنادی',N'کره گیاهی',N'KG',N'Processed',9,400000, N'بسته ۱۰۰ گرمی',0.1,N'PKG-001',N'بسته ۵۰۰ گرمی',0.5,N'PKG-001',N'ظرف ۲ کیلوگرمی',2,N'PKG-009'),
    (N'CAT-022',N'گوشت چرخ‌کرده',N'گوشت گوساله',N'گوشت گوسفندی',N'همبرگر',N'KG',N'Raw',0,900000, N'بسته ۵۰۰ گرمی',0.5,N'PKG-001',N'بسته ۱ کیلوگرمی',1,N'PKG-001',N'کارتن ۵ کیلوگرمی',5,N'PKG-003'),
    (N'CAT-023',N'مرغ کامل',N'سینه مرغ',N'ران مرغ',N'بال مرغ',N'KG',N'Raw',0,140000, N'بسته ۹۰۰ گرمی',0.9,N'PKG-001',N'بسته ۱.۸ کیلوگرمی',1.8,N'PKG-001',N'کارتن ۱۰ کیلوگرمی',10,N'PKG-004'),
    (N'CAT-024',N'کنسرو ماهی تن',N'ماهی قزل‌آلا',N'فیله ماهی',N'میگو',N'KG',N'Processed',9,350000, N'قوطی ۱۸۰ گرمی',0.18,N'PKG-008',N'بسته ۵۰۰ گرمی',0.5,N'PKG-001',N'کارتن ۲۴ عددی قوطی',4.32,N'PKG-003'),
    (N'CAT-025',N'پسته',N'بادام',N'گردو',N'آجیل مخلوط',N'KG',N'Raw',9,1200000, N'بسته ۲۵۰ گرمی',0.25,N'PKG-001',N'ظرف ۵۰۰ گرمی',0.5,N'PKG-009',N'ظرف شیشه‌ای ۱ کیلوگرمی',1,N'PKG-010'),
    (N'CAT-026',N'بیسکویت سبوس‌دار',N'کراکر',N'بیسکویت کرم‌دار',N'کوکی',N'KG',N'Packaged',9,200000, N'بسته ۱۰۰ گرمی',0.1,N'PKG-001',N'بسته چندتایی ۶ عددی',0.6,N'PKG-002',N'کارتن ۴۸ عددی',4.8,N'PKG-003'),
    (N'CAT-027',N'شکلات شیری',N'شکلات تلخ',N'ویفر شکلاتی',N'شکلات مغزدار',N'KG',N'Packaged',9,500000, N'بسته ۵۰ گرمی',0.05,N'PKG-001',N'جعبه ۲۵۰ گرمی',0.25,N'PKG-003',N'کارتن ۲۴ عددی',1.2,N'PKG-003'),
    (N'CAT-028',N'شامپو',N'صابون مایع',N'خمیر دندان',N'ژل بهداشتی',N'Unit',N'Packaged',9,300000, N'بطری ۴۰۰ میلی‌لیتری',0.4,N'PKG-007',N'بطری ۱ لیتری',1,N'PKG-007',N'کارتن ۱۲ عددی',4.8,N'PKG-004'),
    (N'CAT-029',N'دستمال کاغذی جعبه‌ای',N'دستمال آشپزخانه',N'دستمال توالت',N'دستمال جیبی',N'Unit',N'Packaged',9,150000, N'بسته ۱۰۰ برگ',0.3,N'PKG-001',N'بسته ۶ عددی',1.8,N'PKG-002',N'کارتن بزرگ ۲۴ عددی',7.2,N'PKG-005'),
    (N'CAT-030',N'پودر لباسشویی',N'مایع لباسشویی',N'نرم‌کننده لباس',N'پودر دستی',N'KG',N'Packaged',9,120000, N'جعبه ۵۰۰ گرمی',0.5,N'PKG-003',N'کیسه ۳ کیلوگرمی',3,N'PKG-006',N'ظرف ۴ لیتری',4,N'PKG-009'),
    (N'CAT-031',N'مایع ظرفشویی',N'پودر ماشین ظرفشویی',N'قرص ماشین ظرفشویی',N'جرم‌گیر ظروف',N'KG',N'Packaged',9,90000, N'بطری ۷۵۰ گرمی',0.75,N'PKG-007',N'بطری ۱.۵ کیلوگرمی',1.5,N'PKG-007',N'ظرف ۴ کیلوگرمی',4,N'PKG-009'),
    (N'CAT-032',N'نخود فرنگی منجمد',N'سبزیجات مخلوط منجمد',N'ذرت منجمد',N'سیب‌زمینی منجمد',N'KG',N'Processed',9,150000, N'بسته ۴۰۰ گرمی',0.4,N'PKG-001',N'بسته ۱ کیلوگرمی',1,N'PKG-001',N'کارتن ۱۰ کیلوگرمی',10,N'PKG-004'),
    (N'CAT-033',N'پیتزای منجمد',N'ناگت مرغ',N'کوکوی آماده',N'لازانیای منجمد',N'KG',N'Processed',9,300000, N'بسته ۳۰۰ گرمی',0.3,N'PKG-001',N'بسته خانواده ۱ کیلوگرمی',1,N'PKG-001',N'کارتن ۱۲ عددی',3.6,N'PKG-003'),
    (N'CAT-034',N'زردچوبه',N'فلفل سیاه',N'زعفران',N'دارچین',N'KG',N'Raw',9,600000, N'بسته ۵۰ گرمی',0.05,N'PKG-001',N'ظرف شیشه‌ای ۱۰۰ گرمی',0.1,N'PKG-010',N'بسته صنعتی ۱ کیلوگرمی',1,N'PKG-012'),
    (N'CAT-035',N'سس مایونز',N'رب گوجه‌فرنگی',N'سس کچاپ',N'آبلیمو',N'KG',N'Processed',9,150000, N'بطری ۴۵۰ گرمی',0.45,N'PKG-007',N'ظرف شیشه‌ای ۷۰۰ گرمی',0.7,N'PKG-010',N'قوطی ۴ کیلوگرمی',4,N'PKG-008');

    -- Brand focus: level-1 categories, share of products (%), price tier
    DECLARE @BrandFocus TABLE (Brand_Code nvarchar(30), Parent_Code nvarchar(30), PRIMARY KEY (Brand_Code, Parent_Code));
    INSERT INTO @BrandFocus VALUES
    (N'T2S8BR001',N'CAT-001'),(N'T2S8BR001',N'CAT-009'),(N'T2S8BR002',N'CAT-002'),(N'T2S8BR003',N'CAT-005'),
    (N'T2S8BR004',N'CAT-003'),(N'T2S8BR005',N'CAT-006'),(N'T2S8BR005',N'CAT-007'),(N'T2S8BR006',N'CAT-002'),
    (N'T2S8BR006',N'CAT-005'),(N'T2S8BR007',N'CAT-001'),(N'T2S8BR007',N'CAT-008'),(N'T2S8BR008',N'CAT-004'),
    (N'T2S8BR008',N'CAT-008'),(N'T2S8BR009',N'CAT-003'),(N'T2S8BR010',N'CAT-005');
    DECLARE @BrandShare TABLE (Brand_Code nvarchar(30) PRIMARY KEY, Cum_From int, Cum_To int, Tier decimal(4,2));
    INSERT INTO @BrandShare VALUES
    (N'T2S8BR001', 0,20,1.00),(N'T2S8BR004',20,35,1.05),(N'T2S8BR007',35,49,0.85),(N'T2S8BR002',49,61,1.00),
    (N'T2S8BR005',61,71,1.00),(N'T2S8BR003',71,79,1.25),(N'T2S8BR006',79,87,1.10),(N'T2S8BR008',87,94,1.15),
    (N'T2S8BR009',94,97,1.00),(N'T2S8BR010',97,100,0.90);

    ------------------------------------------------------------
    -- 4. PRODUCT
    ------------------------------------------------------------
    CREATE TABLE #Prod (Product_No int PRIMARY KEY, Product_Code nvarchar(30) NOT NULL, Brand_ID int NOT NULL, Brand_Code nvarchar(30) NOT NULL,
                        Brand_Name nvarchar(150) NOT NULL, Tier decimal(4,2) NOT NULL, Category_Code nvarchar(30) NOT NULL,
                        Product_Category_ID int NOT NULL, Stem nvarchar(60) NOT NULL, Product_Name nvarchar(150) NULL,
                        Launch_Date date NOT NULL, Product_Status nvarchar(30) NOT NULL, Created datetime2(0) NOT NULL,
                        Updated datetime2(0) NULL, SKU_Count int NOT NULL);

    ;WITH N AS (
        SELECT TOP (@ProductCount) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Product_No
        FROM sys.all_objects A CROSS JOIN sys.all_objects B
    ),
    H AS (
        SELECT Product_No,
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRODUCT|', Product_No, N'|brand')))) AS HB,
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRODUCT|', Product_No, N'|leaf'))))  AS HL,
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRODUCT|', Product_No, N'|stem'))))  AS HS,
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRODUCT|', Product_No, N'|launch')))) AS HD,
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRODUCT|', Product_No, N'|status')))) AS HT,
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|PRODUCT|', Product_No, N'|sku'))))   AS HK
        FROM N
    ),
    B AS (
        SELECT H.*, bs.Brand_Code, bs.Tier, b.Brand_ID, b.Brand_Name, b.Brand_Start_Date, b.Brand_End_Date,
               ROW_NUMBER() OVER (PARTITION BY bs.Brand_Code ORDER BY H.Product_No) AS Brand_Seq
        FROM H
        JOIN @BrandShare bs ON H.HB % 100 >= bs.Cum_From AND H.HB % 100 < bs.Cum_To
        JOIN core.Brand b ON b.Brand_Code = bs.Brand_Code
    ),
    L AS (
        SELECT B.*, lf.Category_Code, lf.Rn, lf.Cnt
        FROM B
        CROSS APPLY (SELECT c.Category_Code,
                            ROW_NUMBER() OVER (ORDER BY c.Category_Code) AS Rn,
                            COUNT(*) OVER () AS Cnt
                     FROM @Categories c JOIN @BrandFocus f ON f.Parent_Code = c.Parent_Code AND f.Brand_Code = B.Brand_Code) lf
    ),
    P AS (
        SELECT L.*,
               CASE WHEN L.Brand_Start_Date > @PreRangeLaunch THEN L.Brand_Start_Date ELSE @PreRangeLaunch END AS Win_Pre_From,
               CASE WHEN L.Brand_Start_Date > @FromDate THEN L.Brand_Start_Date ELSE @FromDate END AS Win_In_From,
               CASE WHEN L.Brand_End_Date IS NOT NULL AND DATEADD(YEAR, -2, L.Brand_End_Date) < @LastLaunch
                    THEN DATEADD(YEAR, -2, L.Brand_End_Date) ELSE @LastLaunch END AS Win_In_To
        FROM L
        -- round robin over the brand's leaves (start leaf by brand hash): every leaf gets products
        WHERE L.Rn = 1 + (L.Brand_Seq - 1 + CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|BRAND|', L.Brand_Code, N'|leaf0'))))) % L.Cnt
    )
    INSERT #Prod (Product_No, Product_Code, Brand_ID, Brand_Code, Brand_Name, Tier, Category_Code, Product_Category_ID, Stem,
                  Launch_Date, Product_Status, Created, Updated, SKU_Count)
    SELECT P.Product_No,
           CONCAT(N'T2S8PRD', RIGHT(CONCAT(N'000', P.Product_No), 3)),
           P.Brand_ID, P.Brand_Code, P.Brand_Name, P.Tier, P.Category_Code, cm.Product_Category_ID,
           CHOOSE(1 + P.HS % 4, lf.St1, lf.St2, lf.St3, lf.St4),
           d.Launch_Date,
           CASE WHEN P.Brand_End_Date IS NOT NULL THEN N'Discontinued'
                WHEN P.HT % 100 < 7 AND d.Launch_Date < '2023-03-21' THEN N'Discontinued'
                ELSE N'Active' END,
           DATEADD(HOUR, 9, CAST(DATEADD(DAY, -(15 + CONVERT(int, P.HT % 60)), d.Launch_Date) AS datetime2(0))),
           CASE WHEN P.HT % 100 >= 70 THEN NULL
                WHEN DATEADD(DAY, 30 + CONVERT(int, (P.HT / 100) % 1500), d.Launch_Date) > @AsOfDate
                     THEN DATEADD(HOUR, 17, CAST(@AsOfDate AS datetime2(0)))
                ELSE DATEADD(HOUR, 17, CAST(DATEADD(DAY, 30 + CONVERT(int, (P.HT / 100) % 1500), d.Launch_Date) AS datetime2(0))) END,
           CASE WHEN P.HK % 100 < 35 THEN 1 WHEN P.HK % 100 < 75 THEN 2 ELSE 3 END
    FROM P
    JOIN @Leaf lf ON lf.Category_Code = P.Category_Code
    JOIN @CategoryMap cm ON cm.Category_Code = P.Category_Code
    CROSS APPLY (SELECT CASE WHEN P.HD % 100 < 55 AND DATEDIFF(DAY, P.Win_Pre_From, @FromDate) >= 365
                             THEN DATEADD(DAY, CONVERT(int, (P.HD / 100) % (DATEDIFF(DAY, P.Win_Pre_From, @FromDate))), P.Win_Pre_From)
                             ELSE DATEADD(DAY, CONVERT(int, (P.HD / 100) % (DATEDIFF(DAY, P.Win_In_From, P.Win_In_To) + 1)), P.Win_In_From)
                        END AS Launch_Date) d;

    -- name = stem + brand; a repeated name gets a series number
    ;WITH nm AS (SELECT Product_No, CONCAT(Stem, N' ', Brand_Name) AS Base_Name,
                        ROW_NUMBER() OVER (PARTITION BY Stem, Brand_Code ORDER BY Product_No) AS Rn FROM #Prod)
    UPDATE p SET Product_Name = CASE WHEN nm.Rn = 1 THEN nm.Base_Name ELSE CONCAT(nm.Base_Name, N' - سری ', nm.Rn) END
    FROM #Prod p JOIN nm ON nm.Product_No = p.Product_No;

    DECLARE @ProductMap TABLE (Product_ID int NOT NULL, Product_Code nvarchar(30) PRIMARY KEY);

    INSERT INTO core.Product (Product_Code, Product_Name, Product_Description, Product_Category_ID, Brand_ID, Product_Type,
                              Unit_Of_Measure, Product_Status, Launch_Date, Weight, Tax_Rate, Product_Created_Date, Product_Updated_Date)
    OUTPUT INSERTED.Product_ID, INSERTED.Product_Code INTO @ProductMap
    SELECT p.Product_Code, p.Product_Name,
           CONCAT(p.Stem, N' با برند ', p.Brand_Name, N' در دسته ', c.Category_Name, N'؛ داده ساختگی مرحله ۸.'),
           p.Product_Category_ID, p.Brand_ID, lf.PType, lf.UoM, p.Product_Status, p.Launch_Date, lf.K1, lf.Tax,
           p.Created, p.Updated
    FROM #Prod p
    JOIN @Leaf lf ON lf.Category_Code = p.Category_Code
    JOIN @Categories c ON c.Category_Code = p.Category_Code
    ORDER BY p.Product_No;

    IF (SELECT COUNT(*) FROM @ProductMap) <> @ProductCount
        THROW 51009, 'Product insert count mismatch.', 1;

    ------------------------------------------------------------
    -- 5. SKU (one per pack size; first size = base SKU used for Team 1 pricing, T2-S8-01)
    ------------------------------------------------------------
    ;WITH S AS (
        SELECT p.Product_No, pm.Product_ID, p.Product_Name, p.Product_Status, p.Tier, p.Category_Code, v.SKU_No,
               ROW_NUMBER() OVER (ORDER BY p.Product_No, v.SKU_No) AS Seq
        FROM #Prod p
        JOIN @ProductMap pm ON pm.Product_Code = p.Product_Code
        CROSS APPLY (VALUES (1),(2),(3)) v(SKU_No)
        WHERE v.SKU_No <= p.SKU_Count
    ),
    S2 AS (
        SELECT S.*,
               CHOOSE(S.SKU_No, lf.L1, lf.L2, lf.L3) AS Size_Label,
               CHOOSE(S.SKU_No, lf.K1, lf.K2, lf.K3) AS Kg,
               CHOOSE(S.SKU_No, lf.P1, lf.P2, lf.P3) AS Pkg,
               lf.Cost_Per_Kg,
               CONVERT(char(12), CONVERT(bigint, 200000000000) + S.Seq) AS B12,
               CONVERT(bigint, CONVERT(binary(4), HASHBYTES('SHA2_256', CONCAT(@Seed, N'|SKU|', S.Product_No, N'|', S.SKU_No, N'|cost')))) AS HC
        FROM S JOIN @Leaf lf ON lf.Category_Code = S.Category_Code
    )
    INSERT INTO core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, Barcode, Weight, Standard_Cost, Currency, SKU_Status)
    SELECT S2.Product_ID, pk.Package_ID,
           CONCAT(N'T2S8SKU', RIGHT(CONCAT(N'00000', S2.Seq), 5)),
           LEFT(CONCAT(S2.Product_Name, N' - ', S2.Size_Label), 150),
           CONCAT(S2.B12, (10 - ck.S % 10) % 10),
           S2.Kg,
           CASE WHEN ROUND(S2.Cost_Per_Kg * S2.Kg * S2.Tier * (0.90 + (S2.HC % 21) / 100.0), -3) < 1000 THEN 1000
                ELSE ROUND(S2.Cost_Per_Kg * S2.Kg * S2.Tier * (0.90 + (S2.HC % 21) / 100.0), -3) END,
           'IRR',
           CASE WHEN S2.Product_Status = N'Discontinued' THEN N'Inactive' ELSE N'Active' END
    FROM S2
    JOIN ref.Package pk ON pk.Package_Code = S2.Pkg
    CROSS APPLY (SELECT CONVERT(int, SUBSTRING(S2.B12, 1, 1)) + 3 * CONVERT(int, SUBSTRING(S2.B12, 2, 1))
                      + CONVERT(int, SUBSTRING(S2.B12, 3, 1)) + 3 * CONVERT(int, SUBSTRING(S2.B12, 4, 1))
                      + CONVERT(int, SUBSTRING(S2.B12, 5, 1)) + 3 * CONVERT(int, SUBSTRING(S2.B12, 6, 1))
                      + CONVERT(int, SUBSTRING(S2.B12, 7, 1)) + 3 * CONVERT(int, SUBSTRING(S2.B12, 8, 1))
                      + CONVERT(int, SUBSTRING(S2.B12, 9, 1)) + 3 * CONVERT(int, SUBSTRING(S2.B12, 10, 1))
                      + CONVERT(int, SUBSTRING(S2.B12, 11, 1)) + 3 * CONVERT(int, SUBSTRING(S2.B12, 12, 1)) AS S) ck
    ORDER BY S2.Seq;

    DECLARE @SKURows int = @@ROWCOUNT;
    IF @SKURows <> (SELECT SUM(SKU_Count) FROM #Prod)
        THROW 51010, 'SKU insert count mismatch.', 1;

    ------------------------------------------------------------
    -- 6. FINAL VALIDATION (rollback on any failure)
    ------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM core.Product p WHERE NOT EXISTS (SELECT 1 FROM core.SKU s WHERE s.Product_ID = p.Product_ID))
        THROW 51011, 'Some Products have no SKU.', 1;
    IF EXISTS (SELECT 1 FROM core.SKU WHERE LEN(Barcode) <> 13 OR Barcode LIKE '%[^0-9]%' OR LEFT(Barcode, 3) NOT BETWEEN '200' AND '299')
        THROW 51013, 'Invalid EAN-13 format or prefix.', 1;
    IF EXISTS (SELECT 1 FROM core.Product p JOIN ref.ProductCategory c ON c.Product_Category_ID = p.Product_Category_ID
               WHERE EXISTS (SELECT 1 FROM ref.ProductCategory ch WHERE ch.Parent_Category_ID = c.Product_Category_ID))
        THROW 51015, 'A product is attached to a non-leaf category.', 1;
    IF EXISTS (SELECT 1 FROM core.Product p JOIN core.Brand b ON b.Brand_ID = p.Brand_ID
               WHERE p.Launch_Date IS NULL OR p.Launch_Date < b.Brand_Start_Date OR p.Weight <= 0 OR p.Tax_Rate IS NULL
                  OR p.Product_Updated_Date < p.Product_Created_Date)
        THROW 51014, 'Invalid Product attributes.', 1;

    COMMIT TRANSACTION;

    IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
        INSERT #T2LoadLog (Script_Name, Table_Name, Input_Rows, Inserted_Rows)
        SELECT N'08-03-T2-03', t.Table_Name, t.Input_Rows, t.Inserted_Rows
        FROM (VALUES (N'ref.ProductCategory', 35, (SELECT COUNT(*) FROM ref.ProductCategory)),
                     (N'ref.Package', 12, (SELECT COUNT(*) FROM ref.Package)),
                     (N'core.Product', @ProductCount, (SELECT COUNT(*) FROM core.Product)),
                     (N'core.SKU', @SKURows, (SELECT COUNT(*) FROM core.SKU))) t(Table_Name, Input_Rows, Inserted_Rows);

    PRINT CONCAT(N'DataVersion=', @DataVersion, N' | Seed=', @Seed, N' | Scale=', @Scale);
    PRINT N'ref.ProductCategory inserted: 35';
    PRINT N'ref.Package inserted: 12';
    PRINT CONCAT(N'core.Product inserted: ', @ProductCount);
    PRINT CONCAT(N'core.SKU inserted: ', @SKURows);

    -- Product keys for Team 1 (T2-S8-01: base SKU = first SKU_Code of the product, Price_Type = Standard)
    SELECT p.Product_Code, p.Product_Name, p.Launch_Date, p.Product_Status, p.Tax_Rate, p.Unit_Of_Measure,
           (SELECT MIN(s.SKU_Code) FROM core.SKU s WHERE s.Product_ID = p.Product_ID) AS Base_SKU_Code
    FROM core.Product p ORDER BY p.Product_Code;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    PRINT CONCAT(N'08-03-T2-03 FAILED (rolled back). Error ', ERROR_NUMBER(), N' line ', ERROR_LINE(), N': ', ERROR_MESSAGE());
    THROW;
END CATCH;
GO
