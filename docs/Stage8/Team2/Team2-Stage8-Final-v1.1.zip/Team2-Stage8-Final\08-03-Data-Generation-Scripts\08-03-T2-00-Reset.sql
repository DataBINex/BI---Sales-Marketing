/* =============================================================================
 Project       : BI---Sales-Marketing (DataBiNex) - FoodDistributionDB mock data
 Stage         : 8 - Mock Data Design
 Team/Owner    : Team 2 - Product & Marketing (8.8: SinaSepasi, #196)
 Database      : FoodDistributionDB (SQL Server 2022)
 Script        : 08-03-T2-00-Reset.sql
 Version       : 1.1 (1.1, PM review 2026-11-07: no USE statement; runs only after the target database
                 name is typed in @ConfirmDb below, or set as SESSION_CONTEXT 'T2_Reset_DB')
 Purpose       : Remove ALL Team 2 mock data (24 tables) and reseed their IDENTITY columns,
                 so the Team 2 load can be repeated on a clean base (re-run policy, Q17).
 Run Order     : 0 - TEST ENVIRONMENT ONLY
 Prerequisites : 1. Connect to the TEST copy of the database (the script has no USE statement).
                 2. Type that database name in @ConfirmDb (line "DECLARE @ConfirmDb" below), or run
                    EXEC sp_set_session_context N'T2_Reset_DB', N'<test database name>'; first.
                    If the name is empty or differs from DB_NAME(), the script stops and deletes nothing.
                 3. No Team 1 row references core.Product or marketing.Promotion
                    (Contract, SalesOrder, SalesOrderItem, InvoiceItem, CustomerFeedback, SalesTarget).
                    If Team 1 data exists the script stops and changes nothing.
 Seed/Config   : none
 Date          : 2026-11-07
 Notes         : deletes child tables first (reverse FK order); no TRUNCATE (FKs), no constraint or
                 trigger is disabled; reseed only for tables that ever had a row, so the next row is 1.
                 Test log 2026-11-07: run on (localdb)\Stage7Test, database FoodDistributionDB_S8.
============================================================================= */
SET NOCOUNT ON;
SET XACT_ABORT ON;

-- Safety: the test database name must be confirmed explicitly (protects a production copy).
DECLARE @ConfirmDb sysname = N'';   -- <- type the TEST database name here, e.g. N'FoodDistributionDB_S8'
IF @ConfirmDb = N'' SET @ConfirmDb = ISNULL(CONVERT(sysname, SESSION_CONTEXT(N'T2_Reset_DB')), N'');
IF @ConfirmDb = N'' OR @ConfirmDb <> DB_NAME()
    THROW 50900, N'STOP: Reset not confirmed for this database. Type the TEST database name in @ConfirmDb (or set SESSION_CONTEXT T2_Reset_DB); nothing was deleted.', 1;
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50901, N'STOP: wrong database (Team 2 tables not found); nothing was deleted.', 1;
PRINT CONCAT(N'Reset confirmed for database ', DB_NAME());

IF EXISTS (SELECT 1 FROM sales.SalesOrderItem) OR EXISTS (SELECT 1 FROM sales.InvoiceItem)
   OR EXISTS (SELECT 1 FROM sales.Contract WHERE Product_ID IS NOT NULL)
   OR EXISTS (SELECT 1 FROM sales.CustomerFeedback WHERE Product_ID IS NOT NULL)
   OR EXISTS (SELECT 1 FROM sales.SalesTarget WHERE Product_ID IS NOT NULL)
   OR EXISTS (SELECT 1 FROM sales.SalesOrder WHERE Promotion_ID IS NOT NULL)
    THROW 50902, N'STOP: Team 1 rows reference core.Product or marketing.Promotion. Reset Team 1 data first; nothing was deleted.', 1;

DECLARE @T TABLE (Ord int PRIMARY KEY, Table_Name sysname NOT NULL);
INSERT @T VALUES
 ( 1, N'marketing.MarketPrice'),            ( 2, N'marketing.CompetitorProduct'),   ( 3, N'marketing.Competitor'),
 ( 4, N'marketing.ResearchResult'),         ( 5, N'marketing.MarketSurvey'),        ( 6, N'marketing.MarketResearch'),
 ( 7, N'marketing.ProductPrice'),           ( 8, N'marketing.Promotion'),           ( 9, N'marketing.CampaignResult'),
 (10, N'marketing.CampaignCost'),           (11, N'marketing.CampaignBudget'),      (12, N'marketing.MarketingCampaignAudience'),
 (13, N'marketing.MarketingCampaignChannel'),(14, N'marketing.MarketingCampaign'),  (15, N'core.SKU'),
 (16, N'core.Product'),                     (17, N'ref.Package'),                   (18, N'ref.ProductCategory'),
 (19, N'marketing.MarketSegment'),          (20, N'marketing.Market'),              (21, N'marketing.BrandActivity'),
 (22, N'marketing.CampaignAudience'),       (23, N'marketing.CampaignChannel'),     (24, N'core.Brand');

DECLARE @Ord int = 1, @Tbl sysname, @Sql nvarchar(max), @Rows int;
BEGIN TRY
    BEGIN TRANSACTION;
    WHILE @Ord <= 24
    BEGIN
        SELECT @Tbl = Table_Name FROM @T WHERE Ord = @Ord;
        IF @Tbl = N'ref.ProductCategory'
        BEGIN
            -- self reference: children first
            DELETE FROM ref.ProductCategory WHERE Parent_Category_ID IS NOT NULL;
            SET @Rows = @@ROWCOUNT;
            DELETE FROM ref.ProductCategory;
            SET @Rows += @@ROWCOUNT;
        END
        ELSE
        BEGIN
            SET @Sql = N'DELETE FROM ' + @Tbl + N';';
            EXEC sp_executesql @Sql;
            SET @Rows = @@ROWCOUNT;
        END
        PRINT CONCAT(N'Deleted ', @Rows, N' rows from ', @Tbl);
        SET @Ord += 1;
    END;

    -- reseed IDENTITY so the next generated value is 1 (only where a value was ever generated)
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT QUOTENAME(OBJECT_SCHEMA_NAME(ic.object_id)) + N'.' + QUOTENAME(OBJECT_NAME(ic.object_id))
        FROM sys.identity_columns ic
        JOIN @T t ON OBJECT_ID(t.Table_Name) = ic.object_id
        WHERE ic.last_value IS NOT NULL;
    OPEN c; FETCH NEXT FROM c INTO @Tbl;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DBCC CHECKIDENT (@Tbl, RESEED, 0) WITH NO_INFOMSGS;
        FETCH NEXT FROM c INTO @Tbl;
    END;
    CLOSE c; DEALLOCATE c;

    COMMIT TRANSACTION;
    PRINT N'Team 2 reset completed: 24 tables empty, IDENTITY reseeded.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    PRINT CONCAT(N'08-03-T2-00-Reset FAILED (rolled back). Error ', ERROR_NUMBER(), N': ', ERROR_MESSAGE());
    THROW;
END CATCH;
GO
