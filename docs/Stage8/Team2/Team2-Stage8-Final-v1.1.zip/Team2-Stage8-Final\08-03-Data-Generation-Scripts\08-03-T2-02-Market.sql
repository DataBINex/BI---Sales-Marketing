/*=============================================================================
  Project      : Food Distribution BI (Sales & Marketing Dashboard)
  Stage        : 8 - Mock Data Design
  Team / Owner : Team 2 - Product & Marketing
  Database     : FoodDistributionDB  (SQL Server 2022)
  Script       : 08-03-T2-02-Market.sql
  Version      : 1.0   (MockData_v1.1_Seed20261031)
  Date         : 2026-11-01   (static text - the script never reads the clock)
  Purpose      : Load marketing.Market and marketing.MarketSegment.
  Run Order    : 2  (no prerequisite script; Market is a root table of group 4
                     "prices and marketing reference").
  Prerequisites: * FoodDistributionDB restored from FoodDistributionDB.bak
                   (48 empty tables) or built with Datebase-Deployment.sql.
                 * marketing.Market and marketing.MarketSegment exist and are EMPTY.
  Seed / Config: see the DECLARE block below. This script uses NO random
                 numbers: both tables are small curated master lists, so the
                 output is identical on every run (Q17) for any @Seed. @Seed,
                 @Scale and the dates are declared only to keep the common
                 header identical across Team 2 scripts.
                 @Scale has no effect here (reference / small master tables
                 are always built in full).
  Tables       : marketing.Market         8 rows
                 marketing.MarketSegment 24 rows (2..4 per market)

  Re-run       : If either table already has rows the script STOPS with a clear
                 message. Cleaning is done only by 08-03-T2-00-Reset.sql.

  Output contract for children (T2 8.4 / 8.5 - MarketResearch, Competitor,
  MarketPrice, MarketSurvey):
    * Market_Code   : MKT-01 .. MKT-08            (unique, stable)
    * Segment_Code  : SEG-<market no>-<seq>       (unique in the WHOLE table)
    * Market_Status / Segment_Status : Active | Inactive
    * MKT-07 (Export) is the only Inactive market; both of its segments are
      Inactive. Children must attach new activity (research, competitors,
      prices, surveys dated after the pause) only to Active rows.
    * Every Active market has >= 2 Active segments.
    * Resolve parents by business key (Market_Code / Segment_Code) - never by
      a hard-coded ID.

  Allowed values used (PROVISIONAL until the Allowed-Values sheet, D-07, is
  confirmed - see Issue ISS-T2-MKT-01):
    Market_Type        : Retail | Online | Foodservice | Wholesale |
                         Institutional | Export | Specialty
    Market_Status      : Active | Inactive
    Segmentation_Basis : Behavioral | Demographic | Geographic   (table CHECK)
    Segment_Status     : Active | Inactive
  All names are fictional generic categories - no real brand, company, person,
  phone, e-mail or address (Q16).
=============================================================================*/
-- v1.1 PM review (2026-11-07): no USE statement; the database is chosen once in 08-04-Load-Data.sql
-- (:setvar DbName) or by the connection. This guard stops the script in a wrong database.
IF OBJECT_ID(N'core.Brand') IS NULL OR OBJECT_ID(N'marketing.MarketPrice') IS NULL
    THROW 50900, N'STOP: wrong database (Team 2 tables not found). Select the FoodDistributionDB copy first.', 1;

/*------------------------------ common settings ---------------------------*/
DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed        int          = 20261031;
DECLARE @Scale       decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10); -- 0.10 = 10% test, 1.00 = full (no effect on this script)
-- Integration v1.1 (SinaSepasi, #196): @Scale read from the loader session; a row per table is written
-- to #T2LoadLog when 08-04-Load-Data.sql created it (Q18). Data and rules unchanged.
DECLARE @FromDate    date         = '2019-03-21';  -- 1398/01/01
DECLARE @ToDate      date         = '2027-03-20';  -- 1405/12/29
DECLARE @AsOfDate    date         = '2027-03-20';  -- status reference date (until T2-S8-04 is approved)

/*------------------------------ script-local ------------------------------*/
DECLARE @ExpectedMarkets  int = 8;
DECLARE @ExpectedSegments int = 24;
DECLARE @in_m int, @ins_m int, @in_s int, @ins_s int;
DECLARE @msg nvarchar(2000);

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*------------------------------ source lists ------------------------------*/
DECLARE @Market TABLE
(
    Sort_No            int           NOT NULL PRIMARY KEY,
    Market_Code        nvarchar(30)  NOT NULL,
    Market_Name        nvarchar(150) NOT NULL,
    Market_Type        nvarchar(30)  NULL,
    Market_Description nvarchar(1000) NULL,
    Market_Status      nvarchar(30)  NOT NULL
);

INSERT @Market (Sort_No, Market_Code, Market_Name, Market_Type, Market_Description, Market_Status) VALUES
 (1, N'MKT-01', N'بازار خرده‌فروشی سنتی',        N'Retail',        N'فروش مواد غذایی بسته‌بندی‌شده از طریق سوپرمارکت‌ها و خواروبارفروشی‌های مستقل محله‌ای و شهرهای کوچک', N'Active'),
 (2, N'MKT-02', N'بازار فروشگاه‌های زنجیره‌ای',   N'Retail',        N'فروش از طریق هایپرمارکت‌ها و فروشگاه‌های زنجیره‌ای با قرارداد تأمین و شرایط پرداخت مشخص',            N'Active'),
 (3, N'MKT-03', N'بازار فروش آنلاین',            N'Online',        N'فروش مستقیم و اشتراکی مواد غذایی از طریق وب‌سایت و اپلیکیشن فروشگاهی',                             N'Active'),
 (4, N'MKT-04', N'بازار هتل، رستوران و کافه',     N'Foodservice',   N'تأمین مواد اولیه و محصولات مصرفی رستوران‌ها، کافه‌ها، قنادی‌ها و مراکز اقامتی',                        N'Active'),
 (5, N'MKT-05', N'بازار عمده‌فروشی و پخش مویرگی', N'Wholesale',     N'فروش عمده به پخش‌کنندگان منطقه‌ای و زیرپخش‌ها برای توزیع در شبکه مویرگی',                           N'Active'),
 (6, N'MKT-06', N'بازار سازمانی و نهادی',        N'Institutional', N'تأمین کانتین‌ها، مراکز درمانی و سلف‌سرویس سازمان‌ها با قرارداد دوره‌ای',                           N'Active'),
 (7, N'MKT-07', N'بازار صادراتی',               N'Export',        N'فروش محصولات به مشتریان خارج از کشور؛ فعالیت این بازار در حال حاضر متوقف است',                       N'Inactive'),
 (8, N'MKT-08', N'بازار محصولات سلامت‌محور',     N'Specialty',     N'محصولات رژیمی، کم‌چرب و ارگانیک برای مصرف‌کنندگان آگاه به سلامت',                                    N'Active');

DECLARE @Seg TABLE
(
    Sort_No             int           NOT NULL PRIMARY KEY,
    Market_Code         nvarchar(30)  NOT NULL,
    Segment_Code        nvarchar(30)  NOT NULL,
    Segment_Name        nvarchar(150) NOT NULL,
    Segmentation_Basis  nvarchar(30)  NOT NULL,
    Segment_Description nvarchar(1000) NULL,
    Segment_Status      nvarchar(30)  NOT NULL
);

INSERT @Seg (Sort_No, Market_Code, Segment_Code, Segment_Name, Segmentation_Basis, Segment_Description, Segment_Status) VALUES
 -- MKT-01 traditional retail (3)
 ( 1, N'MKT-01', N'SEG-01-01', N'سوپرمارکت‌های محله‌ای',              N'Geographic',  N'فروشگاه‌های مستقل داخل محله‌های شهری با خرید مکرر و حجم کم',                         N'Active'),
 ( 2, N'MKT-01', N'SEG-01-02', N'خواروبارفروشی‌های شهرهای کوچک',       N'Geographic',  N'مغازه‌های شهرهای کوچک و روستاها با تأمین از پخش‌های منطقه‌ای',                         N'Active'),
 ( 3, N'MKT-01', N'SEG-01-03', N'خریداران روزانه سنتی',               N'Behavioral',  N'مشتریانی که خرید روزانه و نقدی انجام می‌دهند و به برند ثابت وفادارند',                  N'Active'),
 -- MKT-02 chain stores (4)
 ( 4, N'MKT-02', N'SEG-02-01', N'هایپرمارکت‌های کلان‌شهرها',           N'Geographic',  N'فروشگاه‌های بزرگ در کلان‌شهرها با سفارش حجیم و دوره تسویه طولانی‌تر',                    N'Active'),
 ( 5, N'MKT-02', N'SEG-02-02', N'فروشگاه‌های زنجیره‌ای متوسط',         N'Behavioral',  N'زنجیره‌های منطقه‌ای با سفارش منظم هفتگی و حساس به تخفیف‌های دوره‌ای',                    N'Active'),
 ( 6, N'MKT-02', N'SEG-02-03', N'خانوارهای پرجمعیت',                 N'Demographic', N'خانوارهای چهار نفره و بیشتر با سبد خرید ماهانه بزرگ',                                 N'Active'),
 ( 7, N'MKT-02', N'SEG-02-04', N'اعضای باشگاه مشتریان (برنامه بسته‌شده)', N'Behavioral', N'اعضای برنامه وفاداری قدیمی که از طرف فروشگاه‌ها متوقف شده است',                          N'Inactive'),
 -- MKT-03 online (3)
 ( 8, N'MKT-03', N'SEG-03-01', N'خریداران جوان آنلاین',               N'Demographic', N'مشتریان ۱۸ تا ۳۵ ساله با خرید از طریق اپلیکیشن و حساس به ارسال سریع',                   N'Active'),
 ( 9, N'MKT-03', N'SEG-03-02', N'خریداران اشتراکی منظم',              N'Behavioral',  N'مشتریان دارای اشتراک ماهانه با سفارش تکرارشونده',                                    N'Active'),
 (10, N'MKT-03', N'SEG-03-03', N'خریداران آنلاین کلان‌شهرها',           N'Geographic',  N'مشتریان ساکن شهرهای بزرگ که پوشش کامل ارسال دارند',                                    N'Active'),
 -- MKT-04 foodservice (4)
 (11, N'MKT-04', N'SEG-04-01', N'رستوران‌ها و فست‌فودها',              N'Behavioral',  N'واحدهای با مصرف روزانه بالا و سفارش مکرر مواد اولیه',                                  N'Active'),
 (12, N'MKT-04', N'SEG-04-02', N'کافه‌ها و قنادی‌ها',                  N'Behavioral',  N'واحدهای کوچک با سفارش متنوع و حجم متوسط، فصلی در مناسبت‌ها',                            N'Active'),
 (13, N'MKT-04', N'SEG-04-03', N'هتل‌ها و مراکز اقامتی گردشگری',        N'Geographic',  N'مراکز اقامتی در شهرها و مناطق گردشگری با تقاضای فصلی',                                  N'Active'),
 (14, N'MKT-04', N'SEG-04-04', N'پذیرایی مراسم و تهیه غذا',            N'Behavioral',  N'شرکت‌های تهیه غذا و پذیرایی با سفارش پروژه‌ای',                                      N'Active'),
 -- MKT-05 wholesale (3)
 (15, N'MKT-05', N'SEG-05-01', N'عمده‌فروشان منطقه‌ای',               N'Geographic',  N'عمده‌فروشان با انبار منطقه‌ای و خرید کامیونی',                                       N'Active'),
 (16, N'MKT-05', N'SEG-05-02', N'زیرپخش‌کنندگان مویرگی',               N'Geographic',  N'پخش‌کنندگان محلی که به مغازه‌های محدوده خود تحویل می‌دهند',                              N'Active'),
 (17, N'MKT-05', N'SEG-05-03', N'خریداران عمده مناسبتی',              N'Behavioral',  N'خریدارانی که پیش از نوروز، رمضان و یلدا خرید عمده انجام می‌دهند',                       N'Active'),
 -- MKT-06 institutional (3)
 (18, N'MKT-06', N'SEG-06-01', N'کانتین مدارس و دانشگاه‌ها',           N'Demographic', N'مراکز آموزشی با تقاضای وابسته به تقویم تحصیلی',                                       N'Active'),
 (19, N'MKT-06', N'SEG-06-02', N'مراکز درمانی',                     N'Behavioral',  N'مراکز درمانی با قرارداد دوره‌ای و الزام کیفیت بالا',                                    N'Active'),
 (20, N'MKT-06', N'SEG-06-03', N'سلف‌سرویس سازمان‌ها و کارخانه‌ها',      N'Behavioral',  N'مجموعه‌های صنعتی و اداری با قرارداد سالانه تأمین',                                     N'Active'),
 -- MKT-07 export, paused (2) - all Inactive
 (21, N'MKT-07', N'SEG-07-01', N'مشتریان صادراتی مرزی',               N'Geographic',  N'مشتریان مناطق مرزی؛ فعالیت متوقف شده',                                             N'Inactive'),
 (22, N'MKT-07', N'SEG-07-02', N'توزیع‌کنندگان خارجی',                N'Geographic',  N'توزیع‌کنندگان خارج از کشور؛ فعالیت متوقف شده',                                       N'Inactive'),
 -- MKT-08 health-oriented (2)
 (23, N'MKT-08', N'SEG-08-01', N'خریداران سلامت‌محور',                N'Behavioral',  N'مشتریانی که به ترکیبات و برچسب تغذیه‌ای توجه می‌کنند',                                   N'Active'),
 (24, N'MKT-08', N'SEG-08-02', N'خانوارهای دارای کودک',               N'Demographic', N'خانوارهایی که برای کودکان محصول کم‌شکر و طبیعی می‌خرند',                                 N'Active');

/*------------------------------ load --------------------------------------*/
BEGIN TRY
    PRINT N'=== 08-03-T2-02-Market.sql | ' + @DataVersion + N' | Seed=' + CONVERT(nvarchar(20), @Seed)
        + N' | Scale=' + CONVERT(nvarchar(10), @Scale) + N' (not used) ===';

    -- prerequisites
    IF OBJECT_ID(N'marketing.Market', N'U') IS NULL OR OBJECT_ID(N'marketing.MarketSegment', N'U') IS NULL
        THROW 50001, N'Prerequisite missing: marketing.Market and/or marketing.MarketSegment do not exist. Restore FoodDistributionDB.bak or run Datebase-Deployment.sql first.', 1;

    -- re-run policy
    IF EXISTS (SELECT 1 FROM marketing.Market) OR EXISTS (SELECT 1 FROM marketing.MarketSegment)
        THROW 50002, N'STOP: marketing.Market or marketing.MarketSegment already contains rows. Nothing was changed. Clean only with 08-03-T2-00-Reset.sql, then run this script again.', 1;

    -- source self-check (before touching the database)
    SELECT @in_m = COUNT(*) FROM @Market;
    SELECT @in_s = COUNT(*) FROM @Seg;
    IF @in_m <> @ExpectedMarkets OR @in_s <> @ExpectedSegments
        THROW 50003, N'Source list size differs from the approved volume (8 markets / 24 segments).', 1;

    BEGIN TRANSACTION;

    -- 1) Market
    INSERT marketing.Market (Market_Code, Market_Name, Market_Type, Market_Description, Market_Status)
    SELECT Market_Code, Market_Name, Market_Type, Market_Description, Market_Status
    FROM   @Market
    ORDER BY Sort_No;
    SET @ins_m = @@ROWCOUNT;

    -- 2) MarketSegment - parent resolved by business key (Market_Code)
    INSERT marketing.MarketSegment (Market_ID, Segment_Code, Segment_Name, Segmentation_Basis, Segment_Description, Segment_Status)
    SELECT m.Market_ID, s.Segment_Code, s.Segment_Name, s.Segmentation_Basis, s.Segment_Description, s.Segment_Status
    FROM   @Seg s
    JOIN   marketing.Market m ON m.Market_Code = s.Market_Code
    ORDER BY s.Sort_No;
    SET @ins_s = @@ROWCOUNT;

    -- in-transaction validation (any failure -> rollback)
    IF @ins_m <> @in_m OR @ins_s <> @in_s
        THROW 50004, N'Rejected rows detected: inserted count differs from input count.', 1;

    IF EXISTS (SELECT 1 FROM marketing.Market m
               WHERE NOT EXISTS (SELECT 1 FROM marketing.MarketSegment s WHERE s.Market_ID = m.Market_ID))
        THROW 50005, N'A market has no segment.', 1;

    IF EXISTS (SELECT 1 FROM marketing.Market m
               WHERE m.Market_Status = N'Active'
                 AND (SELECT COUNT(*) FROM marketing.MarketSegment s
                      WHERE s.Market_ID = m.Market_ID AND s.Segment_Status = N'Active') < 2)
        THROW 50006, N'An Active market has fewer than 2 Active segments.', 1;

    IF EXISTS (SELECT 1 FROM marketing.Market m
               JOIN marketing.MarketSegment s ON s.Market_ID = m.Market_ID
               WHERE m.Market_Status = N'Inactive' AND s.Segment_Status = N'Active')
        THROW 50007, N'An Inactive market has an Active segment.', 1;

    COMMIT TRANSACTION;

    IF OBJECT_ID(N'tempdb..#T2LoadLog') IS NOT NULL
        INSERT #T2LoadLog (Script_Name, Table_Name, Input_Rows, Inserted_Rows)
        VALUES (N'08-03-T2-02', N'marketing.Market', @in_m, @ins_m),
               (N'08-03-T2-02', N'marketing.MarketSegment', @in_s, @ins_s);

    /*------------------------- load log (Q18) ----------------------------*/
    PRINT N'--- Load log ---';
    PRINT N'Table                    | Input | Inserted | Rejected';
    PRINT N'marketing.Market         | ' + CONVERT(nvarchar(10), @in_m) + N' | ' + CONVERT(nvarchar(10), @ins_m) + N' | ' + CONVERT(nvarchar(10), @in_m - @ins_m);
    PRINT N'marketing.MarketSegment  | ' + CONVERT(nvarchar(10), @in_s) + N' | ' + CONVERT(nvarchar(10), @ins_s) + N' | ' + CONVERT(nvarchar(10), @in_s - @ins_s);

    -- per-market breakdown (for the child scripts / sanity check)
    SELECT m.Market_Code, m.Market_Type, m.Market_Status,
           COUNT(*) AS Segments,
           SUM(CASE WHEN s.Segment_Status = N'Active' THEN 1 ELSE 0 END) AS Active_Segments
    FROM   marketing.Market m
    JOIN   marketing.MarketSegment s ON s.Market_ID = m.Market_ID
    GROUP BY m.Market_Code, m.Market_Type, m.Market_Status
    ORDER BY m.Market_Code;

    -- content fingerprint for repeatability checks (Q17): equal on every run of the same version
    SELECT @DataVersion AS Data_Version,
           CONVERT(char(64), HASHBYTES('SHA2_256',
               (SELECT STRING_AGG(CONCAT_WS(N'|', m.Market_Code, m.Market_Name, m.Market_Type, m.Market_Status,
                                            s.Segment_Code, s.Segment_Name, s.Segmentation_Basis, s.Segment_Status), N';')
                       WITHIN GROUP (ORDER BY s.Segment_Code)
                FROM marketing.Market m
                JOIN marketing.MarketSegment s ON s.Market_ID = m.Market_ID)), 2) AS Content_Fingerprint_SHA256;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    SET @msg = N'08-03-T2-02-Market.sql FAILED (rolled back). Error ' + CONVERT(nvarchar(10), ERROR_NUMBER())
             + N' line ' + CONVERT(nvarchar(10), ERROR_LINE()) + N': ' + ERROR_MESSAGE();
    PRINT @msg;
    THROW;
END CATCH;
GO
