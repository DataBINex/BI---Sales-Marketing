/*
Project: FoodDistributionDB - Synthetic Data Quality Checks
Stage: 8 - Mock Data
Team/Owner: Team 2 - Product & Marketing
Database: FoodDistributionDB
Version: 1.1 (author: Sahar-Sayyah; integration: @Scale is read from the loader session, SinaSepasi #196)
*/

SET NOCOUNT ON;

DECLARE @DataVersion nvarchar(50) = N'MockData_v1.1_Seed20261031';
DECLARE @Seed int = 20261031;
DECLARE @Scale decimal(5,2) = ISNULL(TRY_CONVERT(decimal(5,2), SESSION_CONTEXT(N'T2_Scale')), 0.10); -- same as load script: 0.10 or 1.00
DECLARE @FromDate date = '2019-03-21';
DECLARE @ToDate date = '2027-03-20';
DECLARE @ExpectedFullActivityRows int = 480;
DECLARE @ExpectedBrandRows int = 10;
DECLARE @ExpectedChannelRows int = 8;
DECLARE @ExpectedAudienceRows int = 10;

DECLARE @FullGroupCount int;
DECLARE @TargetGroupCount int;
DECLARE @ExpectedActivityRows int;

;WITH BrandYears AS
(
    SELECT b.Brand_ID, b.Brand_Code, y.Year_Number
    FROM core.Brand b
    CROSS JOIN (VALUES (2019),(2020),(2021),(2022),(2023),(2024),(2025),(2026),(2027)) y(Year_Number)
    WHERE b.Brand_Code IN
        (N'T2S8BR001',N'T2S8BR002',N'T2S8BR003',N'T2S8BR004',N'T2S8BR005',
         N'T2S8BR006',N'T2S8BR007',N'T2S8BR008',N'T2S8BR009',N'T2S8BR010')
      AND DATEFROMPARTS(y.Year_Number,1,1) <= @ToDate
      AND DATEFROMPARTS(y.Year_Number,12,31) >= @FromDate
      AND (b.Brand_End_Date IS NULL OR b.Brand_End_Date >= DATEFROMPARTS(y.Year_Number,1,1))
)
SELECT @FullGroupCount = COUNT(*)
FROM BrandYears;

SET @TargetGroupCount = CEILING(@FullGroupCount * @Scale);
SET @ExpectedActivityRows = CEILING(@ExpectedFullActivityRows * @Scale);

;WITH QC AS
(
    SELECT
        N'Q01' AS Test_ID,
        N'core.Brand; marketing.CampaignChannel; marketing.CampaignAudience; marketing.BrandActivity' AS [table],
        N'Expected Team 2-owned rows match configured scale (Brand/Channel/Audience full; BrandActivity scaled).' AS [definition],
        (SELECT COUNT(*) FROM core.Brand WHERE Brand_Code LIKE N'T2S8BR%') +
        (SELECT COUNT(*) FROM marketing.CampaignChannel) +
        (SELECT COUNT(*) FROM marketing.CampaignAudience) +
        (SELECT COUNT(*) FROM marketing.BrandActivity) AS [rows checked],
        (CASE WHEN (SELECT COUNT(*) FROM core.Brand WHERE Brand_Code LIKE N'T2S8BR%') = @ExpectedBrandRows THEN 0 ELSE 1 END) +
        (CASE WHEN (SELECT COUNT(*) FROM marketing.CampaignChannel) = @ExpectedChannelRows THEN 0 ELSE 1 END) +
        (CASE WHEN (SELECT COUNT(*) FROM marketing.CampaignAudience) = @ExpectedAudienceRows THEN 0 ELSE 1 END) +
        (CASE WHEN (SELECT COUNT(*) FROM marketing.BrandActivity) = @ExpectedActivityRows THEN 0 ELSE 1 END) AS [error count],
        CAST(NULL AS nvarchar(100)) AS [sample error ID]

    UNION ALL
    SELECT N'Q02', N'core.Brand; marketing.CampaignChannel; marketing.CampaignAudience',
           N'Business keys/names are unique; active Brand_Name values are unique.',
           (SELECT COUNT(*) FROM core.Brand WHERE Brand_Code LIKE N'T2S8BR%') +
           (SELECT COUNT(*) FROM marketing.CampaignChannel) +
           (SELECT COUNT(*) FROM marketing.CampaignAudience),
           (SELECT COUNT(*) FROM
                (SELECT Brand_Code FROM core.Brand GROUP BY Brand_Code HAVING COUNT(*) > 1) d) +
           (SELECT COUNT(*) FROM
                (SELECT Brand_Name FROM core.Brand WHERE Brand_Status = N'Active'
                 GROUP BY Brand_Name HAVING COUNT(*) > 1) d) +
           (SELECT COUNT(*) FROM
                (SELECT Channel_Name FROM marketing.CampaignChannel GROUP BY Channel_Name HAVING COUNT(*) > 1) d) +
           (SELECT COUNT(*) FROM
                (SELECT Audience_Name FROM marketing.CampaignAudience GROUP BY Audience_Name HAVING COUNT(*) > 1) d),
           (SELECT TOP (1) Brand_Code FROM core.Brand GROUP BY Brand_Code HAVING COUNT(*) > 1)

    UNION ALL
    SELECT N'Q03', N'marketing.BrandActivity -> core.Brand',
           N'Every BrandActivity.Brand_ID resolves to exactly one core.Brand row.',
           (SELECT COUNT(*) FROM marketing.BrandActivity),
           (SELECT COUNT(*) FROM marketing.BrandActivity ba
            LEFT JOIN core.Brand b ON b.Brand_ID = ba.Brand_ID
            WHERE b.Brand_ID IS NULL),
           (SELECT TOP (1) CONVERT(nvarchar(100), ba.Brand_Activity_ID)
            FROM marketing.BrandActivity ba
            LEFT JOIN core.Brand b ON b.Brand_ID = ba.Brand_ID
            WHERE b.Brand_ID IS NULL)

    UNION ALL
    SELECT N'Q04', N'marketing.BrandActivity',
           N'Activity dates lie within the approved Stage 8 date range.',
           (SELECT COUNT(*) FROM marketing.BrandActivity),
           (SELECT COUNT(*) FROM marketing.BrandActivity
            WHERE Activity_Start_Date < @FromDate OR Activity_Start_Date > @ToDate
               OR (Activity_End_Date IS NOT NULL AND Activity_End_Date > @ToDate)),
           (SELECT TOP (1) CONVERT(nvarchar(100), Brand_Activity_ID)
            FROM marketing.BrandActivity
            WHERE Activity_Start_Date < @FromDate OR Activity_Start_Date > @ToDate
               OR (Activity_End_Date IS NOT NULL AND Activity_End_Date > @ToDate))

    UNION ALL
    SELECT N'Q06', N'marketing.BrandActivity',
           N'Activity_Cost is nonnegative and Currency is IRR.',
           (SELECT COUNT(*) FROM marketing.BrandActivity),
           (SELECT COUNT(*) FROM marketing.BrandActivity
            WHERE Activity_Cost IS NULL OR Activity_Cost < 0 OR Currency <> 'IRR'),
           (SELECT TOP (1) CONVERT(nvarchar(100), Brand_Activity_ID)
            FROM marketing.BrandActivity
            WHERE Activity_Cost IS NULL OR Activity_Cost < 0 OR Currency <> 'IRR')

    UNION ALL
    SELECT N'Q07', N'core.Brand; marketing.BrandActivity',
           N'Brand start/end and activity start/end dates follow chronological rules.',
           (SELECT COUNT(*) FROM core.Brand WHERE Brand_Code LIKE N'T2S8BR%') +
           (SELECT COUNT(*) FROM marketing.BrandActivity),
           (SELECT COUNT(*) FROM core.Brand
            WHERE Brand_Code LIKE N'T2S8BR%'
              AND (Brand_Start_Date IS NULL OR
                   (Brand_End_Date IS NOT NULL AND Brand_End_Date < Brand_Start_Date))) +
           (SELECT COUNT(*) FROM marketing.BrandActivity ba
            JOIN core.Brand b ON b.Brand_ID = ba.Brand_ID
            WHERE ba.Activity_Start_Date IS NULL
               OR ba.Activity_Start_Date < b.Brand_Start_Date
               OR (b.Brand_End_Date IS NOT NULL AND ba.Activity_Start_Date > b.Brand_End_Date)
               OR (ba.Activity_End_Date IS NOT NULL AND
                   (ba.Activity_Start_Date IS NULL OR ba.Activity_End_Date < ba.Activity_Start_Date))),
           (SELECT TOP (1) CONVERT(nvarchar(100), Brand_Activity_ID)
            FROM marketing.BrandActivity ba
            JOIN core.Brand b ON b.Brand_ID = ba.Brand_ID
            WHERE ba.Activity_Start_Date IS NULL
               OR ba.Activity_Start_Date < b.Brand_Start_Date
               OR (b.Brand_End_Date IS NOT NULL AND ba.Activity_Start_Date > b.Brand_End_Date)
               OR (ba.Activity_End_Date IS NOT NULL AND
                   (ba.Activity_Start_Date IS NULL OR ba.Activity_End_Date < ba.Activity_Start_Date)))

    UNION ALL
    SELECT N'Q15', N'marketing.BrandActivity',
           N'For every represented Brand x Year group, activity count is between 3 and 8.',
           (SELECT COUNT(*) FROM marketing.BrandActivity),
           (SELECT COUNT(*) FROM
                (SELECT Brand_ID, YEAR(Activity_Start_Date) AS Activity_Year
                 FROM marketing.BrandActivity
                 GROUP BY Brand_ID, YEAR(Activity_Start_Date)
                 HAVING COUNT(*) < 3 OR COUNT(*) > 8) g),
           (SELECT TOP (1) CONCAT(Brand_ID, N'/', YEAR(Activity_Start_Date))
            FROM marketing.BrandActivity
            GROUP BY Brand_ID, YEAR(Activity_Start_Date)
            HAVING COUNT(*) < 3 OR COUNT(*) > 8)

    UNION ALL
    SELECT N'Q16', N'core.Brand; marketing.CampaignChannel; marketing.CampaignAudience',
           N'Brand URLs use example.com only; all supplied contact/person data are synthetic organizational roles.',
           (SELECT COUNT(*) FROM core.Brand WHERE Brand_Code LIKE N'T2S8BR%') +
           (SELECT COUNT(*) FROM marketing.CampaignChannel) +
           (SELECT COUNT(*) FROM marketing.CampaignAudience),
           (SELECT COUNT(*) FROM core.Brand
            WHERE Brand_Code LIKE N'T2S8BR%'
              AND ((Brand_Logo_URL IS NOT NULL AND Brand_Logo_URL NOT LIKE N'https://example.com/%')
                OR (Brand_Website IS NOT NULL AND Brand_Website NOT LIKE N'https://example.com/%'))),
           (SELECT TOP (1) Brand_Code FROM core.Brand
            WHERE Brand_Code LIKE N'T2S8BR%'
              AND ((Brand_Logo_URL IS NOT NULL AND Brand_Logo_URL NOT LIKE N'https://example.com/%')
                OR (Brand_Website IS NOT NULL AND Brand_Website NOT LIKE N'https://example.com/%')))

    UNION ALL
    SELECT N'Q17', N'08-03-T2-01-Brand-Channel-Audience.sql',
           N'Generator declares a fixed DataVersion/Seed and uses SHA2_256-derived deterministic values (review-based check).',
           1,
           CASE WHEN @DataVersion = N'MockData_v1.1_Seed20261031'
                  AND @Seed = 20261031 AND @Scale IN (0.10,1.00)
                THEN 0 ELSE 1 END,
           CAST(NULL AS nvarchar(100))
)
SELECT
    Test_ID, [table], [definition], [rows checked], [error count],
    [sample error ID],
    CASE WHEN [error count] = 0 THEN N'Pass' ELSE N'Fail' END AS [Pass/Fail]
FROM QC
ORDER BY Test_ID;
GO
