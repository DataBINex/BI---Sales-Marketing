﻿/*=============================================================================
 FOOD DISTRIBUTION BI - STAGE 8
 Script  : Stage8-AddPersianDateToCalendar.sql   (v1.1)
 Purpose : STRUCTURE of the Persian (Shamsi) calendar in core.Calendar.
           Adds 5 columns: DateKey, PersianYear, PersianMonth, PersianMonthName, PersianDay
           and the unique index UX_Calendar_DateKey.
 Run order (changed in v1.1):
   1) Run this script ONCE - BEFORE Stage8-Master-Mock-Data-Generation-1398-to-1405-08-30.sql.
      It is safe to re-run (every step checks whether it is already done).
   2) The generation script fills the 5 columns while it loads core.Calendar, and
      stops in its pre-flight check if they are missing.
   3) If core.Calendar already contains rows (an older load), this script also fills the
      columns for those rows and reports whether the range is the expected one.
 Why only 5 columns: they are the ones the data generator (section 8.7: Persian months,
   Persian Fiscal_Year) and every join to a Gregorian date need. All other Persian attributes
   (quarter, year-month key, weekday name, week of year, month-end flag, IsWeekend...) are
   derived and live in the reporting view rpt.Dim_Date (Stage9-0-Create-RPT-Layer.sql).
 Range   : 2019-03-21 .. 2026-11-21  =  1398/01/01 .. 1405/08/30 (2,803 days).
 Status  : not executed by the author against your SQL Server; keep the Messages output.
=============================================================================*/
USE [FoodDistributionDB];
GO

/*========================================================
  Step 1: Validate Persian calendar conversion
========================================================*/

IF FORMAT(
    CAST('2025-03-21' AS DATE),
    'yyyyMMdd',
    'fa-IR'
) <> '14040101'
BEGIN
    THROW 50001,
    'Persian calendar conversion is not working correctly on this SQL Server.',
    1;
END;
GO

/*========================================================
  Step 2: Add new columns (if they do not exist)
========================================================*/

IF COL_LENGTH('core.Calendar', 'DateKey') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [DateKey] INT NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianYear') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianYear] INT NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianMonth') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianMonth] INT NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianMonthName') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianMonthName] NVARCHAR(20) NULL;
GO

IF COL_LENGTH('core.Calendar', 'PersianDay') IS NULL
    ALTER TABLE [core].[Calendar]
    ADD [PersianDay] INT NULL;
GO

/*========================================================
  Step 3: Populate the columns for rows that already exist
          (does nothing on an empty table)
========================================================*/

UPDATE C
SET
    C.DateKey =
        YEAR(C.Calendar_Date) * 10000
        + MONTH(C.Calendar_Date) * 100
        + DAY(C.Calendar_Date),

    C.PersianYear = P.PersianYear,

    C.PersianMonth = P.PersianMonth,

    C.PersianMonthName =
        CASE P.PersianMonth
            WHEN 1  THEN N'فروردین'
            WHEN 2  THEN N'اردیبهشت'
            WHEN 3  THEN N'خرداد'
            WHEN 4  THEN N'تیر'
            WHEN 5  THEN N'مرداد'
            WHEN 6  THEN N'شهریور'
            WHEN 7  THEN N'مهر'
            WHEN 8  THEN N'آبان'
            WHEN 9  THEN N'آذر'
            WHEN 10 THEN N'دی'
            WHEN 11 THEN N'بهمن'
            WHEN 12 THEN N'اسفند'
        END,

    C.PersianDay = P.PersianDay

FROM [core].[Calendar] AS C

CROSS APPLY
(
    SELECT FORMAT(
        C.Calendar_Date,
        'yyyyMMdd',
        'fa-IR'
    ) AS PersianDate
) AS F

CROSS APPLY
(
    SELECT
        TRY_CONVERT(INT, SUBSTRING(F.PersianDate, 1, 4))
            AS PersianYear,

        TRY_CONVERT(INT, SUBSTRING(F.PersianDate, 5, 2))
            AS PersianMonth,

        TRY_CONVERT(INT, SUBSTRING(F.PersianDate, 7, 2))
            AS PersianDay
) AS P
WHERE C.DateKey IS NULL
   OR C.PersianYear IS NULL
   OR C.PersianMonth IS NULL
   OR C.PersianMonthName IS NULL
   OR C.PersianDay IS NULL;

GO

/*========================================================
  Step 4: Validate converted data
========================================================*/

IF EXISTS
(
    SELECT 1
    FROM [core].[Calendar]
    WHERE PersianYear IS NULL
       OR PersianMonth NOT BETWEEN 1 AND 12
       OR PersianDay NOT BETWEEN 1 AND 31
       OR PersianMonthName IS NULL
       OR DateKey IS NULL
)
BEGIN
    THROW 50002,
    'Some calendar records were not converted correctly.',
    1;
END;
GO

/*========================================================
  Step 5: Change columns to NOT NULL
          (the data generator always supplies all 5 values)
========================================================*/

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('core.Calendar') AND name = 'DateKey' AND is_nullable = 1)
    ALTER TABLE [core].[Calendar]
    ALTER COLUMN [DateKey] INT NOT NULL;

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('core.Calendar') AND name = 'PersianYear' AND is_nullable = 1)
    ALTER TABLE [core].[Calendar]
    ALTER COLUMN [PersianYear] INT NOT NULL;

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('core.Calendar') AND name = 'PersianMonth' AND is_nullable = 1)
    ALTER TABLE [core].[Calendar]
    ALTER COLUMN [PersianMonth] INT NOT NULL;

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('core.Calendar') AND name = 'PersianMonthName' AND is_nullable = 1)
    ALTER TABLE [core].[Calendar]
    ALTER COLUMN [PersianMonthName] NVARCHAR(20) NOT NULL;

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('core.Calendar') AND name = 'PersianDay' AND is_nullable = 1)
    ALTER TABLE [core].[Calendar]
    ALTER COLUMN [PersianDay] INT NOT NULL;
GO

/*========================================================
  Step 6: Add unique index for DateKey
========================================================*/

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'UX_Calendar_DateKey'
      AND object_id = OBJECT_ID('core.Calendar')
)
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX [UX_Calendar_DateKey]
    ON [core].[Calendar] ([DateKey]);
END;
GO

/*========================================================
  Step 7: Final result
========================================================*/

SELECT
    COUNT(*)                                   AS Calendar_Rows,
    MIN(Calendar_Date)                         AS First_Date,
    MAX(Calendar_Date)                         AS Last_Date,
    MIN(PersianYear * 10000 + PersianMonth * 100 + PersianDay) AS First_Persian_Date,
    MAX(PersianYear * 10000 + PersianMonth * 100 + PersianDay) AS Last_Persian_Date,
    CASE
        WHEN COUNT(*) = 0 THEN N'Structure ready. Calendar is empty: run the generation script next.'
        WHEN MIN(Calendar_Date) = '2019-03-21' AND MAX(Calendar_Date) = '2026-11-21'
             AND MIN(PersianYear * 10000 + PersianMonth * 100 + PersianDay) = 13980101
             AND MAX(PersianYear * 10000 + PersianMonth * 100 + PersianDay) = 14050830
            THEN N'OK: range is 1398/01/01 .. 1405/08/30 (2026-11-21).'
        ELSE N'WARNING: the loaded range is not 2019-03-21..2026-11-21 (1398/01/01..1405/08/30). Run the Reset script and the new generation script.'
    END                                        AS Range_Status
FROM [core].[Calendar];
GO
