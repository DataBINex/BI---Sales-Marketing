﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 1 - Sales & Customer
    Database: FoodDistributionDB
    SQL Server: 2022
    File    : 07-Team1-02-Create-Constraints.sql
    Purpose : UNIQUE, CHECK and DEFAULT constraints, then FOREIGN KEYs (PKs are already in 01).
    Run order: 2 (after 07-Team1-01-Create-Tables.sql)
    Prerequisites: All 24 Team 1 tables exist. The 6 FKs to Team 2 tables (core.Product, marketing.Promotion) are created only if those tables exist.
    Source  : 06-Team1-Sales-Customer-Logical-Data-Model.xlsx (Stage 6)
    Schemas : Team 1 proposal for the Entity-to-Schema matrix (ref / core / sales); not yet approved
    Re-run  : Safe. Every object is created only if it does not already exist.
*/

USE [FoodDistributionDB];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

/* ---- Prerequisite check: stop the whole script if a prerequisite is missing ---- */
IF OBJECT_ID(N'ref.Province', N'U') IS NULL
   OR OBJECT_ID(N'ref.City', N'U') IS NULL
   OR OBJECT_ID(N'ref.CustomerSegment', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesChannel', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesRegion', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesTerritory', N'U') IS NULL
   OR OBJECT_ID(N'core.Calendar', N'U') IS NULL
   OR OBJECT_ID(N'core.Branch', N'U') IS NULL
   OR OBJECT_ID(N'core.Salesperson', N'U') IS NULL
   OR OBJECT_ID(N'core.Customer', N'U') IS NULL
   OR OBJECT_ID(N'sales.Lead', N'U') IS NULL
   OR OBJECT_ID(N'sales.CustomerInteraction', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOpportunity', N'U') IS NULL
   OR OBJECT_ID(N'sales.Contract', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOrder', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOrderItem', N'U') IS NULL
   OR OBJECT_ID(N'sales.Invoice', N'U') IS NULL
   OR OBJECT_ID(N'sales.InvoiceItem', N'U') IS NULL
   OR OBJECT_ID(N'sales.Payment', N'U') IS NULL
   OR OBJECT_ID(N'sales.ReturnRequest', N'U') IS NULL
   OR OBJECT_ID(N'sales.CustomerFeedback', N'U') IS NULL
   OR OBJECT_ID(N'sales.Commission', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesTarget', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesForecast', N'U') IS NULL
BEGIN
    RAISERROR(N'Team 1 tables are missing. Run 07-Team1-01-Create-Tables.sql first.', 16, 1);
    SET NOEXEC ON;
END;
GO

/* ========================================================================
   1. UNIQUE constraints (business keys)
   ======================================================================== */

IF OBJECT_ID(N'ref.UQ_Province_Province_Code') IS NULL
    ALTER TABLE ref.Province ADD CONSTRAINT UQ_Province_Province_Code UNIQUE (Province_Code);
GO

IF OBJECT_ID(N'ref.UQ_Province_Province_Name') IS NULL
    ALTER TABLE ref.Province ADD CONSTRAINT UQ_Province_Province_Name UNIQUE (Province_Name);
GO

IF OBJECT_ID(N'ref.UQ_City_City_Code') IS NULL
    ALTER TABLE ref.City ADD CONSTRAINT UQ_City_City_Code UNIQUE (City_Code);
GO

IF OBJECT_ID(N'ref.UQ_CustomerSegment_Segment_Code') IS NULL
    ALTER TABLE ref.CustomerSegment ADD CONSTRAINT UQ_CustomerSegment_Segment_Code UNIQUE (Segment_Code);
GO

IF OBJECT_ID(N'ref.UQ_SalesChannel_Sales_Channel_Code') IS NULL
    ALTER TABLE ref.SalesChannel ADD CONSTRAINT UQ_SalesChannel_Sales_Channel_Code UNIQUE (Sales_Channel_Code);
GO

IF OBJECT_ID(N'ref.UQ_SalesRegion_Sales_Region_Code') IS NULL
    ALTER TABLE ref.SalesRegion ADD CONSTRAINT UQ_SalesRegion_Sales_Region_Code UNIQUE (Sales_Region_Code);
GO

IF OBJECT_ID(N'ref.UQ_SalesTerritory_Territory_Code') IS NULL
    ALTER TABLE ref.SalesTerritory ADD CONSTRAINT UQ_SalesTerritory_Territory_Code UNIQUE (Territory_Code);
GO

IF OBJECT_ID(N'core.UQ_Calendar_Calendar_Date') IS NULL
    ALTER TABLE core.Calendar ADD CONSTRAINT UQ_Calendar_Calendar_Date UNIQUE (Calendar_Date);
GO

IF OBJECT_ID(N'core.UQ_Branch_Branch_Code') IS NULL
    ALTER TABLE core.Branch ADD CONSTRAINT UQ_Branch_Branch_Code UNIQUE (Branch_Code);
GO

IF OBJECT_ID(N'core.UQ_Salesperson_Salesperson_Code') IS NULL
    ALTER TABLE core.Salesperson ADD CONSTRAINT UQ_Salesperson_Salesperson_Code UNIQUE (Salesperson_Code);
GO

IF OBJECT_ID(N'core.UQ_Customer_Customer_Code') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT UQ_Customer_Customer_Code UNIQUE (Customer_Code);
GO

IF OBJECT_ID(N'sales.UQ_SalesOpportunity_Opportunity_Code') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT UQ_SalesOpportunity_Opportunity_Code UNIQUE (Opportunity_Code);
GO

IF OBJECT_ID(N'sales.UQ_Contract_Contract_Number') IS NULL
    ALTER TABLE sales.Contract ADD CONSTRAINT UQ_Contract_Contract_Number UNIQUE (Contract_Number);
GO

IF OBJECT_ID(N'sales.UQ_SalesOrder_Sales_Order_Number') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT UQ_SalesOrder_Sales_Order_Number UNIQUE (Sales_Order_Number);
GO

IF OBJECT_ID(N'sales.UQ_SalesOrderItem_Sales_Order_ID_Line_Number') IS NULL
    ALTER TABLE sales.SalesOrderItem ADD CONSTRAINT UQ_SalesOrderItem_Sales_Order_ID_Line_Number UNIQUE (Sales_Order_ID, Line_Number);
GO

IF OBJECT_ID(N'sales.UQ_Invoice_Invoice_Number') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT UQ_Invoice_Invoice_Number UNIQUE (Invoice_Number);
GO

IF OBJECT_ID(N'sales.UQ_Commission_Salesperson_ID_Calendar_ID') IS NULL
    ALTER TABLE sales.Commission ADD CONSTRAINT UQ_Commission_Salesperson_ID_Calendar_ID UNIQUE (Salesperson_ID, Calendar_ID);
GO

IF OBJECT_ID(N'sales.UQ_SalesForecast_Calendar_ID_Forecast_Version') IS NULL
    ALTER TABLE sales.SalesForecast ADD CONSTRAINT UQ_SalesForecast_Calendar_ID_Forecast_Version UNIQUE (Calendar_ID, Forecast_Version);
GO

-- یکتایی (Target_Level، Calendar_ID، Target_Version، FK بُعدیِ همان سطح)؛ چون فقط یک FK بُعدی پر است و بقیه NULL، یک UNIQUE روی همه‌ی ستون‌ها یکتایی هر سطح را می‌دهد
IF OBJECT_ID(N'sales.UQ_SalesTarget_Target_Level_Calendar_ID_Target_Version_Dimensions') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT UQ_SalesTarget_Target_Level_Calendar_ID_Target_Version_Dimensions UNIQUE
        (
            Target_Level,
            Calendar_ID,
            Target_Version,
            Sales_Region_ID,
            Salesperson_ID,
            Sales_Channel_ID,
            Product_ID
        );
GO

/* Helper keys: (PK + Customer_ID) is unique by construction; it exists only as the target of the composite FKs in section 5 (rules CE-01..CE-03; the pair (Invoice_ID, Sales_Order_ID) serves review correction 1). */

IF OBJECT_ID(N'sales.UQ_SalesOrder_Sales_Order_ID_Customer_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT UQ_SalesOrder_Sales_Order_ID_Customer_ID UNIQUE (Sales_Order_ID, Customer_ID);
GO

IF OBJECT_ID(N'sales.UQ_Invoice_Invoice_ID_Customer_ID') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT UQ_Invoice_Invoice_ID_Customer_ID UNIQUE (Invoice_ID, Customer_ID);
GO

-- Review correction 1: (Invoice_ID, Sales_Order_ID) is the target of FK_Payment_Invoice_Invoice_ID_Sales_Order_ID (invoice and order of one payment must belong together)
IF OBJECT_ID(N'sales.UQ_Invoice_Invoice_ID_Sales_Order_ID') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT UQ_Invoice_Invoice_ID_Sales_Order_ID UNIQUE (Invoice_ID, Sales_Order_ID);
GO

IF OBJECT_ID(N'sales.UQ_CustomerInteraction_Customer_Interaction_ID_Customer_ID') IS NULL
    ALTER TABLE sales.CustomerInteraction ADD CONSTRAINT UQ_CustomerInteraction_Customer_Interaction_ID_Customer_ID UNIQUE (Customer_Interaction_ID, Customer_ID);
GO

/* Optional columns that must be unique when filled: filtered unique index (a UNIQUE constraint would allow only one NULL). */

-- Lead_Code در صورت وجود یکتا است
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UQ_Lead_Lead_Code' AND object_id = OBJECT_ID(N'sales.Lead'))
    CREATE UNIQUE NONCLUSTERED INDEX UQ_Lead_Lead_Code ON sales.Lead (Lead_Code) WHERE Lead_Code IS NOT NULL;
GO

-- Transaction_Reference در صورت وجود یکتا است
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UQ_Payment_Transaction_Reference' AND object_id = OBJECT_ID(N'sales.Payment'))
    CREATE UNIQUE NONCLUSTERED INDEX UQ_Payment_Transaction_Reference ON sales.Payment (Transaction_Reference) WHERE Transaction_Reference IS NOT NULL;
GO

-- رابطه 1:1 با Interaction: در صورت وجود یکتا است
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UQ_CustomerFeedback_Customer_Interaction_ID' AND object_id = OBJECT_ID(N'sales.CustomerFeedback'))
    CREATE UNIQUE NONCLUSTERED INDEX UQ_CustomerFeedback_Customer_Interaction_ID ON sales.CustomerFeedback (Customer_Interaction_ID) WHERE Customer_Interaction_ID IS NOT NULL;
GO

/* ========================================================================
   2. CHECK constraints (business rules of the Stage 6 logical model)
   ======================================================================== */

IF OBJECT_ID(N'ref.CK_City_City_Level') IS NULL
    ALTER TABLE ref.City ADD CONSTRAINT CK_City_City_Level CHECK (City_Level IN (N'City', N'District'));
GO

IF OBJECT_ID(N'ref.CK_City_Parent_City_ID') IS NULL
    ALTER TABLE ref.City ADD CONSTRAINT CK_City_Parent_City_ID CHECK (Parent_City_ID IS NULL OR (City_Level = N'District' AND Parent_City_ID <> City_ID));
GO

IF OBJECT_ID(N'ref.CK_CustomerSegment_Priority') IS NULL
    ALTER TABLE ref.CustomerSegment ADD CONSTRAINT CK_CustomerSegment_Priority CHECK (Priority >= 0);
GO

IF OBJECT_ID(N'ref.CK_CustomerSegment_End_Date') IS NULL
    ALTER TABLE ref.CustomerSegment ADD CONSTRAINT CK_CustomerSegment_End_Date CHECK (End_Date >= Created_Date);
GO

IF OBJECT_ID(N'ref.CK_SalesRegion_Parent_Sales_Region_ID') IS NULL
    ALTER TABLE ref.SalesRegion ADD CONSTRAINT CK_SalesRegion_Parent_Sales_Region_ID CHECK (Parent_Sales_Region_ID <> Sales_Region_ID);
GO

IF OBJECT_ID(N'ref.CK_SalesTerritory_Visit_Frequency') IS NULL
    ALTER TABLE ref.SalesTerritory ADD CONSTRAINT CK_SalesTerritory_Visit_Frequency CHECK (Visit_Frequency > 0);
GO

IF OBJECT_ID(N'core.CK_Calendar_Week_Number') IS NULL
    ALTER TABLE core.Calendar ADD CONSTRAINT CK_Calendar_Week_Number CHECK (Week_Number BETWEEN 1 AND 53);
GO

IF OBJECT_ID(N'core.CK_Calendar_Calendar_Date') IS NULL
    ALTER TABLE core.Calendar ADD CONSTRAINT CK_Calendar_Calendar_Date CHECK (Day_Number = DAY(Calendar_Date) AND Month_Number = MONTH(Calendar_Date) AND Quarter_Number = DATEPART(QUARTER, Calendar_Date) AND Year_Number = YEAR(Calendar_Date));
GO

IF OBJECT_ID(N'core.CK_Salesperson_Manager_Salesperson_ID') IS NULL
    ALTER TABLE core.Salesperson ADD CONSTRAINT CK_Salesperson_Manager_Salesperson_ID CHECK (Manager_Salesperson_ID <> Salesperson_ID);
GO

IF OBJECT_ID(N'core.CK_Salesperson_Email') IS NULL
    ALTER TABLE core.Salesperson ADD CONSTRAINT CK_Salesperson_Email CHECK (Email LIKE '_%@_%._%' AND Email NOT LIKE '% %');
GO

IF OBJECT_ID(N'core.CK_Customer_Employee_Count') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT CK_Customer_Employee_Count CHECK (Employee_Count >= 0);
GO

IF OBJECT_ID(N'core.CK_Customer_Annual_Revenue') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT CK_Customer_Annual_Revenue CHECK (Annual_Revenue >= 0);
GO

IF OBJECT_ID(N'core.CK_Customer_Email') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT CK_Customer_Email CHECK (Email LIKE '_%@_%._%' AND Email NOT LIKE '% %');
GO

IF OBJECT_ID(N'core.CK_Customer_Latitude') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT CK_Customer_Latitude CHECK (Latitude BETWEEN -90 AND 90);
GO

IF OBJECT_ID(N'core.CK_Customer_Longitude') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT CK_Customer_Longitude CHECK (Longitude BETWEEN -180 AND 180);
GO

IF OBJECT_ID(N'core.CK_Customer_Credit_Limit') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT CK_Customer_Credit_Limit CHECK (Credit_Limit >= 0);
GO

IF OBJECT_ID(N'sales.CK_Lead_Expected_Value') IS NULL
    ALTER TABLE sales.Lead ADD CONSTRAINT CK_Lead_Expected_Value CHECK (Expected_Value >= 0);
GO

IF OBJECT_ID(N'sales.CK_Lead_Conversion_Date') IS NULL
    ALTER TABLE sales.Lead ADD CONSTRAINT CK_Lead_Conversion_Date CHECK (Conversion_Date >= Created_Date);
GO

IF OBJECT_ID(N'sales.CK_CustomerInteraction_Interaction_Duration_Minutes') IS NULL
    ALTER TABLE sales.CustomerInteraction ADD CONSTRAINT CK_CustomerInteraction_Interaction_Duration_Minutes CHECK (Interaction_Duration_Minutes >= 0);
GO

IF OBJECT_ID(N'sales.CK_CustomerInteraction_Participants_Count') IS NULL
    ALTER TABLE sales.CustomerInteraction ADD CONSTRAINT CK_CustomerInteraction_Participants_Count CHECK (Participants_Count >= 0);
GO

IF OBJECT_ID(N'sales.CK_CustomerInteraction_Follow_Up_Date') IS NULL
    ALTER TABLE sales.CustomerInteraction ADD CONSTRAINT CK_CustomerInteraction_Follow_Up_Date CHECK (Follow_Up_Date IS NULL OR Follow_Up_Required = 1);
GO

IF OBJECT_ID(N'sales.CK_SalesOpportunity_Customer_ID_Lead_ID') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT CK_SalesOpportunity_Customer_ID_Lead_ID CHECK (Customer_ID IS NOT NULL OR Lead_ID IS NOT NULL);
GO

IF OBJECT_ID(N'sales.CK_SalesOpportunity_Probability') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT CK_SalesOpportunity_Probability CHECK (Probability BETWEEN 0 AND 100);
GO

IF OBJECT_ID(N'sales.CK_SalesOpportunity_Expected_Value') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT CK_SalesOpportunity_Expected_Value CHECK (Expected_Value >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesOpportunity_Proposal_Valid_To') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT CK_SalesOpportunity_Proposal_Valid_To CHECK (Proposal_Valid_To >= Proposal_Valid_From);
GO

IF OBJECT_ID(N'sales.CK_SalesOpportunity_Proposed_Price') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT CK_SalesOpportunity_Proposed_Price CHECK (Proposed_Price >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesOpportunity_Proposal_Discount_Amount') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT CK_SalesOpportunity_Proposal_Discount_Amount CHECK (Proposal_Discount_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_Contract_End_Date') IS NULL
    ALTER TABLE sales.Contract ADD CONSTRAINT CK_Contract_End_Date CHECK (End_Date >= Start_Date);
GO

IF OBJECT_ID(N'sales.CK_Contract_Contract_Amount') IS NULL
    ALTER TABLE sales.Contract ADD CONSTRAINT CK_Contract_Contract_Amount CHECK (Contract_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_Contract_Currency_Code') IS NULL
    ALTER TABLE sales.Contract ADD CONSTRAINT CK_Contract_Currency_Code CHECK (Currency_Code COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
GO

IF OBJECT_ID(N'sales.CK_SalesOrder_Total_Amount') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT CK_SalesOrder_Total_Amount CHECK (Total_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesOrder_Discount_Amount') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT CK_SalesOrder_Discount_Amount CHECK (Discount_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesOrderItem_Quantity') IS NULL
    ALTER TABLE sales.SalesOrderItem ADD CONSTRAINT CK_SalesOrderItem_Quantity CHECK (Quantity > 0);
GO

IF OBJECT_ID(N'sales.CK_SalesOrderItem_Unit_Price') IS NULL
    ALTER TABLE sales.SalesOrderItem ADD CONSTRAINT CK_SalesOrderItem_Unit_Price CHECK (Unit_Price >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesOrderItem_Discount_Amount') IS NULL
    ALTER TABLE sales.SalesOrderItem ADD CONSTRAINT CK_SalesOrderItem_Discount_Amount CHECK (Discount_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesOrderItem_Discount_Percentage') IS NULL
    ALTER TABLE sales.SalesOrderItem ADD CONSTRAINT CK_SalesOrderItem_Discount_Percentage CHECK (Discount_Percentage BETWEEN 0 AND 100);
GO

IF OBJECT_ID(N'sales.CK_Invoice_Due_Date') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT CK_Invoice_Due_Date CHECK (Due_Date >= Invoice_Date);
GO

IF OBJECT_ID(N'sales.CK_Invoice_Subtotal') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT CK_Invoice_Subtotal CHECK (Subtotal >= 0);
GO

IF OBJECT_ID(N'sales.CK_Invoice_Discount_Amount') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT CK_Invoice_Discount_Amount CHECK (Discount_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_Invoice_Tax_Amount') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT CK_Invoice_Tax_Amount CHECK (Tax_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_Invoice_Total_Amount') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT CK_Invoice_Total_Amount CHECK (Total_Amount = Subtotal - ISNULL(Discount_Amount, 0) + ISNULL(Tax_Amount, 0));
GO

IF OBJECT_ID(N'sales.CK_InvoiceItem_Quantity') IS NULL
    ALTER TABLE sales.InvoiceItem ADD CONSTRAINT CK_InvoiceItem_Quantity CHECK (Quantity > 0);
GO

IF OBJECT_ID(N'sales.CK_InvoiceItem_Unit_Price') IS NULL
    ALTER TABLE sales.InvoiceItem ADD CONSTRAINT CK_InvoiceItem_Unit_Price CHECK (Unit_Price >= 0);
GO

IF OBJECT_ID(N'sales.CK_InvoiceItem_Discount_Amount') IS NULL
    ALTER TABLE sales.InvoiceItem ADD CONSTRAINT CK_InvoiceItem_Discount_Amount CHECK (Discount_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_InvoiceItem_Tax_Amount') IS NULL
    ALTER TABLE sales.InvoiceItem ADD CONSTRAINT CK_InvoiceItem_Tax_Amount CHECK (Tax_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_InvoiceItem_Final_Amount') IS NULL
    ALTER TABLE sales.InvoiceItem ADD CONSTRAINT CK_InvoiceItem_Final_Amount CHECK (Final_Amount = Net_Amount + ISNULL(Tax_Amount, 0));
GO

IF OBJECT_ID(N'sales.CK_Payment_Invoice_ID_Sales_Order_ID') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT CK_Payment_Invoice_ID_Sales_Order_ID CHECK (Invoice_ID IS NOT NULL OR Sales_Order_ID IS NOT NULL);
GO

IF OBJECT_ID(N'sales.CK_Payment_Amount') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT CK_Payment_Amount CHECK (Amount > 0);
GO

IF OBJECT_ID(N'sales.CK_ReturnRequest_Requested_Quantity') IS NULL
    ALTER TABLE sales.ReturnRequest ADD CONSTRAINT CK_ReturnRequest_Requested_Quantity CHECK (Requested_Quantity > 0);
GO

-- Review correction 2: Approved_Quantity is NULL (request still pending) or between 0 and Requested_Quantity.
-- An older version of this CHECK (only Approved_Quantity <= Requested_Quantity, no lower bound) is dropped and re-created, so a re-run also fixes databases created earlier.
IF OBJECT_ID(N'sales.CK_ReturnRequest_Approved_Quantity') IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM sys.check_constraints
                   WHERE object_id = OBJECT_ID(N'sales.CK_ReturnRequest_Approved_Quantity') AND definition LIKE N'%>=%')
    ALTER TABLE sales.ReturnRequest DROP CONSTRAINT CK_ReturnRequest_Approved_Quantity;
GO

IF OBJECT_ID(N'sales.CK_ReturnRequest_Approved_Quantity') IS NULL
    ALTER TABLE sales.ReturnRequest ADD CONSTRAINT CK_ReturnRequest_Approved_Quantity
        CHECK (Approved_Quantity IS NULL OR (Approved_Quantity >= 0 AND Approved_Quantity <= Requested_Quantity));
GO

IF OBJECT_ID(N'sales.CK_ReturnRequest_Return_Shipping_Cost') IS NULL
    ALTER TABLE sales.ReturnRequest ADD CONSTRAINT CK_ReturnRequest_Return_Shipping_Cost CHECK (Return_Shipping_Cost >= 0);
GO

IF OBJECT_ID(N'sales.CK_ReturnRequest_Refund_Amount') IS NULL
    ALTER TABLE sales.ReturnRequest ADD CONSTRAINT CK_ReturnRequest_Refund_Amount CHECK (Refund_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_CustomerFeedback_Resolution_Date') IS NULL
    ALTER TABLE sales.CustomerFeedback ADD CONSTRAINT CK_CustomerFeedback_Resolution_Date CHECK (Resolution_Date >= Feedback_Date);
GO

IF OBJECT_ID(N'sales.CK_Commission_Commission_Base_Amount') IS NULL
    ALTER TABLE sales.Commission ADD CONSTRAINT CK_Commission_Commission_Base_Amount CHECK (Commission_Base_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_Commission_Commission_Rate') IS NULL
    ALTER TABLE sales.Commission ADD CONSTRAINT CK_Commission_Commission_Rate CHECK (Commission_Rate BETWEEN 0 AND 100);
GO

IF OBJECT_ID(N'sales.CK_SalesTarget_Target_Level') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT CK_SalesTarget_Target_Level CHECK (Target_Level IN (N'Annual', N'Region', N'Team', N'Salesperson', N'Channel', N'Product'));
GO

-- ماتریس الزام FK بُعدی بر اساس Target_Level (OI-15): در هر سطح (جز Annual) دقیقاً یک FK بُعدی پر است
IF OBJECT_ID(N'sales.CK_SalesTarget_Target_Level_Dimensions') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT CK_SalesTarget_Target_Level_Dimensions CHECK
    (
        (Target_Level = N'Annual' AND Sales_Region_ID IS NULL AND Salesperson_ID IS NULL AND Sales_Channel_ID IS NULL AND Product_ID IS NULL)
        OR (Target_Level IN (N'Region', N'Team') AND Sales_Region_ID IS NOT NULL AND Salesperson_ID IS NULL AND Sales_Channel_ID IS NULL AND Product_ID IS NULL)
        OR (Target_Level = N'Salesperson' AND Sales_Region_ID IS NULL AND Salesperson_ID IS NOT NULL AND Sales_Channel_ID IS NULL AND Product_ID IS NULL)
        OR (Target_Level = N'Channel' AND Sales_Region_ID IS NULL AND Salesperson_ID IS NULL AND Sales_Channel_ID IS NOT NULL AND Product_ID IS NULL)
        OR (Target_Level = N'Product' AND Sales_Region_ID IS NULL AND Salesperson_ID IS NULL AND Sales_Channel_ID IS NULL AND Product_ID IS NOT NULL)
    );
GO

IF OBJECT_ID(N'sales.CK_SalesTarget_Target_Value_Target_Quantity') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT CK_SalesTarget_Target_Value_Target_Quantity CHECK (Target_Value IS NOT NULL OR Target_Quantity IS NOT NULL);
GO

IF OBJECT_ID(N'sales.CK_SalesTarget_Target_Value') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT CK_SalesTarget_Target_Value CHECK (Target_Value >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesTarget_Target_Quantity') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT CK_SalesTarget_Target_Quantity CHECK (Target_Quantity >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesTarget_Target_Version') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT CK_SalesTarget_Target_Version CHECK (Target_Version >= 1);
GO

IF OBJECT_ID(N'sales.CK_SalesTarget_Currency_Code') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT CK_SalesTarget_Currency_Code CHECK (Currency_Code COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
GO

IF OBJECT_ID(N'sales.CK_SalesForecast_Forecast_Amount') IS NULL
    ALTER TABLE sales.SalesForecast ADD CONSTRAINT CK_SalesForecast_Forecast_Amount CHECK (Forecast_Amount >= 0);
GO

IF OBJECT_ID(N'sales.CK_SalesForecast_Forecast_Version') IS NULL
    ALTER TABLE sales.SalesForecast ADD CONSTRAINT CK_SalesForecast_Forecast_Version CHECK (Forecast_Version >= 1);
GO

IF OBJECT_ID(N'sales.CK_SalesForecast_Forecast_Accuracy_Percent') IS NULL
    ALTER TABLE sales.SalesForecast ADD CONSTRAINT CK_SalesForecast_Forecast_Accuracy_Percent CHECK (Forecast_Accuracy_Percent BETWEEN 0 AND 100);
GO

/* ========================================================================
   3. DEFAULT constraints
   ======================================================================== */

-- نسخه اولیه هدف = ۱ (مدل منطقی: عدد صحیح ≥ ۱)
IF OBJECT_ID(N'sales.DF_SalesTarget_Target_Version') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT DF_SalesTarget_Target_Version DEFAULT (1) FOR Target_Version;
GO

-- ۱ = پیش‌بینی اولیه (مدل منطقی)
IF OBJECT_ID(N'sales.DF_SalesForecast_Forecast_Version') IS NULL
    ALTER TABLE sales.SalesForecast ADD CONSTRAINT DF_SalesForecast_Forecast_Version DEFAULT (1) FOR Forecast_Version;
GO

/* ========================================================================
   4. FOREIGN KEY constraints between Team 1 tables
      (ON DELETE / ON UPDATE NO ACTION: no cascading deletes of business history)
   ======================================================================== */

-- Province -> City  (Province_ID)
IF OBJECT_ID(N'ref.FK_City_Province_Province_ID') IS NULL
    ALTER TABLE ref.City ADD CONSTRAINT FK_City_Province_Province_ID
        FOREIGN KEY (Province_ID) REFERENCES ref.Province (Province_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- City -> City  (Parent_City_ID, optional)
IF OBJECT_ID(N'ref.FK_City_City_Parent_City_ID') IS NULL
    ALTER TABLE ref.City ADD CONSTRAINT FK_City_City_Parent_City_ID
        FOREIGN KEY (Parent_City_ID) REFERENCES ref.City (City_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Region -> Sales Region  (Parent_Sales_Region_ID, optional)
IF OBJECT_ID(N'ref.FK_SalesRegion_SalesRegion_Parent_Sales_Region_ID') IS NULL
    ALTER TABLE ref.SalesRegion ADD CONSTRAINT FK_SalesRegion_SalesRegion_Parent_Sales_Region_ID
        FOREIGN KEY (Parent_Sales_Region_ID) REFERENCES ref.SalesRegion (Sales_Region_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Region -> Branch  (Sales_Region_ID)
IF OBJECT_ID(N'core.FK_Branch_SalesRegion_Sales_Region_ID') IS NULL
    ALTER TABLE core.Branch ADD CONSTRAINT FK_Branch_SalesRegion_Sales_Region_ID
        FOREIGN KEY (Sales_Region_ID) REFERENCES ref.SalesRegion (Sales_Region_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Branch -> Salesperson  (Branch_ID, optional)
IF OBJECT_ID(N'core.FK_Salesperson_Branch_Branch_ID') IS NULL
    ALTER TABLE core.Salesperson ADD CONSTRAINT FK_Salesperson_Branch_Branch_ID
        FOREIGN KEY (Branch_ID) REFERENCES core.Branch (Branch_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Salesperson  (Manager_Salesperson_ID, optional)
IF OBJECT_ID(N'core.FK_Salesperson_Salesperson_Manager_Salesperson_ID') IS NULL
    ALTER TABLE core.Salesperson ADD CONSTRAINT FK_Salesperson_Salesperson_Manager_Salesperson_ID
        FOREIGN KEY (Manager_Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- City -> Customer  (City_ID, optional)
IF OBJECT_ID(N'core.FK_Customer_City_City_ID') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT FK_Customer_City_City_ID
        FOREIGN KEY (City_ID) REFERENCES ref.City (City_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer Segment -> Customer  (Customer_Segment_ID, optional)
IF OBJECT_ID(N'core.FK_Customer_CustomerSegment_Customer_Segment_ID') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT FK_Customer_CustomerSegment_Customer_Segment_ID
        FOREIGN KEY (Customer_Segment_ID) REFERENCES ref.CustomerSegment (Customer_Segment_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Channel -> Customer  (Sales_Channel_ID, optional)
IF OBJECT_ID(N'core.FK_Customer_SalesChannel_Sales_Channel_ID') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT FK_Customer_SalesChannel_Sales_Channel_ID
        FOREIGN KEY (Sales_Channel_ID) REFERENCES ref.SalesChannel (Sales_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Territory -> Customer  (Sales_Territory_ID, optional)
IF OBJECT_ID(N'core.FK_Customer_SalesTerritory_Sales_Territory_ID') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT FK_Customer_SalesTerritory_Sales_Territory_ID
        FOREIGN KEY (Sales_Territory_ID) REFERENCES ref.SalesTerritory (Sales_Territory_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Customer  (Salesperson_ID, optional)
IF OBJECT_ID(N'core.FK_Customer_Salesperson_Salesperson_ID') IS NULL
    ALTER TABLE core.Customer ADD CONSTRAINT FK_Customer_Salesperson_Salesperson_ID
        FOREIGN KEY (Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Lead  (Salesperson_ID, optional)
IF OBJECT_ID(N'sales.FK_Lead_Salesperson_Salesperson_ID') IS NULL
    ALTER TABLE sales.Lead ADD CONSTRAINT FK_Lead_Salesperson_Salesperson_ID
        FOREIGN KEY (Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer -> Customer Interaction  (Customer_ID)
IF OBJECT_ID(N'sales.FK_CustomerInteraction_Customer_Customer_ID') IS NULL
    ALTER TABLE sales.CustomerInteraction ADD CONSTRAINT FK_CustomerInteraction_Customer_Customer_ID
        FOREIGN KEY (Customer_ID) REFERENCES core.Customer (Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Customer Interaction  (Salesperson_ID, optional)
IF OBJECT_ID(N'sales.FK_CustomerInteraction_Salesperson_Salesperson_ID') IS NULL
    ALTER TABLE sales.CustomerInteraction ADD CONSTRAINT FK_CustomerInteraction_Salesperson_Salesperson_ID
        FOREIGN KEY (Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Territory -> Customer Interaction  (Sales_Territory_ID, optional)
IF OBJECT_ID(N'sales.FK_CustomerInteraction_SalesTerritory_Sales_Territory_ID') IS NULL
    ALTER TABLE sales.CustomerInteraction ADD CONSTRAINT FK_CustomerInteraction_SalesTerritory_Sales_Territory_ID
        FOREIGN KEY (Sales_Territory_ID) REFERENCES ref.SalesTerritory (Sales_Territory_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer -> Sales Opportunity  (Customer_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesOpportunity_Customer_Customer_ID') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT FK_SalesOpportunity_Customer_Customer_ID
        FOREIGN KEY (Customer_ID) REFERENCES core.Customer (Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Lead -> Sales Opportunity  (Lead_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesOpportunity_Lead_Lead_ID') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT FK_SalesOpportunity_Lead_Lead_ID
        FOREIGN KEY (Lead_ID) REFERENCES sales.Lead (Lead_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Sales Opportunity  (Salesperson_ID)
IF OBJECT_ID(N'sales.FK_SalesOpportunity_Salesperson_Salesperson_ID') IS NULL
    ALTER TABLE sales.SalesOpportunity ADD CONSTRAINT FK_SalesOpportunity_Salesperson_Salesperson_ID
        FOREIGN KEY (Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer -> Contract  (Customer_ID)
IF OBJECT_ID(N'sales.FK_Contract_Customer_Customer_ID') IS NULL
    ALTER TABLE sales.Contract ADD CONSTRAINT FK_Contract_Customer_Customer_ID
        FOREIGN KEY (Customer_ID) REFERENCES core.Customer (Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Opportunity -> Contract  (Sales_Opportunity_ID, optional)
IF OBJECT_ID(N'sales.FK_Contract_SalesOpportunity_Sales_Opportunity_ID') IS NULL
    ALTER TABLE sales.Contract ADD CONSTRAINT FK_Contract_SalesOpportunity_Sales_Opportunity_ID
        FOREIGN KEY (Sales_Opportunity_ID) REFERENCES sales.SalesOpportunity (Sales_Opportunity_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer -> Sales Order  (Customer_ID)
IF OBJECT_ID(N'sales.FK_SalesOrder_Customer_Customer_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_Customer_Customer_ID
        FOREIGN KEY (Customer_ID) REFERENCES core.Customer (Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Sales Order  (Salesperson_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesOrder_Salesperson_Salesperson_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_Salesperson_Salesperson_ID
        FOREIGN KEY (Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Channel -> Sales Order  (Sales_Channel_ID)
IF OBJECT_ID(N'sales.FK_SalesOrder_SalesChannel_Sales_Channel_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_SalesChannel_Sales_Channel_ID
        FOREIGN KEY (Sales_Channel_ID) REFERENCES ref.SalesChannel (Sales_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Region -> Sales Order  (Sales_Region_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesOrder_SalesRegion_Sales_Region_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_SalesRegion_Sales_Region_ID
        FOREIGN KEY (Sales_Region_ID) REFERENCES ref.SalesRegion (Sales_Region_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Contract -> Sales Order  (Contract_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesOrder_Contract_Contract_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_Contract_Contract_ID
        FOREIGN KEY (Contract_ID) REFERENCES sales.Contract (Contract_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer Interaction -> Sales Order  (Customer_Interaction_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesOrder_CustomerInteraction_Customer_Interaction_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_CustomerInteraction_Customer_Interaction_ID
        FOREIGN KEY (Customer_Interaction_ID) REFERENCES sales.CustomerInteraction (Customer_Interaction_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Calendar -> Sales Order  (Calendar_ID)
IF OBJECT_ID(N'sales.FK_SalesOrder_Calendar_Calendar_ID') IS NULL
    ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_Calendar_Calendar_ID
        FOREIGN KEY (Calendar_ID) REFERENCES core.Calendar (Calendar_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Order -> Sales Order Item  (Sales_Order_ID)
IF OBJECT_ID(N'sales.FK_SalesOrderItem_SalesOrder_Sales_Order_ID') IS NULL
    ALTER TABLE sales.SalesOrderItem ADD CONSTRAINT FK_SalesOrderItem_SalesOrder_Sales_Order_ID
        FOREIGN KEY (Sales_Order_ID) REFERENCES sales.SalesOrder (Sales_Order_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer -> Invoice  (Customer_ID)
IF OBJECT_ID(N'sales.FK_Invoice_Customer_Customer_ID') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT FK_Invoice_Customer_Customer_ID
        FOREIGN KEY (Customer_ID) REFERENCES core.Customer (Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Order -> Invoice  (Sales_Order_ID)
IF OBJECT_ID(N'sales.FK_Invoice_SalesOrder_Sales_Order_ID') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT FK_Invoice_SalesOrder_Sales_Order_ID
        FOREIGN KEY (Sales_Order_ID) REFERENCES sales.SalesOrder (Sales_Order_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Invoice -> Invoice Item  (Invoice_ID)
IF OBJECT_ID(N'sales.FK_InvoiceItem_Invoice_Invoice_ID') IS NULL
    ALTER TABLE sales.InvoiceItem ADD CONSTRAINT FK_InvoiceItem_Invoice_Invoice_ID
        FOREIGN KEY (Invoice_ID) REFERENCES sales.Invoice (Invoice_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer -> Payment  (Customer_ID)
IF OBJECT_ID(N'sales.FK_Payment_Customer_Customer_ID') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT FK_Payment_Customer_Customer_ID
        FOREIGN KEY (Customer_ID) REFERENCES core.Customer (Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Invoice -> Payment  (Invoice_ID, optional)
IF OBJECT_ID(N'sales.FK_Payment_Invoice_Invoice_ID') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT FK_Payment_Invoice_Invoice_ID
        FOREIGN KEY (Invoice_ID) REFERENCES sales.Invoice (Invoice_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Order -> Payment  (Sales_Order_ID, optional)
IF OBJECT_ID(N'sales.FK_Payment_SalesOrder_Sales_Order_ID') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT FK_Payment_SalesOrder_Sales_Order_ID
        FOREIGN KEY (Sales_Order_ID) REFERENCES sales.SalesOrder (Sales_Order_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Order Item -> Return Request  (Sales_Order_Item_ID)
IF OBJECT_ID(N'sales.FK_ReturnRequest_SalesOrderItem_Sales_Order_Item_ID') IS NULL
    ALTER TABLE sales.ReturnRequest ADD CONSTRAINT FK_ReturnRequest_SalesOrderItem_Sales_Order_Item_ID
        FOREIGN KEY (Sales_Order_Item_ID) REFERENCES sales.SalesOrderItem (Sales_Order_Item_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Payment -> Return Request  (Payment_ID, optional)
IF OBJECT_ID(N'sales.FK_ReturnRequest_Payment_Payment_ID') IS NULL
    ALTER TABLE sales.ReturnRequest ADD CONSTRAINT FK_ReturnRequest_Payment_Payment_ID
        FOREIGN KEY (Payment_ID) REFERENCES sales.Payment (Payment_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Calendar -> Return Request  (Calendar_ID)
IF OBJECT_ID(N'sales.FK_ReturnRequest_Calendar_Calendar_ID') IS NULL
    ALTER TABLE sales.ReturnRequest ADD CONSTRAINT FK_ReturnRequest_Calendar_Calendar_ID
        FOREIGN KEY (Calendar_ID) REFERENCES core.Calendar (Calendar_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer -> Customer Feedback  (Customer_ID)
IF OBJECT_ID(N'sales.FK_CustomerFeedback_Customer_Customer_ID') IS NULL
    ALTER TABLE sales.CustomerFeedback ADD CONSTRAINT FK_CustomerFeedback_Customer_Customer_ID
        FOREIGN KEY (Customer_ID) REFERENCES core.Customer (Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Customer Interaction -> Customer Feedback  (Customer_Interaction_ID, optional)
IF OBJECT_ID(N'sales.FK_CustomerFeedback_CustomerInteraction_Customer_Interaction_ID') IS NULL
    ALTER TABLE sales.CustomerFeedback ADD CONSTRAINT FK_CustomerFeedback_CustomerInteraction_Customer_Interaction_ID
        FOREIGN KEY (Customer_Interaction_ID) REFERENCES sales.CustomerInteraction (Customer_Interaction_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Order -> Customer Feedback  (Sales_Order_ID, optional)
IF OBJECT_ID(N'sales.FK_CustomerFeedback_SalesOrder_Sales_Order_ID') IS NULL
    ALTER TABLE sales.CustomerFeedback ADD CONSTRAINT FK_CustomerFeedback_SalesOrder_Sales_Order_ID
        FOREIGN KEY (Sales_Order_ID) REFERENCES sales.SalesOrder (Sales_Order_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Commission  (Salesperson_ID)
IF OBJECT_ID(N'sales.FK_Commission_Salesperson_Salesperson_ID') IS NULL
    ALTER TABLE sales.Commission ADD CONSTRAINT FK_Commission_Salesperson_Salesperson_ID
        FOREIGN KEY (Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Calendar -> Commission  (Calendar_ID)
IF OBJECT_ID(N'sales.FK_Commission_Calendar_Calendar_ID') IS NULL
    ALTER TABLE sales.Commission ADD CONSTRAINT FK_Commission_Calendar_Calendar_ID
        FOREIGN KEY (Calendar_ID) REFERENCES core.Calendar (Calendar_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Calendar -> Sales Target  (Calendar_ID)
IF OBJECT_ID(N'sales.FK_SalesTarget_Calendar_Calendar_ID') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT FK_SalesTarget_Calendar_Calendar_ID
        FOREIGN KEY (Calendar_ID) REFERENCES core.Calendar (Calendar_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Region -> Sales Target  (Sales_Region_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesTarget_SalesRegion_Sales_Region_ID') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT FK_SalesTarget_SalesRegion_Sales_Region_ID
        FOREIGN KEY (Sales_Region_ID) REFERENCES ref.SalesRegion (Sales_Region_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Salesperson -> Sales Target  (Salesperson_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesTarget_Salesperson_Salesperson_ID') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT FK_SalesTarget_Salesperson_Salesperson_ID
        FOREIGN KEY (Salesperson_ID) REFERENCES core.Salesperson (Salesperson_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Sales Channel -> Sales Target  (Sales_Channel_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesTarget_SalesChannel_Sales_Channel_ID') IS NULL
    ALTER TABLE sales.SalesTarget ADD CONSTRAINT FK_SalesTarget_SalesChannel_Sales_Channel_ID
        FOREIGN KEY (Sales_Channel_ID) REFERENCES ref.SalesChannel (Sales_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Calendar -> Sales Forecast  (Calendar_ID)
IF OBJECT_ID(N'sales.FK_SalesForecast_Calendar_Calendar_ID') IS NULL
    ALTER TABLE sales.SalesForecast ADD CONSTRAINT FK_SalesForecast_Calendar_Calendar_ID
        FOREIGN KEY (Calendar_ID) REFERENCES core.Calendar (Calendar_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

/* ========================================================================
   5. Composite FOREIGN KEYs for the consistency rules CE-01..CE-03 of Stage 6
      (same Customer_ID on the child row and on the related order / invoice / interaction)
      and review correction 1 (the invoice of a payment belongs to the order of the same payment).
      If the optional column of the pair is NULL, SQL Server skips the check - exactly the wanted behaviour.
   ======================================================================== */

-- CE-01: مشتری فاکتور = مشتری سفارش مبنا
IF OBJECT_ID(N'sales.FK_Invoice_SalesOrder_Sales_Order_ID_Customer_ID') IS NULL
    ALTER TABLE sales.Invoice ADD CONSTRAINT FK_Invoice_SalesOrder_Sales_Order_ID_Customer_ID
        FOREIGN KEY (Sales_Order_ID, Customer_ID) REFERENCES sales.SalesOrder (Sales_Order_ID, Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- CE-02: مشتری پرداخت = مشتری فاکتور (وقتی Invoice_ID پر است)
IF OBJECT_ID(N'sales.FK_Payment_Invoice_Invoice_ID_Customer_ID') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT FK_Payment_Invoice_Invoice_ID_Customer_ID
        FOREIGN KEY (Invoice_ID, Customer_ID) REFERENCES sales.Invoice (Invoice_ID, Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- CE-02: مشتری پرداخت = مشتری سفارش (وقتی Sales_Order_ID پر است)
IF OBJECT_ID(N'sales.FK_Payment_SalesOrder_Sales_Order_ID_Customer_ID') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT FK_Payment_SalesOrder_Sales_Order_ID_Customer_ID
        FOREIGN KEY (Sales_Order_ID, Customer_ID) REFERENCES sales.SalesOrder (Sales_Order_ID, Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Review correction 1: فاکتور و سفارش یک پرداخت باید به هم تعلق داشته باشند (وقتی هر دو Invoice_ID و Sales_Order_ID پر هستند؛ اگر یکی NULL باشد کنترل نمی‌شود)
IF OBJECT_ID(N'sales.FK_Payment_Invoice_Invoice_ID_Sales_Order_ID') IS NULL
    ALTER TABLE sales.Payment ADD CONSTRAINT FK_Payment_Invoice_Invoice_ID_Sales_Order_ID
        FOREIGN KEY (Invoice_ID, Sales_Order_ID) REFERENCES sales.Invoice (Invoice_ID, Sales_Order_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- CE-03: مشتری بازخورد = مشتری سفارش مرتبط
IF OBJECT_ID(N'sales.FK_CustomerFeedback_SalesOrder_Sales_Order_ID_Customer_ID') IS NULL
    ALTER TABLE sales.CustomerFeedback ADD CONSTRAINT FK_CustomerFeedback_SalesOrder_Sales_Order_ID_Customer_ID
        FOREIGN KEY (Sales_Order_ID, Customer_ID) REFERENCES sales.SalesOrder (Sales_Order_ID, Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- CE-03: مشتری بازخورد = مشتری تعامل مرتبط
IF OBJECT_ID(N'sales.FK_CustomerFeedback_CustomerInteraction_Customer_Interaction_ID_Customer_ID') IS NULL
    ALTER TABLE sales.CustomerFeedback ADD CONSTRAINT FK_CustomerFeedback_CustomerInteraction_Customer_Interaction_ID_Customer_ID
        FOREIGN KEY (Customer_Interaction_ID, Customer_ID) REFERENCES sales.CustomerInteraction (Customer_Interaction_ID, Customer_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

/* ========================================================================
   6. FOREIGN KEYs to Team 2 tables (core.Product, marketing.Promotion)
      Created only when the Team 2 table exists. Otherwise a WARNING is printed and nothing is created:
      run 07-Team2-03-Create-Tables.sql and then run this file again.
   ======================================================================== */

-- Product (Team 2) -> Contract  (Product_ID, optional)
IF OBJECT_ID(N'sales.FK_Contract_Product_Product_ID') IS NULL
BEGIN
    IF OBJECT_ID(N'core.Product', N'U') IS NULL
        PRINT N'WARNING: core.Product does not exist yet - FK_Contract_Product_Product_ID was NOT created. Run 07-Team2-03-Create-Tables.sql, then run this file again.';
    ELSE
    BEGIN
        EXEC (N'ALTER TABLE sales.Contract ADD CONSTRAINT FK_Contract_Product_Product_ID FOREIGN KEY (Product_ID) REFERENCES core.Product (Product_ID) ON DELETE NO ACTION ON UPDATE NO ACTION;');
        PRINT N'Created FK_Contract_Product_Product_ID.';
    END
END
GO

-- Promotion (Team 2) -> Sales Order  (Promotion_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesOrder_Promotion_Promotion_ID') IS NULL
BEGIN
    IF OBJECT_ID(N'marketing.Promotion', N'U') IS NULL
        PRINT N'WARNING: marketing.Promotion does not exist yet - FK_SalesOrder_Promotion_Promotion_ID was NOT created. Run 07-Team2-03-Create-Tables.sql, then run this file again.';
    ELSE
    BEGIN
        EXEC (N'ALTER TABLE sales.SalesOrder ADD CONSTRAINT FK_SalesOrder_Promotion_Promotion_ID FOREIGN KEY (Promotion_ID) REFERENCES marketing.Promotion (Promotion_ID) ON DELETE NO ACTION ON UPDATE NO ACTION;');
        PRINT N'Created FK_SalesOrder_Promotion_Promotion_ID.';
    END
END
GO

-- Product (Team 2) -> Sales Order Item  (Product_ID)
IF OBJECT_ID(N'sales.FK_SalesOrderItem_Product_Product_ID') IS NULL
BEGIN
    IF OBJECT_ID(N'core.Product', N'U') IS NULL
        PRINT N'WARNING: core.Product does not exist yet - FK_SalesOrderItem_Product_Product_ID was NOT created. Run 07-Team2-03-Create-Tables.sql, then run this file again.';
    ELSE
    BEGIN
        EXEC (N'ALTER TABLE sales.SalesOrderItem ADD CONSTRAINT FK_SalesOrderItem_Product_Product_ID FOREIGN KEY (Product_ID) REFERENCES core.Product (Product_ID) ON DELETE NO ACTION ON UPDATE NO ACTION;');
        PRINT N'Created FK_SalesOrderItem_Product_Product_ID.';
    END
END
GO

-- Product (Team 2) -> Invoice Item  (Product_ID)
IF OBJECT_ID(N'sales.FK_InvoiceItem_Product_Product_ID') IS NULL
BEGIN
    IF OBJECT_ID(N'core.Product', N'U') IS NULL
        PRINT N'WARNING: core.Product does not exist yet - FK_InvoiceItem_Product_Product_ID was NOT created. Run 07-Team2-03-Create-Tables.sql, then run this file again.';
    ELSE
    BEGIN
        EXEC (N'ALTER TABLE sales.InvoiceItem ADD CONSTRAINT FK_InvoiceItem_Product_Product_ID FOREIGN KEY (Product_ID) REFERENCES core.Product (Product_ID) ON DELETE NO ACTION ON UPDATE NO ACTION;');
        PRINT N'Created FK_InvoiceItem_Product_Product_ID.';
    END
END
GO

-- Product (Team 2) -> Customer Feedback  (Product_ID, optional)
IF OBJECT_ID(N'sales.FK_CustomerFeedback_Product_Product_ID') IS NULL
BEGIN
    IF OBJECT_ID(N'core.Product', N'U') IS NULL
        PRINT N'WARNING: core.Product does not exist yet - FK_CustomerFeedback_Product_Product_ID was NOT created. Run 07-Team2-03-Create-Tables.sql, then run this file again.';
    ELSE
    BEGIN
        EXEC (N'ALTER TABLE sales.CustomerFeedback ADD CONSTRAINT FK_CustomerFeedback_Product_Product_ID FOREIGN KEY (Product_ID) REFERENCES core.Product (Product_ID) ON DELETE NO ACTION ON UPDATE NO ACTION;');
        PRINT N'Created FK_CustomerFeedback_Product_Product_ID.';
    END
END
GO

-- Product (Team 2) -> Sales Target  (Product_ID, optional)
IF OBJECT_ID(N'sales.FK_SalesTarget_Product_Product_ID') IS NULL
BEGIN
    IF OBJECT_ID(N'core.Product', N'U') IS NULL
        PRINT N'WARNING: core.Product does not exist yet - FK_SalesTarget_Product_Product_ID was NOT created. Run 07-Team2-03-Create-Tables.sql, then run this file again.';
    ELSE
    BEGIN
        EXEC (N'ALTER TABLE sales.SalesTarget ADD CONSTRAINT FK_SalesTarget_Product_Product_ID FOREIGN KEY (Product_ID) REFERENCES core.Product (Product_ID) ON DELETE NO ACTION ON UPDATE NO ACTION;');
        PRINT N'Created FK_SalesTarget_Product_Product_ID.';
    END
END
GO

/* ---- Summary of Team 1 objects ---- */
DECLARE @t TABLE (object_id int PRIMARY KEY);
INSERT @t (object_id)
SELECT OBJECT_ID(n) FROM (VALUES (N'ref.Province'), (N'ref.City'), (N'ref.CustomerSegment'), (N'ref.SalesChannel'), (N'ref.SalesRegion'), (N'ref.SalesTerritory'), (N'core.Calendar'), (N'core.Branch'), (N'core.Salesperson'), (N'core.Customer'), (N'sales.Lead'), (N'sales.CustomerInteraction'), (N'sales.SalesOpportunity'), (N'sales.Contract'), (N'sales.SalesOrder'), (N'sales.SalesOrderItem'), (N'sales.Invoice'), (N'sales.InvoiceItem'), (N'sales.Payment'), (N'sales.ReturnRequest'), (N'sales.CustomerFeedback'), (N'sales.Commission'), (N'sales.SalesTarget'), (N'sales.SalesForecast')) v(n) WHERE OBJECT_ID(n) IS NOT NULL;
DECLARE @msg nvarchar(600) = CONCAT(
    N'Team 1 objects now in FoodDistributionDB: tables ', (SELECT COUNT(*) FROM @t),
    N', columns ', (SELECT COUNT(*) FROM sys.columns c JOIN @t t ON t.object_id = c.object_id),
    N', PK ', (SELECT COUNT(*) FROM sys.key_constraints k JOIN @t t ON t.object_id = k.parent_object_id WHERE k.type = 'PK'),
    N', UNIQUE ', (SELECT COUNT(*) FROM sys.key_constraints k JOIN @t t ON t.object_id = k.parent_object_id WHERE k.type = 'UQ')
                + (SELECT COUNT(*) FROM sys.indexes i JOIN @t t ON t.object_id = i.object_id WHERE i.is_unique = 1 AND i.has_filter = 1),
    N', CHECK ', (SELECT COUNT(*) FROM sys.check_constraints k JOIN @t t ON t.object_id = k.parent_object_id),
    N', DEFAULT ', (SELECT COUNT(*) FROM sys.default_constraints k JOIN @t t ON t.object_id = k.parent_object_id),
    N', FK ', (SELECT COUNT(*) FROM sys.foreign_keys k JOIN @t t ON t.object_id = k.parent_object_id),
    N', indexes ', (SELECT COUNT(*) FROM sys.indexes i JOIN @t t ON t.object_id = i.object_id WHERE i.type = 2 AND i.is_unique = 0),
    N'.');
PRINT @msg;
GO

SET NOEXEC OFF;
GO
PRINT N'07-Team1-02-Create-Constraints.sql finished.';
GO
