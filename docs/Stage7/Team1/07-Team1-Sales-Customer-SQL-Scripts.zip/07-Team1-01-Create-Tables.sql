﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 1 - Sales & Customer
    Database: FoodDistributionDB
    SQL Server: 2022
    File    : 07-Team1-01-Create-Tables.sql
    Purpose : Create the 24 Team 1 tables (columns, data types, NULL/NOT NULL, IDENTITY, PRIMARY KEY).
    Run order: 1 (after 07-01-Create-Database.sql and 07-02-Create-Schemas.sql)
    Prerequisites: Database FoodDistributionDB and schemas ref, core and sales exist.
    Source  : 06-Team1-Sales-Customer-Logical-Data-Model.xlsx (Stage 6)
    Schemas : Team 1 proposal for the Entity-to-Schema matrix (ref / core / sales); not yet approved
    Re-run  : Safe. Every object is created only if it does not already exist.
*/

USE [FoodDistributionDB];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

/* ---- Prerequisite check: stop the whole script if a prerequisite is missing ---- */
IF SCHEMA_ID(N'ref') IS NULL OR SCHEMA_ID(N'core') IS NULL OR SCHEMA_ID(N'sales') IS NULL
BEGIN
    RAISERROR(N'Schemas ref, core and sales are required. Run 07-02-Create-Schemas.sql first.', 16, 1);
    SET NOEXEC ON;
END;
GO

/* ========================================================================
   Schema [ref] - Reference tables (depend only on ref)
   ======================================================================== */

-- ref.Province  <-  Stage 6 entity "Province"
IF OBJECT_ID(N'ref.Province', N'U') IS NULL
BEGIN
    CREATE TABLE ref.Province
    (
        Province_ID      int IDENTITY(1,1)  NOT NULL,
        Province_Code    nvarchar(30)       NOT NULL,
        Province_Name    nvarchar(150)      NOT NULL,
        Province_Status  nvarchar(30)       NOT NULL,
        CONSTRAINT PK_Province PRIMARY KEY CLUSTERED (Province_ID)
    );
    PRINT N'Created table ref.Province.';
END
ELSE
    PRINT N'Table ref.Province already exists - skipped.';
GO

-- ref.City  <-  Stage 6 entity "City"
IF OBJECT_ID(N'ref.City', N'U') IS NULL
BEGIN
    CREATE TABLE ref.City
    (
        City_ID         int IDENTITY(1,1)  NOT NULL,
        Province_ID     int                NOT NULL,
        Parent_City_ID  int                NULL,
        City_Code       nvarchar(30)       NOT NULL,
        City_Name       nvarchar(150)      NOT NULL,
        City_Level      nvarchar(30)       NOT NULL,
        City_Status     nvarchar(30)       NULL,
        CONSTRAINT PK_City PRIMARY KEY CLUSTERED (City_ID)
    );
    PRINT N'Created table ref.City.';
END
ELSE
    PRINT N'Table ref.City already exists - skipped.';
GO

-- ref.CustomerSegment  <-  Stage 6 entity "Customer Segment"
IF OBJECT_ID(N'ref.CustomerSegment', N'U') IS NULL
BEGIN
    CREATE TABLE ref.CustomerSegment
    (
        Customer_Segment_ID  int IDENTITY(1,1)  NOT NULL,
        Segment_Code         nvarchar(30)       NOT NULL,
        Segment_Name         nvarchar(150)      NOT NULL,
        Segment_Type         nvarchar(30)       NULL,
        Segment_Level        nvarchar(30)       NULL,
        Segment_Criteria     nvarchar(1000)     NULL,
        Segment_Description  nvarchar(1000)     NULL,
        Priority             int                NULL,
        Segment_Status       nvarchar(30)       NULL,
        Created_Date         date               NULL,
        End_Date             date               NULL,
        CONSTRAINT PK_CustomerSegment PRIMARY KEY CLUSTERED (Customer_Segment_ID)
    );
    PRINT N'Created table ref.CustomerSegment.';
END
ELSE
    PRINT N'Table ref.CustomerSegment already exists - skipped.';
GO

-- ref.SalesChannel  <-  Stage 6 entity "Sales Channel"
IF OBJECT_ID(N'ref.SalesChannel', N'U') IS NULL
BEGIN
    CREATE TABLE ref.SalesChannel
    (
        Sales_Channel_ID    int IDENTITY(1,1)  NOT NULL,
        Sales_Channel_Code  nvarchar(30)       NOT NULL,
        Sales_Channel_Name  nvarchar(150)      NOT NULL,
        Sales_Channel_Type  nvarchar(30)       NOT NULL,
        Channel_Status      nvarchar(30)       NOT NULL,
        Campaign_Name       nvarchar(150)      NULL,
        CONSTRAINT PK_SalesChannel PRIMARY KEY CLUSTERED (Sales_Channel_ID)
    );
    PRINT N'Created table ref.SalesChannel.';
END
ELSE
    PRINT N'Table ref.SalesChannel already exists - skipped.';
GO

-- ref.SalesRegion  <-  Stage 6 entity "Sales Region"
IF OBJECT_ID(N'ref.SalesRegion', N'U') IS NULL
BEGIN
    CREATE TABLE ref.SalesRegion
    (
        Sales_Region_ID         int IDENTITY(1,1)  NOT NULL,
        Parent_Sales_Region_ID  int                NULL,
        Sales_Region_Code       nvarchar(30)       NOT NULL,
        Sales_Region_Name       nvarchar(150)      NOT NULL,
        Region_Level            nvarchar(30)       NULL,
        Region_Status           nvarchar(30)       NOT NULL,
        CONSTRAINT PK_SalesRegion PRIMARY KEY CLUSTERED (Sales_Region_ID)
    );
    PRINT N'Created table ref.SalesRegion.';
END
ELSE
    PRINT N'Table ref.SalesRegion already exists - skipped.';
GO

-- ref.SalesTerritory  <-  Stage 6 entity "Sales Territory"
IF OBJECT_ID(N'ref.SalesTerritory', N'U') IS NULL
BEGIN
    CREATE TABLE ref.SalesTerritory
    (
        Sales_Territory_ID      int IDENTITY(1,1)  NOT NULL,
        Territory_Code          nvarchar(30)       NOT NULL,
        Territory_Name          nvarchar(150)      NOT NULL,
        Territory_Type          nvarchar(30)       NULL,
        Territory_Manager_Name  nvarchar(150)      NULL,
        Route_Code              nvarchar(30)       NULL,
        Route_Name              nvarchar(150)      NULL,
        Visit_Frequency         int                NULL,
        Territory_Status        nvarchar(30)       NOT NULL,
        CONSTRAINT PK_SalesTerritory PRIMARY KEY CLUSTERED (Sales_Territory_ID)
    );
    PRINT N'Created table ref.SalesTerritory.';
END
ELSE
    PRINT N'Table ref.SalesTerritory already exists - skipped.';
GO

/* ========================================================================
   Schema [core] - Core master tables (depend on core and ref)
   ======================================================================== */

-- core.Calendar  <-  Stage 6 entity "Calendar"
IF OBJECT_ID(N'core.Calendar', N'U') IS NULL
BEGIN
    CREATE TABLE core.Calendar
    (
        Calendar_ID     int IDENTITY(1,1)  NOT NULL,
        Calendar_Date   date               NOT NULL,
        Day_Number      int                NOT NULL,
        Month_Number    int                NOT NULL,
        Quarter_Number  int                NOT NULL,
        Week_Number     int                NOT NULL,
        Year_Number     int                NOT NULL,
        CONSTRAINT PK_Calendar PRIMARY KEY CLUSTERED (Calendar_ID)
    );
    PRINT N'Created table core.Calendar.';
END
ELSE
    PRINT N'Table core.Calendar already exists - skipped.';
GO

-- core.Branch  <-  Stage 6 entity "Branch"
IF OBJECT_ID(N'core.Branch', N'U') IS NULL
BEGIN
    CREATE TABLE core.Branch
    (
        Branch_ID        int IDENTITY(1,1)  NOT NULL,
        Sales_Region_ID  int                NOT NULL,
        Branch_Code      nvarchar(30)       NOT NULL,
        Branch_Name      nvarchar(150)      NOT NULL,
        Branch_Status    nvarchar(30)       NULL,
        CONSTRAINT PK_Branch PRIMARY KEY CLUSTERED (Branch_ID)
    );
    PRINT N'Created table core.Branch.';
END
ELSE
    PRINT N'Table core.Branch already exists - skipped.';
GO

-- core.Salesperson  <-  Stage 6 entity "Salesperson"
IF OBJECT_ID(N'core.Salesperson', N'U') IS NULL
BEGIN
    CREATE TABLE core.Salesperson
    (
        Salesperson_ID          int IDENTITY(1,1)  NOT NULL,
        Branch_ID               int                NULL,
        Manager_Salesperson_ID  int                NULL,
        Salesperson_Code        nvarchar(30)       NOT NULL,
        Salesperson_Name        nvarchar(150)      NOT NULL,
        Role                    nvarchar(100)      NOT NULL,
        Employment_Status       nvarchar(30)       NOT NULL,
        Hire_Date               date               NULL,
        Email                   nvarchar(254)      NULL,
        Phone_Number            nvarchar(20)       NULL,
        CONSTRAINT PK_Salesperson PRIMARY KEY CLUSTERED (Salesperson_ID)
    );
    PRINT N'Created table core.Salesperson.';
END
ELSE
    PRINT N'Table core.Salesperson already exists - skipped.';
GO

-- core.Customer  <-  Stage 6 entity "Customer"
IF OBJECT_ID(N'core.Customer', N'U') IS NULL
BEGIN
    CREATE TABLE core.Customer
    (
        Customer_ID                int IDENTITY(1,1)  NOT NULL,
        City_ID                    int                NULL,
        Customer_Segment_ID        int                NULL,
        Sales_Channel_ID           int                NULL,
        Sales_Territory_ID         int                NULL,
        Salesperson_ID             int                NULL,
        Customer_Code              nvarchar(30)       NOT NULL,
        Customer_Name              nvarchar(150)      NOT NULL,
        Customer_Type              nvarchar(30)       NOT NULL,
        Customer_Status            nvarchar(30)       NOT NULL,
        Status_Reason              nvarchar(250)      NULL,
        Status_Effective_Date      date               NULL,
        Business_Type              nvarchar(50)       NULL,
        Industry                   nvarchar(100)      NULL,
        Customer_Size              nvarchar(30)       NULL,
        Employee_Count             int                NULL,
        Annual_Revenue             decimal(18,2)      NULL,
        Contact_Person_Name        nvarchar(150)      NULL,
        Phone                      nvarchar(20)       NULL,
        Mobile                     nvarchar(20)       NULL,
        Email                      nvarchar(254)      NULL,
        Preferred_Contact_Channel  nvarchar(30)       NULL,
        Address                    nvarchar(500)      NULL,
        Postal_Code                nvarchar(20)       NULL,
        Latitude                   decimal(9,6)       NULL,
        Longitude                  decimal(9,6)       NULL,
        Registration_Date          date               NULL,
        Credit_Limit               decimal(18,2)      NULL,
        Credit_Status              nvarchar(30)       NULL,
        Credit_Review_Date         date               NULL,
        Last_Update_Date           date               NULL,
        CONSTRAINT PK_Customer PRIMARY KEY CLUSTERED (Customer_ID)
    );
    PRINT N'Created table core.Customer.';
END
ELSE
    PRINT N'Table core.Customer already exists - skipped.';
GO

/* ========================================================================
   Schema [sales] - Sales transactions and planning (depend on core, ref and Team 2 keys)
   ======================================================================== */

-- sales.Lead  <-  Stage 6 entity "Lead"
IF OBJECT_ID(N'sales.Lead', N'U') IS NULL
BEGIN
    CREATE TABLE sales.Lead
    (
        Lead_ID          int IDENTITY(1,1)  NOT NULL,
        Salesperson_ID   int                NULL,
        Lead_Code        nvarchar(30)       NULL,
        Lead_Name        nvarchar(150)      NOT NULL,
        Lead_Source      nvarchar(100)      NOT NULL,
        Lead_Status      nvarchar(30)       NOT NULL,
        Lead_Score       decimal(5,2)       NULL,
        Expected_Value   decimal(18,2)      NULL,
        Created_Date     date               NOT NULL,
        Conversion_Date  date               NULL,
        CONSTRAINT PK_Lead PRIMARY KEY CLUSTERED (Lead_ID)
    );
    PRINT N'Created table sales.Lead.';
END
ELSE
    PRINT N'Table sales.Lead already exists - skipped.';
GO

-- sales.CustomerInteraction  <-  Stage 6 entity "Customer Interaction"
IF OBJECT_ID(N'sales.CustomerInteraction', N'U') IS NULL
BEGIN
    CREATE TABLE sales.CustomerInteraction
    (
        Customer_Interaction_ID       int IDENTITY(1,1)  NOT NULL,
        Customer_ID                   int                NOT NULL,
        Salesperson_ID                int                NULL,
        Sales_Territory_ID            int                NULL,
        Interaction_Type              nvarchar(30)       NOT NULL,
        Interaction_DateTime          datetime2(0)       NOT NULL,
        Interaction_Channel           nvarchar(30)       NULL,
        Interaction_Subject           nvarchar(200)      NULL,
        Interaction_Purpose           nvarchar(250)      NULL,
        Interaction_Status            nvarchar(30)       NULL,
        Interaction_Result            nvarchar(250)      NULL,
        Interaction_Duration_Minutes  int                NULL,
        Participants_Count            int                NULL,
        Follow_Up_Required            bit                NULL,
        Follow_Up_Date                date               NULL,
        Interaction_Notes             nvarchar(2000)     NULL,
        CONSTRAINT PK_CustomerInteraction PRIMARY KEY CLUSTERED (Customer_Interaction_ID)
    );
    PRINT N'Created table sales.CustomerInteraction.';
END
ELSE
    PRINT N'Table sales.CustomerInteraction already exists - skipped.';
GO

-- sales.SalesOpportunity  <-  Stage 6 entity "Sales Opportunity"
IF OBJECT_ID(N'sales.SalesOpportunity', N'U') IS NULL
BEGIN
    CREATE TABLE sales.SalesOpportunity
    (
        Sales_Opportunity_ID      int IDENTITY(1,1)  NOT NULL,
        Customer_ID               int                NULL,
        Lead_ID                   int                NULL,
        Salesperson_ID            int                NOT NULL,
        Opportunity_Code          nvarchar(30)       NOT NULL,
        Opportunity_Name          nvarchar(150)      NOT NULL,
        Opportunity_Stage         nvarchar(30)       NOT NULL,
        Opportunity_Status        nvarchar(30)       NOT NULL,
        Opportunity_Type          nvarchar(30)       NULL,
        Opportunity_Date          date               NOT NULL,
        Expected_Close_Date       date               NULL,
        Probability               decimal(5,2)       NULL,
        Expected_Value            decimal(18,2)      NULL,
        Opportunity_Source        nvarchar(100)      NULL,
        Description               nvarchar(1000)     NULL,
        Proposal_Number           nvarchar(30)       NULL,
        Proposal_Date             date               NULL,
        Proposal_Status           nvarchar(30)       NULL,
        Proposal_Valid_From       date               NULL,
        Proposal_Valid_To         date               NULL,
        Proposed_Price            decimal(18,2)      NULL,
        Proposal_Discount_Amount  decimal(18,2)      NULL,
        Proposal_Payment_Terms    nvarchar(250)      NULL,
        Proposal_Delivery_Terms   nvarchar(250)      NULL,
        CONSTRAINT PK_SalesOpportunity PRIMARY KEY CLUSTERED (Sales_Opportunity_ID)
    );
    PRINT N'Created table sales.SalesOpportunity.';
END
ELSE
    PRINT N'Table sales.SalesOpportunity already exists - skipped.';
GO

-- sales.Contract  <-  Stage 6 entity "Contract"
IF OBJECT_ID(N'sales.Contract', N'U') IS NULL
BEGIN
    CREATE TABLE sales.Contract
    (
        Contract_ID           int IDENTITY(1,1)  NOT NULL,
        Customer_ID           int                NOT NULL,
        Sales_Opportunity_ID  int                NULL,
        Product_ID            int                NULL,
        Contract_Number       nvarchar(30)       NOT NULL,
        Contract_Type         nvarchar(30)       NOT NULL,
        Contract_Status       nvarchar(30)       NOT NULL,
        Start_Date            date               NOT NULL,
        End_Date              date               NOT NULL,
        Closed_Date           date               NULL,
        Contract_Amount       decimal(18,2)      NOT NULL,
        Currency_Code         char(3)            NULL,
        Payment_Terms         nvarchar(250)      NOT NULL,
        Delivery_Terms        nvarchar(250)      NULL,
        Contract_Conditions   nvarchar(2000)     NULL,
        Item_Quantity         decimal(18,3)      NULL,
        Item_Unit_Price       decimal(18,2)      NULL,
        Item_Unit_of_Measure  nvarchar(20)       NULL,
        CONSTRAINT PK_Contract PRIMARY KEY CLUSTERED (Contract_ID)
    );
    PRINT N'Created table sales.Contract.';
END
ELSE
    PRINT N'Table sales.Contract already exists - skipped.';
GO

-- sales.SalesOrder  <-  Stage 6 entity "Sales Order"
IF OBJECT_ID(N'sales.SalesOrder', N'U') IS NULL
BEGIN
    CREATE TABLE sales.SalesOrder
    (
        Sales_Order_ID           int IDENTITY(1,1)  NOT NULL,
        Customer_ID              int                NOT NULL,
        Salesperson_ID           int                NULL,
        Sales_Channel_ID         int                NOT NULL,
        Sales_Region_ID          int                NULL,
        Promotion_ID             int                NULL,
        Contract_ID              int                NULL,
        Customer_Interaction_ID  int                NULL,
        Calendar_ID              int                NOT NULL,
        Sales_Order_Number       nvarchar(30)       NOT NULL,
        Order_Status             nvarchar(30)       NOT NULL,
        Total_Amount             decimal(18,2)      NOT NULL,
        Discount_Amount          decimal(18,2)      NULL,
        Payment_Terms            nvarchar(250)      NULL,
        Delivery_Date            date               NULL,
        CONSTRAINT PK_SalesOrder PRIMARY KEY CLUSTERED (Sales_Order_ID)
    );
    PRINT N'Created table sales.SalesOrder.';
END
ELSE
    PRINT N'Table sales.SalesOrder already exists - skipped.';
GO

-- sales.SalesOrderItem  <-  Stage 6 entity "Sales Order Item"
IF OBJECT_ID(N'sales.SalesOrderItem', N'U') IS NULL
BEGIN
    CREATE TABLE sales.SalesOrderItem
    (
        Sales_Order_Item_ID  int IDENTITY(1,1)  NOT NULL,
        Sales_Order_ID       int                NOT NULL,
        Product_ID           int                NOT NULL,
        Line_Number          int                NOT NULL,
        Quantity             decimal(18,3)      NOT NULL,
        Unit_of_Measure      nvarchar(20)       NOT NULL,
        Unit_Price           decimal(18,2)      NOT NULL,
        Discount_Amount      decimal(18,2)      NULL,
        Discount_Percentage  decimal(5,2)       NULL,
        Net_Amount           decimal(18,2)      NOT NULL,
        Item_Status          nvarchar(30)       NOT NULL,
        CONSTRAINT PK_SalesOrderItem PRIMARY KEY CLUSTERED (Sales_Order_Item_ID)
    );
    PRINT N'Created table sales.SalesOrderItem.';
END
ELSE
    PRINT N'Table sales.SalesOrderItem already exists - skipped.';
GO

-- sales.Invoice  <-  Stage 6 entity "Invoice"
IF OBJECT_ID(N'sales.Invoice', N'U') IS NULL
BEGIN
    CREATE TABLE sales.Invoice
    (
        Invoice_ID       int IDENTITY(1,1)  NOT NULL,
        Customer_ID      int                NOT NULL,
        Sales_Order_ID   int                NOT NULL,
        Invoice_Number   nvarchar(30)       NOT NULL,
        Invoice_Date     date               NOT NULL,
        Invoice_Type     nvarchar(30)       NULL,
        Due_Date         date               NULL,
        Invoice_Status   nvarchar(30)       NOT NULL,
        Subtotal         decimal(18,2)      NOT NULL,
        Discount_Amount  decimal(18,2)      NULL,
        Tax_Amount       decimal(18,2)      NULL,
        Total_Amount     decimal(18,2)      NOT NULL,
        CONSTRAINT PK_Invoice PRIMARY KEY CLUSTERED (Invoice_ID)
    );
    PRINT N'Created table sales.Invoice.';
END
ELSE
    PRINT N'Table sales.Invoice already exists - skipped.';
GO

-- sales.InvoiceItem  <-  Stage 6 entity "Invoice Item"
IF OBJECT_ID(N'sales.InvoiceItem', N'U') IS NULL
BEGIN
    CREATE TABLE sales.InvoiceItem
    (
        Invoice_Item_ID  int IDENTITY(1,1)  NOT NULL,
        Invoice_ID       int                NOT NULL,
        Product_ID       int                NOT NULL,
        Quantity         decimal(18,3)      NOT NULL,
        Unit_of_Measure  nvarchar(20)       NULL,
        Unit_Price       decimal(18,2)      NOT NULL,
        Discount_Amount  decimal(18,2)      NULL,
        Tax_Amount       decimal(18,2)      NULL,
        Net_Amount       decimal(18,2)      NOT NULL,
        Final_Amount     decimal(18,2)      NOT NULL,
        CONSTRAINT PK_InvoiceItem PRIMARY KEY CLUSTERED (Invoice_Item_ID)
    );
    PRINT N'Created table sales.InvoiceItem.';
END
ELSE
    PRINT N'Table sales.InvoiceItem already exists - skipped.';
GO

-- sales.Payment  <-  Stage 6 entity "Payment"
IF OBJECT_ID(N'sales.Payment', N'U') IS NULL
BEGIN
    CREATE TABLE sales.Payment
    (
        Payment_ID             int IDENTITY(1,1)  NOT NULL,
        Customer_ID            int                NOT NULL,
        Invoice_ID             int                NULL,
        Sales_Order_ID         int                NULL,
        Payment_Date           date               NOT NULL,
        Amount                 decimal(18,2)      NOT NULL,
        Payment_Method         nvarchar(30)       NOT NULL,
        Payment_Status         nvarchar(30)       NOT NULL,
        Transaction_Reference  nvarchar(100)      NULL,
        Received_By            nvarchar(150)      NULL,
        CONSTRAINT PK_Payment PRIMARY KEY CLUSTERED (Payment_ID)
    );
    PRINT N'Created table sales.Payment.';
END
ELSE
    PRINT N'Table sales.Payment already exists - skipped.';
GO

-- sales.ReturnRequest  <-  Stage 6 entity "Return Request"
IF OBJECT_ID(N'sales.ReturnRequest', N'U') IS NULL
BEGIN
    CREATE TABLE sales.ReturnRequest
    (
        Return_Request_ID      int IDENTITY(1,1)  NOT NULL,
        Sales_Order_Item_ID    int                NOT NULL,
        Payment_ID             int                NULL,
        Calendar_ID            int                NOT NULL,
        Return_Reason          nvarchar(250)      NOT NULL,
        Return_Description     nvarchar(1000)     NULL,
        Return_Status          nvarchar(30)       NOT NULL,
        Requested_Quantity     decimal(18,3)      NOT NULL,
        Approved_Quantity      decimal(18,3)      NULL,
        Review_Date            date               NULL,
        Reviewer_Comment       nvarchar(1000)     NULL,
        Return_Shipping_Cost   decimal(18,2)      NULL,
        Refund_Amount          decimal(18,2)      NULL,
        Refund_Date            date               NULL,
        Refund_Status          nvarchar(30)       NULL,
        Refund_Method          nvarchar(30)       NULL,
        Refund_Tracking_Code   nvarchar(100)      NULL,
        Refund_Failure_Reason  nvarchar(250)      NULL,
        CONSTRAINT PK_ReturnRequest PRIMARY KEY CLUSTERED (Return_Request_ID)
    );
    PRINT N'Created table sales.ReturnRequest.';
END
ELSE
    PRINT N'Table sales.ReturnRequest already exists - skipped.';
GO

-- sales.CustomerFeedback  <-  Stage 6 entity "Customer Feedback"
IF OBJECT_ID(N'sales.CustomerFeedback', N'U') IS NULL
BEGIN
    CREATE TABLE sales.CustomerFeedback
    (
        Customer_Feedback_ID     int IDENTITY(1,1)  NOT NULL,
        Customer_ID              int                NOT NULL,
        Customer_Interaction_ID  int                NULL,
        Sales_Order_ID           int                NULL,
        Product_ID               int                NULL,
        Feedback_Type            nvarchar(30)       NOT NULL,
        Feedback_Date            date               NOT NULL,
        Feedback_Channel         nvarchar(30)       NULL,
        Feedback_Category        nvarchar(100)      NULL,
        Feedback_Text            nvarchar(2000)     NULL,
        Rating                   decimal(4,2)       NULL,
        Priority                 nvarchar(30)       NULL,
        Feedback_Status          nvarchar(30)       NULL,
        Resolution_Date          date               NULL,
        SLA_Status               nvarchar(30)       NULL,
        Feedback_Result          nvarchar(250)      NULL,
        Moderation_Comment       nvarchar(1000)     NULL,
        CONSTRAINT PK_CustomerFeedback PRIMARY KEY CLUSTERED (Customer_Feedback_ID)
    );
    PRINT N'Created table sales.CustomerFeedback.';
END
ELSE
    PRINT N'Table sales.CustomerFeedback already exists - skipped.';
GO

-- sales.Commission  <-  Stage 6 entity "Commission"
IF OBJECT_ID(N'sales.Commission', N'U') IS NULL
BEGIN
    CREATE TABLE sales.Commission
    (
        Commission_ID           int IDENTITY(1,1)  NOT NULL,
        Salesperson_ID          int                NOT NULL,
        Calendar_ID             int                NOT NULL,
        Commission_Base_Amount  decimal(18,2)      NOT NULL,
        Commission_Rate         decimal(5,2)       NOT NULL,
        Commission_Amount       decimal(18,2)      NOT NULL,
        CONSTRAINT PK_Commission PRIMARY KEY CLUSTERED (Commission_ID)
    );
    PRINT N'Created table sales.Commission.';
END
ELSE
    PRINT N'Table sales.Commission already exists - skipped.';
GO

-- sales.SalesTarget  <-  Stage 6 entity "Sales Target"
IF OBJECT_ID(N'sales.SalesTarget', N'U') IS NULL
BEGIN
    CREATE TABLE sales.SalesTarget
    (
        Sales_Target_ID   int IDENTITY(1,1)  NOT NULL,
        Calendar_ID       int                NOT NULL,
        Sales_Region_ID   int                NULL,
        Salesperson_ID    int                NULL,
        Sales_Channel_ID  int                NULL,
        Product_ID        int                NULL,
        Target_Level      nvarchar(30)       NOT NULL,
        Plan_Title        nvarchar(200)      NULL,
        Fiscal_Year       int                NULL,
        Target_Value      decimal(18,2)      NULL,
        Target_Quantity   decimal(18,3)      NULL,
        Currency_Code     char(3)            NULL,
        Target_Version    int                NOT NULL,
        Target_Status     nvarchar(30)       NOT NULL,
        CONSTRAINT PK_SalesTarget PRIMARY KEY CLUSTERED (Sales_Target_ID)
    );
    PRINT N'Created table sales.SalesTarget.';
END
ELSE
    PRINT N'Table sales.SalesTarget already exists - skipped.';
GO

-- sales.SalesForecast  <-  Stage 6 entity "Sales Forecast"
IF OBJECT_ID(N'sales.SalesForecast', N'U') IS NULL
BEGIN
    CREATE TABLE sales.SalesForecast
    (
        Sales_Forecast_ID          int IDENTITY(1,1)  NOT NULL,
        Calendar_ID                int                NOT NULL,
        Forecast_Amount            decimal(18,2)      NOT NULL,
        Forecast_Version           int                NOT NULL,
        Forecast_Accuracy_Percent  decimal(5,2)       NULL,
        CONSTRAINT PK_SalesForecast PRIMARY KEY CLUSTERED (Sales_Forecast_ID)
    );
    PRINT N'Created table sales.SalesForecast.';
END
ELSE
    PRINT N'Table sales.SalesForecast already exists - skipped.';
GO

/* ---- Summary of Team 1 objects ---- */
DECLARE @t TABLE (object_id int PRIMARY KEY);
INSERT @t (object_id)
SELECT OBJECT_ID(n) FROM (VALUES (N'ref.Province'), (N'ref.City'), (N'ref.CustomerSegment'), (N'ref.SalesChannel'), (N'ref.SalesRegion'), (N'ref.SalesTerritory'), (N'core.Calendar'), (N'core.Branch'), (N'core.Salesperson'), (N'core.Customer'), (N'sales.Lead'), (N'sales.CustomerInteraction'), (N'sales.SalesOpportunity'), (N'sales.Contract'), (N'sales.SalesOrder'), (N'sales.SalesOrderItem'), (N'sales.Invoice'), (N'sales.InvoiceItem'), (N'sales.Payment'), (N'sales.ReturnRequest'), (N'sales.CustomerFeedback'), (N'sales.Commission'), (N'sales.SalesTarget'), (N'sales.SalesForecast')) v(n) WHERE OBJECT_ID(n) IS NOT NULL;
DECLARE @msg nvarchar(600) = CONCAT(
    N'Team 1 objects now in FoodDistributionDB: tables ', (SELECT COUNT(*) FROM @t),
    N', columns ', (SELECT COUNT(*) FROM sys.columns c JOIN @t t ON t.object_id = c.object_id),
    N', PK ', (SELECT COUNT(*) FROM sys.key_constraints k JOIN @t t ON t.object_id = k.parent_object_id WHERE k.type = 'PK'),
    N', UNIQUE ', (SELECT COUNT(*) FROM sys.key_constraints k JOIN @t t ON t.object_id = k.parent_object_id WHERE k.type = 'UQ')
                + (SELECT COUNT(*) FROM sys.indexes i JOIN @t t ON t.object_id = i.object_id WHERE i.is_unique = 1 AND i.has_filter = 1),
    N', CHECK ', (SELECT COUNT(*) FROM sys.check_constraints k JOIN @t t ON t.object_id = k.parent_object_id),
    N', DEFAULT ', (SELECT COUNT(*) FROM sys.default_constraints k JOIN @t t ON t.object_id = k.parent_object_id),
    N', FK ', (SELECT COUNT(*) FROM sys.foreign_keys k JOIN @t t ON t.object_id = k.parent_object_id),
    N', indexes ', (SELECT COUNT(*) FROM sys.indexes i JOIN @t t ON t.object_id = i.object_id WHERE i.type = 2 AND i.is_unique = 0),
    N'.');
PRINT @msg;
GO

SET NOEXEC OFF;
GO
PRINT N'07-Team1-01-Create-Tables.sql finished.';
GO
