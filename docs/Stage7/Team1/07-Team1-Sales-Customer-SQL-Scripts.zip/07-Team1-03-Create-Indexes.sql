﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 1 - Sales & Customer
    Database: FoodDistributionDB
    SQL Server: 2022
    File    : 07-Team1-03-Create-Indexes.sql
    Purpose : Nonclustered indexes that support FOREIGN KEY joins and FK checks on delete of the parent row.
    Run order: 3 (after 07-Team1-02-Create-Constraints.sql)
    Prerequisites: All 24 Team 1 tables exist (07-Team1-01-Create-Tables.sql).
    Source  : 06-Team1-Sales-Customer-Logical-Data-Model.xlsx (Stage 6)
    Schemas : Team 1 proposal for the Entity-to-Schema matrix (ref / core / sales); not yet approved
    Re-run  : Safe. Every object is created only if it does not already exist.
*/

USE [FoodDistributionDB];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

/* ---- Prerequisite check: stop the whole script if a prerequisite is missing ---- */
IF OBJECT_ID(N'ref.Province', N'U') IS NULL
   OR OBJECT_ID(N'ref.City', N'U') IS NULL
   OR OBJECT_ID(N'ref.CustomerSegment', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesChannel', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesRegion', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesTerritory', N'U') IS NULL
   OR OBJECT_ID(N'core.Calendar', N'U') IS NULL
   OR OBJECT_ID(N'core.Branch', N'U') IS NULL
   OR OBJECT_ID(N'core.Salesperson', N'U') IS NULL
   OR OBJECT_ID(N'core.Customer', N'U') IS NULL
   OR OBJECT_ID(N'sales.Lead', N'U') IS NULL
   OR OBJECT_ID(N'sales.CustomerInteraction', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOpportunity', N'U') IS NULL
   OR OBJECT_ID(N'sales.Contract', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOrder', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOrderItem', N'U') IS NULL
   OR OBJECT_ID(N'sales.Invoice', N'U') IS NULL
   OR OBJECT_ID(N'sales.InvoiceItem', N'U') IS NULL
   OR OBJECT_ID(N'sales.Payment', N'U') IS NULL
   OR OBJECT_ID(N'sales.ReturnRequest', N'U') IS NULL
   OR OBJECT_ID(N'sales.CustomerFeedback', N'U') IS NULL
   OR OBJECT_ID(N'sales.Commission', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesTarget', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesForecast', N'U') IS NULL
BEGIN
    RAISERROR(N'Team 1 tables are missing. Run 07-Team1-01-Create-Tables.sql first.', 16, 1);
    SET NOEXEC ON;
END;
GO

/* ========================================================================
   Nonclustered indexes (one per FK unless the PK or a UNIQUE key already starts with the FK column;
   optional FKs get a filtered index WHERE column IS NOT NULL)
   ======================================================================== */

-- FK_City_Province_Province_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_City_Province_ID' AND object_id = OBJECT_ID(N'ref.City'))
    CREATE NONCLUSTERED INDEX IX_City_Province_ID ON ref.City (Province_ID);
GO

-- FK_City_City_Parent_City_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_City_Parent_City_ID' AND object_id = OBJECT_ID(N'ref.City'))
    CREATE NONCLUSTERED INDEX IX_City_Parent_City_ID ON ref.City (Parent_City_ID) WHERE Parent_City_ID IS NOT NULL;
GO

-- FK_SalesRegion_SalesRegion_Parent_Sales_Region_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesRegion_Parent_Sales_Region_ID' AND object_id = OBJECT_ID(N'ref.SalesRegion'))
    CREATE NONCLUSTERED INDEX IX_SalesRegion_Parent_Sales_Region_ID ON ref.SalesRegion (Parent_Sales_Region_ID) WHERE Parent_Sales_Region_ID IS NOT NULL;
GO

-- FK_Branch_SalesRegion_Sales_Region_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Branch_Sales_Region_ID' AND object_id = OBJECT_ID(N'core.Branch'))
    CREATE NONCLUSTERED INDEX IX_Branch_Sales_Region_ID ON core.Branch (Sales_Region_ID);
GO

-- FK_Salesperson_Branch_Branch_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Salesperson_Branch_ID' AND object_id = OBJECT_ID(N'core.Salesperson'))
    CREATE NONCLUSTERED INDEX IX_Salesperson_Branch_ID ON core.Salesperson (Branch_ID) WHERE Branch_ID IS NOT NULL;
GO

-- FK_Salesperson_Salesperson_Manager_Salesperson_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Salesperson_Manager_Salesperson_ID' AND object_id = OBJECT_ID(N'core.Salesperson'))
    CREATE NONCLUSTERED INDEX IX_Salesperson_Manager_Salesperson_ID ON core.Salesperson (Manager_Salesperson_ID) WHERE Manager_Salesperson_ID IS NOT NULL;
GO

-- FK_Customer_City_City_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Customer_City_ID' AND object_id = OBJECT_ID(N'core.Customer'))
    CREATE NONCLUSTERED INDEX IX_Customer_City_ID ON core.Customer (City_ID) WHERE City_ID IS NOT NULL;
GO

-- FK_Customer_CustomerSegment_Customer_Segment_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Customer_Customer_Segment_ID' AND object_id = OBJECT_ID(N'core.Customer'))
    CREATE NONCLUSTERED INDEX IX_Customer_Customer_Segment_ID ON core.Customer (Customer_Segment_ID) WHERE Customer_Segment_ID IS NOT NULL;
GO

-- FK_Customer_SalesChannel_Sales_Channel_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Customer_Sales_Channel_ID' AND object_id = OBJECT_ID(N'core.Customer'))
    CREATE NONCLUSTERED INDEX IX_Customer_Sales_Channel_ID ON core.Customer (Sales_Channel_ID) WHERE Sales_Channel_ID IS NOT NULL;
GO

-- FK_Customer_SalesTerritory_Sales_Territory_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Customer_Sales_Territory_ID' AND object_id = OBJECT_ID(N'core.Customer'))
    CREATE NONCLUSTERED INDEX IX_Customer_Sales_Territory_ID ON core.Customer (Sales_Territory_ID) WHERE Sales_Territory_ID IS NOT NULL;
GO

-- FK_Customer_Salesperson_Salesperson_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Customer_Salesperson_ID' AND object_id = OBJECT_ID(N'core.Customer'))
    CREATE NONCLUSTERED INDEX IX_Customer_Salesperson_ID ON core.Customer (Salesperson_ID) WHERE Salesperson_ID IS NOT NULL;
GO

-- FK_Lead_Salesperson_Salesperson_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Lead_Salesperson_ID' AND object_id = OBJECT_ID(N'sales.Lead'))
    CREATE NONCLUSTERED INDEX IX_Lead_Salesperson_ID ON sales.Lead (Salesperson_ID) WHERE Salesperson_ID IS NOT NULL;
GO

-- FK_CustomerInteraction_Customer_Customer_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CustomerInteraction_Customer_ID' AND object_id = OBJECT_ID(N'sales.CustomerInteraction'))
    CREATE NONCLUSTERED INDEX IX_CustomerInteraction_Customer_ID ON sales.CustomerInteraction (Customer_ID);
GO

-- FK_CustomerInteraction_Salesperson_Salesperson_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CustomerInteraction_Salesperson_ID' AND object_id = OBJECT_ID(N'sales.CustomerInteraction'))
    CREATE NONCLUSTERED INDEX IX_CustomerInteraction_Salesperson_ID ON sales.CustomerInteraction (Salesperson_ID) WHERE Salesperson_ID IS NOT NULL;
GO

-- FK_CustomerInteraction_SalesTerritory_Sales_Territory_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CustomerInteraction_Sales_Territory_ID' AND object_id = OBJECT_ID(N'sales.CustomerInteraction'))
    CREATE NONCLUSTERED INDEX IX_CustomerInteraction_Sales_Territory_ID ON sales.CustomerInteraction (Sales_Territory_ID) WHERE Sales_Territory_ID IS NOT NULL;
GO

-- FK_SalesOpportunity_Customer_Customer_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOpportunity_Customer_ID' AND object_id = OBJECT_ID(N'sales.SalesOpportunity'))
    CREATE NONCLUSTERED INDEX IX_SalesOpportunity_Customer_ID ON sales.SalesOpportunity (Customer_ID) WHERE Customer_ID IS NOT NULL;
GO

-- FK_SalesOpportunity_Lead_Lead_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOpportunity_Lead_ID' AND object_id = OBJECT_ID(N'sales.SalesOpportunity'))
    CREATE NONCLUSTERED INDEX IX_SalesOpportunity_Lead_ID ON sales.SalesOpportunity (Lead_ID) WHERE Lead_ID IS NOT NULL;
GO

-- FK_SalesOpportunity_Salesperson_Salesperson_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOpportunity_Salesperson_ID' AND object_id = OBJECT_ID(N'sales.SalesOpportunity'))
    CREATE NONCLUSTERED INDEX IX_SalesOpportunity_Salesperson_ID ON sales.SalesOpportunity (Salesperson_ID);
GO

-- FK_Contract_Customer_Customer_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Contract_Customer_ID' AND object_id = OBJECT_ID(N'sales.Contract'))
    CREATE NONCLUSTERED INDEX IX_Contract_Customer_ID ON sales.Contract (Customer_ID);
GO

-- FK_Contract_SalesOpportunity_Sales_Opportunity_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Contract_Sales_Opportunity_ID' AND object_id = OBJECT_ID(N'sales.Contract'))
    CREATE NONCLUSTERED INDEX IX_Contract_Sales_Opportunity_ID ON sales.Contract (Sales_Opportunity_ID) WHERE Sales_Opportunity_ID IS NOT NULL;
GO

-- FK_Contract_Product_Product_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Contract_Product_ID' AND object_id = OBJECT_ID(N'sales.Contract'))
    CREATE NONCLUSTERED INDEX IX_Contract_Product_ID ON sales.Contract (Product_ID) WHERE Product_ID IS NOT NULL;
GO

-- FK_SalesOrder_Customer_Customer_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Customer_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Customer_ID ON sales.SalesOrder (Customer_ID);
GO

-- FK_SalesOrder_Salesperson_Salesperson_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Salesperson_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Salesperson_ID ON sales.SalesOrder (Salesperson_ID) WHERE Salesperson_ID IS NOT NULL;
GO

-- FK_SalesOrder_SalesChannel_Sales_Channel_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Sales_Channel_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Sales_Channel_ID ON sales.SalesOrder (Sales_Channel_ID);
GO

-- FK_SalesOrder_SalesRegion_Sales_Region_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Sales_Region_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Sales_Region_ID ON sales.SalesOrder (Sales_Region_ID) WHERE Sales_Region_ID IS NOT NULL;
GO

-- FK_SalesOrder_Promotion_Promotion_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Promotion_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Promotion_ID ON sales.SalesOrder (Promotion_ID) WHERE Promotion_ID IS NOT NULL;
GO

-- FK_SalesOrder_Contract_Contract_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Contract_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Contract_ID ON sales.SalesOrder (Contract_ID) WHERE Contract_ID IS NOT NULL;
GO

-- FK_SalesOrder_CustomerInteraction_Customer_Interaction_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Customer_Interaction_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Customer_Interaction_ID ON sales.SalesOrder (Customer_Interaction_ID) WHERE Customer_Interaction_ID IS NOT NULL;
GO

-- FK_SalesOrder_Calendar_Calendar_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrder_Calendar_ID' AND object_id = OBJECT_ID(N'sales.SalesOrder'))
    CREATE NONCLUSTERED INDEX IX_SalesOrder_Calendar_ID ON sales.SalesOrder (Calendar_ID);
GO

-- FK_SalesOrderItem_Product_Product_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesOrderItem_Product_ID' AND object_id = OBJECT_ID(N'sales.SalesOrderItem'))
    CREATE NONCLUSTERED INDEX IX_SalesOrderItem_Product_ID ON sales.SalesOrderItem (Product_ID);
GO

-- FK_Invoice_Customer_Customer_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Invoice_Customer_ID' AND object_id = OBJECT_ID(N'sales.Invoice'))
    CREATE NONCLUSTERED INDEX IX_Invoice_Customer_ID ON sales.Invoice (Customer_ID);
GO

-- FK_Invoice_SalesOrder_Sales_Order_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Invoice_Sales_Order_ID' AND object_id = OBJECT_ID(N'sales.Invoice'))
    CREATE NONCLUSTERED INDEX IX_Invoice_Sales_Order_ID ON sales.Invoice (Sales_Order_ID);
GO

-- FK_InvoiceItem_Invoice_Invoice_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_InvoiceItem_Invoice_ID' AND object_id = OBJECT_ID(N'sales.InvoiceItem'))
    CREATE NONCLUSTERED INDEX IX_InvoiceItem_Invoice_ID ON sales.InvoiceItem (Invoice_ID);
GO

-- FK_InvoiceItem_Product_Product_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_InvoiceItem_Product_ID' AND object_id = OBJECT_ID(N'sales.InvoiceItem'))
    CREATE NONCLUSTERED INDEX IX_InvoiceItem_Product_ID ON sales.InvoiceItem (Product_ID);
GO

-- FK_Payment_Customer_Customer_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Payment_Customer_ID' AND object_id = OBJECT_ID(N'sales.Payment'))
    CREATE NONCLUSTERED INDEX IX_Payment_Customer_ID ON sales.Payment (Customer_ID);
GO

-- FK_Payment_Invoice_Invoice_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Payment_Invoice_ID' AND object_id = OBJECT_ID(N'sales.Payment'))
    CREATE NONCLUSTERED INDEX IX_Payment_Invoice_ID ON sales.Payment (Invoice_ID) WHERE Invoice_ID IS NOT NULL;
GO

-- FK_Payment_SalesOrder_Sales_Order_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Payment_Sales_Order_ID' AND object_id = OBJECT_ID(N'sales.Payment'))
    CREATE NONCLUSTERED INDEX IX_Payment_Sales_Order_ID ON sales.Payment (Sales_Order_ID) WHERE Sales_Order_ID IS NOT NULL;
GO

-- FK_ReturnRequest_SalesOrderItem_Sales_Order_Item_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ReturnRequest_Sales_Order_Item_ID' AND object_id = OBJECT_ID(N'sales.ReturnRequest'))
    CREATE NONCLUSTERED INDEX IX_ReturnRequest_Sales_Order_Item_ID ON sales.ReturnRequest (Sales_Order_Item_ID);
GO

-- FK_ReturnRequest_Payment_Payment_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ReturnRequest_Payment_ID' AND object_id = OBJECT_ID(N'sales.ReturnRequest'))
    CREATE NONCLUSTERED INDEX IX_ReturnRequest_Payment_ID ON sales.ReturnRequest (Payment_ID) WHERE Payment_ID IS NOT NULL;
GO

-- FK_ReturnRequest_Calendar_Calendar_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ReturnRequest_Calendar_ID' AND object_id = OBJECT_ID(N'sales.ReturnRequest'))
    CREATE NONCLUSTERED INDEX IX_ReturnRequest_Calendar_ID ON sales.ReturnRequest (Calendar_ID);
GO

-- FK_CustomerFeedback_Customer_Customer_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CustomerFeedback_Customer_ID' AND object_id = OBJECT_ID(N'sales.CustomerFeedback'))
    CREATE NONCLUSTERED INDEX IX_CustomerFeedback_Customer_ID ON sales.CustomerFeedback (Customer_ID);
GO

-- FK_CustomerFeedback_SalesOrder_Sales_Order_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CustomerFeedback_Sales_Order_ID' AND object_id = OBJECT_ID(N'sales.CustomerFeedback'))
    CREATE NONCLUSTERED INDEX IX_CustomerFeedback_Sales_Order_ID ON sales.CustomerFeedback (Sales_Order_ID) WHERE Sales_Order_ID IS NOT NULL;
GO

-- FK_CustomerFeedback_Product_Product_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CustomerFeedback_Product_ID' AND object_id = OBJECT_ID(N'sales.CustomerFeedback'))
    CREATE NONCLUSTERED INDEX IX_CustomerFeedback_Product_ID ON sales.CustomerFeedback (Product_ID) WHERE Product_ID IS NOT NULL;
GO

-- FK_Commission_Calendar_Calendar_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Commission_Calendar_ID' AND object_id = OBJECT_ID(N'sales.Commission'))
    CREATE NONCLUSTERED INDEX IX_Commission_Calendar_ID ON sales.Commission (Calendar_ID);
GO

-- FK_SalesTarget_Calendar_Calendar_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesTarget_Calendar_ID' AND object_id = OBJECT_ID(N'sales.SalesTarget'))
    CREATE NONCLUSTERED INDEX IX_SalesTarget_Calendar_ID ON sales.SalesTarget (Calendar_ID);
GO

-- FK_SalesTarget_SalesRegion_Sales_Region_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesTarget_Sales_Region_ID' AND object_id = OBJECT_ID(N'sales.SalesTarget'))
    CREATE NONCLUSTERED INDEX IX_SalesTarget_Sales_Region_ID ON sales.SalesTarget (Sales_Region_ID) WHERE Sales_Region_ID IS NOT NULL;
GO

-- FK_SalesTarget_Salesperson_Salesperson_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesTarget_Salesperson_ID' AND object_id = OBJECT_ID(N'sales.SalesTarget'))
    CREATE NONCLUSTERED INDEX IX_SalesTarget_Salesperson_ID ON sales.SalesTarget (Salesperson_ID) WHERE Salesperson_ID IS NOT NULL;
GO

-- FK_SalesTarget_SalesChannel_Sales_Channel_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesTarget_Sales_Channel_ID' AND object_id = OBJECT_ID(N'sales.SalesTarget'))
    CREATE NONCLUSTERED INDEX IX_SalesTarget_Sales_Channel_ID ON sales.SalesTarget (Sales_Channel_ID) WHERE Sales_Channel_ID IS NOT NULL;
GO

-- FK_SalesTarget_Product_Product_ID
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesTarget_Product_ID' AND object_id = OBJECT_ID(N'sales.SalesTarget'))
    CREATE NONCLUSTERED INDEX IX_SalesTarget_Product_ID ON sales.SalesTarget (Product_ID) WHERE Product_ID IS NOT NULL;
GO

/* ---- Summary of Team 1 objects ---- */
DECLARE @t TABLE (object_id int PRIMARY KEY);
INSERT @t (object_id)
SELECT OBJECT_ID(n) FROM (VALUES (N'ref.Province'), (N'ref.City'), (N'ref.CustomerSegment'), (N'ref.SalesChannel'), (N'ref.SalesRegion'), (N'ref.SalesTerritory'), (N'core.Calendar'), (N'core.Branch'), (N'core.Salesperson'), (N'core.Customer'), (N'sales.Lead'), (N'sales.CustomerInteraction'), (N'sales.SalesOpportunity'), (N'sales.Contract'), (N'sales.SalesOrder'), (N'sales.SalesOrderItem'), (N'sales.Invoice'), (N'sales.InvoiceItem'), (N'sales.Payment'), (N'sales.ReturnRequest'), (N'sales.CustomerFeedback'), (N'sales.Commission'), (N'sales.SalesTarget'), (N'sales.SalesForecast')) v(n) WHERE OBJECT_ID(n) IS NOT NULL;
DECLARE @msg nvarchar(600) = CONCAT(
    N'Team 1 objects now in FoodDistributionDB: tables ', (SELECT COUNT(*) FROM @t),
    N', columns ', (SELECT COUNT(*) FROM sys.columns c JOIN @t t ON t.object_id = c.object_id),
    N', PK ', (SELECT COUNT(*) FROM sys.key_constraints k JOIN @t t ON t.object_id = k.parent_object_id WHERE k.type = 'PK'),
    N', UNIQUE ', (SELECT COUNT(*) FROM sys.key_constraints k JOIN @t t ON t.object_id = k.parent_object_id WHERE k.type = 'UQ')
                + (SELECT COUNT(*) FROM sys.indexes i JOIN @t t ON t.object_id = i.object_id WHERE i.is_unique = 1 AND i.has_filter = 1),
    N', CHECK ', (SELECT COUNT(*) FROM sys.check_constraints k JOIN @t t ON t.object_id = k.parent_object_id),
    N', DEFAULT ', (SELECT COUNT(*) FROM sys.default_constraints k JOIN @t t ON t.object_id = k.parent_object_id),
    N', FK ', (SELECT COUNT(*) FROM sys.foreign_keys k JOIN @t t ON t.object_id = k.parent_object_id),
    N', indexes ', (SELECT COUNT(*) FROM sys.indexes i JOIN @t t ON t.object_id = i.object_id WHERE i.type = 2 AND i.is_unique = 0),
    N'.');
PRINT @msg;
GO

SET NOEXEC OFF;
GO
PRINT N'07-Team1-03-Create-Indexes.sql finished.';
GO
