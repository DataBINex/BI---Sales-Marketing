﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 1 - Sales & Customer
    Database: FoodDistributionDB
    SQL Server: 2022
    File    : 07-Team1-04-Test-Validation.sql
    Purpose : OPTIONAL test file: checks the structure created by files 01-03 and tests the constraints with sample data. Test rows are ROLLED BACK.
    Run order: 4 (optional; after 07-Team1-03-Create-Indexes.sql)
    Prerequisites: Files 01, 02 and 03 were run. Team 2 tables are optional: only the tests that really need a Team 2 table are reported as SKIP; all other Team 1 tests always run.
    Source  : 06-Team1-Sales-Customer-Logical-Data-Model.xlsx (Stage 6)
    Schemas : Team 1 proposal for the Entity-to-Schema matrix (ref / core / sales); not yet approved
    Re-run  : Safe. It creates nothing permanent: all sample data is rolled back and identity seeds are restored.
*/

USE [FoodDistributionDB];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

/* ---- Prerequisite check ---- */
IF OBJECT_ID(N'ref.Province', N'U') IS NULL
   OR OBJECT_ID(N'ref.City', N'U') IS NULL
   OR OBJECT_ID(N'ref.CustomerSegment', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesChannel', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesRegion', N'U') IS NULL
   OR OBJECT_ID(N'ref.SalesTerritory', N'U') IS NULL
   OR OBJECT_ID(N'core.Calendar', N'U') IS NULL
   OR OBJECT_ID(N'core.Branch', N'U') IS NULL
   OR OBJECT_ID(N'core.Salesperson', N'U') IS NULL
   OR OBJECT_ID(N'core.Customer', N'U') IS NULL
   OR OBJECT_ID(N'sales.Lead', N'U') IS NULL
   OR OBJECT_ID(N'sales.CustomerInteraction', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOpportunity', N'U') IS NULL
   OR OBJECT_ID(N'sales.Contract', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOrder', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesOrderItem', N'U') IS NULL
   OR OBJECT_ID(N'sales.Invoice', N'U') IS NULL
   OR OBJECT_ID(N'sales.InvoiceItem', N'U') IS NULL
   OR OBJECT_ID(N'sales.Payment', N'U') IS NULL
   OR OBJECT_ID(N'sales.ReturnRequest', N'U') IS NULL
   OR OBJECT_ID(N'sales.CustomerFeedback', N'U') IS NULL
   OR OBJECT_ID(N'sales.Commission', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesTarget', N'U') IS NULL
   OR OBJECT_ID(N'sales.SalesForecast', N'U') IS NULL
BEGIN
    RAISERROR(N'Team 1 tables are missing. Run 07-Team1-01, 02 and 03 first.', 16, 1);
    SET NOEXEC ON;
END;
GO

IF OBJECT_ID(N'tempdb..#Result') IS NOT NULL DROP TABLE #Result;
CREATE TABLE #Result (seq int IDENTITY(1,1) PRIMARY KEY, id nvarchar(10) NOT NULL, ok tinyint NOT NULL, msg nvarchar(500) NOT NULL);
-- ok: 1 = PASS, 0 = FAIL, 2 = SKIP
IF OBJECT_ID(N'tempdb..#Tables') IS NOT NULL DROP TABLE #Tables;
CREATE TABLE #Tables (tbl nvarchar(300) NOT NULL PRIMARY KEY);
INSERT #Tables (tbl) VALUES (N'ref.Province'), (N'ref.City'), (N'ref.CustomerSegment'), (N'ref.SalesChannel'), (N'ref.SalesRegion'), (N'ref.SalesTerritory'), (N'core.Calendar'), (N'core.Branch'), (N'core.Salesperson'), (N'core.Customer'), (N'sales.Lead'), (N'sales.CustomerInteraction'), (N'sales.SalesOpportunity'), (N'sales.Contract'), (N'sales.SalesOrder'), (N'sales.SalesOrderItem'), (N'sales.Invoice'), (N'sales.InvoiceItem'), (N'sales.Payment'), (N'sales.ReturnRequest'), (N'sales.CustomerFeedback'), (N'sales.Commission'), (N'sales.SalesTarget'), (N'sales.SalesForecast');
GO

/* ======================================================================
   PART A - structure checks (catalog views)
   ====================================================================== */
IF OBJECT_ID(N'tempdb..#Design') IS NOT NULL DROP TABLE #Design;
CREATE TABLE #Design (tbl nvarchar(300) NOT NULL, col sysname NOT NULL, typ sysname NOT NULL, len_bytes int NULL, prec int NULL, scale int NULL, is_nullable bit NOT NULL, is_identity bit NOT NULL);
INSERT #Design (tbl, col, typ, len_bytes, prec, scale, is_nullable, is_identity) VALUES
    (N'ref.Province', N'Province_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'ref.Province', N'Province_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.Province', N'Province_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'ref.Province', N'Province_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.City', N'City_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'ref.City', N'Province_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'ref.City', N'Parent_City_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'ref.City', N'City_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.City', N'City_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'ref.City', N'City_Level', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.City', N'City_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'Customer_Segment_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'ref.CustomerSegment', N'Segment_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.CustomerSegment', N'Segment_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'ref.CustomerSegment', N'Segment_Type', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'Segment_Level', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'Segment_Criteria', N'nvarchar', 2000, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'Segment_Description', N'nvarchar', 2000, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'Priority', N'int', NULL, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'Segment_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'Created_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'ref.CustomerSegment', N'End_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'ref.SalesChannel', N'Sales_Channel_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'ref.SalesChannel', N'Sales_Channel_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.SalesChannel', N'Sales_Channel_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'ref.SalesChannel', N'Sales_Channel_Type', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.SalesChannel', N'Channel_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.SalesChannel', N'Campaign_Name', N'nvarchar', 300, NULL, NULL, 1, 0),
    (N'ref.SalesRegion', N'Sales_Region_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'ref.SalesRegion', N'Parent_Sales_Region_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'ref.SalesRegion', N'Sales_Region_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.SalesRegion', N'Sales_Region_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'ref.SalesRegion', N'Region_Level', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'ref.SalesRegion', N'Region_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.SalesTerritory', N'Sales_Territory_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'ref.SalesTerritory', N'Territory_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'ref.SalesTerritory', N'Territory_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'ref.SalesTerritory', N'Territory_Type', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'ref.SalesTerritory', N'Territory_Manager_Name', N'nvarchar', 300, NULL, NULL, 1, 0),
    (N'ref.SalesTerritory', N'Route_Code', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'ref.SalesTerritory', N'Route_Name', N'nvarchar', 300, NULL, NULL, 1, 0),
    (N'ref.SalesTerritory', N'Visit_Frequency', N'int', NULL, NULL, NULL, 1, 0),
    (N'ref.SalesTerritory', N'Territory_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'core.Calendar', N'Calendar_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'core.Calendar', N'Calendar_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'core.Calendar', N'Day_Number', N'int', NULL, NULL, NULL, 0, 0),
    (N'core.Calendar', N'Month_Number', N'int', NULL, NULL, NULL, 0, 0),
    (N'core.Calendar', N'Quarter_Number', N'int', NULL, NULL, NULL, 0, 0),
    (N'core.Calendar', N'Week_Number', N'int', NULL, NULL, NULL, 0, 0),
    (N'core.Calendar', N'Year_Number', N'int', NULL, NULL, NULL, 0, 0),
    (N'core.Branch', N'Branch_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'core.Branch', N'Sales_Region_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'core.Branch', N'Branch_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'core.Branch', N'Branch_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'core.Branch', N'Branch_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'core.Salesperson', N'Salesperson_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'core.Salesperson', N'Branch_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Salesperson', N'Manager_Salesperson_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Salesperson', N'Salesperson_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'core.Salesperson', N'Salesperson_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'core.Salesperson', N'Role', N'nvarchar', 200, NULL, NULL, 0, 0),
    (N'core.Salesperson', N'Employment_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'core.Salesperson', N'Hire_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'core.Salesperson', N'Email', N'nvarchar', 508, NULL, NULL, 1, 0),
    (N'core.Salesperson', N'Phone_Number', N'nvarchar', 40, NULL, NULL, 1, 0),
    (N'core.Customer', N'Customer_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'core.Customer', N'City_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Customer_Segment_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Sales_Channel_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Sales_Territory_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Salesperson_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Customer_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'core.Customer', N'Customer_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'core.Customer', N'Customer_Type', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'core.Customer', N'Customer_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'core.Customer', N'Status_Reason', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'core.Customer', N'Status_Effective_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Business_Type', N'nvarchar', 100, NULL, NULL, 1, 0),
    (N'core.Customer', N'Industry', N'nvarchar', 200, NULL, NULL, 1, 0),
    (N'core.Customer', N'Customer_Size', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'core.Customer', N'Employee_Count', N'int', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Annual_Revenue', N'decimal', NULL, 18, 2, 1, 0),
    (N'core.Customer', N'Contact_Person_Name', N'nvarchar', 300, NULL, NULL, 1, 0),
    (N'core.Customer', N'Phone', N'nvarchar', 40, NULL, NULL, 1, 0),
    (N'core.Customer', N'Mobile', N'nvarchar', 40, NULL, NULL, 1, 0),
    (N'core.Customer', N'Email', N'nvarchar', 508, NULL, NULL, 1, 0),
    (N'core.Customer', N'Preferred_Contact_Channel', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'core.Customer', N'Address', N'nvarchar', 1000, NULL, NULL, 1, 0),
    (N'core.Customer', N'Postal_Code', N'nvarchar', 40, NULL, NULL, 1, 0),
    (N'core.Customer', N'Latitude', N'decimal', NULL, 9, 6, 1, 0),
    (N'core.Customer', N'Longitude', N'decimal', NULL, 9, 6, 1, 0),
    (N'core.Customer', N'Registration_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Credit_Limit', N'decimal', NULL, 18, 2, 1, 0),
    (N'core.Customer', N'Credit_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'core.Customer', N'Credit_Review_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'core.Customer', N'Last_Update_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.Lead', N'Lead_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.Lead', N'Salesperson_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.Lead', N'Lead_Code', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.Lead', N'Lead_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'sales.Lead', N'Lead_Source', N'nvarchar', 200, NULL, NULL, 0, 0),
    (N'sales.Lead', N'Lead_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Lead', N'Lead_Score', N'decimal', NULL, 5, 2, 1, 0),
    (N'sales.Lead', N'Expected_Value', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.Lead', N'Created_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'sales.Lead', N'Conversion_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Customer_Interaction_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.CustomerInteraction', N'Customer_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.CustomerInteraction', N'Salesperson_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Sales_Territory_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Interaction_Type', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.CustomerInteraction', N'Interaction_DateTime', N'datetime2', NULL, NULL, 0, 0, 0),
    (N'sales.CustomerInteraction', N'Interaction_Channel', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Interaction_Subject', N'nvarchar', 400, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Interaction_Purpose', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Interaction_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Interaction_Result', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Interaction_Duration_Minutes', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Participants_Count', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Follow_Up_Required', N'bit', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Follow_Up_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerInteraction', N'Interaction_Notes', N'nvarchar', 4000, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Sales_Opportunity_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.SalesOpportunity', N'Customer_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Lead_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Salesperson_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOpportunity', N'Opportunity_Code', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.SalesOpportunity', N'Opportunity_Name', N'nvarchar', 300, NULL, NULL, 0, 0),
    (N'sales.SalesOpportunity', N'Opportunity_Stage', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.SalesOpportunity', N'Opportunity_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.SalesOpportunity', N'Opportunity_Type', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Opportunity_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOpportunity', N'Expected_Close_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Probability', N'decimal', NULL, 5, 2, 1, 0),
    (N'sales.SalesOpportunity', N'Expected_Value', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.SalesOpportunity', N'Opportunity_Source', N'nvarchar', 200, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Description', N'nvarchar', 2000, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Number', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Valid_From', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Valid_To', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Proposed_Price', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Discount_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Payment_Terms', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.SalesOpportunity', N'Proposal_Delivery_Terms', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.Contract', N'Contract_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.Contract', N'Customer_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.Contract', N'Sales_Opportunity_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.Contract', N'Product_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.Contract', N'Contract_Number', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Contract', N'Contract_Type', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Contract', N'Contract_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Contract', N'Start_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'sales.Contract', N'End_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'sales.Contract', N'Closed_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.Contract', N'Contract_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.Contract', N'Currency_Code', N'char', 3, NULL, NULL, 1, 0),
    (N'sales.Contract', N'Payment_Terms', N'nvarchar', 500, NULL, NULL, 0, 0),
    (N'sales.Contract', N'Delivery_Terms', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.Contract', N'Contract_Conditions', N'nvarchar', 4000, NULL, NULL, 1, 0),
    (N'sales.Contract', N'Item_Quantity', N'decimal', NULL, 18, 3, 1, 0),
    (N'sales.Contract', N'Item_Unit_Price', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.Contract', N'Item_Unit_of_Measure', N'nvarchar', 40, NULL, NULL, 1, 0),
    (N'sales.SalesOrder', N'Sales_Order_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.SalesOrder', N'Customer_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOrder', N'Salesperson_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOrder', N'Sales_Channel_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOrder', N'Sales_Region_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOrder', N'Promotion_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOrder', N'Contract_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOrder', N'Customer_Interaction_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOrder', N'Calendar_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOrder', N'Sales_Order_Number', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.SalesOrder', N'Order_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.SalesOrder', N'Total_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.SalesOrder', N'Discount_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.SalesOrder', N'Payment_Terms', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.SalesOrder', N'Delivery_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesOrderItem', N'Sales_Order_Item_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.SalesOrderItem', N'Sales_Order_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOrderItem', N'Product_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOrderItem', N'Line_Number', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesOrderItem', N'Quantity', N'decimal', NULL, 18, 3, 0, 0),
    (N'sales.SalesOrderItem', N'Unit_of_Measure', N'nvarchar', 40, NULL, NULL, 0, 0),
    (N'sales.SalesOrderItem', N'Unit_Price', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.SalesOrderItem', N'Discount_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.SalesOrderItem', N'Discount_Percentage', N'decimal', NULL, 5, 2, 1, 0),
    (N'sales.SalesOrderItem', N'Net_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.SalesOrderItem', N'Item_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Invoice', N'Invoice_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.Invoice', N'Customer_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.Invoice', N'Sales_Order_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.Invoice', N'Invoice_Number', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Invoice', N'Invoice_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'sales.Invoice', N'Invoice_Type', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.Invoice', N'Due_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.Invoice', N'Invoice_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Invoice', N'Subtotal', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.Invoice', N'Discount_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.Invoice', N'Tax_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.Invoice', N'Total_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.InvoiceItem', N'Invoice_Item_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.InvoiceItem', N'Invoice_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.InvoiceItem', N'Product_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.InvoiceItem', N'Quantity', N'decimal', NULL, 18, 3, 0, 0),
    (N'sales.InvoiceItem', N'Unit_of_Measure', N'nvarchar', 40, NULL, NULL, 1, 0),
    (N'sales.InvoiceItem', N'Unit_Price', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.InvoiceItem', N'Discount_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.InvoiceItem', N'Tax_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.InvoiceItem', N'Net_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.InvoiceItem', N'Final_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.Payment', N'Payment_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.Payment', N'Customer_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.Payment', N'Invoice_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.Payment', N'Sales_Order_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.Payment', N'Payment_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'sales.Payment', N'Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.Payment', N'Payment_Method', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Payment', N'Payment_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.Payment', N'Transaction_Reference', N'nvarchar', 200, NULL, NULL, 1, 0),
    (N'sales.Payment', N'Received_By', N'nvarchar', 300, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Return_Request_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.ReturnRequest', N'Sales_Order_Item_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.ReturnRequest', N'Payment_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Calendar_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.ReturnRequest', N'Return_Reason', N'nvarchar', 500, NULL, NULL, 0, 0),
    (N'sales.ReturnRequest', N'Return_Description', N'nvarchar', 2000, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Return_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.ReturnRequest', N'Requested_Quantity', N'decimal', NULL, 18, 3, 0, 0),
    (N'sales.ReturnRequest', N'Approved_Quantity', N'decimal', NULL, 18, 3, 1, 0),
    (N'sales.ReturnRequest', N'Review_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Reviewer_Comment', N'nvarchar', 2000, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Return_Shipping_Cost', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.ReturnRequest', N'Refund_Amount', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.ReturnRequest', N'Refund_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Refund_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Refund_Method', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Refund_Tracking_Code', N'nvarchar', 200, NULL, NULL, 1, 0),
    (N'sales.ReturnRequest', N'Refund_Failure_Reason', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Customer_Feedback_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.CustomerFeedback', N'Customer_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.CustomerFeedback', N'Customer_Interaction_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Sales_Order_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Product_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Feedback_Type', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.CustomerFeedback', N'Feedback_Date', N'date', NULL, NULL, NULL, 0, 0),
    (N'sales.CustomerFeedback', N'Feedback_Channel', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Feedback_Category', N'nvarchar', 200, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Feedback_Text', N'nvarchar', 4000, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Rating', N'decimal', NULL, 4, 2, 1, 0),
    (N'sales.CustomerFeedback', N'Priority', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Feedback_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Resolution_Date', N'date', NULL, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'SLA_Status', N'nvarchar', 60, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Feedback_Result', N'nvarchar', 500, NULL, NULL, 1, 0),
    (N'sales.CustomerFeedback', N'Moderation_Comment', N'nvarchar', 2000, NULL, NULL, 1, 0),
    (N'sales.Commission', N'Commission_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.Commission', N'Salesperson_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.Commission', N'Calendar_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.Commission', N'Commission_Base_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.Commission', N'Commission_Rate', N'decimal', NULL, 5, 2, 0, 0),
    (N'sales.Commission', N'Commission_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.SalesTarget', N'Sales_Target_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.SalesTarget', N'Calendar_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesTarget', N'Sales_Region_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesTarget', N'Salesperson_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesTarget', N'Sales_Channel_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesTarget', N'Product_ID', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesTarget', N'Target_Level', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.SalesTarget', N'Plan_Title', N'nvarchar', 400, NULL, NULL, 1, 0),
    (N'sales.SalesTarget', N'Fiscal_Year', N'int', NULL, NULL, NULL, 1, 0),
    (N'sales.SalesTarget', N'Target_Value', N'decimal', NULL, 18, 2, 1, 0),
    (N'sales.SalesTarget', N'Target_Quantity', N'decimal', NULL, 18, 3, 1, 0),
    (N'sales.SalesTarget', N'Currency_Code', N'char', 3, NULL, NULL, 1, 0),
    (N'sales.SalesTarget', N'Target_Version', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesTarget', N'Target_Status', N'nvarchar', 60, NULL, NULL, 0, 0),
    (N'sales.SalesForecast', N'Sales_Forecast_ID', N'int', NULL, NULL, NULL, 0, 1),
    (N'sales.SalesForecast', N'Calendar_ID', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesForecast', N'Forecast_Amount', N'decimal', NULL, 18, 2, 0, 0),
    (N'sales.SalesForecast', N'Forecast_Version', N'int', NULL, NULL, NULL, 0, 0),
    (N'sales.SalesForecast', N'Forecast_Accuracy_Percent', N'decimal', NULL, 5, 2, 1, 0);
GO
IF OBJECT_ID(N'tempdb..#ExpCons') IS NOT NULL DROP TABLE #ExpCons;
CREATE TABLE #ExpCons (typ char(2) NOT NULL, name sysname NOT NULL, tbl nvarchar(300) NOT NULL);
INSERT #ExpCons (typ, name, tbl) VALUES
    ('PK', N'PK_Province', N'ref.Province'),
    ('PK', N'PK_City', N'ref.City'),
    ('PK', N'PK_CustomerSegment', N'ref.CustomerSegment'),
    ('PK', N'PK_SalesChannel', N'ref.SalesChannel'),
    ('PK', N'PK_SalesRegion', N'ref.SalesRegion'),
    ('PK', N'PK_SalesTerritory', N'ref.SalesTerritory'),
    ('PK', N'PK_Calendar', N'core.Calendar'),
    ('PK', N'PK_Branch', N'core.Branch'),
    ('PK', N'PK_Salesperson', N'core.Salesperson'),
    ('PK', N'PK_Customer', N'core.Customer'),
    ('PK', N'PK_Lead', N'sales.Lead'),
    ('PK', N'PK_CustomerInteraction', N'sales.CustomerInteraction'),
    ('PK', N'PK_SalesOpportunity', N'sales.SalesOpportunity'),
    ('PK', N'PK_Contract', N'sales.Contract'),
    ('PK', N'PK_SalesOrder', N'sales.SalesOrder'),
    ('PK', N'PK_SalesOrderItem', N'sales.SalesOrderItem'),
    ('PK', N'PK_Invoice', N'sales.Invoice'),
    ('PK', N'PK_InvoiceItem', N'sales.InvoiceItem'),
    ('PK', N'PK_Payment', N'sales.Payment'),
    ('PK', N'PK_ReturnRequest', N'sales.ReturnRequest'),
    ('PK', N'PK_CustomerFeedback', N'sales.CustomerFeedback'),
    ('PK', N'PK_Commission', N'sales.Commission'),
    ('PK', N'PK_SalesTarget', N'sales.SalesTarget'),
    ('PK', N'PK_SalesForecast', N'sales.SalesForecast'),
    ('UQ', N'UQ_Province_Province_Code', N'ref.Province'),
    ('UQ', N'UQ_Province_Province_Name', N'ref.Province'),
    ('UQ', N'UQ_City_City_Code', N'ref.City'),
    ('UQ', N'UQ_CustomerSegment_Segment_Code', N'ref.CustomerSegment'),
    ('UQ', N'UQ_SalesChannel_Sales_Channel_Code', N'ref.SalesChannel'),
    ('UQ', N'UQ_SalesRegion_Sales_Region_Code', N'ref.SalesRegion'),
    ('UQ', N'UQ_SalesTerritory_Territory_Code', N'ref.SalesTerritory'),
    ('UQ', N'UQ_Calendar_Calendar_Date', N'core.Calendar'),
    ('UQ', N'UQ_Branch_Branch_Code', N'core.Branch'),
    ('UQ', N'UQ_Salesperson_Salesperson_Code', N'core.Salesperson'),
    ('UQ', N'UQ_Customer_Customer_Code', N'core.Customer'),
    ('UQ', N'UQ_SalesOpportunity_Opportunity_Code', N'sales.SalesOpportunity'),
    ('UQ', N'UQ_Contract_Contract_Number', N'sales.Contract'),
    ('UQ', N'UQ_SalesOrder_Sales_Order_Number', N'sales.SalesOrder'),
    ('UQ', N'UQ_SalesOrderItem_Sales_Order_ID_Line_Number', N'sales.SalesOrderItem'),
    ('UQ', N'UQ_Invoice_Invoice_Number', N'sales.Invoice'),
    ('UQ', N'UQ_Commission_Salesperson_ID_Calendar_ID', N'sales.Commission'),
    ('UQ', N'UQ_SalesForecast_Calendar_ID_Forecast_Version', N'sales.SalesForecast'),
    ('UQ', N'UQ_SalesTarget_Target_Level_Calendar_ID_Target_Version_Dimensions', N'sales.SalesTarget'),
    ('UQ', N'UQ_SalesOrder_Sales_Order_ID_Customer_ID', N'sales.SalesOrder'),
    ('UQ', N'UQ_Invoice_Invoice_ID_Customer_ID', N'sales.Invoice'),
    ('UQ', N'UQ_Invoice_Invoice_ID_Sales_Order_ID', N'sales.Invoice'),
    ('UQ', N'UQ_CustomerInteraction_Customer_Interaction_ID_Customer_ID', N'sales.CustomerInteraction'),
    ('C', N'CK_City_City_Level', N'ref.City'),
    ('C', N'CK_City_Parent_City_ID', N'ref.City'),
    ('C', N'CK_CustomerSegment_Priority', N'ref.CustomerSegment'),
    ('C', N'CK_CustomerSegment_End_Date', N'ref.CustomerSegment'),
    ('C', N'CK_SalesRegion_Parent_Sales_Region_ID', N'ref.SalesRegion'),
    ('C', N'CK_SalesTerritory_Visit_Frequency', N'ref.SalesTerritory'),
    ('C', N'CK_Calendar_Week_Number', N'core.Calendar'),
    ('C', N'CK_Calendar_Calendar_Date', N'core.Calendar'),
    ('C', N'CK_Salesperson_Manager_Salesperson_ID', N'core.Salesperson'),
    ('C', N'CK_Salesperson_Email', N'core.Salesperson'),
    ('C', N'CK_Customer_Employee_Count', N'core.Customer'),
    ('C', N'CK_Customer_Annual_Revenue', N'core.Customer'),
    ('C', N'CK_Customer_Email', N'core.Customer'),
    ('C', N'CK_Customer_Latitude', N'core.Customer'),
    ('C', N'CK_Customer_Longitude', N'core.Customer'),
    ('C', N'CK_Customer_Credit_Limit', N'core.Customer'),
    ('C', N'CK_Lead_Expected_Value', N'sales.Lead'),
    ('C', N'CK_Lead_Conversion_Date', N'sales.Lead'),
    ('C', N'CK_CustomerInteraction_Interaction_Duration_Minutes', N'sales.CustomerInteraction'),
    ('C', N'CK_CustomerInteraction_Participants_Count', N'sales.CustomerInteraction'),
    ('C', N'CK_CustomerInteraction_Follow_Up_Date', N'sales.CustomerInteraction'),
    ('C', N'CK_SalesOpportunity_Customer_ID_Lead_ID', N'sales.SalesOpportunity'),
    ('C', N'CK_SalesOpportunity_Probability', N'sales.SalesOpportunity'),
    ('C', N'CK_SalesOpportunity_Expected_Value', N'sales.SalesOpportunity'),
    ('C', N'CK_SalesOpportunity_Proposal_Valid_To', N'sales.SalesOpportunity'),
    ('C', N'CK_SalesOpportunity_Proposed_Price', N'sales.SalesOpportunity'),
    ('C', N'CK_SalesOpportunity_Proposal_Discount_Amount', N'sales.SalesOpportunity'),
    ('C', N'CK_Contract_End_Date', N'sales.Contract'),
    ('C', N'CK_Contract_Contract_Amount', N'sales.Contract'),
    ('C', N'CK_Contract_Currency_Code', N'sales.Contract'),
    ('C', N'CK_SalesOrder_Total_Amount', N'sales.SalesOrder'),
    ('C', N'CK_SalesOrder_Discount_Amount', N'sales.SalesOrder'),
    ('C', N'CK_SalesOrderItem_Quantity', N'sales.SalesOrderItem'),
    ('C', N'CK_SalesOrderItem_Unit_Price', N'sales.SalesOrderItem'),
    ('C', N'CK_SalesOrderItem_Discount_Amount', N'sales.SalesOrderItem'),
    ('C', N'CK_SalesOrderItem_Discount_Percentage', N'sales.SalesOrderItem'),
    ('C', N'CK_Invoice_Due_Date', N'sales.Invoice'),
    ('C', N'CK_Invoice_Subtotal', N'sales.Invoice'),
    ('C', N'CK_Invoice_Discount_Amount', N'sales.Invoice'),
    ('C', N'CK_Invoice_Tax_Amount', N'sales.Invoice'),
    ('C', N'CK_Invoice_Total_Amount', N'sales.Invoice'),
    ('C', N'CK_InvoiceItem_Quantity', N'sales.InvoiceItem'),
    ('C', N'CK_InvoiceItem_Unit_Price', N'sales.InvoiceItem'),
    ('C', N'CK_InvoiceItem_Discount_Amount', N'sales.InvoiceItem'),
    ('C', N'CK_InvoiceItem_Tax_Amount', N'sales.InvoiceItem'),
    ('C', N'CK_InvoiceItem_Final_Amount', N'sales.InvoiceItem'),
    ('C', N'CK_Payment_Invoice_ID_Sales_Order_ID', N'sales.Payment'),
    ('C', N'CK_Payment_Amount', N'sales.Payment'),
    ('C', N'CK_ReturnRequest_Requested_Quantity', N'sales.ReturnRequest'),
    ('C', N'CK_ReturnRequest_Approved_Quantity', N'sales.ReturnRequest'),
    ('C', N'CK_ReturnRequest_Return_Shipping_Cost', N'sales.ReturnRequest'),
    ('C', N'CK_ReturnRequest_Refund_Amount', N'sales.ReturnRequest'),
    ('C', N'CK_CustomerFeedback_Resolution_Date', N'sales.CustomerFeedback'),
    ('C', N'CK_Commission_Commission_Base_Amount', N'sales.Commission'),
    ('C', N'CK_Commission_Commission_Rate', N'sales.Commission'),
    ('C', N'CK_SalesTarget_Target_Level', N'sales.SalesTarget'),
    ('C', N'CK_SalesTarget_Target_Level_Dimensions', N'sales.SalesTarget'),
    ('C', N'CK_SalesTarget_Target_Value_Target_Quantity', N'sales.SalesTarget'),
    ('C', N'CK_SalesTarget_Target_Value', N'sales.SalesTarget'),
    ('C', N'CK_SalesTarget_Target_Quantity', N'sales.SalesTarget'),
    ('C', N'CK_SalesTarget_Target_Version', N'sales.SalesTarget'),
    ('C', N'CK_SalesTarget_Currency_Code', N'sales.SalesTarget'),
    ('C', N'CK_SalesForecast_Forecast_Amount', N'sales.SalesForecast'),
    ('C', N'CK_SalesForecast_Forecast_Version', N'sales.SalesForecast'),
    ('C', N'CK_SalesForecast_Forecast_Accuracy_Percent', N'sales.SalesForecast'),
    ('D', N'DF_SalesTarget_Target_Version', N'sales.SalesTarget'),
    ('D', N'DF_SalesForecast_Forecast_Version', N'sales.SalesForecast');
IF OBJECT_ID(N'tempdb..#ExpIx') IS NOT NULL DROP TABLE #ExpIx;
CREATE TABLE #ExpIx (name sysname NOT NULL, tbl nvarchar(300) NOT NULL);
INSERT #ExpIx (name, tbl) VALUES
    (N'IX_City_Province_ID', N'ref.City'),
    (N'IX_City_Parent_City_ID', N'ref.City'),
    (N'IX_SalesRegion_Parent_Sales_Region_ID', N'ref.SalesRegion'),
    (N'IX_Branch_Sales_Region_ID', N'core.Branch'),
    (N'IX_Salesperson_Branch_ID', N'core.Salesperson'),
    (N'IX_Salesperson_Manager_Salesperson_ID', N'core.Salesperson'),
    (N'IX_Customer_City_ID', N'core.Customer'),
    (N'IX_Customer_Customer_Segment_ID', N'core.Customer'),
    (N'IX_Customer_Sales_Channel_ID', N'core.Customer'),
    (N'IX_Customer_Sales_Territory_ID', N'core.Customer'),
    (N'IX_Customer_Salesperson_ID', N'core.Customer'),
    (N'IX_Lead_Salesperson_ID', N'sales.Lead'),
    (N'IX_CustomerInteraction_Customer_ID', N'sales.CustomerInteraction'),
    (N'IX_CustomerInteraction_Salesperson_ID', N'sales.CustomerInteraction'),
    (N'IX_CustomerInteraction_Sales_Territory_ID', N'sales.CustomerInteraction'),
    (N'IX_SalesOpportunity_Customer_ID', N'sales.SalesOpportunity'),
    (N'IX_SalesOpportunity_Lead_ID', N'sales.SalesOpportunity'),
    (N'IX_SalesOpportunity_Salesperson_ID', N'sales.SalesOpportunity'),
    (N'IX_Contract_Customer_ID', N'sales.Contract'),
    (N'IX_Contract_Sales_Opportunity_ID', N'sales.Contract'),
    (N'IX_Contract_Product_ID', N'sales.Contract'),
    (N'IX_SalesOrder_Customer_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrder_Salesperson_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrder_Sales_Channel_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrder_Sales_Region_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrder_Promotion_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrder_Contract_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrder_Customer_Interaction_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrder_Calendar_ID', N'sales.SalesOrder'),
    (N'IX_SalesOrderItem_Product_ID', N'sales.SalesOrderItem'),
    (N'IX_Invoice_Customer_ID', N'sales.Invoice'),
    (N'IX_Invoice_Sales_Order_ID', N'sales.Invoice'),
    (N'IX_InvoiceItem_Invoice_ID', N'sales.InvoiceItem'),
    (N'IX_InvoiceItem_Product_ID', N'sales.InvoiceItem'),
    (N'IX_Payment_Customer_ID', N'sales.Payment'),
    (N'IX_Payment_Invoice_ID', N'sales.Payment'),
    (N'IX_Payment_Sales_Order_ID', N'sales.Payment'),
    (N'IX_ReturnRequest_Sales_Order_Item_ID', N'sales.ReturnRequest'),
    (N'IX_ReturnRequest_Payment_ID', N'sales.ReturnRequest'),
    (N'IX_ReturnRequest_Calendar_ID', N'sales.ReturnRequest'),
    (N'IX_CustomerFeedback_Customer_ID', N'sales.CustomerFeedback'),
    (N'IX_CustomerFeedback_Sales_Order_ID', N'sales.CustomerFeedback'),
    (N'IX_CustomerFeedback_Product_ID', N'sales.CustomerFeedback'),
    (N'IX_Commission_Calendar_ID', N'sales.Commission'),
    (N'IX_SalesTarget_Calendar_ID', N'sales.SalesTarget'),
    (N'IX_SalesTarget_Sales_Region_ID', N'sales.SalesTarget'),
    (N'IX_SalesTarget_Salesperson_ID', N'sales.SalesTarget'),
    (N'IX_SalesTarget_Sales_Channel_ID', N'sales.SalesTarget'),
    (N'IX_SalesTarget_Product_ID', N'sales.SalesTarget'),
    (N'UQ_Lead_Lead_Code', N'sales.Lead'),
    (N'UQ_Payment_Transaction_Reference', N'sales.Payment'),
    (N'UQ_CustomerFeedback_Customer_Interaction_ID', N'sales.CustomerFeedback');
IF OBJECT_ID(N'tempdb..#ExpFk') IS NOT NULL DROP TABLE #ExpFk;
CREATE TABLE #ExpFk (name sysname NOT NULL, tbl nvarchar(300) NOT NULL, ref_tbl nvarchar(300) NOT NULL, is_team2 bit NOT NULL);
INSERT #ExpFk (name, tbl, ref_tbl, is_team2) VALUES
    (N'FK_City_Province_Province_ID', N'ref.City', N'ref.Province', 0),
    (N'FK_City_City_Parent_City_ID', N'ref.City', N'ref.City', 0),
    (N'FK_SalesRegion_SalesRegion_Parent_Sales_Region_ID', N'ref.SalesRegion', N'ref.SalesRegion', 0),
    (N'FK_Branch_SalesRegion_Sales_Region_ID', N'core.Branch', N'ref.SalesRegion', 0),
    (N'FK_Salesperson_Branch_Branch_ID', N'core.Salesperson', N'core.Branch', 0),
    (N'FK_Salesperson_Salesperson_Manager_Salesperson_ID', N'core.Salesperson', N'core.Salesperson', 0),
    (N'FK_Customer_City_City_ID', N'core.Customer', N'ref.City', 0),
    (N'FK_Customer_CustomerSegment_Customer_Segment_ID', N'core.Customer', N'ref.CustomerSegment', 0),
    (N'FK_Customer_SalesChannel_Sales_Channel_ID', N'core.Customer', N'ref.SalesChannel', 0),
    (N'FK_Customer_SalesTerritory_Sales_Territory_ID', N'core.Customer', N'ref.SalesTerritory', 0),
    (N'FK_Customer_Salesperson_Salesperson_ID', N'core.Customer', N'core.Salesperson', 0),
    (N'FK_Lead_Salesperson_Salesperson_ID', N'sales.Lead', N'core.Salesperson', 0),
    (N'FK_CustomerInteraction_Customer_Customer_ID', N'sales.CustomerInteraction', N'core.Customer', 0),
    (N'FK_CustomerInteraction_Salesperson_Salesperson_ID', N'sales.CustomerInteraction', N'core.Salesperson', 0),
    (N'FK_CustomerInteraction_SalesTerritory_Sales_Territory_ID', N'sales.CustomerInteraction', N'ref.SalesTerritory', 0),
    (N'FK_SalesOpportunity_Customer_Customer_ID', N'sales.SalesOpportunity', N'core.Customer', 0),
    (N'FK_SalesOpportunity_Lead_Lead_ID', N'sales.SalesOpportunity', N'sales.Lead', 0),
    (N'FK_SalesOpportunity_Salesperson_Salesperson_ID', N'sales.SalesOpportunity', N'core.Salesperson', 0),
    (N'FK_Contract_Customer_Customer_ID', N'sales.Contract', N'core.Customer', 0),
    (N'FK_Contract_SalesOpportunity_Sales_Opportunity_ID', N'sales.Contract', N'sales.SalesOpportunity', 0),
    (N'FK_Contract_Product_Product_ID', N'sales.Contract', N'core.Product', 1),
    (N'FK_SalesOrder_Customer_Customer_ID', N'sales.SalesOrder', N'core.Customer', 0),
    (N'FK_SalesOrder_Salesperson_Salesperson_ID', N'sales.SalesOrder', N'core.Salesperson', 0),
    (N'FK_SalesOrder_SalesChannel_Sales_Channel_ID', N'sales.SalesOrder', N'ref.SalesChannel', 0),
    (N'FK_SalesOrder_SalesRegion_Sales_Region_ID', N'sales.SalesOrder', N'ref.SalesRegion', 0),
    (N'FK_SalesOrder_Promotion_Promotion_ID', N'sales.SalesOrder', N'marketing.Promotion', 1),
    (N'FK_SalesOrder_Contract_Contract_ID', N'sales.SalesOrder', N'sales.Contract', 0),
    (N'FK_SalesOrder_CustomerInteraction_Customer_Interaction_ID', N'sales.SalesOrder', N'sales.CustomerInteraction', 0),
    (N'FK_SalesOrder_Calendar_Calendar_ID', N'sales.SalesOrder', N'core.Calendar', 0),
    (N'FK_SalesOrderItem_SalesOrder_Sales_Order_ID', N'sales.SalesOrderItem', N'sales.SalesOrder', 0),
    (N'FK_SalesOrderItem_Product_Product_ID', N'sales.SalesOrderItem', N'core.Product', 1),
    (N'FK_Invoice_Customer_Customer_ID', N'sales.Invoice', N'core.Customer', 0),
    (N'FK_Invoice_SalesOrder_Sales_Order_ID', N'sales.Invoice', N'sales.SalesOrder', 0),
    (N'FK_InvoiceItem_Invoice_Invoice_ID', N'sales.InvoiceItem', N'sales.Invoice', 0),
    (N'FK_InvoiceItem_Product_Product_ID', N'sales.InvoiceItem', N'core.Product', 1),
    (N'FK_Payment_Customer_Customer_ID', N'sales.Payment', N'core.Customer', 0),
    (N'FK_Payment_Invoice_Invoice_ID', N'sales.Payment', N'sales.Invoice', 0),
    (N'FK_Payment_SalesOrder_Sales_Order_ID', N'sales.Payment', N'sales.SalesOrder', 0),
    (N'FK_ReturnRequest_SalesOrderItem_Sales_Order_Item_ID', N'sales.ReturnRequest', N'sales.SalesOrderItem', 0),
    (N'FK_ReturnRequest_Payment_Payment_ID', N'sales.ReturnRequest', N'sales.Payment', 0),
    (N'FK_ReturnRequest_Calendar_Calendar_ID', N'sales.ReturnRequest', N'core.Calendar', 0),
    (N'FK_CustomerFeedback_Customer_Customer_ID', N'sales.CustomerFeedback', N'core.Customer', 0),
    (N'FK_CustomerFeedback_CustomerInteraction_Customer_Interaction_ID', N'sales.CustomerFeedback', N'sales.CustomerInteraction', 0),
    (N'FK_CustomerFeedback_SalesOrder_Sales_Order_ID', N'sales.CustomerFeedback', N'sales.SalesOrder', 0),
    (N'FK_CustomerFeedback_Product_Product_ID', N'sales.CustomerFeedback', N'core.Product', 1),
    (N'FK_Commission_Salesperson_Salesperson_ID', N'sales.Commission', N'core.Salesperson', 0),
    (N'FK_Commission_Calendar_Calendar_ID', N'sales.Commission', N'core.Calendar', 0),
    (N'FK_SalesTarget_Calendar_Calendar_ID', N'sales.SalesTarget', N'core.Calendar', 0),
    (N'FK_SalesTarget_SalesRegion_Sales_Region_ID', N'sales.SalesTarget', N'ref.SalesRegion', 0),
    (N'FK_SalesTarget_Salesperson_Salesperson_ID', N'sales.SalesTarget', N'core.Salesperson', 0),
    (N'FK_SalesTarget_SalesChannel_Sales_Channel_ID', N'sales.SalesTarget', N'ref.SalesChannel', 0),
    (N'FK_SalesTarget_Product_Product_ID', N'sales.SalesTarget', N'core.Product', 1),
    (N'FK_SalesForecast_Calendar_Calendar_ID', N'sales.SalesForecast', N'core.Calendar', 0),
    (N'FK_Invoice_SalesOrder_Sales_Order_ID_Customer_ID', N'sales.Invoice', N'sales.SalesOrder', 0),
    (N'FK_Payment_Invoice_Invoice_ID_Customer_ID', N'sales.Payment', N'sales.Invoice', 0),
    (N'FK_Payment_SalesOrder_Sales_Order_ID_Customer_ID', N'sales.Payment', N'sales.SalesOrder', 0),
    (N'FK_Payment_Invoice_Invoice_ID_Sales_Order_ID', N'sales.Payment', N'sales.Invoice', 0),
    (N'FK_CustomerFeedback_SalesOrder_Sales_Order_ID_Customer_ID', N'sales.CustomerFeedback', N'sales.SalesOrder', 0),
    (N'FK_CustomerFeedback_CustomerInteraction_Customer_Interaction_ID_Customer_ID', N'sales.CustomerFeedback', N'sales.CustomerInteraction', 0);
GO

DECLARE @bad int, @n int;

-- A1: all 24 tables exist in the approved schemas
SELECT @bad = COUNT(*) FROM #Tables WHERE OBJECT_ID(tbl, N'U') IS NULL;
INSERT #Result (id, ok, msg) VALUES (N'A1', CASE WHEN @bad = 0 THEN 1 ELSE 0 END,
    CONCAT(N'all 24 tables exist in the approved schemas (missing: ', @bad, N')'));

-- A2: every column matches the design (name, data type, length / precision / scale, NULL, IDENTITY)
;WITH actual AS (
    SELECT s.name + N'.' + o.name AS tbl, c.name AS col, t.name AS typ, c.max_length, c.precision, c.scale, c.is_nullable, c.is_identity
    FROM sys.columns c
    JOIN sys.objects o ON o.object_id = c.object_id AND o.type = 'U'
    JOIN sys.schemas s ON s.schema_id = o.schema_id
    JOIN sys.types t ON t.user_type_id = c.user_type_id
    WHERE s.name + N'.' + o.name IN (SELECT tbl FROM #Tables)
)
SELECT @bad = COUNT(*)
FROM #Design d
FULL JOIN actual a ON a.tbl = d.tbl AND a.col = d.col
WHERE d.tbl IS NULL OR a.col IS NULL
   OR a.typ <> d.typ
   OR a.is_nullable <> d.is_nullable OR a.is_identity <> d.is_identity
   OR (d.typ IN (N'nvarchar', N'char') AND a.max_length <> d.len_bytes)
   OR (d.typ = N'decimal' AND (a.precision <> d.prec OR a.scale <> d.scale))
   OR (d.typ = N'datetime2' AND a.scale <> d.scale);
SELECT @n = COUNT(*) FROM #Design;
INSERT #Result (id, ok, msg) VALUES (N'A2', CASE WHEN @bad = 0 AND @n = 282 THEN 1 ELSE 0 END,
    CONCAT(N'columns checked: ', @n, N' (expected 282); mismatches: ', @bad));

-- A3: PK, UNIQUE, CHECK, DEFAULT constraints and indexes exist with the standard names
SELECT @bad = COUNT(*) FROM #ExpCons e
WHERE NOT EXISTS (SELECT 1 FROM sys.objects o WHERE o.name = e.name AND o.parent_object_id = OBJECT_ID(e.tbl) AND o.type = e.typ);
SELECT @n = COUNT(*) FROM #ExpIx e
WHERE NOT EXISTS (SELECT 1 FROM sys.indexes i WHERE i.name = e.name AND i.object_id = OBJECT_ID(e.tbl));
INSERT #Result (id, ok, msg) VALUES (N'A3', CASE WHEN @bad = 0 AND @n = 0 THEN 1 ELSE 0 END,
    CONCAT((SELECT COUNT(*) FROM #ExpCons), N' constraints and ', (SELECT COUNT(*) FROM #ExpIx), N' indexes expected; missing constraints: ', @bad, N', missing indexes: ', @n));

-- A4: foreign keys exist, point to the right table, are enabled and trusted, NO ACTION on delete / update
--     (the 6 FKs to Team 2 tables are required only when the Team 2 table exists)
SELECT @bad = COUNT(*) FROM #ExpFk e
WHERE (e.is_team2 = 0 OR OBJECT_ID(e.ref_tbl, N'U') IS NOT NULL)
  AND NOT EXISTS (SELECT 1 FROM sys.foreign_keys f
                  WHERE f.name = e.name AND f.parent_object_id = OBJECT_ID(e.tbl) AND f.referenced_object_id = OBJECT_ID(e.ref_tbl)
                    AND f.is_disabled = 0 AND f.is_not_trusted = 0 AND f.delete_referential_action = 0 AND f.update_referential_action = 0);
SELECT @n = COUNT(*) FROM #ExpFk WHERE is_team2 = 1 AND OBJECT_ID(ref_tbl, N'U') IS NULL;
INSERT #Result (id, ok, msg) VALUES (N'A4', CASE WHEN @bad = 0 THEN 1 ELSE 0 END,
    CONCAT((SELECT COUNT(*) FROM #ExpFk), N' foreign keys expected; problems: ', @bad, N'; FKs to Team 2 tables not required yet (Team 2 table absent): ', @n));

-- A5: all CHECK constraints are enabled and trusted
SELECT @bad = COUNT(*) FROM sys.check_constraints k JOIN #Tables t ON k.parent_object_id = OBJECT_ID(t.tbl)
WHERE k.is_disabled = 1 OR k.is_not_trusted = 1;
INSERT #Result (id, ok, msg) VALUES (N'A5', CASE WHEN @bad = 0 THEN 1 ELSE 0 END, CONCAT(N'disabled or untrusted CHECK constraints: ', @bad));

-- A6: every FK column has the same data type as the referenced key
SELECT @bad = COUNT(*)
FROM sys.foreign_key_columns fc
JOIN sys.foreign_keys f ON f.object_id = fc.constraint_object_id
JOIN #Tables t ON f.parent_object_id = OBJECT_ID(t.tbl)
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE pc.system_type_id <> rc.system_type_id OR pc.max_length <> rc.max_length OR pc.precision <> rc.precision OR pc.scale <> rc.scale;
INSERT #Result (id, ok, msg) VALUES (N'A6', CASE WHEN @bad = 0 THEN 1 ELSE 0 END, CONCAT(N'FK columns whose type differs from the referenced key: ', @bad));

-- A7: every table has a primary key
SELECT @bad = COUNT(*) FROM #Tables t
WHERE NOT EXISTS (SELECT 1 FROM sys.key_constraints k WHERE k.type = 'PK' AND k.parent_object_id = OBJECT_ID(t.tbl));
INSERT #Result (id, ok, msg) VALUES (N'A7', CASE WHEN @bad = 0 THEN 1 ELSE 0 END, CONCAT(N'tables without a primary key: ', @bad));
GO

/* ======================================================================
   PART B - constraint tests with sample data (everything is rolled back)
   ====================================================================== */
SET XACT_ABORT OFF;
DECLARE @Prov int, @City int, @District int, @Seg int, @Chan int, @Reg int, @RegChild int, @Terr int, @Cal1 int, @Cal2 int,
        @Branch int, @SP1 int, @SP2 int, @Cust1 int, @Cust2 int, @LeadC int, @Inter1 int, @Inter2 int, @Opp int, @Ctr int,
        @Order1 int, @Order2 int, @Order3 int, @Item1 int, @Inv1 int, @Pay1 int, @Fc1 int, @Tgt1 int,
        @Prod int = 1, @ProdN int, @Promo int = NULL, @ProdOk bit = 1, @Valid bit = 0, @ItemsValid bit = 0,
        @T2Msg nvarchar(300) = NULL, @v int, @nm nvarchar(100);

/* ---- Team 2 values for the sample rows ----
   Only the Team 2 tables that Team 1 has an FK to matter here:
   - FK to core.Product not present (Team 2 table absent)  -> any Product_ID is accepted (@Prod = 1); every test runs.
   - FK present -> an existing core.Product row is used; if there is none, helper rows are created (rolled back at the end).
     If neither is possible, only the tests that need a valid Product_ID are reported as SKIP (message B0); all other tests still run.
   - Promotion_ID is optional: without a usable marketing.Promotion row the sample order simply has no promotion. */
BEGIN TRAN;

IF OBJECT_ID(N'sales.FK_SalesOrderItem_Product_Product_ID') IS NOT NULL
BEGIN
    SET @Prod = NULL;
    BEGIN TRY
        EXEC sp_executesql N'SELECT TOP (1) @p = Product_ID FROM core.Product ORDER BY Product_ID', N'@p int OUTPUT', @p = @Prod OUTPUT;
        IF @Prod IS NULL AND OBJECT_ID(N'ref.ProductCategory', N'U') IS NOT NULL AND OBJECT_ID(N'core.Brand', N'U') IS NOT NULL
            EXEC sp_executesql N'
                DECLARE @cat int, @brand int;
                INSERT ref.ProductCategory (Category_Code, Category_Name, Category_Level, Category_Status) VALUES (N''T1-TEST-CAT'', N''T1 test category'', 1, N''Active'');
                SET @cat = SCOPE_IDENTITY();
                INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N''T1 test brand'', N''T1-TEST-BRD'', N''Own'', N''Active'');
                SET @brand = SCOPE_IDENTITY();
                INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status, Product_Created_Date)
                    VALUES (N''T1-TEST-PRD'', N''T1 test product'', @cat, @brand, N''Physical'', N''EA'', N''Active'', SYSDATETIME());
                SET @p = SCOPE_IDENTITY();',
                N'@p int OUTPUT', @p = @Prod OUTPUT;
    END TRY
    BEGIN CATCH
        SET @Prod = NULL;
        SET @T2Msg = LEFT(ERROR_MESSAGE(), 300);
    END CATCH;
    IF @Prod IS NULL
    BEGIN
        SET @ProdOk = 0;
        INSERT #Result (id, ok, msg) VALUES (N'B0', 2, CONCAT(N'no valid Product_ID available (core.Product has no row and a helper row could not be created',
            CASE WHEN @T2Msg IS NULL THEN N'' ELSE CONCAT(N': ', @T2Msg) END,
            N')  ->  SKIPPED only the tests that need a Product row (B1b, B11, B24 group, B27, B28); all other tests run'));
    END;
END;
SET @ProdN = CASE WHEN @ProdOk = 1 THEN @Prod ELSE NULL END;

IF OBJECT_ID(N'sales.FK_SalesOrder_Promotion_Promotion_ID') IS NOT NULL
BEGIN
    SET @T2Msg = NULL;
    BEGIN TRY
        EXEC sp_executesql N'SELECT TOP (1) @pr = Promotion_ID FROM marketing.Promotion ORDER BY Promotion_ID', N'@pr int OUTPUT', @pr = @Promo OUTPUT;
        IF @Promo IS NULL
            EXEC sp_executesql N'
                INSERT marketing.Promotion (Promotion_Code, Promotion_Name, Promotion_Type, Discount_Type, Discount_Value, Start_Date, End_Date, Promotion_Status)
                    VALUES (N''T1-TEST-PRM'', N''T1 test promotion'', N''Discount'', N''Percentage'', 10, ''2026-01-01'', ''2026-12-31'', N''Active'');
                SET @pr = SCOPE_IDENTITY();',
                N'@pr int OUTPUT', @pr = @Promo OUTPUT;
    END TRY
    BEGIN CATCH
        SET @Promo = NULL;
        SET @T2Msg = LEFT(ERROR_MESSAGE(), 300);
    END CATCH;
    IF @Promo IS NULL
        INSERT #Result (id, ok, msg) VALUES (N'B0b', 2, CONCAT(N'no usable marketing.Promotion row (none exists and a helper row could not be created',
            CASE WHEN @T2Msg IS NULL THEN N'' ELSE CONCAT(N': ', @T2Msg) END,
            N')  ->  sample order is created without Promotion_ID; no test is skipped because of this'));
END;

/* ---- B1: valid rows in the 21 tables that need no Product row ---- */
BEGIN TRY
INSERT ref.Province (Province_Code, Province_Name, Province_Status) VALUES (N'T1-P01', N'تهران', N'Active'); SET @Prov = SCOPE_IDENTITY();
INSERT ref.City (Province_ID, City_Code, City_Name, City_Level) VALUES (@Prov, N'T1-C01', N'تهران', N'City'); SET @City = SCOPE_IDENTITY();
INSERT ref.City (Province_ID, Parent_City_ID, City_Code, City_Name, City_Level) VALUES (@Prov, @City, N'T1-C02', N'District 1', N'District'); SET @District = SCOPE_IDENTITY();
INSERT ref.CustomerSegment (Segment_Code, Segment_Name) VALUES (N'T1-S01', N'Test segment'); SET @Seg = SCOPE_IDENTITY();
INSERT ref.SalesChannel (Sales_Channel_Code, Sales_Channel_Name, Sales_Channel_Type, Channel_Status) VALUES (N'T1-CH01', N'Test channel', N'Online', N'Active'); SET @Chan = SCOPE_IDENTITY();
INSERT ref.SalesRegion (Sales_Region_Code, Sales_Region_Name, Region_Status) VALUES (N'T1-R01', N'Test region', N'Active'); SET @Reg = SCOPE_IDENTITY();
INSERT ref.SalesRegion (Parent_Sales_Region_ID, Sales_Region_Code, Sales_Region_Name, Region_Level, Region_Status) VALUES (@Reg, N'T1-R02', N'Test team', N'Team', N'Active'); SET @RegChild = SCOPE_IDENTITY();
INSERT ref.SalesTerritory (Territory_Code, Territory_Name, Territory_Status) VALUES (N'T1-T01', N'Test territory', N'Active'); SET @Terr = SCOPE_IDENTITY();
INSERT core.Calendar (Calendar_Date, Day_Number, Month_Number, Quarter_Number, Week_Number, Year_Number) VALUES ('2026-10-25', 25, 10, 4, 43, 2026); SET @Cal1 = SCOPE_IDENTITY();
INSERT core.Calendar (Calendar_Date, Day_Number, Month_Number, Quarter_Number, Week_Number, Year_Number) VALUES ('2026-10-26', 26, 10, 4, 43, 2026); SET @Cal2 = SCOPE_IDENTITY();
INSERT core.Branch (Sales_Region_ID, Branch_Code, Branch_Name) VALUES (@Reg, N'T1-B01', N'Test branch'); SET @Branch = SCOPE_IDENTITY();
INSERT core.Salesperson (Branch_ID, Salesperson_Code, Salesperson_Name, Role, Employment_Status, Email) VALUES (@Branch, N'T1-SP01', N'Test manager', N'Manager', N'Active', N'manager@example.com'); SET @SP1 = SCOPE_IDENTITY();
INSERT core.Salesperson (Branch_ID, Manager_Salesperson_ID, Salesperson_Code, Salesperson_Name, Role, Employment_Status) VALUES (@Branch, @SP1, N'T1-SP02', N'Test seller', N'Seller', N'Active'); SET @SP2 = SCOPE_IDENTITY();
INSERT core.Customer (City_ID, Customer_Segment_ID, Sales_Channel_ID, Sales_Territory_ID, Salesperson_ID, Customer_Code, Customer_Name, Customer_Type, Customer_Status, Email, Latitude, Longitude, Credit_Limit)
    VALUES (@City, @Seg, @Chan, @Terr, @SP2, N'T1-CUST-1', N'مشتری آزمایشی ۱', N'Business', N'Active', N'c1@example.com', 35.689200, 51.389000, 1000000.00); SET @Cust1 = SCOPE_IDENTITY();
INSERT core.Customer (Customer_Code, Customer_Name, Customer_Type, Customer_Status) VALUES (N'T1-CUST-2', N'Test customer 2', N'Individual', N'Active'); SET @Cust2 = SCOPE_IDENTITY();
INSERT sales.Lead (Lead_Name, Lead_Source, Lead_Status, Created_Date) VALUES (N'Lead without code', N'Website', N'New', '2026-10-01');
INSERT sales.Lead (Salesperson_ID, Lead_Code, Lead_Name, Lead_Source, Lead_Status, Created_Date, Conversion_Date) VALUES (@SP2, N'T1-LEAD-1', N'Converted lead', N'Referral', N'Converted', '2026-10-01', '2026-10-10'); SET @LeadC = SCOPE_IDENTITY();
INSERT sales.CustomerInteraction (Customer_ID, Salesperson_ID, Sales_Territory_ID, Interaction_Type, Interaction_DateTime, Interaction_Duration_Minutes, Follow_Up_Required, Follow_Up_Date)
    VALUES (@Cust1, @SP2, @Terr, N'Call', '2026-10-25 10:30:00', 5, 1, '2026-10-30'); SET @Inter1 = SCOPE_IDENTITY();
INSERT sales.CustomerInteraction (Customer_ID, Interaction_Type, Interaction_DateTime) VALUES (@Cust1, N'Visit', '2026-10-26 09:00:00'); SET @Inter2 = SCOPE_IDENTITY();
INSERT sales.SalesOpportunity (Customer_ID, Lead_ID, Salesperson_ID, Opportunity_Code, Opportunity_Name, Opportunity_Stage, Opportunity_Status, Opportunity_Date, Probability, Expected_Value)
    VALUES (@Cust1, @LeadC, @SP2, N'T1-OPP-1', N'Test opportunity', N'Proposal', N'Open', '2026-10-05', 60, 5000000.00); SET @Opp = SCOPE_IDENTITY();
INSERT sales.Contract (Customer_ID, Sales_Opportunity_ID, Product_ID, Contract_Number, Contract_Type, Contract_Status, Start_Date, End_Date, Contract_Amount, Currency_Code, Payment_Terms)
    VALUES (@Cust1, @Opp, @ProdN, N'T1-CTR-1', N'Annual', N'Active', '2026-11-01', '2027-10-31', 5000000.00, 'IRR', N'Net 30'); SET @Ctr = SCOPE_IDENTITY();
INSERT sales.SalesOrder (Customer_ID, Salesperson_ID, Sales_Channel_ID, Sales_Region_ID, Promotion_ID, Contract_ID, Customer_Interaction_ID, Calendar_ID, Sales_Order_Number, Order_Status, Total_Amount, Delivery_Date)
    VALUES (@Cust1, @SP2, @Chan, @Reg, @Promo, @Ctr, @Inter1, @Cal1, N'T1-SO-1', N'Confirmed', 190.00, '2026-10-28'); SET @Order1 = SCOPE_IDENTITY();
INSERT sales.SalesOrder (Customer_ID, Sales_Channel_ID, Calendar_ID, Sales_Order_Number, Order_Status, Total_Amount) VALUES (@Cust2, @Chan, @Cal1, N'T1-SO-2', N'Confirmed', 50.00); SET @Order2 = SCOPE_IDENTITY();
INSERT sales.SalesOrder (Customer_ID, Sales_Channel_ID, Calendar_ID, Sales_Order_Number, Order_Status, Total_Amount) VALUES (@Cust1, @Chan, @Cal1, N'T1-SO-3', N'Confirmed', 10.00); SET @Order3 = SCOPE_IDENTITY();
INSERT sales.Invoice (Customer_ID, Sales_Order_ID, Invoice_Number, Invoice_Date, Due_Date, Invoice_Status, Subtotal, Discount_Amount, Tax_Amount, Total_Amount)
    VALUES (@Cust1, @Order1, N'T1-INV-1', '2026-10-26', '2026-11-25', N'Issued', 200.00, 10.00, 19.00, 209.00); SET @Inv1 = SCOPE_IDENTITY();
INSERT sales.Payment (Customer_ID, Invoice_ID, Sales_Order_ID, Payment_Date, Amount, Payment_Method, Payment_Status, Transaction_Reference)
    VALUES (@Cust1, @Inv1, @Order1, '2026-10-27', 209.00, N'Online', N'Completed', N'T1-TXN-1'); SET @Pay1 = SCOPE_IDENTITY();
INSERT sales.CustomerFeedback (Customer_ID, Customer_Interaction_ID, Sales_Order_ID, Product_ID, Feedback_Type, Feedback_Date, Rating, Resolution_Date)
    VALUES (@Cust1, @Inter1, @Order1, @ProdN, N'Complaint', '2026-10-26', 3.50, '2026-10-28');
INSERT sales.Commission (Salesperson_ID, Calendar_ID, Commission_Base_Amount, Commission_Rate, Commission_Amount) VALUES (@SP2, @Cal1, 1000.00, 5.00, 50.00);
INSERT sales.SalesTarget (Calendar_ID, Target_Level, Fiscal_Year, Target_Value, Currency_Code, Target_Version, Target_Status) VALUES (@Cal1, N'Annual', 2026, 1000000.00, 'IRR', 1, N'Approved');
INSERT sales.SalesTarget (Calendar_ID, Sales_Region_ID, Target_Level, Target_Value, Target_Version, Target_Status) VALUES (@Cal1, @Reg, N'Region', 400000.00, 1, N'Approved');
INSERT sales.SalesTarget (Calendar_ID, Sales_Region_ID, Target_Level, Target_Quantity, Target_Version, Target_Status) VALUES (@Cal1, @RegChild, N'Team', 500.000, 1, N'Approved');
INSERT sales.SalesTarget (Calendar_ID, Salesperson_ID, Target_Level, Target_Value, Target_Version, Target_Status) VALUES (@Cal1, @SP2, N'Salesperson', 100000.00, 1, N'Approved');
INSERT sales.SalesTarget (Calendar_ID, Sales_Channel_ID, Target_Level, Target_Value, Target_Status) VALUES (@Cal1, @Chan, N'Channel', 200000.00, N'Draft'); SET @Tgt1 = SCOPE_IDENTITY();
INSERT sales.SalesForecast (Calendar_ID, Forecast_Amount) VALUES (@Cal1, 750000.00); SET @Fc1 = SCOPE_IDENTITY();
SET @Valid = 1;
INSERT #Result (id, ok, msg) VALUES (N'B1', 1, N'valid rows accepted in 21 tables (incl. 2 leads with NULL Lead_Code)  ->  accepted');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B1', 0, CONCAT(N'valid rows were rejected: Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 350)));
END CATCH;

/* ---- B1b: valid rows in the 3 tables that need a Product row (SalesOrderItem, InvoiceItem, ReturnRequest) + Product-level target ---- */
IF @Valid = 1 AND @ProdOk = 1
BEGIN
    BEGIN TRY
INSERT sales.SalesOrderItem (Sales_Order_ID, Product_ID, Line_Number, Quantity, Unit_of_Measure, Unit_Price, Discount_Amount, Discount_Percentage, Net_Amount, Item_Status)
    VALUES (@Order1, @Prod, 1, 2.000, N'EA', 100.00, 10.00, 5.00, 190.00, N'Open'); SET @Item1 = SCOPE_IDENTITY();
INSERT sales.InvoiceItem (Invoice_ID, Product_ID, Quantity, Unit_Price, Discount_Amount, Tax_Amount, Net_Amount, Final_Amount) VALUES (@Inv1, @Prod, 2.000, 100.00, 10.00, 19.00, 190.00, 209.00);
INSERT sales.ReturnRequest (Sales_Order_Item_ID, Payment_ID, Calendar_ID, Return_Reason, Return_Status, Requested_Quantity, Approved_Quantity, Refund_Amount)
    VALUES (@Item1, @Pay1, @Cal2, N'Damaged', N'Approved', 1.000, 1.000, 95.00);
INSERT sales.SalesTarget (Calendar_ID, Product_ID, Target_Level, Target_Quantity, Target_Version, Target_Status) VALUES (@Cal1, @Prod, N'Product', 300.000, 1, N'Approved');
    SET @ItemsValid = 1;
    INSERT #Result (id, ok, msg) VALUES (N'B1b', 1, N'valid rows accepted in SalesOrderItem, InvoiceItem, ReturnRequest and a Product-level SalesTarget  ->  accepted');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B1b', 0, CONCAT(N'valid item / return rows were rejected: Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 350)));
    END CATCH;
END;
IF @Valid = 1 AND @ProdOk = 0
    INSERT #Result (id, ok, msg) VALUES (N'B1b', 2, N'valid rows in SalesOrderItem, InvoiceItem, ReturnRequest  ->  SKIPPED (needs a valid Product_ID, see B0)');

IF @Valid = 1
BEGIN


/* ---- B2: DEFAULT values ---- */
SELECT @v = Target_Version FROM sales.SalesTarget WHERE Sales_Target_ID = @Tgt1;
INSERT #Result (id, ok, msg) VALUES (N'B2', CASE WHEN @v = 1 THEN 1 ELSE 0 END, CONCAT(N'DF_SalesTarget_Target_Version fills 1  ->  ', @v));
SELECT @v = Forecast_Version FROM sales.SalesForecast WHERE Sales_Forecast_ID = @Fc1;
INSERT #Result (id, ok, msg) VALUES (N'B2b', CASE WHEN @v = 1 THEN 1 ELSE 0 END, CONCAT(N'DF_SalesForecast_Forecast_Version fills 1  ->  ', @v));

/* ---- B3: Persian (Unicode) text is stored correctly ---- */
SELECT @nm = Province_Name FROM ref.Province WHERE Province_ID = @Prov;
INSERT #Result (id, ok, msg) VALUES (N'B3', CASE WHEN @nm = N'تهران' AND LEN(@nm) = 5 THEN 1 ELSE 0 END, N'Persian text in nvarchar column  ->  stored and read back unchanged');

BEGIN TRY
    INSERT core.Customer (Customer_Code, Customer_Name, Customer_Type, Customer_Status) VALUES (N'T1-CUST-1', N'dup', N'Business', N'Active');
    INSERT #Result (id, ok, msg) VALUES (N'B4', 0, N'duplicate Customer_Code (UQ)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B4', CASE WHEN ERROR_NUMBER() = 2627 AND ERROR_MESSAGE() LIKE N'%UQ_Customer_Customer_Code%' THEN 1 ELSE 0 END,
        CONCAT(N'duplicate Customer_Code (UQ)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 2627 THEN N'' ELSE CONCAT(N' (expected 2627): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT core.Customer (City_ID, Customer_Code, Customer_Name, Customer_Type, Customer_Status) VALUES (-1, N'T1-CUST-B5', N'x', N'Business', N'Active');
    INSERT #Result (id, ok, msg) VALUES (N'B5', 0, N'Customer with a City_ID that does not exist (FK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B5', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_Customer_City_City_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'Customer with a City_ID that does not exist (FK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT core.Customer (Customer_Code, Customer_Name, Customer_Type, Customer_Status) VALUES (N'T1-CUST-B6', NULL, N'Business', N'Active');
    INSERT #Result (id, ok, msg) VALUES (N'B6', 0, N'Customer_Name NULL (NOT NULL)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B6', CASE WHEN ERROR_NUMBER() = 515 AND ERROR_MESSAGE() LIKE N'%Customer_Name%' THEN 1 ELSE 0 END,
        CONCAT(N'Customer_Name NULL (NOT NULL)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 515 THEN N'' ELSE CONCAT(N' (expected 515): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Lead (Lead_Code, Lead_Name, Lead_Source, Lead_Status, Created_Date) VALUES (N'T1-LEAD-1', N'dup', N'Web', N'New', '2026-10-01');
    INSERT #Result (id, ok, msg) VALUES (N'B7', 0, N'duplicate Lead_Code (filtered unique index)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B7', CASE WHEN ERROR_NUMBER() = 2601 AND ERROR_MESSAGE() LIKE N'%UQ_Lead_Lead_Code%' THEN 1 ELSE 0 END,
        CONCAT(N'duplicate Lead_Code (filtered unique index)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 2601 THEN N'' ELSE CONCAT(N' (expected 2601): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT ref.City (Province_ID, Parent_City_ID, City_Code, City_Name, City_Level) VALUES (@Prov, @City, N'T1-C99', N'x', N'City');
    INSERT #Result (id, ok, msg) VALUES (N'B8', 0, N'City (level City) with a parent city (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B8', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_City_Parent_City_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'City (level City) with a parent city (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT ref.City (Province_ID, City_Code, City_Name, City_Level) VALUES (@Prov, N'T1-C98', N'x', N'Village');
    INSERT #Result (id, ok, msg) VALUES (N'B9', 0, N'City_Level outside City / District (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B9', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_City_City_Level%' THEN 1 ELSE 0 END,
        CONCAT(N'City_Level outside City / District (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.SalesTarget (Calendar_ID, Target_Level, Target_Value, Target_Version, Target_Status) VALUES (@Cal1, N'Region', 10, 99, N'Draft');
    INSERT #Result (id, ok, msg) VALUES (N'B10', 0, N'Sales Target level Region without Sales_Region_ID (CK, OI-15 matrix)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B10', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_SalesTarget_Target_Level_Dimensions%' THEN 1 ELSE 0 END,
        CONCAT(N'Sales Target level Region without Sales_Region_ID (CK, OI-15 matrix)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

IF NOT (@ProdOk = 1)
    INSERT #Result (id, ok, msg) VALUES (N'B11', 2, N'Sales Target level Product with two dimension FKs (CK)  ->  SKIPPED (needs a valid Product_ID, see B0)');
IF @ProdOk = 1
BEGIN
    BEGIN TRY
        INSERT sales.SalesTarget (Calendar_ID, Sales_Region_ID, Product_ID, Target_Level, Target_Value, Target_Version, Target_Status) VALUES (@Cal1, @Reg, @Prod, N'Product', 10, 98, N'Draft');
        INSERT #Result (id, ok, msg) VALUES (N'B11', 0, N'Sales Target level Product with two dimension FKs (CK)  ->  was ACCEPTED (expected rejection)');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B11', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_SalesTarget_Target_Level_Dimensions%' THEN 1 ELSE 0 END,
            CONCAT(N'Sales Target level Product with two dimension FKs (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
    END CATCH;
END;

BEGIN TRY
    INSERT sales.SalesTarget (Calendar_ID, Target_Level, Target_Value, Target_Version, Target_Status) VALUES (@Cal1, N'Annual', 5, 1, N'Draft');
    INSERT #Result (id, ok, msg) VALUES (N'B12', 0, N'duplicate Sales Target (same level, day, version, dimension) (UQ)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B12', CASE WHEN ERROR_NUMBER() = 2627 AND ERROR_MESSAGE() LIKE N'%UQ_SalesTarget_Target_Level_Calendar_ID_Target_Version_Dimensions%' THEN 1 ELSE 0 END,
        CONCAT(N'duplicate Sales Target (same level, day, version, dimension) (UQ)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 2627 THEN N'' ELSE CONCAT(N' (expected 2627): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.SalesTarget (Calendar_ID, Target_Level, Target_Version, Target_Status) VALUES (@Cal1, N'Annual', 97, N'Draft');
    INSERT #Result (id, ok, msg) VALUES (N'B13', 0, N'Sales Target with neither Target_Value nor Target_Quantity (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B13', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_SalesTarget_Target_Value_Target_Quantity%' THEN 1 ELSE 0 END,
        CONCAT(N'Sales Target with neither Target_Value nor Target_Quantity (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Invoice (Customer_ID, Sales_Order_ID, Invoice_Number, Invoice_Date, Invoice_Status, Subtotal, Total_Amount) VALUES (@Cust2, @Order1, N'T1-INV-B14', '2026-10-26', N'Issued', 10, 10);
    INSERT #Result (id, ok, msg) VALUES (N'B14', 0, N'invoice of another customer than its sales order (CE-01, composite FK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B14', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_Invoice_SalesOrder_Sales_Order_ID_Customer_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'invoice of another customer than its sales order (CE-01, composite FK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Invoice (Customer_ID, Sales_Order_ID, Invoice_Number, Invoice_Date, Invoice_Status, Subtotal, Total_Amount) VALUES (@Cust1, @Order1, N'T1-INV-B15', '2026-10-26', N'Issued', 100, 999);
    INSERT #Result (id, ok, msg) VALUES (N'B15', 0, N'invoice Total_Amount different from Subtotal - Discount + Tax (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B15', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Invoice_Total_Amount%' THEN 1 ELSE 0 END,
        CONCAT(N'invoice Total_Amount different from Subtotal - Discount + Tax (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Payment (Customer_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust1, '2026-10-27', 10, N'Cash', N'Completed');
    INSERT #Result (id, ok, msg) VALUES (N'B16', 0, N'payment without Invoice_ID and without Sales_Order_ID (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B16', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Payment_Invoice_ID_Sales_Order_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'payment without Invoice_ID and without Sales_Order_ID (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Payment (Customer_ID, Sales_Order_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust2, @Order1, '2026-10-27', 10, N'Cash', N'Completed');
    INSERT #Result (id, ok, msg) VALUES (N'B17', 0, N'payment of another customer than its sales order (CE-02, composite FK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B17', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_Payment_SalesOrder_Sales_Order_ID_Customer_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'payment of another customer than its sales order (CE-02, composite FK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Payment (Customer_ID, Invoice_ID, Sales_Order_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust1, @Inv1, @Order3, '2026-10-27', 10, N'Cash', N'Completed');
    INSERT #Result (id, ok, msg) VALUES (N'B17b', 0, N'payment whose invoice belongs to another order of the same customer (review correction 1, composite FK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B17b', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_Payment_Invoice_Invoice_ID_Sales_Order_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'payment whose invoice belongs to another order of the same customer (review correction 1, composite FK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Payment (Customer_ID, Invoice_ID, Sales_Order_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust1, @Inv1, @Order1, '2026-10-27', 10, N'Cash', N'Completed');
    INSERT #Result (id, ok, msg) VALUES (N'B17c', 1, N'payment whose invoice belongs to the order of the same payment  ->  accepted');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B17c', 0, CONCAT(N'payment whose invoice belongs to the order of the same payment  ->  was REJECTED (expected acceptance): Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 200)));
END CATCH;

BEGIN TRY
    INSERT sales.Payment (Customer_ID, Invoice_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust1, @Inv1, '2026-10-27', 10, N'Cash', N'Completed');
    INSERT sales.Payment (Customer_ID, Sales_Order_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust1, @Order3, '2026-10-27', 10, N'Cash', N'Completed');
    INSERT #Result (id, ok, msg) VALUES (N'B17d', 1, N'payment with only Invoice_ID, and payment with only Sales_Order_ID (the other column is NULL)  ->  accepted');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B17d', 0, CONCAT(N'payment with only Invoice_ID, or only Sales_Order_ID  ->  was REJECTED (expected acceptance): Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 200)));
END CATCH;

BEGIN TRY
    INSERT sales.Payment (Customer_ID, Invoice_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust2, @Inv1, '2026-10-27', 10, N'Cash', N'Completed');
    INSERT #Result (id, ok, msg) VALUES (N'B18', 0, N'payment of another customer than its invoice (CE-02, composite FK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B18', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_Payment_Invoice_Invoice_ID_Customer_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'payment of another customer than its invoice (CE-02, composite FK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Payment (Customer_ID, Invoice_ID, Payment_Date, Amount, Payment_Method, Payment_Status) VALUES (@Cust1, @Inv1, '2026-10-27', 0, N'Cash', N'Completed');
    INSERT #Result (id, ok, msg) VALUES (N'B19', 0, N'payment Amount = 0 (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B19', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Payment_Amount%' THEN 1 ELSE 0 END,
        CONCAT(N'payment Amount = 0 (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.CustomerFeedback (Customer_ID, Customer_Interaction_ID, Feedback_Type, Feedback_Date) VALUES (@Cust2, @Inter2, N'Comment', '2026-10-26');
    INSERT #Result (id, ok, msg) VALUES (N'B20', 0, N'feedback of another customer than its interaction (CE-03, composite FK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B20', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_CustomerFeedback_CustomerInteraction_Customer_Interaction_ID_Customer_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'feedback of another customer than its interaction (CE-03, composite FK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.CustomerFeedback (Customer_ID, Sales_Order_ID, Feedback_Type, Feedback_Date) VALUES (@Cust2, @Order1, N'Comment', '2026-10-26');
    INSERT #Result (id, ok, msg) VALUES (N'B21', 0, N'feedback of another customer than its sales order (CE-03, composite FK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B21', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_CustomerFeedback_SalesOrder_Sales_Order_ID_Customer_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'feedback of another customer than its sales order (CE-03, composite FK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.CustomerFeedback (Customer_ID, Customer_Interaction_ID, Feedback_Type, Feedback_Date) VALUES (@Cust1, @Inter1, N'Comment', '2026-10-26');
    INSERT #Result (id, ok, msg) VALUES (N'B22', 0, N'second feedback for the same interaction (1:1, filtered unique index)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B22', CASE WHEN ERROR_NUMBER() = 2601 AND ERROR_MESSAGE() LIKE N'%UQ_CustomerFeedback_Customer_Interaction_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'second feedback for the same interaction (1:1, filtered unique index)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 2601 THEN N'' ELSE CONCAT(N' (expected 2601): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.CustomerFeedback (Customer_ID, Feedback_Type, Feedback_Date, Resolution_Date) VALUES (@Cust1, N'Comment', '2026-10-26', '2026-10-01');
    INSERT #Result (id, ok, msg) VALUES (N'B23', 0, N'feedback Resolution_Date before Feedback_Date (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B23', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_CustomerFeedback_Resolution_Date%' THEN 1 ELSE 0 END,
        CONCAT(N'feedback Resolution_Date before Feedback_Date (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

IF @ItemsValid = 0
    INSERT #Result (id, ok, msg) VALUES (N'B24', 2, N'return Approved_Quantity tests B24 to B24f (CK)  ->  SKIPPED (needs the sample order item row: see B0 or B1b)');
IF @ItemsValid = 1
BEGIN
    BEGIN TRY
        INSERT sales.ReturnRequest (Sales_Order_Item_ID, Calendar_ID, Return_Reason, Return_Status, Requested_Quantity, Approved_Quantity) VALUES (@Item1, @Cal2, N'Damaged', N'Open', 10, 12);
        INSERT #Result (id, ok, msg) VALUES (N'B24', 0, N'return Approved_Quantity 12 with Requested_Quantity 10 (CK, review correction 2)  ->  was ACCEPTED (expected rejection)');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B24', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_ReturnRequest_Approved_Quantity%' THEN 1 ELSE 0 END,
            CONCAT(N'return Approved_Quantity 12 with Requested_Quantity 10 (CK, review correction 2)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
    END CATCH;

    BEGIN TRY
        INSERT sales.ReturnRequest (Sales_Order_Item_ID, Calendar_ID, Return_Reason, Return_Status, Requested_Quantity, Approved_Quantity) VALUES (@Item1, @Cal2, N'Damaged', N'Open', 10, -2);
        INSERT #Result (id, ok, msg) VALUES (N'B24b', 0, N'return Approved_Quantity -2 with Requested_Quantity 10 (CK, review correction 2)  ->  was ACCEPTED (expected rejection)');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B24b', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_ReturnRequest_Approved_Quantity%' THEN 1 ELSE 0 END,
            CONCAT(N'return Approved_Quantity -2 with Requested_Quantity 10 (CK, review correction 2)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
    END CATCH;

    BEGIN TRY
        INSERT sales.ReturnRequest (Sales_Order_Item_ID, Calendar_ID, Return_Reason, Return_Status, Requested_Quantity, Approved_Quantity) VALUES (@Item1, @Cal2, N'Damaged', N'Open', 10, 8);
        INSERT #Result (id, ok, msg) VALUES (N'B24c', 1, N'return Approved_Quantity 8 with Requested_Quantity 10 (CK)  ->  accepted');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B24c', 0, CONCAT(N'return Approved_Quantity 8 with Requested_Quantity 10 (CK)  ->  was REJECTED (expected acceptance): Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 200)));
    END CATCH;

    BEGIN TRY
        INSERT sales.ReturnRequest (Sales_Order_Item_ID, Calendar_ID, Return_Reason, Return_Status, Requested_Quantity, Approved_Quantity) VALUES (@Item1, @Cal2, N'Damaged', N'Open', 10, 10);
        INSERT #Result (id, ok, msg) VALUES (N'B24d', 1, N'return Approved_Quantity 10 with Requested_Quantity 10 (CK)  ->  accepted');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B24d', 0, CONCAT(N'return Approved_Quantity 10 with Requested_Quantity 10 (CK)  ->  was REJECTED (expected acceptance): Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 200)));
    END CATCH;

    BEGIN TRY
        INSERT sales.ReturnRequest (Sales_Order_Item_ID, Calendar_ID, Return_Reason, Return_Status, Requested_Quantity, Approved_Quantity) VALUES (@Item1, @Cal2, N'Damaged', N'Open', 10, 0);
        INSERT #Result (id, ok, msg) VALUES (N'B24e', 1, N'return Approved_Quantity 0 with Requested_Quantity 10 (CK)  ->  accepted');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B24e', 0, CONCAT(N'return Approved_Quantity 0 with Requested_Quantity 10 (CK)  ->  was REJECTED (expected acceptance): Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 200)));
    END CATCH;

    BEGIN TRY
        INSERT sales.ReturnRequest (Sales_Order_Item_ID, Calendar_ID, Return_Reason, Return_Status, Requested_Quantity, Approved_Quantity) VALUES (@Item1, @Cal2, N'Damaged', N'Open', 10, NULL);
        INSERT #Result (id, ok, msg) VALUES (N'B24f', 1, N'return Approved_Quantity NULL (request pending) (CK)  ->  accepted');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B24f', 0, CONCAT(N'return Approved_Quantity NULL (request pending) (CK)  ->  was REJECTED (expected acceptance): Msg ', ERROR_NUMBER(), N' - ', LEFT(ERROR_MESSAGE(), 200)));
    END CATCH;
END;

BEGIN TRY
    INSERT sales.SalesOpportunity (Salesperson_ID, Opportunity_Code, Opportunity_Name, Opportunity_Stage, Opportunity_Status, Opportunity_Date) VALUES (@SP2, N'T1-OPP-B25', N'x', N'New', N'Open', '2026-10-05');
    INSERT #Result (id, ok, msg) VALUES (N'B25', 0, N'opportunity with neither Customer_ID nor Lead_ID (CK, OI-07)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B25', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_SalesOpportunity_Customer_ID_Lead_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'opportunity with neither Customer_ID nor Lead_ID (CK, OI-07)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.SalesOpportunity (Customer_ID, Salesperson_ID, Opportunity_Code, Opportunity_Name, Opportunity_Stage, Opportunity_Status, Opportunity_Date, Probability) VALUES (@Cust1, @SP2, N'T1-OPP-B26', N'x', N'New', N'Open', '2026-10-05', 150);
    INSERT #Result (id, ok, msg) VALUES (N'B26', 0, N'opportunity Probability = 150 (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B26', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_SalesOpportunity_Probability%' THEN 1 ELSE 0 END,
        CONCAT(N'opportunity Probability = 150 (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

IF NOT (@ItemsValid = 1)
    INSERT #Result (id, ok, msg) VALUES (N'B27', 2, N'duplicate order line (Sales_Order_ID, Line_Number) (UQ)  ->  SKIPPED (needs the sample order item row: see B0 or B1b)');
IF @ItemsValid = 1
BEGIN
    BEGIN TRY
        INSERT sales.SalesOrderItem (Sales_Order_ID, Product_ID, Line_Number, Quantity, Unit_of_Measure, Unit_Price, Net_Amount, Item_Status) VALUES (@Order1, @Prod, 1, 1, N'EA', 10, 10, N'Open');
        INSERT #Result (id, ok, msg) VALUES (N'B27', 0, N'duplicate order line (Sales_Order_ID, Line_Number) (UQ)  ->  was ACCEPTED (expected rejection)');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B27', CASE WHEN ERROR_NUMBER() = 2627 AND ERROR_MESSAGE() LIKE N'%UQ_SalesOrderItem_Sales_Order_ID_Line_Number%' THEN 1 ELSE 0 END,
            CONCAT(N'duplicate order line (Sales_Order_ID, Line_Number) (UQ)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 2627 THEN N'' ELSE CONCAT(N' (expected 2627): ', LEFT(ERROR_MESSAGE(), 200)) END));
    END CATCH;
END;

IF NOT (@ItemsValid = 1)
    INSERT #Result (id, ok, msg) VALUES (N'B28', 2, N'order item Quantity = 0 (CK)  ->  SKIPPED (needs the sample order item row: see B0 or B1b)');
IF @ItemsValid = 1
BEGIN
    BEGIN TRY
        INSERT sales.SalesOrderItem (Sales_Order_ID, Product_ID, Line_Number, Quantity, Unit_of_Measure, Unit_Price, Net_Amount, Item_Status) VALUES (@Order1, @Prod, 2, 0, N'EA', 10, 0, N'Open');
        INSERT #Result (id, ok, msg) VALUES (N'B28', 0, N'order item Quantity = 0 (CK)  ->  was ACCEPTED (expected rejection)');
    END TRY
    BEGIN CATCH
        INSERT #Result (id, ok, msg) VALUES (N'B28', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_SalesOrderItem_Quantity%' THEN 1 ELSE 0 END,
            CONCAT(N'order item Quantity = 0 (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
    END CATCH;
END;

BEGIN TRY
    INSERT sales.Contract (Customer_ID, Contract_Number, Contract_Type, Contract_Status, Start_Date, End_Date, Contract_Amount, Payment_Terms) VALUES (@Cust1, N'T1-CTR-B29', N'Annual', N'Active', '2026-11-01', '2026-10-01', 10, N'Net 30');
    INSERT #Result (id, ok, msg) VALUES (N'B29', 0, N'contract End_Date before Start_Date (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B29', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Contract_End_Date%' THEN 1 ELSE 0 END,
        CONCAT(N'contract End_Date before Start_Date (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Contract (Customer_ID, Contract_Number, Contract_Type, Contract_Status, Start_Date, End_Date, Contract_Amount, Currency_Code, Payment_Terms) VALUES (@Cust1, N'T1-CTR-B30', N'Annual', N'Active', '2026-11-01', '2027-10-01', 10, 'irr', N'Net 30');
    INSERT #Result (id, ok, msg) VALUES (N'B30', 0, N'lower-case currency code (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B30', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Contract_Currency_Code%' THEN 1 ELSE 0 END,
        CONCAT(N'lower-case currency code (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Commission (Salesperson_ID, Calendar_ID, Commission_Base_Amount, Commission_Rate, Commission_Amount) VALUES (@SP2, @Cal1, 1, 1, 0.01);
    INSERT #Result (id, ok, msg) VALUES (N'B31', 0, N'duplicate commission for the same salesperson and day (UQ)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B31', CASE WHEN ERROR_NUMBER() = 2627 AND ERROR_MESSAGE() LIKE N'%UQ_Commission_Salesperson_ID_Calendar_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'duplicate commission for the same salesperson and day (UQ)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 2627 THEN N'' ELSE CONCAT(N' (expected 2627): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT sales.Commission (Salesperson_ID, Calendar_ID, Commission_Base_Amount, Commission_Rate, Commission_Amount) VALUES (@SP2, @Cal2, 1, 120, 1.2);
    INSERT #Result (id, ok, msg) VALUES (N'B32', 0, N'Commission_Rate = 120 (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B32', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Commission_Commission_Rate%' THEN 1 ELSE 0 END,
        CONCAT(N'Commission_Rate = 120 (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT core.Calendar (Calendar_Date, Day_Number, Month_Number, Quarter_Number, Week_Number, Year_Number) VALUES ('2026-10-27', 1, 10, 4, 43, 2026);
    INSERT #Result (id, ok, msg) VALUES (N'B33', 0, N'calendar day parts that do not match Calendar_Date (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B33', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Calendar_Calendar_Date%' THEN 1 ELSE 0 END,
        CONCAT(N'calendar day parts that do not match Calendar_Date (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    UPDATE core.Salesperson SET Manager_Salesperson_ID = Salesperson_ID WHERE Salesperson_ID = @SP1;
    INSERT #Result (id, ok, msg) VALUES (N'B34', 0, N'salesperson as his or her own manager (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B34', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Salesperson_Manager_Salesperson_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'salesperson as his or her own manager (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT core.Salesperson (Salesperson_Code, Salesperson_Name, Role, Employment_Status, Email) VALUES (N'T1-SP-B35', N'x', N'Seller', N'Active', N'not-an-email');
    INSERT #Result (id, ok, msg) VALUES (N'B35', 0, N'invalid e-mail format (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B35', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Salesperson_Email%' THEN 1 ELSE 0 END,
        CONCAT(N'invalid e-mail format (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT core.Customer (Customer_Code, Customer_Name, Customer_Type, Customer_Status, Latitude) VALUES (N'T1-CUST-B36', N'x', N'Business', N'Active', 100);
    INSERT #Result (id, ok, msg) VALUES (N'B36', 0, N'Latitude = 100 (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B36', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Customer_Latitude%' THEN 1 ELSE 0 END,
        CONCAT(N'Latitude = 100 (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    INSERT core.Customer (Customer_Code, Customer_Name, Customer_Type, Customer_Status, Credit_Limit) VALUES (N'T1-CUST-B37', N'x', N'Business', N'Active', -1);
    INSERT #Result (id, ok, msg) VALUES (N'B37', 0, N'Credit_Limit negative (CK)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B37', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%CK_Customer_Credit_Limit%' THEN 1 ELSE 0 END,
        CONCAT(N'Credit_Limit negative (CK)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

BEGIN TRY
    DELETE core.Customer WHERE Customer_ID = @Cust1;
    INSERT #Result (id, ok, msg) VALUES (N'B38', 0, N'delete a Customer that still has related rows (FK NO ACTION)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B38', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%REFERENCE constraint%' THEN 1 ELSE 0 END,
        CONCAT(N'delete a Customer that still has related rows (FK NO ACTION)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;

IF OBJECT_ID(N'sales.FK_SalesOrderItem_Product_Product_ID') IS NULL
    INSERT #Result (id, ok, msg) VALUES (N'B39', 2, N'order item with a Product_ID that does not exist (FK to Team 2)  ->  SKIPPED (Team 2 table / FK not present yet)');
ELSE
BEGIN
BEGIN TRY
    INSERT sales.SalesOrderItem (Sales_Order_ID, Product_ID, Line_Number, Quantity, Unit_of_Measure, Unit_Price, Net_Amount, Item_Status) VALUES (@Order1, -1, 3, 1, N'EA', 10, 10, N'Open');
    INSERT #Result (id, ok, msg) VALUES (N'B39', 0, N'order item with a Product_ID that does not exist (FK to Team 2)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B39', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_SalesOrderItem_Product_Product_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'order item with a Product_ID that does not exist (FK to Team 2)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;
END;

IF OBJECT_ID(N'sales.FK_SalesOrder_Promotion_Promotion_ID') IS NULL
    INSERT #Result (id, ok, msg) VALUES (N'B40', 2, N'order with a Promotion_ID that does not exist (FK to Team 2)  ->  SKIPPED (Team 2 table / FK not present yet)');
ELSE
BEGIN
BEGIN TRY
    INSERT sales.SalesOrder (Customer_ID, Sales_Channel_ID, Promotion_ID, Calendar_ID, Sales_Order_Number, Order_Status, Total_Amount) VALUES (@Cust2, @Chan, -1, @Cal1, N'T1-SO-B40', N'Confirmed', 1);
    INSERT #Result (id, ok, msg) VALUES (N'B40', 0, N'order with a Promotion_ID that does not exist (FK to Team 2)  ->  was ACCEPTED (expected rejection)');
END TRY
BEGIN CATCH
    INSERT #Result (id, ok, msg) VALUES (N'B40', CASE WHEN ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N'%FK_SalesOrder_Promotion_Promotion_ID%' THEN 1 ELSE 0 END,
        CONCAT(N'order with a Promotion_ID that does not exist (FK to Team 2)  ->  rejected, Msg ', ERROR_NUMBER(), CASE WHEN ERROR_NUMBER() = 547 THEN N'' ELSE CONCAT(N' (expected 547): ', LEFT(ERROR_MESSAGE(), 200)) END));
END CATCH;
END;

END; -- IF @Valid = 1

IF @Valid = 0
    INSERT #Result (id, ok, msg) VALUES (N'B2-B40', 2, N'tests B2 to B40  ->  SKIPPED because B1 failed (the valid base rows they need could not be inserted); fix B1 first');

IF @@TRANCOUNT > 0 ROLLBACK TRAN;
GO

/* ======================================================================
   Cleanup check, identity reseed and result report
   ====================================================================== */
DECLARE @tbl nvarchar(300), @sql nvarchar(600), @rows int = 0, @cnt int;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT tbl FROM #Tables;
OPEN c; FETCH NEXT FROM c INTO @tbl;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @sql = N'SELECT @n = COUNT(*) FROM ' + @tbl;
    EXEC sp_executesql @sql, N'@n int OUTPUT', @n = @cnt OUTPUT;
    SET @rows += @cnt;
    IF @cnt = 0
    BEGIN
        SET @sql = N'DBCC CHECKIDENT (N''' + @tbl + N''', RESEED, 0) WITH NO_INFOMSGS;';
        EXEC (@sql);
    END;
    FETCH NEXT FROM c INTO @tbl;
END;
CLOSE c; DEALLOCATE c;
-- helper rows of Team 2 tables (if they were used by Part B): restore their identity seeds too when the tables are empty
DECLARE c2 CURSOR LOCAL FAST_FORWARD FOR
    SELECT n FROM (VALUES (N'ref.ProductCategory'), (N'core.Brand'), (N'core.Product'), (N'marketing.Promotion')) v(n) WHERE OBJECT_ID(n, N'U') IS NOT NULL;
OPEN c2; FETCH NEXT FROM c2 INTO @tbl;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @sql = N'SELECT @n = COUNT(*) FROM ' + @tbl;
    EXEC sp_executesql @sql, N'@n int OUTPUT', @n = @cnt OUTPUT;
    IF @cnt = 0
    BEGIN
        SET @sql = N'DBCC CHECKIDENT (N''' + @tbl + N''', RESEED, 0) WITH NO_INFOMSGS;';
        EXEC (@sql);
    END;
    FETCH NEXT FROM c2 INTO @tbl;
END;
CLOSE c2; DEALLOCATE c2;
INSERT #Result (id, ok, msg) VALUES (N'Z1', CASE WHEN @rows = 0 THEN 1 ELSE 2 END,
    CASE WHEN @rows = 0 THEN N'all sample data rolled back; Team 1 tables are empty and IDENTITY seeds restored'
         ELSE CONCAT(N'Team 1 tables contain ', @rows, N' rows (real data): identity seeds were NOT reset; make sure the sample data was rolled back') END);

DECLARE @id nvarchar(10), @ok tinyint, @msg nvarchar(500);
DECLARE r CURSOR LOCAL FAST_FORWARD FOR SELECT id, ok, msg FROM #Result ORDER BY seq;
OPEN r; FETCH NEXT FROM r INTO @id, @ok, @msg;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT CONCAT(CASE @ok WHEN 1 THEN N'PASS ' WHEN 2 THEN N'SKIP ' ELSE N'FAIL ' END, @id, N'  ', @msg);
    FETCH NEXT FROM r INTO @id, @ok, @msg;
END;
CLOSE r; DEALLOCATE r;
PRINT CONCAT(N'RESULT: PASS ', (SELECT COUNT(*) FROM #Result WHERE ok = 1), N', SKIP ', (SELECT COUNT(*) FROM #Result WHERE ok = 2),
             N', FAIL ', (SELECT COUNT(*) FROM #Result WHERE ok = 0), N'.');
PRINT N'PASS = test ran and the result was as expected; FAIL = test ran and the result was NOT as expected (real error); SKIP = test was not run because a Team 2 object or a base row it needs is missing (the reason is in the message; not an error).';
GO

SET NOEXEC OFF;
GO
PRINT N'07-Team1-04-Test-Validation.sql finished.';
GO
