﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 2 - Product & Marketing
    Database: FoodDistributionDB
    SQL Server: 2022
    Version : 1.1 (2026-10-28)
    File    : 07-Team2-03-Create-Tables.sql
    Purpose : Create the 24 Team 2 tables (columns, data types, NULL/NOT NULL, IDENTITY, PRIMARY KEY).
    Run order: 3 (after 07-01-Create-Database.sql and 07-02-Create-Schemas.sql)
    Prerequisites: Database FoodDistributionDB and schemas ref, core, marketing exist.
    Source  : 06-Team2-Product-Marketing-Logical-Data-Model.xlsx (Stage 6, #175)
    Schemas : Team 2 proposal for #183 (ref / core / marketing); not yet approved
    Re-run  : Safe. A table is created only if it does not exist. An existing table is NOT altered: if its columns or
              primary key differ from the expected definition, the script reports the difference as an error.
              The verification at the end compares the whole structure with the expected definition.
*/

USE [FoodDistributionDB];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

/* ---- Prerequisite check: stop the whole script if a prerequisite is missing ---- */
IF SCHEMA_ID(N'ref') IS NULL OR SCHEMA_ID(N'core') IS NULL OR SCHEMA_ID(N'marketing') IS NULL
BEGIN
    RAISERROR(N'Schemas ref, core and marketing are required. Run 07-02-Create-Schemas.sql first.', 16, 1);
    SET NOEXEC ON;
END;
GO

/* ========================================================================
   Schema [ref] - Reference tables (no dependencies)
   ======================================================================== */

-- ref.ProductCategory  <-  Stage 6 entity "Product Category"
IF OBJECT_ID(N'ref.ProductCategory', N'U') IS NULL
BEGIN
    CREATE TABLE ref.ProductCategory
    (
        Product_Category_ID  int IDENTITY(1,1)  NOT NULL,
        Parent_Category_ID   int                NULL,
        Category_Code        nvarchar(30)       NOT NULL,
        Category_Name        nvarchar(150)      NOT NULL,
        Category_Level       int                NOT NULL,
        Category_Status      nvarchar(30)       NOT NULL,
        CONSTRAINT PK_ProductCategory PRIMARY KEY CLUSTERED (Product_Category_ID)
    );
    PRINT N'Created table ref.ProductCategory.';
END
ELSE
    PRINT N'Table ref.ProductCategory already exists - not altered; its structure is checked in the verification below.';
GO

-- ref.Package  <-  Stage 6 entity "Package"
IF OBJECT_ID(N'ref.Package', N'U') IS NULL
BEGIN
    CREATE TABLE ref.Package
    (
        Package_ID           int IDENTITY(1,1)  NOT NULL,
        Package_Code         nvarchar(30)       NOT NULL,
        Package_Name         nvarchar(150)      NOT NULL,
        Package_Description  nvarchar(1000)     NULL,
        CONSTRAINT PK_Package PRIMARY KEY CLUSTERED (Package_ID)
    );
    PRINT N'Created table ref.Package.';
END
ELSE
    PRINT N'Table ref.Package already exists - not altered; its structure is checked in the verification below.';
GO

/* ========================================================================
   Schema [core] - Core shared master tables
   ======================================================================== */

-- core.Brand  <-  Stage 6 entity "Brand"
IF OBJECT_ID(N'core.Brand', N'U') IS NULL
BEGIN
    CREATE TABLE core.Brand
    (
        Brand_ID           int IDENTITY(1,1)  NOT NULL,
        Brand_Name         nvarchar(150)      NOT NULL,
        Brand_Code         nvarchar(30)       NOT NULL,
        Brand_Type         nvarchar(30)       NOT NULL,
        Brand_Status       nvarchar(30)       NOT NULL,
        Brand_Start_Date   date               NULL,
        Brand_End_Date     date               NULL,
        Brand_Owner        nvarchar(150)      NULL,
        Brand_Positioning  nvarchar(500)      NULL,
        Target_Market      nvarchar(100)      NULL,
        Target_Segment     nvarchar(100)      NULL,
        Brand_Tagline      nvarchar(250)      NULL,
        Brand_Logo_URL     nvarchar(500)      NULL,
        Brand_Website      nvarchar(500)      NULL,
        Brand_Country      char(2)            NULL,
        CONSTRAINT PK_Brand PRIMARY KEY CLUSTERED (Brand_ID)
    );
    PRINT N'Created table core.Brand.';
END
ELSE
    PRINT N'Table core.Brand already exists - not altered; its structure is checked in the verification below.';
GO

-- core.Product  <-  Stage 6 entity "Product"
IF OBJECT_ID(N'core.Product', N'U') IS NULL
BEGIN
    CREATE TABLE core.Product
    (
        Product_ID            int IDENTITY(1,1)  NOT NULL,
        Product_Code          nvarchar(30)       NOT NULL,
        Product_Name          nvarchar(150)      NOT NULL,
        Product_Description   nvarchar(1000)     NULL,
        Product_Category_ID   int                NOT NULL,
        Brand_ID              int                NOT NULL,
        Product_Type          nvarchar(30)       NOT NULL,
        Unit_Of_Measure       nvarchar(20)       NOT NULL,
        Product_Status        nvarchar(30)       NOT NULL,
        Launch_Date           date               NULL,
        Weight                decimal(10,3)      NULL,
        Tax_Rate              decimal(5,2)       NULL,
        Product_Created_Date  datetime2(0)       NOT NULL,
        Product_Updated_Date  datetime2(0)       NULL,
        CONSTRAINT PK_Product PRIMARY KEY CLUSTERED (Product_ID)
    );
    PRINT N'Created table core.Product.';
END
ELSE
    PRINT N'Table core.Product already exists - not altered; its structure is checked in the verification below.';
GO

-- core.SKU  <-  Stage 6 entity "SKU"
IF OBJECT_ID(N'core.SKU', N'U') IS NULL
BEGIN
    CREATE TABLE core.SKU
    (
        SKU_ID         int IDENTITY(1,1)  NOT NULL,
        Product_ID     int                NOT NULL,
        Package_ID     int                NOT NULL,
        SKU_Code       nvarchar(30)       NOT NULL,
        SKU_Name       nvarchar(150)      NOT NULL,
        Barcode        nvarchar(20)       NULL,
        Weight         decimal(10,3)      NULL,
        Standard_Cost  decimal(18,2)      NULL,
        Currency       char(3)            NULL,
        SKU_Status     nvarchar(30)       NOT NULL,
        CONSTRAINT PK_SKU PRIMARY KEY CLUSTERED (SKU_ID)
    );
    PRINT N'Created table core.SKU.';
END
ELSE
    PRINT N'Table core.SKU already exists - not altered; its structure is checked in the verification below.';
GO

/* ========================================================================
   Schema [marketing] - Marketing tables
   ======================================================================== */

-- marketing.ProductPrice  <-  Stage 6 entity "Product Price"
IF OBJECT_ID(N'marketing.ProductPrice', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.ProductPrice
    (
        Product_Price_ID  int IDENTITY(1,1)  NOT NULL,
        SKU_ID            int                NOT NULL,
        Price_Type        nvarchar(30)       NOT NULL,
        Unit_Price        decimal(18,2)      NOT NULL,
        Currency          char(3)            NOT NULL,
        Effective_From    date               NOT NULL,
        Effective_To      date               NULL,
        Price_Status      nvarchar(30)       NOT NULL,
        CONSTRAINT PK_ProductPrice PRIMARY KEY CLUSTERED (Product_Price_ID)
    );
    PRINT N'Created table marketing.ProductPrice.';
END
ELSE
    PRINT N'Table marketing.ProductPrice already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.CampaignChannel  <-  Stage 6 entity "Campaign Channel"
IF OBJECT_ID(N'marketing.CampaignChannel', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.CampaignChannel
    (
        Campaign_Channel_ID  int IDENTITY(1,1)  NOT NULL,
        Channel_Name         nvarchar(150)      NOT NULL,
        Channel_Type         nvarchar(30)       NOT NULL,
        Channel_Description  nvarchar(1000)     NULL,
        Channel_Status       nvarchar(30)       NOT NULL,
        CONSTRAINT PK_CampaignChannel PRIMARY KEY CLUSTERED (Campaign_Channel_ID)
    );
    PRINT N'Created table marketing.CampaignChannel.';
END
ELSE
    PRINT N'Table marketing.CampaignChannel already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.CampaignAudience  <-  Stage 6 entity "Campaign Audience"
IF OBJECT_ID(N'marketing.CampaignAudience', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.CampaignAudience
    (
        Campaign_Audience_ID  int IDENTITY(1,1)  NOT NULL,
        Audience_Name         nvarchar(150)      NOT NULL,
        Audience_Type         nvarchar(30)       NOT NULL,
        Audience_Description  nvarchar(1000)     NULL,
        Audience_Status       nvarchar(30)       NOT NULL,
        Age_Range             nvarchar(20)       NULL,
        Gender                nvarchar(20)       NULL,
        Geographic_Location   nvarchar(150)      NULL,
        CONSTRAINT PK_CampaignAudience PRIMARY KEY CLUSTERED (Campaign_Audience_ID)
    );
    PRINT N'Created table marketing.CampaignAudience.';
END
ELSE
    PRINT N'Table marketing.CampaignAudience already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.MarketingCampaign  <-  Stage 6 entity "Marketing Campaign"
IF OBJECT_ID(N'marketing.MarketingCampaign', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.MarketingCampaign
    (
        Marketing_Campaign_ID  int IDENTITY(1,1)  NOT NULL,
        Brand_ID               int                NULL,
        Campaign_Name          nvarchar(150)      NOT NULL,
        Campaign_Type          nvarchar(30)       NOT NULL,
        Campaign_Purpose       nvarchar(30)       NOT NULL,
        Campaign_Objective     nvarchar(500)      NULL,
        Start_Date             date               NOT NULL,
        End_Date               date               NULL,
        Campaign_Status        nvarchar(30)       NOT NULL,
        CONSTRAINT PK_MarketingCampaign PRIMARY KEY CLUSTERED (Marketing_Campaign_ID)
    );
    PRINT N'Created table marketing.MarketingCampaign.';
END
ELSE
    PRINT N'Table marketing.MarketingCampaign already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.MarketingCampaignChannel  <-  Stage 6 entity "Marketing Campaign Channel"
IF OBJECT_ID(N'marketing.MarketingCampaignChannel', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.MarketingCampaignChannel
    (
        Marketing_Campaign_ID  int  NOT NULL,
        Campaign_Channel_ID    int  NOT NULL,
        CONSTRAINT PK_MarketingCampaignChannel PRIMARY KEY CLUSTERED (Marketing_Campaign_ID, Campaign_Channel_ID)
    );
    PRINT N'Created table marketing.MarketingCampaignChannel.';
END
ELSE
    PRINT N'Table marketing.MarketingCampaignChannel already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.MarketingCampaignAudience  <-  Stage 6 entity "Marketing Campaign Audience"
IF OBJECT_ID(N'marketing.MarketingCampaignAudience', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.MarketingCampaignAudience
    (
        Marketing_Campaign_ID  int  NOT NULL,
        Campaign_Audience_ID   int  NOT NULL,
        CONSTRAINT PK_MarketingCampaignAudience PRIMARY KEY CLUSTERED (Marketing_Campaign_ID, Campaign_Audience_ID)
    );
    PRINT N'Created table marketing.MarketingCampaignAudience.';
END
ELSE
    PRINT N'Table marketing.MarketingCampaignAudience already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.CampaignBudget  <-  Stage 6 entity "Campaign Budget"
IF OBJECT_ID(N'marketing.CampaignBudget', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.CampaignBudget
    (
        Campaign_Budget_ID      int IDENTITY(1,1)  NOT NULL,
        Marketing_Campaign_ID   int                NOT NULL,
        Campaign_Channel_ID     int                NULL,
        Total_Allocated_Amount  decimal(18,2)      NOT NULL,
        Currency                char(3)            NOT NULL,
        Approval_Date           date               NULL,
        CONSTRAINT PK_CampaignBudget PRIMARY KEY CLUSTERED (Campaign_Budget_ID)
    );
    PRINT N'Created table marketing.CampaignBudget.';
END
ELSE
    PRINT N'Table marketing.CampaignBudget already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.CampaignCost  <-  Stage 6 entity "Campaign Cost"
IF OBJECT_ID(N'marketing.CampaignCost', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.CampaignCost
    (
        Campaign_Cost_ID       int IDENTITY(1,1)  NOT NULL,
        Marketing_Campaign_ID  int                NOT NULL,
        Campaign_Channel_ID    int                NULL,
        Actual_Spent           decimal(18,2)      NOT NULL,
        Currency               char(3)            NOT NULL,
        Cost_Date              date               NOT NULL,
        CONSTRAINT PK_CampaignCost PRIMARY KEY CLUSTERED (Campaign_Cost_ID)
    );
    PRINT N'Created table marketing.CampaignCost.';
END
ELSE
    PRINT N'Table marketing.CampaignCost already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.CampaignResult  <-  Stage 6 entity "Campaign Result"
IF OBJECT_ID(N'marketing.CampaignResult', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.CampaignResult
    (
        Campaign_Result_ID     int IDENTITY(1,1)  NOT NULL,
        Marketing_Campaign_ID  int                NOT NULL,
        Metric_Name            nvarchar(100)      NOT NULL,
        Metric_Value           decimal(18,4)      NOT NULL,
        Measurement_Date       date               NOT NULL,
        CONSTRAINT PK_CampaignResult PRIMARY KEY CLUSTERED (Campaign_Result_ID)
    );
    PRINT N'Created table marketing.CampaignResult.';
END
ELSE
    PRINT N'Table marketing.CampaignResult already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.Promotion  <-  Stage 6 entity "Promotion"
IF OBJECT_ID(N'marketing.Promotion', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.Promotion
    (
        Promotion_ID           int IDENTITY(1,1)  NOT NULL,
        Marketing_Campaign_ID  int                NULL,
        Promotion_Code         nvarchar(30)       NOT NULL,
        Promotion_Name         nvarchar(150)      NOT NULL,
        Promotion_Type         nvarchar(30)       NOT NULL,
        Discount_Type          nvarchar(30)       NOT NULL,
        Discount_Value         decimal(18,2)      NOT NULL,
        Currency               char(3)            NULL,
        Start_Date             date               NOT NULL,
        End_Date               date               NOT NULL,
        Promotion_Status       nvarchar(30)       NOT NULL,
        CONSTRAINT PK_Promotion PRIMARY KEY CLUSTERED (Promotion_ID)
    );
    PRINT N'Created table marketing.Promotion.';
END
ELSE
    PRINT N'Table marketing.Promotion already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.BrandActivity  <-  Stage 6 entity "Brand Activity"
IF OBJECT_ID(N'marketing.BrandActivity', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.BrandActivity
    (
        Brand_Activity_ID     int IDENTITY(1,1)  NOT NULL,
        Brand_ID              int                NOT NULL,
        Activity_Type         nvarchar(30)       NULL,
        Activity_Title        nvarchar(200)      NULL,
        Activity_Description  nvarchar(1000)     NULL,
        Activity_Start_Date   date               NULL,
        Activity_End_Date     date               NULL,
        Activity_Channel      nvarchar(100)      NULL,
        Activity_Status       nvarchar(30)       NULL,
        Activity_Owner        nvarchar(150)      NULL,
        Activity_Cost         decimal(18,2)      NULL,
        Currency              char(3)            NULL,
        Activity_Result       nvarchar(1000)     NULL,
        CONSTRAINT PK_BrandActivity PRIMARY KEY CLUSTERED (Brand_Activity_ID)
    );
    PRINT N'Created table marketing.BrandActivity.';
END
ELSE
    PRINT N'Table marketing.BrandActivity already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.Market  <-  Stage 6 entity "Market"
IF OBJECT_ID(N'marketing.Market', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.Market
    (
        Market_ID           int IDENTITY(1,1)  NOT NULL,
        Market_Code         nvarchar(30)       NOT NULL,
        Market_Name         nvarchar(150)      NOT NULL,
        Market_Type         nvarchar(30)       NULL,
        Market_Description  nvarchar(1000)     NULL,
        Market_Status       nvarchar(30)       NOT NULL,
        CONSTRAINT PK_Market PRIMARY KEY CLUSTERED (Market_ID)
    );
    PRINT N'Created table marketing.Market.';
END
ELSE
    PRINT N'Table marketing.Market already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.MarketSegment  <-  Stage 6 entity "Market Segment"
IF OBJECT_ID(N'marketing.MarketSegment', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.MarketSegment
    (
        Market_Segment_ID    int IDENTITY(1,1)  NOT NULL,
        Market_ID            int                NOT NULL,
        Segment_Code         nvarchar(30)       NOT NULL,
        Segment_Name         nvarchar(150)      NOT NULL,
        Segmentation_Basis   nvarchar(30)       NOT NULL,
        Segment_Description  nvarchar(1000)     NULL,
        Segment_Status       nvarchar(30)       NOT NULL,
        CONSTRAINT PK_MarketSegment PRIMARY KEY CLUSTERED (Market_Segment_ID)
    );
    PRINT N'Created table marketing.MarketSegment.';
END
ELSE
    PRINT N'Table marketing.MarketSegment already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.MarketResearch  <-  Stage 6 entity "Market Research"
IF OBJECT_ID(N'marketing.MarketResearch', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.MarketResearch
    (
        Market_Research_ID  int IDENTITY(1,1)  NOT NULL,
        Market_ID           int                NOT NULL,
        Research_Title      nvarchar(200)      NOT NULL,
        Research_Type       nvarchar(30)       NOT NULL,
        Start_Date          date               NOT NULL,
        End_Date            date               NULL,
        Research_Status     nvarchar(30)       NOT NULL,
        Responsible_Person  nvarchar(150)      NOT NULL,
        Research_Cost       decimal(18,2)      NULL,
        Currency            char(3)            NULL,
        CONSTRAINT PK_MarketResearch PRIMARY KEY CLUSTERED (Market_Research_ID)
    );
    PRINT N'Created table marketing.MarketResearch.';
END
ELSE
    PRINT N'Table marketing.MarketResearch already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.MarketSurvey  <-  Stage 6 entity "Market Survey"
IF OBJECT_ID(N'marketing.MarketSurvey', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.MarketSurvey
    (
        Market_Survey_ID    int IDENTITY(1,1)  NOT NULL,
        Market_Research_ID  int                NOT NULL,
        Market_Segment_ID   int                NULL,
        Survey_Title        nvarchar(200)      NOT NULL,
        Survey_Date         date               NOT NULL,
        Survey_Method       nvarchar(30)       NOT NULL,
        Sample_Size         int                NOT NULL,
        Survey_Status       nvarchar(30)       NOT NULL,
        CONSTRAINT PK_MarketSurvey PRIMARY KEY CLUSTERED (Market_Survey_ID)
    );
    PRINT N'Created table marketing.MarketSurvey.';
END
ELSE
    PRINT N'Table marketing.MarketSurvey already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.ResearchResult  <-  Stage 6 entity "Research Result"
IF OBJECT_ID(N'marketing.ResearchResult', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.ResearchResult
    (
        Research_Result_ID      int IDENTITY(1,1)  NOT NULL,
        Market_Research_ID      int                NOT NULL,
        Result_Title            nvarchar(200)      NOT NULL,
        Result_Summary          nvarchar(2000)     NOT NULL,
        Result_Date             date               NOT NULL,
        Recommendation          nvarchar(2000)     NULL,
        Opportunity_Identified  nvarchar(500)      NULL,
        CONSTRAINT PK_ResearchResult PRIMARY KEY CLUSTERED (Research_Result_ID)
    );
    PRINT N'Created table marketing.ResearchResult.';
END
ELSE
    PRINT N'Table marketing.ResearchResult already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.Competitor  <-  Stage 6 entity "Competitor"
IF OBJECT_ID(N'marketing.Competitor', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.Competitor
    (
        Competitor_ID      int IDENTITY(1,1)  NOT NULL,
        Competitor_Name    nvarchar(150)      NOT NULL,
        Competitor_Type    nvarchar(30)       NOT NULL,
        Market_ID          int                NULL,
        Competitor_Status  nvarchar(30)       NOT NULL,
        CONSTRAINT PK_Competitor PRIMARY KEY CLUSTERED (Competitor_ID)
    );
    PRINT N'Created table marketing.Competitor.';
END
ELSE
    PRINT N'Table marketing.Competitor already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.CompetitorProduct  <-  Stage 6 entity "Competitor Product"
IF OBJECT_ID(N'marketing.CompetitorProduct', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.CompetitorProduct
    (
        Competitor_Product_ID    int IDENTITY(1,1)  NOT NULL,
        Competitor_ID            int                NOT NULL,
        Competitor_Product_Name  nvarchar(150)      NOT NULL,
        Category                 nvarchar(100)      NULL,
        CONSTRAINT PK_CompetitorProduct PRIMARY KEY CLUSTERED (Competitor_Product_ID)
    );
    PRINT N'Created table marketing.CompetitorProduct.';
END
ELSE
    PRINT N'Table marketing.CompetitorProduct already exists - not altered; its structure is checked in the verification below.';
GO

-- marketing.MarketPrice  <-  Stage 6 entity "Market Price"
IF OBJECT_ID(N'marketing.MarketPrice', N'U') IS NULL
BEGIN
    CREATE TABLE marketing.MarketPrice
    (
        Market_Price_ID        int IDENTITY(1,1)  NOT NULL,
        Product_ID             int                NULL,
        Competitor_Product_ID  int                NULL,
        Market_ID              int                NOT NULL,
        Price_Date             datetime2(0)       NOT NULL,
        Price_Value            decimal(18,2)      NOT NULL,
        Currency               char(3)            NOT NULL,
        Price_Source           nvarchar(100)      NOT NULL,
        CONSTRAINT PK_MarketPrice PRIMARY KEY CLUSTERED (Market_Price_ID)
    );
    PRINT N'Created table marketing.MarketPrice.';
END
ELSE
    PRINT N'Table marketing.MarketPrice already exists - not altered; its structure is checked in the verification below.';
GO

/* ---- Verification: existing structure is compared with the expected definition (not assumed to be correct) ---- */
DECLARE @E TABLE (kind nvarchar(10), obj sysname, parent nvarchar(300), sig nvarchar(max));
INSERT @E VALUES
    (N'TABLE', N'ref.ProductCategory', N'ref.ProductCategory', N'Product_Category_ID int NOT NULL IDENTITY; Parent_Category_ID int NULL; Category_Code nvarchar(30) NOT NULL; Category_Name nvarchar(150) NOT NULL; Category_Level int NOT NULL; Category_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_ProductCategory', N'ref.ProductCategory', N'CLUSTERED:Product_Category_ID'),
    (N'TABLE', N'ref.Package', N'ref.Package', N'Package_ID int NOT NULL IDENTITY; Package_Code nvarchar(30) NOT NULL; Package_Name nvarchar(150) NOT NULL; Package_Description nvarchar(1000) NULL'),
    (N'PK', N'PK_Package', N'ref.Package', N'CLUSTERED:Package_ID'),
    (N'TABLE', N'core.Brand', N'core.Brand', N'Brand_ID int NOT NULL IDENTITY; Brand_Name nvarchar(150) NOT NULL; Brand_Code nvarchar(30) NOT NULL; Brand_Type nvarchar(30) NOT NULL; Brand_Status nvarchar(30) NOT NULL; Brand_Start_Date date NULL; Brand_End_Date date NULL; Brand_Owner nvarchar(150) NULL; Brand_Positioning nvarchar(500) NULL; Target_Market nvarchar(100) NULL; Target_Segment nvarchar(100) NULL; Brand_Tagline nvarchar(250) NULL; Brand_Logo_URL nvarchar(500) NULL; Brand_Website nvarchar(500) NULL; Brand_Country char(2) NULL'),
    (N'PK', N'PK_Brand', N'core.Brand', N'CLUSTERED:Brand_ID'),
    (N'TABLE', N'core.Product', N'core.Product', N'Product_ID int NOT NULL IDENTITY; Product_Code nvarchar(30) NOT NULL; Product_Name nvarchar(150) NOT NULL; Product_Description nvarchar(1000) NULL; Product_Category_ID int NOT NULL; Brand_ID int NOT NULL; Product_Type nvarchar(30) NOT NULL; Unit_Of_Measure nvarchar(20) NOT NULL; Product_Status nvarchar(30) NOT NULL; Launch_Date date NULL; Weight decimal(10,3) NULL; Tax_Rate decimal(5,2) NULL; Product_Created_Date datetime2(0) NOT NULL; Product_Updated_Date datetime2(0) NULL'),
    (N'PK', N'PK_Product', N'core.Product', N'CLUSTERED:Product_ID'),
    (N'TABLE', N'core.SKU', N'core.SKU', N'SKU_ID int NOT NULL IDENTITY; Product_ID int NOT NULL; Package_ID int NOT NULL; SKU_Code nvarchar(30) NOT NULL; SKU_Name nvarchar(150) NOT NULL; Barcode nvarchar(20) NULL; Weight decimal(10,3) NULL; Standard_Cost decimal(18,2) NULL; Currency char(3) NULL; SKU_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_SKU', N'core.SKU', N'CLUSTERED:SKU_ID'),
    (N'TABLE', N'marketing.ProductPrice', N'marketing.ProductPrice', N'Product_Price_ID int NOT NULL IDENTITY; SKU_ID int NOT NULL; Price_Type nvarchar(30) NOT NULL; Unit_Price decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Effective_From date NOT NULL; Effective_To date NULL; Price_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_ProductPrice', N'marketing.ProductPrice', N'CLUSTERED:Product_Price_ID'),
    (N'TABLE', N'marketing.CampaignChannel', N'marketing.CampaignChannel', N'Campaign_Channel_ID int NOT NULL IDENTITY; Channel_Name nvarchar(150) NOT NULL; Channel_Type nvarchar(30) NOT NULL; Channel_Description nvarchar(1000) NULL; Channel_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_CampaignChannel', N'marketing.CampaignChannel', N'CLUSTERED:Campaign_Channel_ID'),
    (N'TABLE', N'marketing.CampaignAudience', N'marketing.CampaignAudience', N'Campaign_Audience_ID int NOT NULL IDENTITY; Audience_Name nvarchar(150) NOT NULL; Audience_Type nvarchar(30) NOT NULL; Audience_Description nvarchar(1000) NULL; Audience_Status nvarchar(30) NOT NULL; Age_Range nvarchar(20) NULL; Gender nvarchar(20) NULL; Geographic_Location nvarchar(150) NULL'),
    (N'PK', N'PK_CampaignAudience', N'marketing.CampaignAudience', N'CLUSTERED:Campaign_Audience_ID'),
    (N'TABLE', N'marketing.MarketingCampaign', N'marketing.MarketingCampaign', N'Marketing_Campaign_ID int NOT NULL IDENTITY; Brand_ID int NULL; Campaign_Name nvarchar(150) NOT NULL; Campaign_Type nvarchar(30) NOT NULL; Campaign_Purpose nvarchar(30) NOT NULL; Campaign_Objective nvarchar(500) NULL; Start_Date date NOT NULL; End_Date date NULL; Campaign_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketingCampaign', N'marketing.MarketingCampaign', N'CLUSTERED:Marketing_Campaign_ID'),
    (N'TABLE', N'marketing.MarketingCampaignChannel', N'marketing.MarketingCampaignChannel', N'Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NOT NULL'),
    (N'PK', N'PK_MarketingCampaignChannel', N'marketing.MarketingCampaignChannel', N'CLUSTERED:Marketing_Campaign_ID,Campaign_Channel_ID'),
    (N'TABLE', N'marketing.MarketingCampaignAudience', N'marketing.MarketingCampaignAudience', N'Marketing_Campaign_ID int NOT NULL; Campaign_Audience_ID int NOT NULL'),
    (N'PK', N'PK_MarketingCampaignAudience', N'marketing.MarketingCampaignAudience', N'CLUSTERED:Marketing_Campaign_ID,Campaign_Audience_ID'),
    (N'TABLE', N'marketing.CampaignBudget', N'marketing.CampaignBudget', N'Campaign_Budget_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NULL; Total_Allocated_Amount decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Approval_Date date NULL'),
    (N'PK', N'PK_CampaignBudget', N'marketing.CampaignBudget', N'CLUSTERED:Campaign_Budget_ID'),
    (N'TABLE', N'marketing.CampaignCost', N'marketing.CampaignCost', N'Campaign_Cost_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NULL; Actual_Spent decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Cost_Date date NOT NULL'),
    (N'PK', N'PK_CampaignCost', N'marketing.CampaignCost', N'CLUSTERED:Campaign_Cost_ID'),
    (N'TABLE', N'marketing.CampaignResult', N'marketing.CampaignResult', N'Campaign_Result_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Metric_Name nvarchar(100) NOT NULL; Metric_Value decimal(18,4) NOT NULL; Measurement_Date date NOT NULL'),
    (N'PK', N'PK_CampaignResult', N'marketing.CampaignResult', N'CLUSTERED:Campaign_Result_ID'),
    (N'TABLE', N'marketing.Promotion', N'marketing.Promotion', N'Promotion_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NULL; Promotion_Code nvarchar(30) NOT NULL; Promotion_Name nvarchar(150) NOT NULL; Promotion_Type nvarchar(30) NOT NULL; Discount_Type nvarchar(30) NOT NULL; Discount_Value decimal(18,2) NOT NULL; Currency char(3) NULL; Start_Date date NOT NULL; End_Date date NOT NULL; Promotion_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Promotion', N'marketing.Promotion', N'CLUSTERED:Promotion_ID'),
    (N'TABLE', N'marketing.BrandActivity', N'marketing.BrandActivity', N'Brand_Activity_ID int NOT NULL IDENTITY; Brand_ID int NOT NULL; Activity_Type nvarchar(30) NULL; Activity_Title nvarchar(200) NULL; Activity_Description nvarchar(1000) NULL; Activity_Start_Date date NULL; Activity_End_Date date NULL; Activity_Channel nvarchar(100) NULL; Activity_Status nvarchar(30) NULL; Activity_Owner nvarchar(150) NULL; Activity_Cost decimal(18,2) NULL; Currency char(3) NULL; Activity_Result nvarchar(1000) NULL'),
    (N'PK', N'PK_BrandActivity', N'marketing.BrandActivity', N'CLUSTERED:Brand_Activity_ID'),
    (N'TABLE', N'marketing.Market', N'marketing.Market', N'Market_ID int NOT NULL IDENTITY; Market_Code nvarchar(30) NOT NULL; Market_Name nvarchar(150) NOT NULL; Market_Type nvarchar(30) NULL; Market_Description nvarchar(1000) NULL; Market_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Market', N'marketing.Market', N'CLUSTERED:Market_ID'),
    (N'TABLE', N'marketing.MarketSegment', N'marketing.MarketSegment', N'Market_Segment_ID int NOT NULL IDENTITY; Market_ID int NOT NULL; Segment_Code nvarchar(30) NOT NULL; Segment_Name nvarchar(150) NOT NULL; Segmentation_Basis nvarchar(30) NOT NULL; Segment_Description nvarchar(1000) NULL; Segment_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketSegment', N'marketing.MarketSegment', N'CLUSTERED:Market_Segment_ID'),
    (N'TABLE', N'marketing.MarketResearch', N'marketing.MarketResearch', N'Market_Research_ID int NOT NULL IDENTITY; Market_ID int NOT NULL; Research_Title nvarchar(200) NOT NULL; Research_Type nvarchar(30) NOT NULL; Start_Date date NOT NULL; End_Date date NULL; Research_Status nvarchar(30) NOT NULL; Responsible_Person nvarchar(150) NOT NULL; Research_Cost decimal(18,2) NULL; Currency char(3) NULL'),
    (N'PK', N'PK_MarketResearch', N'marketing.MarketResearch', N'CLUSTERED:Market_Research_ID'),
    (N'TABLE', N'marketing.MarketSurvey', N'marketing.MarketSurvey', N'Market_Survey_ID int NOT NULL IDENTITY; Market_Research_ID int NOT NULL; Market_Segment_ID int NULL; Survey_Title nvarchar(200) NOT NULL; Survey_Date date NOT NULL; Survey_Method nvarchar(30) NOT NULL; Sample_Size int NOT NULL; Survey_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketSurvey', N'marketing.MarketSurvey', N'CLUSTERED:Market_Survey_ID'),
    (N'TABLE', N'marketing.ResearchResult', N'marketing.ResearchResult', N'Research_Result_ID int NOT NULL IDENTITY; Market_Research_ID int NOT NULL; Result_Title nvarchar(200) NOT NULL; Result_Summary nvarchar(2000) NOT NULL; Result_Date date NOT NULL; Recommendation nvarchar(2000) NULL; Opportunity_Identified nvarchar(500) NULL'),
    (N'PK', N'PK_ResearchResult', N'marketing.ResearchResult', N'CLUSTERED:Research_Result_ID'),
    (N'TABLE', N'marketing.Competitor', N'marketing.Competitor', N'Competitor_ID int NOT NULL IDENTITY; Competitor_Name nvarchar(150) NOT NULL; Competitor_Type nvarchar(30) NOT NULL; Market_ID int NULL; Competitor_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Competitor', N'marketing.Competitor', N'CLUSTERED:Competitor_ID'),
    (N'TABLE', N'marketing.CompetitorProduct', N'marketing.CompetitorProduct', N'Competitor_Product_ID int NOT NULL IDENTITY; Competitor_ID int NOT NULL; Competitor_Product_Name nvarchar(150) NOT NULL; Category nvarchar(100) NULL'),
    (N'PK', N'PK_CompetitorProduct', N'marketing.CompetitorProduct', N'CLUSTERED:Competitor_Product_ID'),
    (N'TABLE', N'marketing.MarketPrice', N'marketing.MarketPrice', N'Market_Price_ID int NOT NULL IDENTITY; Product_ID int NULL; Competitor_Product_ID int NULL; Market_ID int NOT NULL; Price_Date datetime2(0) NOT NULL; Price_Value decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Price_Source nvarchar(100) NOT NULL'),
    (N'PK', N'PK_MarketPrice', N'marketing.MarketPrice', N'CLUSTERED:Market_Price_ID');
DECLARE @D TABLE (kind nvarchar(10), obj sysname, problem nvarchar(max));
WITH tbl AS (SELECT OBJECT_ID(n) AS object_id, n AS full_name FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n) WHERE OBJECT_ID(n) IS NOT NULL),
icols AS (
    SELECT i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition,
           STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS keys,
           STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS incs
    FROM sys.indexes i
    JOIN tbl t ON t.object_id = i.object_id
    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
    GROUP BY i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition),
act AS (
    SELECT N'TABLE' AS kind, t.full_name AS obj, t.full_name AS parent,
           (SELECT STRING_AGG(CONCAT(CAST(c.name AS nvarchar(max)), N' ', CASE WHEN ty.name IN (N'nvarchar', N'nchar') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length / 2 AS nvarchar(10)) END + N')' WHEN ty.name IN (N'varchar', N'char') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length AS nvarchar(10)) END + N')' WHEN ty.name IN (N'decimal', N'numeric') THEN ty.name + N'(' + CAST(c.precision AS nvarchar(10)) + N',' + CAST(c.scale AS nvarchar(10)) + N')' WHEN ty.name = N'datetime2' THEN N'datetime2(' + CAST(c.scale AS nvarchar(10)) + N')' ELSE ty.name END, IIF(c.is_nullable = 1, N' NULL', N' NOT NULL'), IIF(c.is_identity = 1, N' IDENTITY', N'')), N'; ')
                   WITHIN GROUP (ORDER BY c.column_id)
            FROM sys.columns c JOIN sys.types ty ON ty.user_type_id = c.user_type_id WHERE c.object_id = t.object_id) AS sig
    FROM tbl t
    UNION ALL
    SELECT CASE WHEN x.is_primary_key = 1 THEN N'PK' WHEN x.is_unique_constraint = 1 THEN N'UQ' WHEN x.is_unique = 1 THEN N'UX' ELSE N'IX' END,
           x.name, t.full_name,
           CASE WHEN x.is_primary_key = 1 THEN CONCAT(x.type_desc, N':', x.keys)
                ELSE CONCAT(x.type_desc, N'|', IIF(x.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|', x.keys, N'|', x.incs, N'|', x.filter_definition) END
    FROM icols x JOIN tbl t ON t.object_id = x.object_id
    UNION ALL
    SELECT N'CK', k.name, t.full_name, k.definition FROM sys.check_constraints k JOIN tbl t ON t.object_id = k.parent_object_id
    UNION ALL
    SELECT N'DF', d.name, t.full_name, CONCAT(col.name, N'=', d.definition)
    FROM sys.default_constraints d JOIN tbl t ON t.object_id = d.parent_object_id
    JOIN sys.columns col ON col.object_id = d.parent_object_id AND col.column_id = d.parent_column_id
    UNION ALL
    SELECT N'FK', f.name, t.full_name,
           CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
                  OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
                  STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
                  f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
    FROM sys.foreign_keys f JOIN tbl t ON t.object_id = f.parent_object_id
    JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
    JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
    JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
    GROUP BY f.name, t.full_name, f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc
    UNION ALL
    SELECT N'TR', tr.name, t.full_name,
           CONCAT(t.full_name, N'|', IIF(tr.is_instead_of_trigger = 1, N'INSTEAD OF', N'AFTER'), N'|',
                  (SELECT STRING_AGG(CAST(te.type_desc AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY te.type_desc) FROM sys.trigger_events te WHERE te.object_id = tr.object_id),
                  N'|', IIF(tr.is_disabled = 1, N'DISABLED', N'ENABLED'))
    FROM sys.triggers tr JOIN tbl t ON t.object_id = tr.parent_id)
INSERT @D
SELECT COALESCE(e.kind, a.kind), COALESCE(e.obj, a.obj),
       CASE WHEN a.obj IS NULL THEN N'missing'
            WHEN e.obj IS NULL THEN N'unexpected object: ' + a.sig
            ELSE N'expected [' + e.sig + N'] actual [' + a.sig + N']' END
FROM @E e
FULL JOIN (SELECT * FROM act WHERE kind IN (N'TABLE', N'PK')) a
  ON a.kind = e.kind AND a.obj COLLATE Latin1_General_BIN2 = e.obj COLLATE Latin1_General_BIN2 AND a.parent COLLATE Latin1_General_BIN2 = e.parent COLLATE Latin1_General_BIN2
WHERE a.obj IS NULL OR e.obj IS NULL OR a.sig COLLATE Latin1_General_BIN2 <> e.sig COLLATE Latin1_General_BIN2;
DECLARE @nE int = (SELECT COUNT(*) FROM @E), @nD int = (SELECT COUNT(*) FROM @D), @line nvarchar(max);
IF @nD = 0
    PRINT CONCAT(N'Verification passed: all ', @nE, N' tables and primary keys (columns, data types, lengths, NULL/NOT NULL, IDENTITY, PK columns) match the expected definition.');
ELSE
BEGIN
    DECLARE d CURSOR LOCAL FAST_FORWARD FOR SELECT CONCAT(N'  DIFFERENCE ', kind, N' ', obj, N': ', problem) FROM @D;
    OPEN d; FETCH NEXT FROM d INTO @line;
    WHILE @@FETCH_STATUS = 0 BEGIN PRINT @line; FETCH NEXT FROM d INTO @line; END;
    CLOSE d; DEALLOCATE d;
    RAISERROR(N'Verification FAILED: %d object(s) differ from the expected definition (see the lines above).', 16, 1, @nD);
END;
GO

SET NOEXEC OFF;
GO
PRINT N'07-Team2-03-Create-Tables.sql finished.';
GO
