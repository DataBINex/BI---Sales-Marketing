﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 2 - Product & Marketing
    Database: FoodDistributionDB
    SQL Server: 2022
    Version : 1.1 (2026-10-28)
    File    : 07-Team2-05-Create-Indexes.sql
    Purpose : Nonclustered indexes that support FOREIGN KEY joins and the frequent report queries.
    Run order: 5 (after 07-Team2-04-Create-Constraints.sql)
    Prerequisites: All 24 Team 2 tables exist (07-Team2-03-Create-Tables.sql).
    Source  : 06-Team2-Product-Marketing-Logical-Data-Model.xlsx (Stage 6, #175)
    Schemas : Team 2 proposal for #183 (ref / core / marketing); not yet approved
    Re-run  : Safe. An index is created if missing. If one exists with the same name but different key columns,
              column order, INCLUDE columns, uniqueness, type or filter, it is dropped and recreated.
              The verification at the end compares the whole structure with the expected definition.
*/

USE [FoodDistributionDB];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

/* ---- Prerequisite check: stop the whole script if a prerequisite is missing ---- */
IF OBJECT_ID(N'ref.ProductCategory', N'U') IS NULL
   OR OBJECT_ID(N'ref.Package', N'U') IS NULL
   OR OBJECT_ID(N'core.Brand', N'U') IS NULL
   OR OBJECT_ID(N'core.Product', N'U') IS NULL
   OR OBJECT_ID(N'core.SKU', N'U') IS NULL
   OR OBJECT_ID(N'marketing.ProductPrice', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignChannel', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignAudience', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketingCampaign', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketingCampaignChannel', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketingCampaignAudience', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignBudget', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignCost', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignResult', N'U') IS NULL
   OR OBJECT_ID(N'marketing.Promotion', N'U') IS NULL
   OR OBJECT_ID(N'marketing.BrandActivity', N'U') IS NULL
   OR OBJECT_ID(N'marketing.Market', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketSegment', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketResearch', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketSurvey', N'U') IS NULL
   OR OBJECT_ID(N'marketing.ResearchResult', N'U') IS NULL
   OR OBJECT_ID(N'marketing.Competitor', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CompetitorProduct', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketPrice', N'U') IS NULL
BEGIN
    RAISERROR(N'Team 2 tables are missing. Run 07-Team2-03-Create-Tables.sql first.', 16, 1);
    SET NOEXEC ON;
END;
GO

/* ========================================================================
   Nonclustered indexes (evaluated with 07-Team2-07-Index-Evaluation.sql)
   ======================================================================== */

-- FK R29
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'ref.ProductCategory') AND i.name = N'IX_ProductCategory_Parent_Category_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Parent_Category_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_ProductCategory_Parent_Category_ID ON ref.ProductCategory;
    PRINT N'IX_ProductCategory_Parent_Category_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_ProductCategory_Parent_Category_ID ON ref.ProductCategory (Parent_Category_ID);
    PRINT N'Created IX_ProductCategory_Parent_Category_ID.';
END;
GO

-- FK R01
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.Product') AND i.name = N'IX_Product_Product_Category_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Product_Category_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_Product_Product_Category_ID ON core.Product;
    PRINT N'IX_Product_Product_Category_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_Product_Product_Category_ID ON core.Product (Product_Category_ID);
    PRINT N'Created IX_Product_Product_Category_ID.';
END;
GO

-- FK R02
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.Product') AND i.name = N'IX_Product_Brand_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Brand_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_Product_Brand_ID ON core.Product;
    PRINT N'IX_Product_Brand_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_Product_Brand_ID ON core.Product (Brand_ID);
    PRINT N'Created IX_Product_Brand_ID.';
END;
GO

-- FK R03
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.SKU') AND i.name = N'IX_SKU_Product_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Product_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_SKU_Product_ID ON core.SKU;
    PRINT N'IX_SKU_Product_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_SKU_Product_ID ON core.SKU (Product_ID);
    PRINT N'Created IX_SKU_Product_ID.';
END;
GO

-- FK R05
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.SKU') AND i.name = N'IX_SKU_Package_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Package_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_SKU_Package_ID ON core.SKU;
    PRINT N'IX_SKU_Package_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_SKU_Package_ID ON core.SKU (Package_ID);
    PRINT N'Created IX_SKU_Package_ID.';
END;
GO

-- FK R06
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.ProductPrice') AND i.name = N'IX_ProductPrice_SKU_ID_Price_Type_Effective_From'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|SKU_ID,Price_Type,Effective_From||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_ProductPrice_SKU_ID_Price_Type_Effective_From ON marketing.ProductPrice;
    PRINT N'IX_ProductPrice_SKU_ID_Price_Type_Effective_From: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_ProductPrice_SKU_ID_Price_Type_Effective_From ON marketing.ProductPrice (SKU_ID, Price_Type, Effective_From);
    PRINT N'Created IX_ProductPrice_SKU_ID_Price_Type_Effective_From.';
END;
GO

-- FK R08
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketingCampaign') AND i.name = N'IX_MarketingCampaign_Brand_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Brand_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketingCampaign_Brand_ID ON marketing.MarketingCampaign;
    PRINT N'IX_MarketingCampaign_Brand_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketingCampaign_Brand_ID ON marketing.MarketingCampaign (Brand_ID);
    PRINT N'Created IX_MarketingCampaign_Brand_ID.';
END;
GO

-- FK R09b
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketingCampaignChannel') AND i.name = N'IX_MarketingCampaignChannel_Campaign_Channel_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketingCampaignChannel_Campaign_Channel_ID ON marketing.MarketingCampaignChannel;
    PRINT N'IX_MarketingCampaignChannel_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketingCampaignChannel_Campaign_Channel_ID ON marketing.MarketingCampaignChannel (Campaign_Channel_ID);
    PRINT N'Created IX_MarketingCampaignChannel_Campaign_Channel_ID.';
END;
GO

-- FK R10b
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketingCampaignAudience') AND i.name = N'IX_MarketingCampaignAudience_Campaign_Audience_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Campaign_Audience_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketingCampaignAudience_Campaign_Audience_ID ON marketing.MarketingCampaignAudience;
    PRINT N'IX_MarketingCampaignAudience_Campaign_Audience_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketingCampaignAudience_Campaign_Audience_ID ON marketing.MarketingCampaignAudience (Campaign_Audience_ID);
    PRINT N'Created IX_MarketingCampaignAudience_Campaign_Audience_ID.';
END;
GO

-- FK R11 و FK قاعده‌ی R27
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.CampaignBudget') AND i.name = N'IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID ON marketing.CampaignBudget;
    PRINT N'IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID ON marketing.CampaignBudget (Marketing_Campaign_ID, Campaign_Channel_ID);
    PRINT N'Created IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID.';
END;
GO

-- FK R12 و FK قاعده‌ی R28
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.CampaignCost') AND i.name = N'IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID ON marketing.CampaignCost;
    PRINT N'IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID ON marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID);
    PRINT N'Created IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID.';
END;
GO

-- FK R28 و داشبورد مرحله ۳ (هزینه به تفکیک کانال و دوره، Q1 و Q3)  [v1.1: جدید]
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.CampaignCost') AND i.name = N'IX_CampaignCost_Campaign_Channel_ID_Cost_Date'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID,Cost_Date|Actual_Spent,Currency|([Campaign_Channel_ID] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_CampaignCost_Campaign_Channel_ID_Cost_Date ON marketing.CampaignCost;
    PRINT N'IX_CampaignCost_Campaign_Channel_ID_Cost_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_CampaignCost_Campaign_Channel_ID_Cost_Date ON marketing.CampaignCost (Campaign_Channel_ID, Cost_Date)
        INCLUDE (Actual_Spent, Currency)
        WHERE Campaign_Channel_ID IS NOT NULL;
    PRINT N'Created IX_CampaignCost_Campaign_Channel_ID_Cost_Date.';
END;
GO

-- FK R14
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.Promotion') AND i.name = N'IX_Promotion_Marketing_Campaign_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_Promotion_Marketing_Campaign_ID ON marketing.Promotion;
    PRINT N'IX_Promotion_Marketing_Campaign_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_Promotion_Marketing_Campaign_ID ON marketing.Promotion (Marketing_Campaign_ID);
    PRINT N'Created IX_Promotion_Marketing_Campaign_ID.';
END;
GO

-- FK R07
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.BrandActivity') AND i.name = N'IX_BrandActivity_Brand_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Brand_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_BrandActivity_Brand_ID ON marketing.BrandActivity;
    PRINT N'IX_BrandActivity_Brand_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_BrandActivity_Brand_ID ON marketing.BrandActivity (Brand_ID);
    PRINT N'Created IX_BrandActivity_Brand_ID.';
END;
GO

-- FK R16
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketSegment') AND i.name = N'IX_MarketSegment_Market_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Market_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketSegment_Market_ID ON marketing.MarketSegment;
    PRINT N'IX_MarketSegment_Market_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketSegment_Market_ID ON marketing.MarketSegment (Market_ID);
    PRINT N'Created IX_MarketSegment_Market_ID.';
END;
GO

-- FK R17
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketResearch') AND i.name = N'IX_MarketResearch_Market_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Market_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketResearch_Market_ID ON marketing.MarketResearch;
    PRINT N'IX_MarketResearch_Market_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketResearch_Market_ID ON marketing.MarketResearch (Market_ID);
    PRINT N'Created IX_MarketResearch_Market_ID.';
END;
GO

-- FK R21
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketSurvey') AND i.name = N'IX_MarketSurvey_Market_Research_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketSurvey_Market_Research_ID ON marketing.MarketSurvey;
    PRINT N'IX_MarketSurvey_Market_Research_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketSurvey_Market_Research_ID ON marketing.MarketSurvey (Market_Research_ID);
    PRINT N'Created IX_MarketSurvey_Market_Research_ID.';
END;
GO

-- FK R20 (اختیاری
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketSurvey') AND i.name = N'IX_MarketSurvey_Market_Segment_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Market_Segment_ID||([Market_Segment_ID] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketSurvey_Market_Segment_ID ON marketing.MarketSurvey;
    PRINT N'IX_MarketSurvey_Market_Segment_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketSurvey_Market_Segment_ID ON marketing.MarketSurvey (Market_Segment_ID)
        WHERE Market_Segment_ID IS NOT NULL;
    PRINT N'Created IX_MarketSurvey_Market_Segment_ID.';
END;
GO

-- FK R22
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.ResearchResult') AND i.name = N'IX_ResearchResult_Market_Research_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_ResearchResult_Market_Research_ID ON marketing.ResearchResult;
    PRINT N'IX_ResearchResult_Market_Research_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_ResearchResult_Market_Research_ID ON marketing.ResearchResult (Market_Research_ID);
    PRINT N'Created IX_ResearchResult_Market_Research_ID.';
END;
GO

-- FK R19 (اختیاری
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.Competitor') AND i.name = N'IX_Competitor_Market_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Market_ID||([Market_ID] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_Competitor_Market_ID ON marketing.Competitor;
    PRINT N'IX_Competitor_Market_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_Competitor_Market_ID ON marketing.Competitor (Market_ID)
        WHERE Market_ID IS NOT NULL;
    PRINT N'Created IX_Competitor_Market_ID.';
END;
GO

-- FK R25
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.CompetitorProduct') AND i.name = N'IX_CompetitorProduct_Competitor_ID'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Competitor_ID||' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_CompetitorProduct_Competitor_ID ON marketing.CompetitorProduct;
    PRINT N'IX_CompetitorProduct_Competitor_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_CompetitorProduct_Competitor_ID ON marketing.CompetitorProduct (Competitor_ID);
    PRINT N'Created IX_CompetitorProduct_Competitor_ID.';
END;
GO

-- FK R18  [v1.1: ستون‌های INCLUDE اضافه شد]
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketPrice') AND i.name = N'IX_MarketPrice_Market_ID_Price_Date'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Market_ID,Price_Date|Competitor_Product_ID,Currency,Price_Value,Product_ID|' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketPrice_Market_ID_Price_Date ON marketing.MarketPrice;
    PRINT N'IX_MarketPrice_Market_ID_Price_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketPrice_Market_ID_Price_Date ON marketing.MarketPrice (Market_ID, Price_Date)
        INCLUDE (Product_ID, Competitor_Product_ID, Price_Value, Currency);
    PRINT N'Created IX_MarketPrice_Market_ID_Price_Date.';
END;
GO

-- FK R04
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketPrice') AND i.name = N'IX_MarketPrice_Product_ID_Price_Date'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Product_ID,Price_Date||([Product_ID] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketPrice_Product_ID_Price_Date ON marketing.MarketPrice;
    PRINT N'IX_MarketPrice_Product_ID_Price_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketPrice_Product_ID_Price_Date ON marketing.MarketPrice (Product_ID, Price_Date)
        WHERE Product_ID IS NOT NULL;
    PRINT N'Created IX_MarketPrice_Product_ID_Price_Date.';
END;
GO

-- FK R26
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketPrice') AND i.name = N'IX_MarketPrice_Competitor_Product_ID_Price_Date'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|NONUNIQUE|Competitor_Product_ID,Price_Date||([Competitor_Product_ID] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX IX_MarketPrice_Competitor_Product_ID_Price_Date ON marketing.MarketPrice;
    PRINT N'IX_MarketPrice_Competitor_Product_ID_Price_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE NONCLUSTERED INDEX IX_MarketPrice_Competitor_Product_ID_Price_Date ON marketing.MarketPrice (Competitor_Product_ID, Price_Date)
        WHERE Competitor_Product_ID IS NOT NULL;
    PRINT N'Created IX_MarketPrice_Competitor_Product_ID_Price_Date.';
END;
GO

/* ---- Verification: existing structure is compared with the expected definition (not assumed to be correct) ---- */
DECLARE @E TABLE (kind nvarchar(10), obj sysname, parent nvarchar(300), sig nvarchar(max));
INSERT @E VALUES
    (N'IX', N'IX_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'NONCLUSTERED|NONUNIQUE|Parent_Category_ID||'),
    (N'IX', N'IX_Product_Product_Category_ID', N'core.Product', N'NONCLUSTERED|NONUNIQUE|Product_Category_ID||'),
    (N'IX', N'IX_Product_Brand_ID', N'core.Product', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_SKU_Product_ID', N'core.SKU', N'NONCLUSTERED|NONUNIQUE|Product_ID||'),
    (N'IX', N'IX_SKU_Package_ID', N'core.SKU', N'NONCLUSTERED|NONUNIQUE|Package_ID||'),
    (N'IX', N'IX_ProductPrice_SKU_ID_Price_Type_Effective_From', N'marketing.ProductPrice', N'NONCLUSTERED|NONUNIQUE|SKU_ID,Price_Type,Effective_From||'),
    (N'IX', N'IX_MarketingCampaign_Brand_ID', N'marketing.MarketingCampaign', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_MarketingCampaignChannel_Campaign_Channel_ID', N'marketing.MarketingCampaignChannel', N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID||'),
    (N'IX', N'IX_MarketingCampaignAudience_Campaign_Audience_ID', N'marketing.MarketingCampaignAudience', N'NONCLUSTERED|NONUNIQUE|Campaign_Audience_ID||'),
    (N'IX', N'IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignBudget', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||'),
    (N'IX', N'IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignCost', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||'),
    (N'IX', N'IX_CampaignCost_Campaign_Channel_ID_Cost_Date', N'marketing.CampaignCost', N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID,Cost_Date|Actual_Spent,Currency|([Campaign_Channel_ID] IS NOT NULL)'),
    (N'IX', N'IX_Promotion_Marketing_Campaign_ID', N'marketing.Promotion', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID||'),
    (N'IX', N'IX_BrandActivity_Brand_ID', N'marketing.BrandActivity', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_MarketSegment_Market_ID', N'marketing.MarketSegment', N'NONCLUSTERED|NONUNIQUE|Market_ID||'),
    (N'IX', N'IX_MarketResearch_Market_ID', N'marketing.MarketResearch', N'NONCLUSTERED|NONUNIQUE|Market_ID||'),
    (N'IX', N'IX_MarketSurvey_Market_Research_ID', N'marketing.MarketSurvey', N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||'),
    (N'IX', N'IX_MarketSurvey_Market_Segment_ID', N'marketing.MarketSurvey', N'NONCLUSTERED|NONUNIQUE|Market_Segment_ID||([Market_Segment_ID] IS NOT NULL)'),
    (N'IX', N'IX_ResearchResult_Market_Research_ID', N'marketing.ResearchResult', N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||'),
    (N'IX', N'IX_Competitor_Market_ID', N'marketing.Competitor', N'NONCLUSTERED|NONUNIQUE|Market_ID||([Market_ID] IS NOT NULL)'),
    (N'IX', N'IX_CompetitorProduct_Competitor_ID', N'marketing.CompetitorProduct', N'NONCLUSTERED|NONUNIQUE|Competitor_ID||'),
    (N'IX', N'IX_MarketPrice_Market_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Market_ID,Price_Date|Competitor_Product_ID,Currency,Price_Value,Product_ID|'),
    (N'IX', N'IX_MarketPrice_Product_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Product_ID,Price_Date||([Product_ID] IS NOT NULL)'),
    (N'IX', N'IX_MarketPrice_Competitor_Product_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Competitor_Product_ID,Price_Date||([Competitor_Product_ID] IS NOT NULL)');
DECLARE @D TABLE (kind nvarchar(10), obj sysname, problem nvarchar(max));
WITH tbl AS (SELECT OBJECT_ID(n) AS object_id, n AS full_name FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n) WHERE OBJECT_ID(n) IS NOT NULL),
icols AS (
    SELECT i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition,
           STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS keys,
           STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS incs
    FROM sys.indexes i
    JOIN tbl t ON t.object_id = i.object_id
    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
    GROUP BY i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition),
act AS (
    SELECT N'TABLE' AS kind, t.full_name AS obj, t.full_name AS parent,
           (SELECT STRING_AGG(CONCAT(CAST(c.name AS nvarchar(max)), N' ', CASE WHEN ty.name IN (N'nvarchar', N'nchar') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length / 2 AS nvarchar(10)) END + N')' WHEN ty.name IN (N'varchar', N'char') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length AS nvarchar(10)) END + N')' WHEN ty.name IN (N'decimal', N'numeric') THEN ty.name + N'(' + CAST(c.precision AS nvarchar(10)) + N',' + CAST(c.scale AS nvarchar(10)) + N')' WHEN ty.name = N'datetime2' THEN N'datetime2(' + CAST(c.scale AS nvarchar(10)) + N')' ELSE ty.name END, IIF(c.is_nullable = 1, N' NULL', N' NOT NULL'), IIF(c.is_identity = 1, N' IDENTITY', N'')), N'; ')
                   WITHIN GROUP (ORDER BY c.column_id)
            FROM sys.columns c JOIN sys.types ty ON ty.user_type_id = c.user_type_id WHERE c.object_id = t.object_id) AS sig
    FROM tbl t
    UNION ALL
    SELECT CASE WHEN x.is_primary_key = 1 THEN N'PK' WHEN x.is_unique_constraint = 1 THEN N'UQ' WHEN x.is_unique = 1 THEN N'UX' ELSE N'IX' END,
           x.name, t.full_name,
           CASE WHEN x.is_primary_key = 1 THEN CONCAT(x.type_desc, N':', x.keys)
                ELSE CONCAT(x.type_desc, N'|', IIF(x.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|', x.keys, N'|', x.incs, N'|', x.filter_definition) END
    FROM icols x JOIN tbl t ON t.object_id = x.object_id
    UNION ALL
    SELECT N'CK', k.name, t.full_name, k.definition FROM sys.check_constraints k JOIN tbl t ON t.object_id = k.parent_object_id
    UNION ALL
    SELECT N'DF', d.name, t.full_name, CONCAT(col.name, N'=', d.definition)
    FROM sys.default_constraints d JOIN tbl t ON t.object_id = d.parent_object_id
    JOIN sys.columns col ON col.object_id = d.parent_object_id AND col.column_id = d.parent_column_id
    UNION ALL
    SELECT N'FK', f.name, t.full_name,
           CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
                  OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
                  STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
                  f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
    FROM sys.foreign_keys f JOIN tbl t ON t.object_id = f.parent_object_id
    JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
    JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
    JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
    GROUP BY f.name, t.full_name, f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc
    UNION ALL
    SELECT N'TR', tr.name, t.full_name,
           CONCAT(t.full_name, N'|', IIF(tr.is_instead_of_trigger = 1, N'INSTEAD OF', N'AFTER'), N'|',
                  (SELECT STRING_AGG(CAST(te.type_desc AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY te.type_desc) FROM sys.trigger_events te WHERE te.object_id = tr.object_id),
                  N'|', IIF(tr.is_disabled = 1, N'DISABLED', N'ENABLED'))
    FROM sys.triggers tr JOIN tbl t ON t.object_id = tr.parent_id)
INSERT @D
SELECT COALESCE(e.kind, a.kind), COALESCE(e.obj, a.obj),
       CASE WHEN a.obj IS NULL THEN N'missing'
            WHEN e.obj IS NULL THEN N'unexpected object: ' + a.sig
            ELSE N'expected [' + e.sig + N'] actual [' + a.sig + N']' END
FROM @E e
FULL JOIN (SELECT * FROM act WHERE kind IN (N'IX')) a
  ON a.kind = e.kind AND a.obj COLLATE Latin1_General_BIN2 = e.obj COLLATE Latin1_General_BIN2 AND a.parent COLLATE Latin1_General_BIN2 = e.parent COLLATE Latin1_General_BIN2
WHERE a.obj IS NULL OR e.obj IS NULL OR a.sig COLLATE Latin1_General_BIN2 <> e.sig COLLATE Latin1_General_BIN2;
DECLARE @nE int = (SELECT COUNT(*) FROM @E), @nD int = (SELECT COUNT(*) FROM @D), @line nvarchar(max);
IF @nD = 0
    PRINT CONCAT(N'Verification passed: all ', @nE, N' nonclustered indexes (key columns and order, INCLUDE columns, uniqueness, type, filter) match the expected definition.');
ELSE
BEGIN
    DECLARE d CURSOR LOCAL FAST_FORWARD FOR SELECT CONCAT(N'  DIFFERENCE ', kind, N' ', obj, N': ', problem) FROM @D;
    OPEN d; FETCH NEXT FROM d INTO @line;
    WHILE @@FETCH_STATUS = 0 BEGIN PRINT @line; FETCH NEXT FROM d INTO @line; END;
    CLOSE d; DEALLOCATE d;
    RAISERROR(N'Verification FAILED: %d object(s) differ from the expected definition (see the lines above).', 16, 1, @nD);
END;
GO

SET NOEXEC OFF;
GO
PRINT N'07-Team2-05-Create-Indexes.sql finished.';
GO
