﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 2 - Product & Marketing
    Database: FoodDistributionDB
    SQL Server: 2022
    Version : 1.1 (2026-10-28)
    File    : 07-Team2-07-Index-Evaluation.sql
    Purpose : Test only (not part of the build). Loads realistic volumes of sample data inside a
              transaction, runs the frequent report queries with STATISTICS IO and the actual
              execution plan (in SSMS: Ctrl+M before running), then ROLLS BACK. Nothing is left behind.
              Each query runs twice: as the optimizer chooses, and forced to the clustered index
              (WITH (INDEX(1))) to show the cost without the nonclustered index.
    Run order: optional, after 07-Team2-05-Create-Indexes.sql, on an EMPTY Team 2 database.
*/

USE [FoodDistributionDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF EXISTS (SELECT 1 FROM marketing.CampaignCost) OR EXISTS (SELECT 1 FROM marketing.ProductPrice) OR EXISTS (SELECT 1 FROM marketing.MarketPrice)
BEGIN
    RAISERROR(N'Index evaluation skipped: Team 2 tables already contain data. Run it on an empty database only.', 16, 1);
    SET NOEXEC ON;
END;
GO

BEGIN TRANSACTION;

/* ---- Sample data (deterministic). Volumes: 2,000 products, 6,000 SKUs, 48,000 official prices,
        2,000 campaigns on 12 channels, 6,000 budgets, 100,000 costs, 30 markets, 90,000 market prices ---- */
;WITH n AS (SELECT TOP (200000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS i FROM sys.all_columns a CROSS JOIN sys.all_columns b)
SELECT i INTO #n FROM n;

SET IDENTITY_INSERT ref.ProductCategory ON;
INSERT ref.ProductCategory (Product_Category_ID, Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status)
SELECT i, NULL, CONCAT(N'C', i), CONCAT(N'Category ', i), 1, N'Active' FROM #n WHERE i <= 10;
INSERT ref.ProductCategory (Product_Category_ID, Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status)
SELECT 10 + i, 1 + (i - 1) % 10, CONCAT(N'C', 10 + i), CONCAT(N'Sub ', i), 2, N'Active' FROM #n WHERE i <= 50;
SET IDENTITY_INSERT ref.ProductCategory OFF;

SET IDENTITY_INSERT ref.Package ON;
INSERT ref.Package (Package_ID, Package_Code, Package_Name) SELECT i, CONCAT(N'P', i), CONCAT(N'Package ', i) FROM #n WHERE i <= 10;
SET IDENTITY_INSERT ref.Package OFF;

SET IDENTITY_INSERT core.Brand ON;
INSERT core.Brand (Brand_ID, Brand_Name, Brand_Code, Brand_Type, Brand_Status) SELECT i, CONCAT(N'Brand ', i), CONCAT(N'B', i), N'Product', N'Active' FROM #n WHERE i <= 20;
SET IDENTITY_INSERT core.Brand OFF;

SET IDENTITY_INSERT core.Product ON;
INSERT core.Product (Product_ID, Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
SELECT i, CONCAT(N'PRD-', i), CONCAT(N'Product ', i), 11 + (i - 1) % 50, 1 + (i - 1) % 20, N'Physical', N'PCS', N'Active' FROM #n WHERE i <= 2000;
SET IDENTITY_INSERT core.Product OFF;

SET IDENTITY_INSERT core.SKU ON;
INSERT core.SKU (SKU_ID, Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status)
SELECT i, 1 + (i - 1) % 2000, 1 + (i - 1) % 10, CONCAT(N'SKU-', i), CONCAT(N'SKU ', i), N'Active' FROM #n WHERE i <= 6000;
SET IDENTITY_INSERT core.SKU OFF;

-- 4 consecutive, non-overlapping quarters per SKU and price type; the last one is open-ended
INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status)
SELECT s.i, t.Price_Type, 100000 + s.i * 10 + q.q * 1000, 'IRR',
       DATEADD(QUARTER, q.q - 1, CAST('2026-01-01' AS date)),
       CASE WHEN q.q = 4 THEN NULL ELSE DATEADD(DAY, -1, DATEADD(QUARTER, q.q, CAST('2026-01-01' AS date))) END, N'Active'
FROM #n s CROSS JOIN (VALUES (1), (2), (3), (4)) q(q) CROSS JOIN (VALUES (N'List'), (N'Wholesale')) t(Price_Type)
WHERE s.i <= 6000;

SET IDENTITY_INSERT marketing.CampaignChannel ON;
INSERT marketing.CampaignChannel (Campaign_Channel_ID, Channel_Name, Channel_Type, Channel_Status) SELECT i, CONCAT(N'Channel ', i), N'Digital', N'Active' FROM #n WHERE i <= 12;
SET IDENTITY_INSERT marketing.CampaignChannel OFF;

SET IDENTITY_INSERT marketing.MarketingCampaign ON;
INSERT marketing.MarketingCampaign (Marketing_Campaign_ID, Brand_ID, Campaign_Name, Campaign_Type, Campaign_Purpose, Start_Date, End_Date, Campaign_Status)
SELECT i, 1 + (i - 1) % 20, CONCAT(N'Campaign ', i), N'Awareness', N'Marketing', DATEADD(DAY, i % 300, CAST('2025-01-01' AS date)), NULL, N'Active' FROM #n WHERE i <= 2000;
SET IDENTITY_INSERT marketing.MarketingCampaign OFF;

-- each campaign uses 3 channels
INSERT marketing.MarketingCampaignChannel (Marketing_Campaign_ID, Campaign_Channel_ID)
SELECT c.i, 1 + (c.i + k.k * 4) % 12 FROM #n c CROSS JOIN (VALUES (0), (1), (2)) k(k) WHERE c.i <= 2000;

INSERT marketing.CampaignBudget (Marketing_Campaign_ID, Campaign_Channel_ID, Total_Allocated_Amount, Currency)
SELECT Marketing_Campaign_ID, Campaign_Channel_ID, 50000000, 'IRR' FROM marketing.MarketingCampaignChannel;

INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date)
SELECT 1 + (n.i - 1) % 2000, 1 + ((1 + (n.i - 1) % 2000) + ((n.i / 2000) % 3) * 4) % 12, 1000000 + n.i % 5000 * 100, 'IRR',
       DATEADD(DAY, n.i % 365, CAST('2026-01-01' AS date))
FROM #n n WHERE n.i <= 100000;

SET IDENTITY_INSERT marketing.Market ON;
INSERT marketing.Market (Market_ID, Market_Code, Market_Name, Market_Status) SELECT i, CONCAT(N'M', i), CONCAT(N'Market ', i), N'Active' FROM #n WHERE i <= 30;
SET IDENTITY_INSERT marketing.Market OFF;

SET IDENTITY_INSERT marketing.Competitor ON;
INSERT marketing.Competitor (Competitor_ID, Competitor_Name, Competitor_Type, Market_ID, Competitor_Status) SELECT i, CONCAT(N'Competitor ', i), N'Direct', 1 + (i - 1) % 30, N'Active' FROM #n WHERE i <= 100;
SET IDENTITY_INSERT marketing.Competitor OFF;

SET IDENTITY_INSERT marketing.CompetitorProduct ON;
INSERT marketing.CompetitorProduct (Competitor_Product_ID, Competitor_ID, Competitor_Product_Name) SELECT i, 1 + (i - 1) % 100, CONCAT(N'Rival product ', i) FROM #n WHERE i <= 1000;
SET IDENTITY_INSERT marketing.CompetitorProduct OFF;

-- 60,000 observations of own products and 30,000 of competitor products
INSERT marketing.MarketPrice (Product_ID, Competitor_Product_ID, Market_ID, Price_Date, Price_Value, Currency, Price_Source)
SELECT 1 + (i - 1) % 2000, NULL, 1 + (i - 1) % 30, DATEADD(HOUR, i % 8760, CAST('2026-01-01' AS datetime2(0))), 300000 + i % 1000, 'IRR', N'Field Visit' FROM #n WHERE i <= 60000;
INSERT marketing.MarketPrice (Product_ID, Competitor_Product_ID, Market_ID, Price_Date, Price_Value, Currency, Price_Source)
SELECT NULL, 1 + (i - 1) % 1000, 1 + (i - 1) % 30, DATEADD(HOUR, i % 8760, CAST('2026-01-01' AS datetime2(0))), 290000 + i % 1000, 'IRR', N'Field Visit' FROM #n WHERE i <= 30000;

UPDATE STATISTICS marketing.CampaignCost;  UPDATE STATISTICS marketing.CampaignBudget;
UPDATE STATISTICS marketing.ProductPrice;  UPDATE STATISTICS marketing.MarketPrice;
PRINT N'Sample data loaded.';

/* ---- Frequent queries. STATISTICS IO reports logical reads; compare each query with its INDEX(1) run. ---- */
DECLARE @ch int = 5, @sku int = 1234, @d date = '2026-08-15', @p int = 77, @cp int = 345, @m int = 7,
        @from date = '2026-04-01', @to date = '2026-07-01', @x decimal(18,2), @n int;
SET STATISTICS IO ON;

PRINT N'== Q1 spend of one channel per day in a quarter (Stage 3 dashboard: spend by channel)';
SELECT @n = COUNT(*), @x = SUM(Actual_Spent) FROM marketing.CampaignCost WHERE Campaign_Channel_ID = @ch AND Cost_Date >= @from AND Cost_Date < @to;
PRINT N'-- Q1 forced clustered';
SELECT @n = COUNT(*), @x = SUM(Actual_Spent) FROM marketing.CampaignCost WITH (INDEX(1)) WHERE Campaign_Channel_ID = @ch AND Cost_Date >= @from AND Cost_Date < @to;

PRINT N'== Q2 all cost rows of one channel (SELECT *)';
SELECT * INTO #q2 FROM marketing.CampaignCost WHERE Campaign_Channel_ID = @ch;
PRINT N'-- Q2 forced clustered';
SELECT * INTO #q2b FROM marketing.CampaignCost WITH (INDEX(1)) WHERE Campaign_Channel_ID = @ch;

PRINT N'== Q3 does any cost row use a channel? (the check behind FK_CampaignCost_CampaignChannel when a channel is deleted)';
SELECT @n = COUNT(*) FROM marketing.CampaignCost WHERE Campaign_Channel_ID = @ch;
PRINT N'-- Q3 forced clustered';
SELECT @n = COUNT(*) FROM marketing.CampaignCost WITH (INDEX(1)) WHERE Campaign_Channel_ID = @ch;

PRINT N'== Q4 budget of one channel (planning table, 6,000 rows)';
SELECT @x = SUM(Total_Allocated_Amount) FROM marketing.CampaignBudget WHERE Campaign_Channel_ID = @ch;
PRINT N'-- Q4 forced clustered';
SELECT @x = SUM(Total_Allocated_Amount) FROM marketing.CampaignBudget WITH (INDEX(1)) WHERE Campaign_Channel_ID = @ch;

PRINT N'== Q5 official price of one SKU and price type on a date';
SELECT TOP (1) @x = Unit_Price FROM marketing.ProductPrice
WHERE SKU_ID = @sku AND Price_Type = N'List' AND Effective_From <= @d AND (Effective_To IS NULL OR Effective_To >= @d)
ORDER BY Effective_From DESC;
PRINT N'-- Q5 forced clustered';
SELECT TOP (1) @x = Unit_Price FROM marketing.ProductPrice WITH (INDEX(1))
WHERE SKU_ID = @sku AND Price_Type = N'List' AND Effective_From <= @d AND (Effective_To IS NULL OR Effective_To >= @d)
ORDER BY Effective_From DESC;

PRINT N'== Q6 overlap probe for one SKU and price type (what TR_ProductPrice_NoOverlap runs per inserted row)';
SELECT @n = COUNT(*) FROM marketing.ProductPrice
WHERE SKU_ID = @sku AND Price_Type = N'List' AND Effective_From <= '2026-12-31' AND ISNULL(Effective_To, '9999-12-31') >= '2026-06-01';
PRINT N'-- Q6 forced clustered';
SELECT @n = COUNT(*) FROM marketing.ProductPrice WITH (INDEX(1))
WHERE SKU_ID = @sku AND Price_Type = N'List' AND Effective_From <= '2026-12-31' AND ISNULL(Effective_To, '9999-12-31') >= '2026-06-01';

PRINT N'== Q7 market price trend of one own product in a period';
SELECT @n = COUNT(*), @x = AVG(Price_Value) FROM marketing.MarketPrice WHERE Product_ID = @p AND Price_Date >= @from AND Price_Date < @to;
PRINT N'-- Q7 forced clustered';
SELECT @n = COUNT(*), @x = AVG(Price_Value) FROM marketing.MarketPrice WITH (INDEX(1)) WHERE Product_ID = @p AND Price_Date >= @from AND Price_Date < @to;

PRINT N'== Q8 market price trend of one competitor product in a period';
SELECT @n = COUNT(*), @x = AVG(Price_Value) FROM marketing.MarketPrice WHERE Competitor_Product_ID = @cp AND Price_Date >= @from AND Price_Date < @to;
PRINT N'-- Q8 forced clustered';
SELECT @n = COUNT(*), @x = AVG(Price_Value) FROM marketing.MarketPrice WITH (INDEX(1)) WHERE Competitor_Product_ID = @cp AND Price_Date >= @from AND Price_Date < @to;

PRINT N'== Q9 all prices observed in one market in a period';
SELECT @n = COUNT(*), @x = AVG(Price_Value) FROM marketing.MarketPrice WHERE Market_ID = @m AND Price_Date >= @from AND Price_Date < @to;
PRINT N'-- Q9 forced clustered';
SELECT @n = COUNT(*), @x = AVG(Price_Value) FROM marketing.MarketPrice WITH (INDEX(1)) WHERE Market_ID = @m AND Price_Date >= @from AND Price_Date < @to;

SET STATISTICS IO OFF;
ROLLBACK TRANSACTION;
PRINT N'Index evaluation finished; all sample data rolled back.';
GO

/* ---- Restore IDENTITY seeds consumed by the rolled-back sample rows, so the first real row gets ID 1 ---- */
DECLARE @tbl nvarchar(300), @sql nvarchar(400);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT QUOTENAME(OBJECT_SCHEMA_NAME(ic.object_id)) + N'.' + QUOTENAME(OBJECT_NAME(ic.object_id))
    FROM sys.identity_columns ic
    WHERE ic.last_value IS NOT NULL AND OBJECT_SCHEMA_NAME(ic.object_id) IN (N'ref', N'core', N'marketing');
OPEN c; FETCH NEXT FROM c INTO @tbl;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF NOT EXISTS (SELECT 1 FROM sys.partitions WHERE object_id = OBJECT_ID(@tbl) AND index_id IN (0, 1) AND rows > 0)
    BEGIN
        SET @sql = N'DBCC CHECKIDENT (''' + @tbl + N''', RESEED, 0) WITH NO_INFOMSGS;';
        EXEC (@sql);
    END;
    FETCH NEXT FROM c INTO @tbl;
END;
CLOSE c; DEALLOCATE c;
PRINT N'IDENTITY seeds restored.';
GO

SET NOEXEC OFF;
GO
