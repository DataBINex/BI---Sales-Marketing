﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 2 - Product & Marketing
    Database: FoodDistributionDB
    SQL Server: 2022
    Version : 1.1 (2026-10-28)
    File    : 07-Team2-04-Create-Constraints.sql
    Purpose : UNIQUE, CHECK and DEFAULT constraints, FOREIGN KEYs and the two integrity triggers for multi-row rules.
    Run order: 4 (after 07-Team2-03-Create-Tables.sql)
    Prerequisites: All 24 Team 2 tables exist (07-Team2-03-Create-Tables.sql).
    Source  : 06-Team2-Product-Marketing-Logical-Data-Model.xlsx (Stage 6, #175)
    Schemas : Team 2 proposal for #183 (ref / core / marketing); not yet approved
    Re-run  : Safe. A constraint is created if missing. If one exists with the same name but a different definition
              (columns, expression, referenced table), it is dropped and recreated. Disabled or untrusted constraints
              are re-enabled WITH CHECK. Triggers use CREATE OR ALTER.
              The verification at the end compares the whole structure with the expected definition.
*/

USE [FoodDistributionDB];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
GO

/* ---- Prerequisite check: stop the whole script if a prerequisite is missing ---- */
IF OBJECT_ID(N'ref.ProductCategory', N'U') IS NULL
   OR OBJECT_ID(N'ref.Package', N'U') IS NULL
   OR OBJECT_ID(N'core.Brand', N'U') IS NULL
   OR OBJECT_ID(N'core.Product', N'U') IS NULL
   OR OBJECT_ID(N'core.SKU', N'U') IS NULL
   OR OBJECT_ID(N'marketing.ProductPrice', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignChannel', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignAudience', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketingCampaign', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketingCampaignChannel', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketingCampaignAudience', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignBudget', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignCost', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CampaignResult', N'U') IS NULL
   OR OBJECT_ID(N'marketing.Promotion', N'U') IS NULL
   OR OBJECT_ID(N'marketing.BrandActivity', N'U') IS NULL
   OR OBJECT_ID(N'marketing.Market', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketSegment', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketResearch', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketSurvey', N'U') IS NULL
   OR OBJECT_ID(N'marketing.ResearchResult', N'U') IS NULL
   OR OBJECT_ID(N'marketing.Competitor', N'U') IS NULL
   OR OBJECT_ID(N'marketing.CompetitorProduct', N'U') IS NULL
   OR OBJECT_ID(N'marketing.MarketPrice', N'U') IS NULL
BEGIN
    RAISERROR(N'Team 2 tables are missing. Run 07-Team2-03-Create-Tables.sql first.', 16, 1);
    SET NOEXEC ON;
END;
GO

/* ========================================================================
   1. UNIQUE constraints (business keys)
   ======================================================================== */

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'ref.ProductCategory') AND i.name = N'UQ_ProductCategory_Category_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Category_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE ref.ProductCategory DROP CONSTRAINT UQ_ProductCategory_Category_Code;
    PRINT N'UQ_ProductCategory_Category_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE ref.ProductCategory ADD CONSTRAINT UQ_ProductCategory_Category_Code UNIQUE (Category_Code);
    PRINT N'Created UQ_ProductCategory_Category_Code.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'ref.Package') AND i.name = N'UQ_Package_Package_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Package_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE ref.Package DROP CONSTRAINT UQ_Package_Package_Code;
    PRINT N'UQ_Package_Package_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE ref.Package ADD CONSTRAINT UQ_Package_Package_Code UNIQUE (Package_Code);
    PRINT N'Created UQ_Package_Package_Code.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.Brand') AND i.name = N'UQ_Brand_Brand_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Brand_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Brand DROP CONSTRAINT UQ_Brand_Brand_Code;
    PRINT N'UQ_Brand_Brand_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Brand ADD CONSTRAINT UQ_Brand_Brand_Code UNIQUE (Brand_Code);
    PRINT N'Created UQ_Brand_Brand_Code.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.Product') AND i.name = N'UQ_Product_Product_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Product_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Product DROP CONSTRAINT UQ_Product_Product_Code;
    PRINT N'UQ_Product_Product_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Product ADD CONSTRAINT UQ_Product_Product_Code UNIQUE (Product_Code);
    PRINT N'Created UQ_Product_Product_Code.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.SKU') AND i.name = N'UQ_SKU_SKU_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|SKU_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.SKU DROP CONSTRAINT UQ_SKU_SKU_Code;
    PRINT N'UQ_SKU_SKU_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.SKU ADD CONSTRAINT UQ_SKU_SKU_Code UNIQUE (SKU_Code);
    PRINT N'Created UQ_SKU_SKU_Code.';
END;
GO

-- Barcode is optional but must be unique when filled: filtered unique index (a UNIQUE constraint would allow only one NULL).
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'core.SKU') AND i.name = N'UQ_SKU_Barcode'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Barcode||([Barcode] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    DROP INDEX UQ_SKU_Barcode ON core.SKU;
    PRINT N'UQ_SKU_Barcode: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX UQ_SKU_Barcode ON core.SKU (Barcode) WHERE Barcode IS NOT NULL;
    PRINT N'Created UQ_SKU_Barcode.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.Promotion') AND i.name = N'UQ_Promotion_Promotion_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Promotion_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Promotion DROP CONSTRAINT UQ_Promotion_Promotion_Code;
    PRINT N'UQ_Promotion_Promotion_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Promotion ADD CONSTRAINT UQ_Promotion_Promotion_Code UNIQUE (Promotion_Code);
    PRINT N'Created UQ_Promotion_Promotion_Code.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.Market') AND i.name = N'UQ_Market_Market_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Market_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Market DROP CONSTRAINT UQ_Market_Market_Code;
    PRINT N'UQ_Market_Market_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Market ADD CONSTRAINT UQ_Market_Market_Code UNIQUE (Market_Code);
    PRINT N'Created UQ_Market_Market_Code.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.MarketSegment') AND i.name = N'UQ_MarketSegment_Segment_Code'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Segment_Code||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketSegment DROP CONSTRAINT UQ_MarketSegment_Segment_Code;
    PRINT N'UQ_MarketSegment_Segment_Code: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketSegment ADD CONSTRAINT UQ_MarketSegment_Segment_Code UNIQUE (Segment_Code);
    PRINT N'Created UQ_MarketSegment_Segment_Code.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(i.type_desc, N'|', IIF(i.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|',
       STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',') WITHIN GROUP (ORDER BY ic.key_ordinal, col.name), N'|', i.filter_definition)
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID(N'marketing.CampaignResult') AND i.name = N'UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date'
GROUP BY i.type_desc, i.is_unique, i.filter_definition;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'NONCLUSTERED|UNIQUE|Marketing_Campaign_ID,Metric_Name,Measurement_Date||' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignResult DROP CONSTRAINT UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date;
    PRINT N'UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignResult ADD CONSTRAINT UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date UNIQUE (Marketing_Campaign_ID, Metric_Name, Measurement_Date);
    PRINT N'Created UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date.';
END;
GO

/* ========================================================================
   2. CHECK constraints (business rules of the Stage 6 logical model and the v1.1 decisions)
   ======================================================================== */

-- v1.1: تاریخ پایان بدون تاریخ شروع رد می‌شود
DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.Brand') AND name = N'CK_Brand_Brand_End_Date';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Brand_End_Date] IS NULL OR [Brand_Start_Date] IS NOT NULL AND [Brand_End_Date]>=[Brand_Start_Date])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Brand DROP CONSTRAINT CK_Brand_Brand_End_Date;
    PRINT N'CK_Brand_Brand_End_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Brand WITH CHECK ADD CONSTRAINT CK_Brand_Brand_End_Date CHECK (Brand_End_Date IS NULL OR (Brand_Start_Date IS NOT NULL AND Brand_End_Date >= Brand_Start_Date));
    PRINT N'Created CK_Brand_Brand_End_Date.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.Brand') AND name = N'CK_Brand_Brand_Country';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Brand_Country]) collate Latin1_General_BIN like ''[A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Brand DROP CONSTRAINT CK_Brand_Brand_Country;
    PRINT N'CK_Brand_Brand_Country: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Brand WITH CHECK ADD CONSTRAINT CK_Brand_Brand_Country CHECK (Brand_Country COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z]');
    PRINT N'Created CK_Brand_Brand_Country.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.Product') AND name = N'CK_Product_Weight';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Weight]>(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Product DROP CONSTRAINT CK_Product_Weight;
    PRINT N'CK_Product_Weight: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Product WITH CHECK ADD CONSTRAINT CK_Product_Weight CHECK (Weight > 0);
    PRINT N'Created CK_Product_Weight.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.Product') AND name = N'CK_Product_Tax_Rate';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Tax_Rate]>=(0) AND [Tax_Rate]<=(100))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Product DROP CONSTRAINT CK_Product_Tax_Rate;
    PRINT N'CK_Product_Tax_Rate: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Product WITH CHECK ADD CONSTRAINT CK_Product_Tax_Rate CHECK (Tax_Rate BETWEEN 0 AND 100);
    PRINT N'Created CK_Product_Tax_Rate.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.Product') AND name = N'CK_Product_Product_Updated_Date';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Product_Updated_Date]>=[Product_Created_Date])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Product DROP CONSTRAINT CK_Product_Product_Updated_Date;
    PRINT N'CK_Product_Product_Updated_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Product WITH CHECK ADD CONSTRAINT CK_Product_Product_Updated_Date CHECK (Product_Updated_Date >= Product_Created_Date);
    PRINT N'Created CK_Product_Product_Updated_Date.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'ref.ProductCategory') AND name = N'CK_ProductCategory_Parent_Category_ID';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Parent_Category_ID]<>[Product_Category_ID])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE ref.ProductCategory DROP CONSTRAINT CK_ProductCategory_Parent_Category_ID;
    PRINT N'CK_ProductCategory_Parent_Category_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE ref.ProductCategory WITH CHECK ADD CONSTRAINT CK_ProductCategory_Parent_Category_ID CHECK (Parent_Category_ID <> Product_Category_ID);
    PRINT N'Created CK_ProductCategory_Parent_Category_ID.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'ref.ProductCategory') AND name = N'CK_ProductCategory_Category_Level';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Category_Level]>=(1))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE ref.ProductCategory DROP CONSTRAINT CK_ProductCategory_Category_Level;
    PRINT N'CK_ProductCategory_Category_Level: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE ref.ProductCategory WITH CHECK ADD CONSTRAINT CK_ProductCategory_Category_Level CHECK (Category_Level >= 1);
    PRINT N'Created CK_ProductCategory_Category_Level.';
END;
GO

-- v1.1: جدید
DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.SKU') AND name = N'CK_SKU_Weight';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Weight]>(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.SKU DROP CONSTRAINT CK_SKU_Weight;
    PRINT N'CK_SKU_Weight: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.SKU WITH CHECK ADD CONSTRAINT CK_SKU_Weight CHECK (Weight > 0);
    PRINT N'Created CK_SKU_Weight.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.SKU') AND name = N'CK_SKU_Standard_Cost';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Standard_Cost]>=(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.SKU DROP CONSTRAINT CK_SKU_Standard_Cost;
    PRINT N'CK_SKU_Standard_Cost: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.SKU WITH CHECK ADD CONSTRAINT CK_SKU_Standard_Cost CHECK (Standard_Cost >= 0);
    PRINT N'Created CK_SKU_Standard_Cost.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.SKU') AND name = N'CK_SKU_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.SKU DROP CONSTRAINT CK_SKU_Currency;
    PRINT N'CK_SKU_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.SKU WITH CHECK ADD CONSTRAINT CK_SKU_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_SKU_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'core.SKU') AND name = N'CK_SKU_Standard_Cost_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Standard_Cost] IS NULL OR [Currency] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.SKU DROP CONSTRAINT CK_SKU_Standard_Cost_Currency;
    PRINT N'CK_SKU_Standard_Cost_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.SKU WITH CHECK ADD CONSTRAINT CK_SKU_Standard_Cost_Currency CHECK (Standard_Cost IS NULL OR Currency IS NOT NULL);
    PRINT N'Created CK_SKU_Standard_Cost_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.ProductPrice') AND name = N'CK_ProductPrice_Unit_Price';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Unit_Price]>=(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.ProductPrice DROP CONSTRAINT CK_ProductPrice_Unit_Price;
    PRINT N'CK_ProductPrice_Unit_Price: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.ProductPrice WITH CHECK ADD CONSTRAINT CK_ProductPrice_Unit_Price CHECK (Unit_Price >= 0);
    PRINT N'Created CK_ProductPrice_Unit_Price.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.ProductPrice') AND name = N'CK_ProductPrice_Effective_To';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Effective_To]>=[Effective_From])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.ProductPrice DROP CONSTRAINT CK_ProductPrice_Effective_To;
    PRINT N'CK_ProductPrice_Effective_To: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.ProductPrice WITH CHECK ADD CONSTRAINT CK_ProductPrice_Effective_To CHECK (Effective_To >= Effective_From);
    PRINT N'Created CK_ProductPrice_Effective_To.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.ProductPrice') AND name = N'CK_ProductPrice_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.ProductPrice DROP CONSTRAINT CK_ProductPrice_Currency;
    PRINT N'CK_ProductPrice_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.ProductPrice WITH CHECK ADD CONSTRAINT CK_ProductPrice_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_ProductPrice_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.CampaignChannel') AND name = N'CK_CampaignChannel_Channel_Status';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Channel_Status]=N''Inactive'' OR [Channel_Status]=N''Active'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignChannel DROP CONSTRAINT CK_CampaignChannel_Channel_Status;
    PRINT N'CK_CampaignChannel_Channel_Status: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignChannel WITH CHECK ADD CONSTRAINT CK_CampaignChannel_Channel_Status CHECK (Channel_Status IN (N'Active', N'Inactive'));
    PRINT N'Created CK_CampaignChannel_Channel_Status.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.CampaignAudience') AND name = N'CK_CampaignAudience_Audience_Status';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Audience_Status]=N''Inactive'' OR [Audience_Status]=N''Active'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignAudience DROP CONSTRAINT CK_CampaignAudience_Audience_Status;
    PRINT N'CK_CampaignAudience_Audience_Status: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignAudience WITH CHECK ADD CONSTRAINT CK_CampaignAudience_Audience_Status CHECK (Audience_Status IN (N'Active', N'Inactive'));
    PRINT N'Created CK_CampaignAudience_Audience_Status.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketingCampaign') AND name = N'CK_MarketingCampaign_End_Date';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([End_Date]>=[Start_Date])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaign DROP CONSTRAINT CK_MarketingCampaign_End_Date;
    PRINT N'CK_MarketingCampaign_End_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaign WITH CHECK ADD CONSTRAINT CK_MarketingCampaign_End_Date CHECK (End_Date >= Start_Date);
    PRINT N'Created CK_MarketingCampaign_End_Date.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketingCampaign') AND name = N'CK_MarketingCampaign_Campaign_Purpose';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Campaign_Purpose]=N''Marketing'' OR [Campaign_Purpose]=N''Brand'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaign DROP CONSTRAINT CK_MarketingCampaign_Campaign_Purpose;
    PRINT N'CK_MarketingCampaign_Campaign_Purpose: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaign WITH CHECK ADD CONSTRAINT CK_MarketingCampaign_Campaign_Purpose CHECK (Campaign_Purpose IN (N'Brand', N'Marketing'));
    PRINT N'Created CK_MarketingCampaign_Campaign_Purpose.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketingCampaign') AND name = N'CK_MarketingCampaign_Brand_ID';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Campaign_Purpose]<>N''Brand'' OR [Brand_ID] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaign DROP CONSTRAINT CK_MarketingCampaign_Brand_ID;
    PRINT N'CK_MarketingCampaign_Brand_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaign WITH CHECK ADD CONSTRAINT CK_MarketingCampaign_Brand_ID CHECK (Campaign_Purpose <> N'Brand' OR Brand_ID IS NOT NULL);
    PRINT N'Created CK_MarketingCampaign_Brand_ID.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.CampaignBudget') AND name = N'CK_CampaignBudget_Total_Allocated_Amount';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Total_Allocated_Amount]>=(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignBudget DROP CONSTRAINT CK_CampaignBudget_Total_Allocated_Amount;
    PRINT N'CK_CampaignBudget_Total_Allocated_Amount: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignBudget WITH CHECK ADD CONSTRAINT CK_CampaignBudget_Total_Allocated_Amount CHECK (Total_Allocated_Amount >= 0);
    PRINT N'Created CK_CampaignBudget_Total_Allocated_Amount.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.CampaignBudget') AND name = N'CK_CampaignBudget_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignBudget DROP CONSTRAINT CK_CampaignBudget_Currency;
    PRINT N'CK_CampaignBudget_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignBudget WITH CHECK ADD CONSTRAINT CK_CampaignBudget_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_CampaignBudget_Currency.';
END;
GO

-- v1.1: جدید؛ T2-OI-19 بسته شد
DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.CampaignCost') AND name = N'CK_CampaignCost_Actual_Spent';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Actual_Spent]>=(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignCost DROP CONSTRAINT CK_CampaignCost_Actual_Spent;
    PRINT N'CK_CampaignCost_Actual_Spent: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignCost WITH CHECK ADD CONSTRAINT CK_CampaignCost_Actual_Spent CHECK (Actual_Spent >= 0);
    PRINT N'Created CK_CampaignCost_Actual_Spent.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.CampaignCost') AND name = N'CK_CampaignCost_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignCost DROP CONSTRAINT CK_CampaignCost_Currency;
    PRINT N'CK_CampaignCost_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignCost WITH CHECK ADD CONSTRAINT CK_CampaignCost_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_CampaignCost_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.Promotion') AND name = N'CK_Promotion_End_Date';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([End_Date]>=[Start_Date])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Promotion DROP CONSTRAINT CK_Promotion_End_Date;
    PRINT N'CK_Promotion_End_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Promotion WITH CHECK ADD CONSTRAINT CK_Promotion_End_Date CHECK (End_Date >= Start_Date);
    PRINT N'Created CK_Promotion_End_Date.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.Promotion') AND name = N'CK_Promotion_Discount_Type';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Discount_Type]=N''Fixed Amount'' OR [Discount_Type]=N''Percentage'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Promotion DROP CONSTRAINT CK_Promotion_Discount_Type;
    PRINT N'CK_Promotion_Discount_Type: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Promotion WITH CHECK ADD CONSTRAINT CK_Promotion_Discount_Type CHECK (Discount_Type IN (N'Percentage', N'Fixed Amount'));
    PRINT N'Created CK_Promotion_Discount_Type.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.Promotion') AND name = N'CK_Promotion_Discount_Value';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Discount_Value]>=(0) AND ([Discount_Type]<>N''Percentage'' OR [Discount_Value]<=(100)))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Promotion DROP CONSTRAINT CK_Promotion_Discount_Value;
    PRINT N'CK_Promotion_Discount_Value: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Promotion WITH CHECK ADD CONSTRAINT CK_Promotion_Discount_Value CHECK (Discount_Value >= 0 AND (Discount_Type <> N'Percentage' OR Discount_Value <= 100));
    PRINT N'Created CK_Promotion_Discount_Value.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.Promotion') AND name = N'CK_Promotion_Discount_Type_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Discount_Type]<>N''Fixed Amount'' OR [Currency] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Promotion DROP CONSTRAINT CK_Promotion_Discount_Type_Currency;
    PRINT N'CK_Promotion_Discount_Type_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Promotion WITH CHECK ADD CONSTRAINT CK_Promotion_Discount_Type_Currency CHECK (Discount_Type <> N'Fixed Amount' OR Currency IS NOT NULL);
    PRINT N'Created CK_Promotion_Discount_Type_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.Promotion') AND name = N'CK_Promotion_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Promotion DROP CONSTRAINT CK_Promotion_Currency;
    PRINT N'CK_Promotion_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Promotion WITH CHECK ADD CONSTRAINT CK_Promotion_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_Promotion_Currency.';
END;
GO

-- v1.1: تاریخ پایان بدون تاریخ شروع رد می‌شود
DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.BrandActivity') AND name = N'CK_BrandActivity_Activity_End_Date';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Activity_End_Date] IS NULL OR [Activity_Start_Date] IS NOT NULL AND [Activity_End_Date]>=[Activity_Start_Date])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.BrandActivity DROP CONSTRAINT CK_BrandActivity_Activity_End_Date;
    PRINT N'CK_BrandActivity_Activity_End_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.BrandActivity WITH CHECK ADD CONSTRAINT CK_BrandActivity_Activity_End_Date CHECK (Activity_End_Date IS NULL OR (Activity_Start_Date IS NOT NULL AND Activity_End_Date >= Activity_Start_Date));
    PRINT N'Created CK_BrandActivity_Activity_End_Date.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.BrandActivity') AND name = N'CK_BrandActivity_Activity_Cost';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Activity_Cost]>=(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.BrandActivity DROP CONSTRAINT CK_BrandActivity_Activity_Cost;
    PRINT N'CK_BrandActivity_Activity_Cost: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.BrandActivity WITH CHECK ADD CONSTRAINT CK_BrandActivity_Activity_Cost CHECK (Activity_Cost >= 0);
    PRINT N'Created CK_BrandActivity_Activity_Cost.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.BrandActivity') AND name = N'CK_BrandActivity_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.BrandActivity DROP CONSTRAINT CK_BrandActivity_Currency;
    PRINT N'CK_BrandActivity_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.BrandActivity WITH CHECK ADD CONSTRAINT CK_BrandActivity_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_BrandActivity_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.BrandActivity') AND name = N'CK_BrandActivity_Activity_Cost_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Activity_Cost] IS NULL OR [Currency] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.BrandActivity DROP CONSTRAINT CK_BrandActivity_Activity_Cost_Currency;
    PRINT N'CK_BrandActivity_Activity_Cost_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.BrandActivity WITH CHECK ADD CONSTRAINT CK_BrandActivity_Activity_Cost_Currency CHECK (Activity_Cost IS NULL OR Currency IS NOT NULL);
    PRINT N'Created CK_BrandActivity_Activity_Cost_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketSegment') AND name = N'CK_MarketSegment_Segmentation_Basis';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Segmentation_Basis]=N''Behavioral'' OR [Segmentation_Basis]=N''Demographic'' OR [Segmentation_Basis]=N''Geographic'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketSegment DROP CONSTRAINT CK_MarketSegment_Segmentation_Basis;
    PRINT N'CK_MarketSegment_Segmentation_Basis: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketSegment WITH CHECK ADD CONSTRAINT CK_MarketSegment_Segmentation_Basis CHECK (Segmentation_Basis IN (N'Geographic', N'Demographic', N'Behavioral'));
    PRINT N'Created CK_MarketSegment_Segmentation_Basis.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketResearch') AND name = N'CK_MarketResearch_End_Date';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([End_Date]>=[Start_Date])' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketResearch DROP CONSTRAINT CK_MarketResearch_End_Date;
    PRINT N'CK_MarketResearch_End_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketResearch WITH CHECK ADD CONSTRAINT CK_MarketResearch_End_Date CHECK (End_Date >= Start_Date);
    PRINT N'Created CK_MarketResearch_End_Date.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketResearch') AND name = N'CK_MarketResearch_Research_Cost';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Research_Cost]>=(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketResearch DROP CONSTRAINT CK_MarketResearch_Research_Cost;
    PRINT N'CK_MarketResearch_Research_Cost: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketResearch WITH CHECK ADD CONSTRAINT CK_MarketResearch_Research_Cost CHECK (Research_Cost >= 0);
    PRINT N'Created CK_MarketResearch_Research_Cost.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketResearch') AND name = N'CK_MarketResearch_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketResearch DROP CONSTRAINT CK_MarketResearch_Currency;
    PRINT N'CK_MarketResearch_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketResearch WITH CHECK ADD CONSTRAINT CK_MarketResearch_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_MarketResearch_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketResearch') AND name = N'CK_MarketResearch_Research_Cost_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Research_Cost] IS NULL OR [Currency] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketResearch DROP CONSTRAINT CK_MarketResearch_Research_Cost_Currency;
    PRINT N'CK_MarketResearch_Research_Cost_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketResearch WITH CHECK ADD CONSTRAINT CK_MarketResearch_Research_Cost_Currency CHECK (Research_Cost IS NULL OR Currency IS NOT NULL);
    PRINT N'Created CK_MarketResearch_Research_Cost_Currency.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketSurvey') AND name = N'CK_MarketSurvey_Sample_Size';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Sample_Size]>(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketSurvey DROP CONSTRAINT CK_MarketSurvey_Sample_Size;
    PRINT N'CK_MarketSurvey_Sample_Size: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketSurvey WITH CHECK ADD CONSTRAINT CK_MarketSurvey_Sample_Size CHECK (Sample_Size > 0);
    PRINT N'Created CK_MarketSurvey_Sample_Size.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketPrice') AND name = N'CK_MarketPrice_Product_ID_Competitor_Product_ID';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Product_ID] IS NOT NULL AND [Competitor_Product_ID] IS NULL OR [Product_ID] IS NULL AND [Competitor_Product_ID] IS NOT NULL)' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketPrice DROP CONSTRAINT CK_MarketPrice_Product_ID_Competitor_Product_ID;
    PRINT N'CK_MarketPrice_Product_ID_Competitor_Product_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketPrice WITH CHECK ADD CONSTRAINT CK_MarketPrice_Product_ID_Competitor_Product_ID CHECK ((Product_ID IS NOT NULL AND Competitor_Product_ID IS NULL) OR (Product_ID IS NULL AND Competitor_Product_ID IS NOT NULL));
    PRINT N'Created CK_MarketPrice_Product_ID_Competitor_Product_ID.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketPrice') AND name = N'CK_MarketPrice_Price_Value';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'([Price_Value]>=(0))' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketPrice DROP CONSTRAINT CK_MarketPrice_Price_Value;
    PRINT N'CK_MarketPrice_Price_Value: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketPrice WITH CHECK ADD CONSTRAINT CK_MarketPrice_Price_Value CHECK (Price_Value >= 0);
    PRINT N'Created CK_MarketPrice_Price_Value.';
END;
GO

DECLARE @sig nvarchar(max);
SELECT @sig = definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID(N'marketing.MarketPrice') AND name = N'CK_MarketPrice_Currency';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketPrice DROP CONSTRAINT CK_MarketPrice_Currency;
    PRINT N'CK_MarketPrice_Currency: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketPrice WITH CHECK ADD CONSTRAINT CK_MarketPrice_Currency CHECK (Currency COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]');
    PRINT N'Created CK_MarketPrice_Currency.';
END;
GO

/* ========================================================================
   3. DEFAULT constraints
   ======================================================================== */

DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(col.name, N'=', d.definition) FROM sys.default_constraints d
JOIN sys.columns col ON col.object_id = d.parent_object_id AND col.column_id = d.parent_column_id
WHERE d.parent_object_id = OBJECT_ID(N'core.Product') AND d.name = N'DF_Product_Product_Created_Date';
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Product_Created_Date=(sysdatetime())' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Product DROP CONSTRAINT DF_Product_Product_Created_Date;
    PRINT N'DF_Product_Product_Created_Date: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Product ADD CONSTRAINT DF_Product_Product_Created_Date DEFAULT (SYSDATETIME()) FOR Product_Created_Date;
    PRINT N'Created DF_Product_Product_Created_Date.';
END;
GO

/* ========================================================================
   4. FOREIGN KEY constraints (ON DELETE / ON UPDATE NO ACTION: no cascading deletes of business history)
   ======================================================================== */

-- R01: Product Category -> Product
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'core.Product') AND f.name = N'FK_Product_ProductCategory_Product_Category_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Product_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Product DROP CONSTRAINT FK_Product_ProductCategory_Product_Category_ID;
    PRINT N'FK_Product_ProductCategory_Product_Category_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Product WITH CHECK ADD CONSTRAINT FK_Product_ProductCategory_Product_Category_ID
        FOREIGN KEY (Product_Category_ID) REFERENCES ref.ProductCategory (Product_Category_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_Product_ProductCategory_Product_Category_ID.';
END;
GO

-- R02: Brand -> Product
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'core.Product') AND f.name = N'FK_Product_Brand_Brand_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.Product DROP CONSTRAINT FK_Product_Brand_Brand_ID;
    PRINT N'FK_Product_Brand_Brand_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.Product WITH CHECK ADD CONSTRAINT FK_Product_Brand_Brand_ID
        FOREIGN KEY (Brand_ID) REFERENCES core.Brand (Brand_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_Product_Brand_Brand_ID.';
END;
GO

-- R03: Product -> SKU
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'core.SKU') AND f.name = N'FK_SKU_Product_Product_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.SKU DROP CONSTRAINT FK_SKU_Product_Product_ID;
    PRINT N'FK_SKU_Product_Product_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.SKU WITH CHECK ADD CONSTRAINT FK_SKU_Product_Product_ID
        FOREIGN KEY (Product_ID) REFERENCES core.Product (Product_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_SKU_Product_Product_ID.';
END;
GO

-- R04: Product -> Market Price
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketPrice') AND f.name = N'FK_MarketPrice_Product_Product_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketPrice DROP CONSTRAINT FK_MarketPrice_Product_Product_ID;
    PRINT N'FK_MarketPrice_Product_Product_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketPrice WITH CHECK ADD CONSTRAINT FK_MarketPrice_Product_Product_ID
        FOREIGN KEY (Product_ID) REFERENCES core.Product (Product_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketPrice_Product_Product_ID.';
END;
GO

-- R05: Package -> SKU
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'core.SKU') AND f.name = N'FK_SKU_Package_Package_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Package_ID -> ref.Package(Package_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE core.SKU DROP CONSTRAINT FK_SKU_Package_Package_ID;
    PRINT N'FK_SKU_Package_Package_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE core.SKU WITH CHECK ADD CONSTRAINT FK_SKU_Package_Package_ID
        FOREIGN KEY (Package_ID) REFERENCES ref.Package (Package_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_SKU_Package_Package_ID.';
END;
GO

-- R06: SKU -> Product Price
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.ProductPrice') AND f.name = N'FK_ProductPrice_SKU_SKU_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'SKU_ID -> core.SKU(SKU_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.ProductPrice DROP CONSTRAINT FK_ProductPrice_SKU_SKU_ID;
    PRINT N'FK_ProductPrice_SKU_SKU_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.ProductPrice WITH CHECK ADD CONSTRAINT FK_ProductPrice_SKU_SKU_ID
        FOREIGN KEY (SKU_ID) REFERENCES core.SKU (SKU_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_ProductPrice_SKU_SKU_ID.';
END;
GO

-- R07: Brand -> Brand Activity
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.BrandActivity') AND f.name = N'FK_BrandActivity_Brand_Brand_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.BrandActivity DROP CONSTRAINT FK_BrandActivity_Brand_Brand_ID;
    PRINT N'FK_BrandActivity_Brand_Brand_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.BrandActivity WITH CHECK ADD CONSTRAINT FK_BrandActivity_Brand_Brand_ID
        FOREIGN KEY (Brand_ID) REFERENCES core.Brand (Brand_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_BrandActivity_Brand_Brand_ID.';
END;
GO

-- R08: Brand -> Marketing Campaign
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketingCampaign') AND f.name = N'FK_MarketingCampaign_Brand_Brand_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaign DROP CONSTRAINT FK_MarketingCampaign_Brand_Brand_ID;
    PRINT N'FK_MarketingCampaign_Brand_Brand_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaign WITH CHECK ADD CONSTRAINT FK_MarketingCampaign_Brand_Brand_ID
        FOREIGN KEY (Brand_ID) REFERENCES core.Brand (Brand_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketingCampaign_Brand_Brand_ID.';
END;
GO

-- R09a: Marketing Campaign -> Marketing Campaign Channel
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketingCampaignChannel') AND f.name = N'FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaignChannel DROP CONSTRAINT FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID;
    PRINT N'FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaignChannel WITH CHECK ADD CONSTRAINT FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID
        FOREIGN KEY (Marketing_Campaign_ID) REFERENCES marketing.MarketingCampaign (Marketing_Campaign_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID.';
END;
GO

-- R09b: Campaign Channel -> Marketing Campaign Channel
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketingCampaignChannel') AND f.name = N'FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaignChannel DROP CONSTRAINT FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID;
    PRINT N'FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaignChannel WITH CHECK ADD CONSTRAINT FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID
        FOREIGN KEY (Campaign_Channel_ID) REFERENCES marketing.CampaignChannel (Campaign_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID.';
END;
GO

-- R10a: Marketing Campaign -> Marketing Campaign Audience
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketingCampaignAudience') AND f.name = N'FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaignAudience DROP CONSTRAINT FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID;
    PRINT N'FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaignAudience WITH CHECK ADD CONSTRAINT FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID
        FOREIGN KEY (Marketing_Campaign_ID) REFERENCES marketing.MarketingCampaign (Marketing_Campaign_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID.';
END;
GO

-- R10b: Campaign Audience -> Marketing Campaign Audience
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketingCampaignAudience') AND f.name = N'FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Campaign_Audience_ID -> marketing.CampaignAudience(Campaign_Audience_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketingCampaignAudience DROP CONSTRAINT FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID;
    PRINT N'FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketingCampaignAudience WITH CHECK ADD CONSTRAINT FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID
        FOREIGN KEY (Campaign_Audience_ID) REFERENCES marketing.CampaignAudience (Campaign_Audience_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID.';
END;
GO

-- R11: Marketing Campaign -> Campaign Budget
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CampaignBudget') AND f.name = N'FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignBudget DROP CONSTRAINT FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID;
    PRINT N'FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignBudget WITH CHECK ADD CONSTRAINT FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID
        FOREIGN KEY (Marketing_Campaign_ID) REFERENCES marketing.MarketingCampaign (Marketing_Campaign_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID.';
END;
GO

-- R12: Marketing Campaign -> Campaign Cost
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CampaignCost') AND f.name = N'FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignCost DROP CONSTRAINT FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID;
    PRINT N'FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignCost WITH CHECK ADD CONSTRAINT FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID
        FOREIGN KEY (Marketing_Campaign_ID) REFERENCES marketing.MarketingCampaign (Marketing_Campaign_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID.';
END;
GO

-- R13: Marketing Campaign -> Campaign Result
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CampaignResult') AND f.name = N'FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignResult DROP CONSTRAINT FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID;
    PRINT N'FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignResult WITH CHECK ADD CONSTRAINT FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID
        FOREIGN KEY (Marketing_Campaign_ID) REFERENCES marketing.MarketingCampaign (Marketing_Campaign_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID.';
END;
GO

-- R14: Marketing Campaign -> Promotion
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.Promotion') AND f.name = N'FK_Promotion_MarketingCampaign_Marketing_Campaign_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Promotion DROP CONSTRAINT FK_Promotion_MarketingCampaign_Marketing_Campaign_ID;
    PRINT N'FK_Promotion_MarketingCampaign_Marketing_Campaign_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Promotion WITH CHECK ADD CONSTRAINT FK_Promotion_MarketingCampaign_Marketing_Campaign_ID
        FOREIGN KEY (Marketing_Campaign_ID) REFERENCES marketing.MarketingCampaign (Marketing_Campaign_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_Promotion_MarketingCampaign_Marketing_Campaign_ID.';
END;
GO

-- R16: Market -> Market Segment
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketSegment') AND f.name = N'FK_MarketSegment_Market_Market_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketSegment DROP CONSTRAINT FK_MarketSegment_Market_Market_ID;
    PRINT N'FK_MarketSegment_Market_Market_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketSegment WITH CHECK ADD CONSTRAINT FK_MarketSegment_Market_Market_ID
        FOREIGN KEY (Market_ID) REFERENCES marketing.Market (Market_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketSegment_Market_Market_ID.';
END;
GO

-- R17: Market -> Market Research
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketResearch') AND f.name = N'FK_MarketResearch_Market_Market_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketResearch DROP CONSTRAINT FK_MarketResearch_Market_Market_ID;
    PRINT N'FK_MarketResearch_Market_Market_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketResearch WITH CHECK ADD CONSTRAINT FK_MarketResearch_Market_Market_ID
        FOREIGN KEY (Market_ID) REFERENCES marketing.Market (Market_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketResearch_Market_Market_ID.';
END;
GO

-- R18: Market -> Market Price
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketPrice') AND f.name = N'FK_MarketPrice_Market_Market_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketPrice DROP CONSTRAINT FK_MarketPrice_Market_Market_ID;
    PRINT N'FK_MarketPrice_Market_Market_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketPrice WITH CHECK ADD CONSTRAINT FK_MarketPrice_Market_Market_ID
        FOREIGN KEY (Market_ID) REFERENCES marketing.Market (Market_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketPrice_Market_Market_ID.';
END;
GO

-- R19: Market -> Competitor
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.Competitor') AND f.name = N'FK_Competitor_Market_Market_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.Competitor DROP CONSTRAINT FK_Competitor_Market_Market_ID;
    PRINT N'FK_Competitor_Market_Market_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.Competitor WITH CHECK ADD CONSTRAINT FK_Competitor_Market_Market_ID
        FOREIGN KEY (Market_ID) REFERENCES marketing.Market (Market_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_Competitor_Market_Market_ID.';
END;
GO

-- R20: Market Segment -> Market Survey
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketSurvey') AND f.name = N'FK_MarketSurvey_MarketSegment_Market_Segment_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Market_Segment_ID -> marketing.MarketSegment(Market_Segment_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketSurvey DROP CONSTRAINT FK_MarketSurvey_MarketSegment_Market_Segment_ID;
    PRINT N'FK_MarketSurvey_MarketSegment_Market_Segment_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketSurvey WITH CHECK ADD CONSTRAINT FK_MarketSurvey_MarketSegment_Market_Segment_ID
        FOREIGN KEY (Market_Segment_ID) REFERENCES marketing.MarketSegment (Market_Segment_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketSurvey_MarketSegment_Market_Segment_ID.';
END;
GO

-- R21: Market Research -> Market Survey
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketSurvey') AND f.name = N'FK_MarketSurvey_MarketResearch_Market_Research_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketSurvey DROP CONSTRAINT FK_MarketSurvey_MarketResearch_Market_Research_ID;
    PRINT N'FK_MarketSurvey_MarketResearch_Market_Research_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketSurvey WITH CHECK ADD CONSTRAINT FK_MarketSurvey_MarketResearch_Market_Research_ID
        FOREIGN KEY (Market_Research_ID) REFERENCES marketing.MarketResearch (Market_Research_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketSurvey_MarketResearch_Market_Research_ID.';
END;
GO

-- R22: Market Research -> Research Result
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.ResearchResult') AND f.name = N'FK_ResearchResult_MarketResearch_Market_Research_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.ResearchResult DROP CONSTRAINT FK_ResearchResult_MarketResearch_Market_Research_ID;
    PRINT N'FK_ResearchResult_MarketResearch_Market_Research_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.ResearchResult WITH CHECK ADD CONSTRAINT FK_ResearchResult_MarketResearch_Market_Research_ID
        FOREIGN KEY (Market_Research_ID) REFERENCES marketing.MarketResearch (Market_Research_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_ResearchResult_MarketResearch_Market_Research_ID.';
END;
GO

-- R25: Competitor -> Competitor Product
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CompetitorProduct') AND f.name = N'FK_CompetitorProduct_Competitor_Competitor_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Competitor_ID -> marketing.Competitor(Competitor_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CompetitorProduct DROP CONSTRAINT FK_CompetitorProduct_Competitor_Competitor_ID;
    PRINT N'FK_CompetitorProduct_Competitor_Competitor_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CompetitorProduct WITH CHECK ADD CONSTRAINT FK_CompetitorProduct_Competitor_Competitor_ID
        FOREIGN KEY (Competitor_ID) REFERENCES marketing.Competitor (Competitor_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CompetitorProduct_Competitor_Competitor_ID.';
END;
GO

-- R26: Competitor Product -> Market Price
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.MarketPrice') AND f.name = N'FK_MarketPrice_CompetitorProduct_Competitor_Product_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Competitor_Product_ID -> marketing.CompetitorProduct(Competitor_Product_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.MarketPrice DROP CONSTRAINT FK_MarketPrice_CompetitorProduct_Competitor_Product_ID;
    PRINT N'FK_MarketPrice_CompetitorProduct_Competitor_Product_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.MarketPrice WITH CHECK ADD CONSTRAINT FK_MarketPrice_CompetitorProduct_Competitor_Product_ID
        FOREIGN KEY (Competitor_Product_ID) REFERENCES marketing.CompetitorProduct (Competitor_Product_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_MarketPrice_CompetitorProduct_Competitor_Product_ID.';
END;
GO

-- R27: Campaign Channel -> Campaign Budget
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CampaignBudget') AND f.name = N'FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignBudget DROP CONSTRAINT FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID;
    PRINT N'FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignBudget WITH CHECK ADD CONSTRAINT FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID
        FOREIGN KEY (Campaign_Channel_ID) REFERENCES marketing.CampaignChannel (Campaign_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID.';
END;
GO

-- R28: Campaign Channel -> Campaign Cost
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CampaignCost') AND f.name = N'FK_CampaignCost_CampaignChannel_Campaign_Channel_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignCost DROP CONSTRAINT FK_CampaignCost_CampaignChannel_Campaign_Channel_ID;
    PRINT N'FK_CampaignCost_CampaignChannel_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignCost WITH CHECK ADD CONSTRAINT FK_CampaignCost_CampaignChannel_Campaign_Channel_ID
        FOREIGN KEY (Campaign_Channel_ID) REFERENCES marketing.CampaignChannel (Campaign_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CampaignCost_CampaignChannel_Campaign_Channel_ID.';
END;
GO

-- R29: Product Category -> Product Category
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'ref.ProductCategory') AND f.name = N'FK_ProductCategory_ProductCategory_Parent_Category_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Parent_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE ref.ProductCategory DROP CONSTRAINT FK_ProductCategory_ProductCategory_Parent_Category_ID;
    PRINT N'FK_ProductCategory_ProductCategory_Parent_Category_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE ref.ProductCategory WITH CHECK ADD CONSTRAINT FK_ProductCategory_ProductCategory_Parent_Category_ID
        FOREIGN KEY (Parent_Category_ID) REFERENCES ref.ProductCategory (Product_Category_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_ProductCategory_ProductCategory_Parent_Category_ID.';
END;
GO

-- R27 rule: Marketing Campaign Channel -> Campaign Budget  (enforces: channel of a budget/cost row must be a channel of that campaign)
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CampaignBudget') AND f.name = N'FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignBudget DROP CONSTRAINT FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID;
    PRINT N'FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignBudget WITH CHECK ADD CONSTRAINT FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID
        FOREIGN KEY (Marketing_Campaign_ID, Campaign_Channel_ID) REFERENCES marketing.MarketingCampaignChannel (Marketing_Campaign_ID, Campaign_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID.';
END;
GO

-- R28 rule: Marketing Campaign Channel -> Campaign Cost  (enforces: channel of a budget/cost row must be a channel of that campaign)
DECLARE @sig nvarchar(max);
SELECT @sig = CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
       OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
       STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
       f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
FROM sys.foreign_keys f
JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE f.parent_object_id = OBJECT_ID(N'marketing.CampaignCost') AND f.name = N'FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID'
GROUP BY f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc;
IF @sig IS NOT NULL AND @sig COLLATE Latin1_General_BIN2 <> N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION' COLLATE Latin1_General_BIN2
BEGIN
    ALTER TABLE marketing.CampaignCost DROP CONSTRAINT FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID;
    PRINT N'FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID: existing definition differed - replaced. Old: ' + @sig;
    SET @sig = NULL;
END;
IF @sig IS NULL
BEGIN
    ALTER TABLE marketing.CampaignCost WITH CHECK ADD CONSTRAINT FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID
        FOREIGN KEY (Marketing_Campaign_ID, Campaign_Channel_ID) REFERENCES marketing.MarketingCampaignChannel (Marketing_Campaign_ID, Campaign_Channel_ID)
        ON DELETE NO ACTION ON UPDATE NO ACTION;
    PRINT N'Created FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID.';
END;
GO

/* ========================================================================
   5. Constraint status: every CHECK and FOREIGN KEY must be enabled and trusted (existing rows validated)
   ======================================================================== */

DECLARE @tbl nvarchar(300), @con sysname, @sql nvarchar(max), @n int = 0;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT QUOTENAME(OBJECT_SCHEMA_NAME(k.parent_object_id)) + N'.' + QUOTENAME(OBJECT_NAME(k.parent_object_id)), k.name
    FROM (SELECT parent_object_id, name, is_disabled, is_not_trusted FROM sys.check_constraints
          UNION ALL SELECT parent_object_id, name, is_disabled, is_not_trusted FROM sys.foreign_keys) k
    WHERE (k.is_disabled = 1 OR k.is_not_trusted = 1)
      AND k.parent_object_id IN (SELECT OBJECT_ID(n) FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n));
OPEN c; FETCH NEXT FROM c INTO @tbl, @con;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @sql = N'ALTER TABLE ' + @tbl + N' WITH CHECK CHECK CONSTRAINT ' + QUOTENAME(@con) + N';';
    EXEC (@sql);
    PRINT N'Re-enabled and validated ' + @con + N' (it was disabled or not trusted).';
    SET @n += 1;
    FETCH NEXT FROM c INTO @tbl, @con;
END;
CLOSE c; DEALLOCATE c;
PRINT CONCAT(N'Constraint status checked: ', @n, N' constraint(s) had to be re-enabled.');
GO

/* ========================================================================
   6. Integrity triggers for rules that depend on several rows (a CHECK constraint cannot see other rows)
   ======================================================================== */

-- TR_ProductPrice_NoOverlap: raises error 51001 and rolls the statement back when the rule is broken.
-- Created through EXEC so that the batch also compiles when the prerequisite check above has stopped the script.
IF OBJECT_ID(N'marketing.ProductPrice', N'U') IS NOT NULL
BEGIN
    EXEC (N'
CREATE OR ALTER TRIGGER marketing.TR_ProductPrice_NoOverlap
ON marketing.ProductPrice
AFTER INSERT, UPDATE
AS
BEGIN
    /* Stage 6 rule (Product Price): for one SKU_ID and one Price_Type the validity periods must not overlap.
       Effective_To NULL means open-ended. Every inserted or updated row is compared with all rows of the same
       SKU_ID and Price_Type, including the other rows of the same statement. Uses IX_ProductPrice_SKU_ID_Price_Type_Effective_From. */
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    IF EXISTS (
        SELECT 1
        FROM inserted AS i
        JOIN marketing.ProductPrice AS p
          ON  p.SKU_ID = i.SKU_ID
          AND p.Price_Type = i.Price_Type
          AND p.Product_Price_ID <> i.Product_Price_ID
          AND p.Effective_From <= ISNULL(i.Effective_To, ''9999-12-31'')
          AND i.Effective_From <= ISNULL(p.Effective_To, ''9999-12-31''))
    BEGIN
        THROW 51001, N''ProductPrice: the validity period overlaps another price of the same SKU_ID and Price_Type.'', 1;
    END;
END;
');
    EXEC (N'ENABLE TRIGGER marketing.TR_ProductPrice_NoOverlap ON marketing.ProductPrice;');
    PRINT N'Trigger marketing.TR_ProductPrice_NoOverlap is in place and enabled (CREATE OR ALTER).';
END;
GO

-- TR_ProductCategory_Hierarchy: raises error 51002 / 51003 and rolls the statement back when the rule is broken.
-- Created through EXEC so that the batch also compiles when the prerequisite check above has stopped the script.
IF OBJECT_ID(N'ref.ProductCategory', N'U') IS NOT NULL
BEGIN
    EXEC (N'
CREATE OR ALTER TRIGGER ref.TR_ProductCategory_Hierarchy
ON ref.ProductCategory
AFTER INSERT, UPDATE
AS
BEGIN
    /* Stage 6 rules (Product Category, R29): (1) no cycles in the parent chain; (2) Category_Level is 1 for a
       root and parent level + 1 for a child. Checked for the inserted/updated rows and for their direct children
       (a change of a parent''s level must move its children in the same statement). */
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @bad int;
    WITH up AS (
        SELECT i.Product_Category_ID AS Start_ID, c.Parent_Category_ID AS Ancestor_ID, 1 AS Depth
        FROM inserted AS i
        JOIN ref.ProductCategory AS c ON c.Product_Category_ID = i.Product_Category_ID
        WHERE c.Parent_Category_ID IS NOT NULL
        UNION ALL
        SELECT u.Start_ID, c.Parent_Category_ID, u.Depth + 1
        FROM up AS u
        JOIN ref.ProductCategory AS c ON c.Product_Category_ID = u.Ancestor_ID
        WHERE c.Parent_Category_ID IS NOT NULL AND u.Ancestor_ID <> u.Start_ID AND u.Depth < 100)
    SELECT @bad = COUNT(*) FROM up WHERE Ancestor_ID = Start_ID OR Depth >= 100;
    IF @bad > 0
    BEGIN
        THROW 51003, N''ProductCategory: the parent assignment creates a cycle in the category hierarchy.'', 1;
    END;
    IF EXISTS (
        SELECT 1
        FROM ref.ProductCategory AS c
        LEFT JOIN ref.ProductCategory AS p ON p.Product_Category_ID = c.Parent_Category_ID
        WHERE (c.Product_Category_ID IN (SELECT Product_Category_ID FROM inserted)
               OR c.Parent_Category_ID IN (SELECT Product_Category_ID FROM inserted))
          AND c.Category_Level <> ISNULL(p.Category_Level + 1, 1))
    BEGIN
        THROW 51002, N''ProductCategory: Category_Level must be 1 for a root category and the parent level + 1 for a child category.'', 1;
    END;
END;
');
    EXEC (N'ENABLE TRIGGER ref.TR_ProductCategory_Hierarchy ON ref.ProductCategory;');
    PRINT N'Trigger ref.TR_ProductCategory_Hierarchy is in place and enabled (CREATE OR ALTER).';
END;
GO

/* ---- Verification: existing structure is compared with the expected definition (not assumed to be correct) ---- */
DECLARE @E TABLE (kind nvarchar(10), obj sysname, parent nvarchar(300), sig nvarchar(max));
INSERT @E VALUES
    (N'UQ', N'UQ_ProductCategory_Category_Code', N'ref.ProductCategory', N'NONCLUSTERED|UNIQUE|Category_Code||'),
    (N'UQ', N'UQ_Package_Package_Code', N'ref.Package', N'NONCLUSTERED|UNIQUE|Package_Code||'),
    (N'UQ', N'UQ_Brand_Brand_Code', N'core.Brand', N'NONCLUSTERED|UNIQUE|Brand_Code||'),
    (N'UQ', N'UQ_Product_Product_Code', N'core.Product', N'NONCLUSTERED|UNIQUE|Product_Code||'),
    (N'UQ', N'UQ_SKU_SKU_Code', N'core.SKU', N'NONCLUSTERED|UNIQUE|SKU_Code||'),
    (N'UX', N'UQ_SKU_Barcode', N'core.SKU', N'NONCLUSTERED|UNIQUE|Barcode||([Barcode] IS NOT NULL)'),
    (N'UQ', N'UQ_Promotion_Promotion_Code', N'marketing.Promotion', N'NONCLUSTERED|UNIQUE|Promotion_Code||'),
    (N'UQ', N'UQ_Market_Market_Code', N'marketing.Market', N'NONCLUSTERED|UNIQUE|Market_Code||'),
    (N'UQ', N'UQ_MarketSegment_Segment_Code', N'marketing.MarketSegment', N'NONCLUSTERED|UNIQUE|Segment_Code||'),
    (N'UQ', N'UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date', N'marketing.CampaignResult', N'NONCLUSTERED|UNIQUE|Marketing_Campaign_ID,Metric_Name,Measurement_Date||'),
    (N'CK', N'CK_Brand_Brand_End_Date', N'core.Brand', N'([Brand_End_Date] IS NULL OR [Brand_Start_Date] IS NOT NULL AND [Brand_End_Date]>=[Brand_Start_Date])'),
    (N'CK', N'CK_Brand_Brand_Country', N'core.Brand', N'(([Brand_Country]) collate Latin1_General_BIN like ''[A-Z][A-Z]'')'),
    (N'CK', N'CK_Product_Weight', N'core.Product', N'([Weight]>(0))'),
    (N'CK', N'CK_Product_Tax_Rate', N'core.Product', N'([Tax_Rate]>=(0) AND [Tax_Rate]<=(100))'),
    (N'CK', N'CK_Product_Product_Updated_Date', N'core.Product', N'([Product_Updated_Date]>=[Product_Created_Date])'),
    (N'CK', N'CK_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'([Parent_Category_ID]<>[Product_Category_ID])'),
    (N'CK', N'CK_ProductCategory_Category_Level', N'ref.ProductCategory', N'([Category_Level]>=(1))'),
    (N'CK', N'CK_SKU_Weight', N'core.SKU', N'([Weight]>(0))'),
    (N'CK', N'CK_SKU_Standard_Cost', N'core.SKU', N'([Standard_Cost]>=(0))'),
    (N'CK', N'CK_SKU_Currency', N'core.SKU', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_SKU_Standard_Cost_Currency', N'core.SKU', N'([Standard_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_ProductPrice_Unit_Price', N'marketing.ProductPrice', N'([Unit_Price]>=(0))'),
    (N'CK', N'CK_ProductPrice_Effective_To', N'marketing.ProductPrice', N'([Effective_To]>=[Effective_From])'),
    (N'CK', N'CK_ProductPrice_Currency', N'marketing.ProductPrice', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_CampaignChannel_Channel_Status', N'marketing.CampaignChannel', N'([Channel_Status]=N''Inactive'' OR [Channel_Status]=N''Active'')'),
    (N'CK', N'CK_CampaignAudience_Audience_Status', N'marketing.CampaignAudience', N'([Audience_Status]=N''Inactive'' OR [Audience_Status]=N''Active'')'),
    (N'CK', N'CK_MarketingCampaign_End_Date', N'marketing.MarketingCampaign', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_MarketingCampaign_Campaign_Purpose', N'marketing.MarketingCampaign', N'([Campaign_Purpose]=N''Marketing'' OR [Campaign_Purpose]=N''Brand'')'),
    (N'CK', N'CK_MarketingCampaign_Brand_ID', N'marketing.MarketingCampaign', N'([Campaign_Purpose]<>N''Brand'' OR [Brand_ID] IS NOT NULL)'),
    (N'CK', N'CK_CampaignBudget_Total_Allocated_Amount', N'marketing.CampaignBudget', N'([Total_Allocated_Amount]>=(0))'),
    (N'CK', N'CK_CampaignBudget_Currency', N'marketing.CampaignBudget', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_CampaignCost_Actual_Spent', N'marketing.CampaignCost', N'([Actual_Spent]>=(0))'),
    (N'CK', N'CK_CampaignCost_Currency', N'marketing.CampaignCost', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_Promotion_End_Date', N'marketing.Promotion', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_Promotion_Discount_Type', N'marketing.Promotion', N'([Discount_Type]=N''Fixed Amount'' OR [Discount_Type]=N''Percentage'')'),
    (N'CK', N'CK_Promotion_Discount_Value', N'marketing.Promotion', N'([Discount_Value]>=(0) AND ([Discount_Type]<>N''Percentage'' OR [Discount_Value]<=(100)))'),
    (N'CK', N'CK_Promotion_Discount_Type_Currency', N'marketing.Promotion', N'([Discount_Type]<>N''Fixed Amount'' OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_Promotion_Currency', N'marketing.Promotion', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_BrandActivity_Activity_End_Date', N'marketing.BrandActivity', N'([Activity_End_Date] IS NULL OR [Activity_Start_Date] IS NOT NULL AND [Activity_End_Date]>=[Activity_Start_Date])'),
    (N'CK', N'CK_BrandActivity_Activity_Cost', N'marketing.BrandActivity', N'([Activity_Cost]>=(0))'),
    (N'CK', N'CK_BrandActivity_Currency', N'marketing.BrandActivity', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_BrandActivity_Activity_Cost_Currency', N'marketing.BrandActivity', N'([Activity_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_MarketSegment_Segmentation_Basis', N'marketing.MarketSegment', N'([Segmentation_Basis]=N''Behavioral'' OR [Segmentation_Basis]=N''Demographic'' OR [Segmentation_Basis]=N''Geographic'')'),
    (N'CK', N'CK_MarketResearch_End_Date', N'marketing.MarketResearch', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_MarketResearch_Research_Cost', N'marketing.MarketResearch', N'([Research_Cost]>=(0))'),
    (N'CK', N'CK_MarketResearch_Currency', N'marketing.MarketResearch', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_MarketResearch_Research_Cost_Currency', N'marketing.MarketResearch', N'([Research_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_MarketSurvey_Sample_Size', N'marketing.MarketSurvey', N'([Sample_Size]>(0))'),
    (N'CK', N'CK_MarketPrice_Product_ID_Competitor_Product_ID', N'marketing.MarketPrice', N'([Product_ID] IS NOT NULL AND [Competitor_Product_ID] IS NULL OR [Product_ID] IS NULL AND [Competitor_Product_ID] IS NOT NULL)'),
    (N'CK', N'CK_MarketPrice_Price_Value', N'marketing.MarketPrice', N'([Price_Value]>=(0))'),
    (N'CK', N'CK_MarketPrice_Currency', N'marketing.MarketPrice', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'DF', N'DF_Product_Product_Created_Date', N'core.Product', N'Product_Created_Date=(sysdatetime())'),
    (N'FK', N'FK_Product_ProductCategory_Product_Category_ID', N'core.Product', N'Product_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Product_Brand_Brand_ID', N'core.Product', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_SKU_Product_Product_ID', N'core.SKU', N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_Product_Product_ID', N'marketing.MarketPrice', N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_SKU_Package_Package_ID', N'core.SKU', N'Package_ID -> ref.Package(Package_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ProductPrice_SKU_SKU_ID', N'marketing.ProductPrice', N'SKU_ID -> core.SKU(SKU_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_BrandActivity_Brand_Brand_ID', N'marketing.BrandActivity', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaign_Brand_Brand_ID', N'marketing.MarketingCampaign', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID', N'marketing.MarketingCampaignChannel', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID', N'marketing.MarketingCampaignChannel', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID', N'marketing.MarketingCampaignAudience', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID', N'marketing.MarketingCampaignAudience', N'Campaign_Audience_ID -> marketing.CampaignAudience(Campaign_Audience_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignBudget', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignCost', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignResult', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Promotion_MarketingCampaign_Marketing_Campaign_ID', N'marketing.Promotion', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSegment_Market_Market_ID', N'marketing.MarketSegment', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketResearch_Market_Market_ID', N'marketing.MarketResearch', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_Market_Market_ID', N'marketing.MarketPrice', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Competitor_Market_Market_ID', N'marketing.Competitor', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSurvey_MarketSegment_Market_Segment_ID', N'marketing.MarketSurvey', N'Market_Segment_ID -> marketing.MarketSegment(Market_Segment_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSurvey_MarketResearch_Market_Research_ID', N'marketing.MarketSurvey', N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ResearchResult_MarketResearch_Market_Research_ID', N'marketing.ResearchResult', N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CompetitorProduct_Competitor_Competitor_ID', N'marketing.CompetitorProduct', N'Competitor_ID -> marketing.Competitor(Competitor_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_CompetitorProduct_Competitor_Product_ID', N'marketing.MarketPrice', N'Competitor_Product_ID -> marketing.CompetitorProduct(Competitor_Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID', N'marketing.CampaignBudget', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_CampaignChannel_Campaign_Channel_ID', N'marketing.CampaignCost', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ProductCategory_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'Parent_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignBudget', N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignCost', N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'TR', N'TR_ProductPrice_NoOverlap', N'marketing.ProductPrice', N'marketing.ProductPrice|AFTER|INSERT,UPDATE|ENABLED'),
    (N'TR', N'TR_ProductCategory_Hierarchy', N'ref.ProductCategory', N'ref.ProductCategory|AFTER|INSERT,UPDATE|ENABLED');
DECLARE @D TABLE (kind nvarchar(10), obj sysname, problem nvarchar(max));
WITH tbl AS (SELECT OBJECT_ID(n) AS object_id, n AS full_name FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n) WHERE OBJECT_ID(n) IS NOT NULL),
icols AS (
    SELECT i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition,
           STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS keys,
           STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS incs
    FROM sys.indexes i
    JOIN tbl t ON t.object_id = i.object_id
    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
    GROUP BY i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition),
act AS (
    SELECT N'TABLE' AS kind, t.full_name AS obj, t.full_name AS parent,
           (SELECT STRING_AGG(CONCAT(CAST(c.name AS nvarchar(max)), N' ', CASE WHEN ty.name IN (N'nvarchar', N'nchar') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length / 2 AS nvarchar(10)) END + N')' WHEN ty.name IN (N'varchar', N'char') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length AS nvarchar(10)) END + N')' WHEN ty.name IN (N'decimal', N'numeric') THEN ty.name + N'(' + CAST(c.precision AS nvarchar(10)) + N',' + CAST(c.scale AS nvarchar(10)) + N')' WHEN ty.name = N'datetime2' THEN N'datetime2(' + CAST(c.scale AS nvarchar(10)) + N')' ELSE ty.name END, IIF(c.is_nullable = 1, N' NULL', N' NOT NULL'), IIF(c.is_identity = 1, N' IDENTITY', N'')), N'; ')
                   WITHIN GROUP (ORDER BY c.column_id)
            FROM sys.columns c JOIN sys.types ty ON ty.user_type_id = c.user_type_id WHERE c.object_id = t.object_id) AS sig
    FROM tbl t
    UNION ALL
    SELECT CASE WHEN x.is_primary_key = 1 THEN N'PK' WHEN x.is_unique_constraint = 1 THEN N'UQ' WHEN x.is_unique = 1 THEN N'UX' ELSE N'IX' END,
           x.name, t.full_name,
           CASE WHEN x.is_primary_key = 1 THEN CONCAT(x.type_desc, N':', x.keys)
                ELSE CONCAT(x.type_desc, N'|', IIF(x.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|', x.keys, N'|', x.incs, N'|', x.filter_definition) END
    FROM icols x JOIN tbl t ON t.object_id = x.object_id
    UNION ALL
    SELECT N'CK', k.name, t.full_name, k.definition FROM sys.check_constraints k JOIN tbl t ON t.object_id = k.parent_object_id
    UNION ALL
    SELECT N'DF', d.name, t.full_name, CONCAT(col.name, N'=', d.definition)
    FROM sys.default_constraints d JOIN tbl t ON t.object_id = d.parent_object_id
    JOIN sys.columns col ON col.object_id = d.parent_object_id AND col.column_id = d.parent_column_id
    UNION ALL
    SELECT N'FK', f.name, t.full_name,
           CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
                  OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
                  STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
                  f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
    FROM sys.foreign_keys f JOIN tbl t ON t.object_id = f.parent_object_id
    JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
    JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
    JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
    GROUP BY f.name, t.full_name, f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc
    UNION ALL
    SELECT N'TR', tr.name, t.full_name,
           CONCAT(t.full_name, N'|', IIF(tr.is_instead_of_trigger = 1, N'INSTEAD OF', N'AFTER'), N'|',
                  (SELECT STRING_AGG(CAST(te.type_desc AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY te.type_desc) FROM sys.trigger_events te WHERE te.object_id = tr.object_id),
                  N'|', IIF(tr.is_disabled = 1, N'DISABLED', N'ENABLED'))
    FROM sys.triggers tr JOIN tbl t ON t.object_id = tr.parent_id)
INSERT @D
SELECT COALESCE(e.kind, a.kind), COALESCE(e.obj, a.obj),
       CASE WHEN a.obj IS NULL THEN N'missing'
            WHEN e.obj IS NULL THEN N'unexpected object: ' + a.sig
            ELSE N'expected [' + e.sig + N'] actual [' + a.sig + N']' END
FROM @E e
FULL JOIN (SELECT * FROM act WHERE kind IN (N'UQ', N'UX', N'CK', N'DF', N'FK', N'TR')) a
  ON a.kind = e.kind AND a.obj COLLATE Latin1_General_BIN2 = e.obj COLLATE Latin1_General_BIN2 AND a.parent COLLATE Latin1_General_BIN2 = e.parent COLLATE Latin1_General_BIN2
WHERE a.obj IS NULL OR e.obj IS NULL OR a.sig COLLATE Latin1_General_BIN2 <> e.sig COLLATE Latin1_General_BIN2;
DECLARE @nE int = (SELECT COUNT(*) FROM @E), @nD int = (SELECT COUNT(*) FROM @D), @line nvarchar(max);
IF @nD = 0
    PRINT CONCAT(N'Verification passed: all ', @nE, N' UNIQUE, CHECK, DEFAULT, FOREIGN KEY and trigger definitions match the expected definition.');
ELSE
BEGIN
    DECLARE d CURSOR LOCAL FAST_FORWARD FOR SELECT CONCAT(N'  DIFFERENCE ', kind, N' ', obj, N': ', problem) FROM @D;
    OPEN d; FETCH NEXT FROM d INTO @line;
    WHILE @@FETCH_STATUS = 0 BEGIN PRINT @line; FETCH NEXT FROM d INTO @line; END;
    CLOSE d; DEALLOCATE d;
    RAISERROR(N'Verification FAILED: %d object(s) differ from the expected definition (see the lines above).', 16, 1, @nD);
END;
GO

SET NOEXEC OFF;
GO
PRINT N'07-Team2-04-Create-Constraints.sql finished.';
GO
