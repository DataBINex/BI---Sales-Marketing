﻿/*
    Project : Food Distribution (Etemad Iranian Food Distribution)
    Stage   : 7 - Physical Data Model
    Team    : Team 2 - Product & Marketing
    Database: FoodDistributionDB
    SQL Server: 2022
    Version : 1.1 (2026-10-28)
    File    : 07-Team2-06-Test-Validation.sql
    Purpose : Test only (not part of the build).
              Part A  structure: the real definition of every table, key, constraint, index and trigger is compared
                      with the expected definition (columns and their order, referenced columns, CHECK text, filters...).
              Part B  constraint behaviour: valid rows are accepted; each invalid row must be rejected with the
                      expected error number BY the expected constraint.
              Part C  multi-row rules (price overlap, category level and cycles), one transaction per test.
              Part D  clean-up: no test row left, IDENTITY seeds restored, structure unchanged.
              Every test prints: TEST|id|PASS or FAIL|goal|input|expected|actual
    Run order: 6 (after 07-Team2-05-Create-Indexes.sql), on an EMPTY Team 2 database.
*/

USE [FoodDistributionDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT OFF;
GO

/* ========================================================================
   Part A - Structure: the real definition of every object is compared with the expected definition
   ======================================================================== */
IF OBJECT_ID(N'tempdb..#R') IS NOT NULL DROP TABLE #R;
CREATE TABLE #R (seq int IDENTITY, id varchar(10), status varchar(4), goal nvarchar(400), input nvarchar(1000), expected nvarchar(1000), actual nvarchar(max));
IF OBJECT_ID(N'tempdb..#Diff') IS NOT NULL DROP TABLE #Diff;
CREATE TABLE #Diff (kind nvarchar(10), obj sysname, problem nvarchar(max));
GO

DECLARE @E TABLE (kind nvarchar(10), obj sysname, parent nvarchar(300), sig nvarchar(max));
INSERT @E VALUES
    (N'TABLE', N'ref.ProductCategory', N'ref.ProductCategory', N'Product_Category_ID int NOT NULL IDENTITY; Parent_Category_ID int NULL; Category_Code nvarchar(30) NOT NULL; Category_Name nvarchar(150) NOT NULL; Category_Level int NOT NULL; Category_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_ProductCategory', N'ref.ProductCategory', N'CLUSTERED:Product_Category_ID'),
    (N'TABLE', N'ref.Package', N'ref.Package', N'Package_ID int NOT NULL IDENTITY; Package_Code nvarchar(30) NOT NULL; Package_Name nvarchar(150) NOT NULL; Package_Description nvarchar(1000) NULL'),
    (N'PK', N'PK_Package', N'ref.Package', N'CLUSTERED:Package_ID'),
    (N'TABLE', N'core.Brand', N'core.Brand', N'Brand_ID int NOT NULL IDENTITY; Brand_Name nvarchar(150) NOT NULL; Brand_Code nvarchar(30) NOT NULL; Brand_Type nvarchar(30) NOT NULL; Brand_Status nvarchar(30) NOT NULL; Brand_Start_Date date NULL; Brand_End_Date date NULL; Brand_Owner nvarchar(150) NULL; Brand_Positioning nvarchar(500) NULL; Target_Market nvarchar(100) NULL; Target_Segment nvarchar(100) NULL; Brand_Tagline nvarchar(250) NULL; Brand_Logo_URL nvarchar(500) NULL; Brand_Website nvarchar(500) NULL; Brand_Country char(2) NULL'),
    (N'PK', N'PK_Brand', N'core.Brand', N'CLUSTERED:Brand_ID'),
    (N'TABLE', N'core.Product', N'core.Product', N'Product_ID int NOT NULL IDENTITY; Product_Code nvarchar(30) NOT NULL; Product_Name nvarchar(150) NOT NULL; Product_Description nvarchar(1000) NULL; Product_Category_ID int NOT NULL; Brand_ID int NOT NULL; Product_Type nvarchar(30) NOT NULL; Unit_Of_Measure nvarchar(20) NOT NULL; Product_Status nvarchar(30) NOT NULL; Launch_Date date NULL; Weight decimal(10,3) NULL; Tax_Rate decimal(5,2) NULL; Product_Created_Date datetime2(0) NOT NULL; Product_Updated_Date datetime2(0) NULL'),
    (N'PK', N'PK_Product', N'core.Product', N'CLUSTERED:Product_ID'),
    (N'TABLE', N'core.SKU', N'core.SKU', N'SKU_ID int NOT NULL IDENTITY; Product_ID int NOT NULL; Package_ID int NOT NULL; SKU_Code nvarchar(30) NOT NULL; SKU_Name nvarchar(150) NOT NULL; Barcode nvarchar(20) NULL; Weight decimal(10,3) NULL; Standard_Cost decimal(18,2) NULL; Currency char(3) NULL; SKU_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_SKU', N'core.SKU', N'CLUSTERED:SKU_ID'),
    (N'TABLE', N'marketing.ProductPrice', N'marketing.ProductPrice', N'Product_Price_ID int NOT NULL IDENTITY; SKU_ID int NOT NULL; Price_Type nvarchar(30) NOT NULL; Unit_Price decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Effective_From date NOT NULL; Effective_To date NULL; Price_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_ProductPrice', N'marketing.ProductPrice', N'CLUSTERED:Product_Price_ID'),
    (N'TABLE', N'marketing.CampaignChannel', N'marketing.CampaignChannel', N'Campaign_Channel_ID int NOT NULL IDENTITY; Channel_Name nvarchar(150) NOT NULL; Channel_Type nvarchar(30) NOT NULL; Channel_Description nvarchar(1000) NULL; Channel_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_CampaignChannel', N'marketing.CampaignChannel', N'CLUSTERED:Campaign_Channel_ID'),
    (N'TABLE', N'marketing.CampaignAudience', N'marketing.CampaignAudience', N'Campaign_Audience_ID int NOT NULL IDENTITY; Audience_Name nvarchar(150) NOT NULL; Audience_Type nvarchar(30) NOT NULL; Audience_Description nvarchar(1000) NULL; Audience_Status nvarchar(30) NOT NULL; Age_Range nvarchar(20) NULL; Gender nvarchar(20) NULL; Geographic_Location nvarchar(150) NULL'),
    (N'PK', N'PK_CampaignAudience', N'marketing.CampaignAudience', N'CLUSTERED:Campaign_Audience_ID'),
    (N'TABLE', N'marketing.MarketingCampaign', N'marketing.MarketingCampaign', N'Marketing_Campaign_ID int NOT NULL IDENTITY; Brand_ID int NULL; Campaign_Name nvarchar(150) NOT NULL; Campaign_Type nvarchar(30) NOT NULL; Campaign_Purpose nvarchar(30) NOT NULL; Campaign_Objective nvarchar(500) NULL; Start_Date date NOT NULL; End_Date date NULL; Campaign_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketingCampaign', N'marketing.MarketingCampaign', N'CLUSTERED:Marketing_Campaign_ID'),
    (N'TABLE', N'marketing.MarketingCampaignChannel', N'marketing.MarketingCampaignChannel', N'Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NOT NULL'),
    (N'PK', N'PK_MarketingCampaignChannel', N'marketing.MarketingCampaignChannel', N'CLUSTERED:Marketing_Campaign_ID,Campaign_Channel_ID'),
    (N'TABLE', N'marketing.MarketingCampaignAudience', N'marketing.MarketingCampaignAudience', N'Marketing_Campaign_ID int NOT NULL; Campaign_Audience_ID int NOT NULL'),
    (N'PK', N'PK_MarketingCampaignAudience', N'marketing.MarketingCampaignAudience', N'CLUSTERED:Marketing_Campaign_ID,Campaign_Audience_ID'),
    (N'TABLE', N'marketing.CampaignBudget', N'marketing.CampaignBudget', N'Campaign_Budget_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NULL; Total_Allocated_Amount decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Approval_Date date NULL'),
    (N'PK', N'PK_CampaignBudget', N'marketing.CampaignBudget', N'CLUSTERED:Campaign_Budget_ID'),
    (N'TABLE', N'marketing.CampaignCost', N'marketing.CampaignCost', N'Campaign_Cost_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NULL; Actual_Spent decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Cost_Date date NOT NULL'),
    (N'PK', N'PK_CampaignCost', N'marketing.CampaignCost', N'CLUSTERED:Campaign_Cost_ID'),
    (N'TABLE', N'marketing.CampaignResult', N'marketing.CampaignResult', N'Campaign_Result_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Metric_Name nvarchar(100) NOT NULL; Metric_Value decimal(18,4) NOT NULL; Measurement_Date date NOT NULL'),
    (N'PK', N'PK_CampaignResult', N'marketing.CampaignResult', N'CLUSTERED:Campaign_Result_ID'),
    (N'TABLE', N'marketing.Promotion', N'marketing.Promotion', N'Promotion_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NULL; Promotion_Code nvarchar(30) NOT NULL; Promotion_Name nvarchar(150) NOT NULL; Promotion_Type nvarchar(30) NOT NULL; Discount_Type nvarchar(30) NOT NULL; Discount_Value decimal(18,2) NOT NULL; Currency char(3) NULL; Start_Date date NOT NULL; End_Date date NOT NULL; Promotion_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Promotion', N'marketing.Promotion', N'CLUSTERED:Promotion_ID'),
    (N'TABLE', N'marketing.BrandActivity', N'marketing.BrandActivity', N'Brand_Activity_ID int NOT NULL IDENTITY; Brand_ID int NOT NULL; Activity_Type nvarchar(30) NULL; Activity_Title nvarchar(200) NULL; Activity_Description nvarchar(1000) NULL; Activity_Start_Date date NULL; Activity_End_Date date NULL; Activity_Channel nvarchar(100) NULL; Activity_Status nvarchar(30) NULL; Activity_Owner nvarchar(150) NULL; Activity_Cost decimal(18,2) NULL; Currency char(3) NULL; Activity_Result nvarchar(1000) NULL'),
    (N'PK', N'PK_BrandActivity', N'marketing.BrandActivity', N'CLUSTERED:Brand_Activity_ID'),
    (N'TABLE', N'marketing.Market', N'marketing.Market', N'Market_ID int NOT NULL IDENTITY; Market_Code nvarchar(30) NOT NULL; Market_Name nvarchar(150) NOT NULL; Market_Type nvarchar(30) NULL; Market_Description nvarchar(1000) NULL; Market_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Market', N'marketing.Market', N'CLUSTERED:Market_ID'),
    (N'TABLE', N'marketing.MarketSegment', N'marketing.MarketSegment', N'Market_Segment_ID int NOT NULL IDENTITY; Market_ID int NOT NULL; Segment_Code nvarchar(30) NOT NULL; Segment_Name nvarchar(150) NOT NULL; Segmentation_Basis nvarchar(30) NOT NULL; Segment_Description nvarchar(1000) NULL; Segment_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketSegment', N'marketing.MarketSegment', N'CLUSTERED:Market_Segment_ID'),
    (N'TABLE', N'marketing.MarketResearch', N'marketing.MarketResearch', N'Market_Research_ID int NOT NULL IDENTITY; Market_ID int NOT NULL; Research_Title nvarchar(200) NOT NULL; Research_Type nvarchar(30) NOT NULL; Start_Date date NOT NULL; End_Date date NULL; Research_Status nvarchar(30) NOT NULL; Responsible_Person nvarchar(150) NOT NULL; Research_Cost decimal(18,2) NULL; Currency char(3) NULL'),
    (N'PK', N'PK_MarketResearch', N'marketing.MarketResearch', N'CLUSTERED:Market_Research_ID'),
    (N'TABLE', N'marketing.MarketSurvey', N'marketing.MarketSurvey', N'Market_Survey_ID int NOT NULL IDENTITY; Market_Research_ID int NOT NULL; Market_Segment_ID int NULL; Survey_Title nvarchar(200) NOT NULL; Survey_Date date NOT NULL; Survey_Method nvarchar(30) NOT NULL; Sample_Size int NOT NULL; Survey_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketSurvey', N'marketing.MarketSurvey', N'CLUSTERED:Market_Survey_ID'),
    (N'TABLE', N'marketing.ResearchResult', N'marketing.ResearchResult', N'Research_Result_ID int NOT NULL IDENTITY; Market_Research_ID int NOT NULL; Result_Title nvarchar(200) NOT NULL; Result_Summary nvarchar(2000) NOT NULL; Result_Date date NOT NULL; Recommendation nvarchar(2000) NULL; Opportunity_Identified nvarchar(500) NULL'),
    (N'PK', N'PK_ResearchResult', N'marketing.ResearchResult', N'CLUSTERED:Research_Result_ID'),
    (N'TABLE', N'marketing.Competitor', N'marketing.Competitor', N'Competitor_ID int NOT NULL IDENTITY; Competitor_Name nvarchar(150) NOT NULL; Competitor_Type nvarchar(30) NOT NULL; Market_ID int NULL; Competitor_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Competitor', N'marketing.Competitor', N'CLUSTERED:Competitor_ID'),
    (N'TABLE', N'marketing.CompetitorProduct', N'marketing.CompetitorProduct', N'Competitor_Product_ID int NOT NULL IDENTITY; Competitor_ID int NOT NULL; Competitor_Product_Name nvarchar(150) NOT NULL; Category nvarchar(100) NULL'),
    (N'PK', N'PK_CompetitorProduct', N'marketing.CompetitorProduct', N'CLUSTERED:Competitor_Product_ID'),
    (N'TABLE', N'marketing.MarketPrice', N'marketing.MarketPrice', N'Market_Price_ID int NOT NULL IDENTITY; Product_ID int NULL; Competitor_Product_ID int NULL; Market_ID int NOT NULL; Price_Date datetime2(0) NOT NULL; Price_Value decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Price_Source nvarchar(100) NOT NULL'),
    (N'PK', N'PK_MarketPrice', N'marketing.MarketPrice', N'CLUSTERED:Market_Price_ID'),
    (N'UQ', N'UQ_ProductCategory_Category_Code', N'ref.ProductCategory', N'NONCLUSTERED|UNIQUE|Category_Code||'),
    (N'UQ', N'UQ_Package_Package_Code', N'ref.Package', N'NONCLUSTERED|UNIQUE|Package_Code||'),
    (N'UQ', N'UQ_Brand_Brand_Code', N'core.Brand', N'NONCLUSTERED|UNIQUE|Brand_Code||'),
    (N'UQ', N'UQ_Product_Product_Code', N'core.Product', N'NONCLUSTERED|UNIQUE|Product_Code||'),
    (N'UQ', N'UQ_SKU_SKU_Code', N'core.SKU', N'NONCLUSTERED|UNIQUE|SKU_Code||'),
    (N'UX', N'UQ_SKU_Barcode', N'core.SKU', N'NONCLUSTERED|UNIQUE|Barcode||([Barcode] IS NOT NULL)'),
    (N'UQ', N'UQ_Promotion_Promotion_Code', N'marketing.Promotion', N'NONCLUSTERED|UNIQUE|Promotion_Code||'),
    (N'UQ', N'UQ_Market_Market_Code', N'marketing.Market', N'NONCLUSTERED|UNIQUE|Market_Code||'),
    (N'UQ', N'UQ_MarketSegment_Segment_Code', N'marketing.MarketSegment', N'NONCLUSTERED|UNIQUE|Segment_Code||'),
    (N'UQ', N'UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date', N'marketing.CampaignResult', N'NONCLUSTERED|UNIQUE|Marketing_Campaign_ID,Metric_Name,Measurement_Date||'),
    (N'CK', N'CK_Brand_Brand_End_Date', N'core.Brand', N'([Brand_End_Date] IS NULL OR [Brand_Start_Date] IS NOT NULL AND [Brand_End_Date]>=[Brand_Start_Date])'),
    (N'CK', N'CK_Brand_Brand_Country', N'core.Brand', N'(([Brand_Country]) collate Latin1_General_BIN like ''[A-Z][A-Z]'')'),
    (N'CK', N'CK_Product_Weight', N'core.Product', N'([Weight]>(0))'),
    (N'CK', N'CK_Product_Tax_Rate', N'core.Product', N'([Tax_Rate]>=(0) AND [Tax_Rate]<=(100))'),
    (N'CK', N'CK_Product_Product_Updated_Date', N'core.Product', N'([Product_Updated_Date]>=[Product_Created_Date])'),
    (N'CK', N'CK_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'([Parent_Category_ID]<>[Product_Category_ID])'),
    (N'CK', N'CK_ProductCategory_Category_Level', N'ref.ProductCategory', N'([Category_Level]>=(1))'),
    (N'CK', N'CK_SKU_Weight', N'core.SKU', N'([Weight]>(0))'),
    (N'CK', N'CK_SKU_Standard_Cost', N'core.SKU', N'([Standard_Cost]>=(0))'),
    (N'CK', N'CK_SKU_Currency', N'core.SKU', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_SKU_Standard_Cost_Currency', N'core.SKU', N'([Standard_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_ProductPrice_Unit_Price', N'marketing.ProductPrice', N'([Unit_Price]>=(0))'),
    (N'CK', N'CK_ProductPrice_Effective_To', N'marketing.ProductPrice', N'([Effective_To]>=[Effective_From])'),
    (N'CK', N'CK_ProductPrice_Currency', N'marketing.ProductPrice', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_CampaignChannel_Channel_Status', N'marketing.CampaignChannel', N'([Channel_Status]=N''Inactive'' OR [Channel_Status]=N''Active'')'),
    (N'CK', N'CK_CampaignAudience_Audience_Status', N'marketing.CampaignAudience', N'([Audience_Status]=N''Inactive'' OR [Audience_Status]=N''Active'')'),
    (N'CK', N'CK_MarketingCampaign_End_Date', N'marketing.MarketingCampaign', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_MarketingCampaign_Campaign_Purpose', N'marketing.MarketingCampaign', N'([Campaign_Purpose]=N''Marketing'' OR [Campaign_Purpose]=N''Brand'')'),
    (N'CK', N'CK_MarketingCampaign_Brand_ID', N'marketing.MarketingCampaign', N'([Campaign_Purpose]<>N''Brand'' OR [Brand_ID] IS NOT NULL)'),
    (N'CK', N'CK_CampaignBudget_Total_Allocated_Amount', N'marketing.CampaignBudget', N'([Total_Allocated_Amount]>=(0))'),
    (N'CK', N'CK_CampaignBudget_Currency', N'marketing.CampaignBudget', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_CampaignCost_Actual_Spent', N'marketing.CampaignCost', N'([Actual_Spent]>=(0))'),
    (N'CK', N'CK_CampaignCost_Currency', N'marketing.CampaignCost', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_Promotion_End_Date', N'marketing.Promotion', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_Promotion_Discount_Type', N'marketing.Promotion', N'([Discount_Type]=N''Fixed Amount'' OR [Discount_Type]=N''Percentage'')'),
    (N'CK', N'CK_Promotion_Discount_Value', N'marketing.Promotion', N'([Discount_Value]>=(0) AND ([Discount_Type]<>N''Percentage'' OR [Discount_Value]<=(100)))'),
    (N'CK', N'CK_Promotion_Discount_Type_Currency', N'marketing.Promotion', N'([Discount_Type]<>N''Fixed Amount'' OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_Promotion_Currency', N'marketing.Promotion', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_BrandActivity_Activity_End_Date', N'marketing.BrandActivity', N'([Activity_End_Date] IS NULL OR [Activity_Start_Date] IS NOT NULL AND [Activity_End_Date]>=[Activity_Start_Date])'),
    (N'CK', N'CK_BrandActivity_Activity_Cost', N'marketing.BrandActivity', N'([Activity_Cost]>=(0))'),
    (N'CK', N'CK_BrandActivity_Currency', N'marketing.BrandActivity', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_BrandActivity_Activity_Cost_Currency', N'marketing.BrandActivity', N'([Activity_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_MarketSegment_Segmentation_Basis', N'marketing.MarketSegment', N'([Segmentation_Basis]=N''Behavioral'' OR [Segmentation_Basis]=N''Demographic'' OR [Segmentation_Basis]=N''Geographic'')'),
    (N'CK', N'CK_MarketResearch_End_Date', N'marketing.MarketResearch', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_MarketResearch_Research_Cost', N'marketing.MarketResearch', N'([Research_Cost]>=(0))'),
    (N'CK', N'CK_MarketResearch_Currency', N'marketing.MarketResearch', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_MarketResearch_Research_Cost_Currency', N'marketing.MarketResearch', N'([Research_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_MarketSurvey_Sample_Size', N'marketing.MarketSurvey', N'([Sample_Size]>(0))'),
    (N'CK', N'CK_MarketPrice_Product_ID_Competitor_Product_ID', N'marketing.MarketPrice', N'([Product_ID] IS NOT NULL AND [Competitor_Product_ID] IS NULL OR [Product_ID] IS NULL AND [Competitor_Product_ID] IS NOT NULL)'),
    (N'CK', N'CK_MarketPrice_Price_Value', N'marketing.MarketPrice', N'([Price_Value]>=(0))'),
    (N'CK', N'CK_MarketPrice_Currency', N'marketing.MarketPrice', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'DF', N'DF_Product_Product_Created_Date', N'core.Product', N'Product_Created_Date=(sysdatetime())'),
    (N'FK', N'FK_Product_ProductCategory_Product_Category_ID', N'core.Product', N'Product_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Product_Brand_Brand_ID', N'core.Product', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_SKU_Product_Product_ID', N'core.SKU', N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_Product_Product_ID', N'marketing.MarketPrice', N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_SKU_Package_Package_ID', N'core.SKU', N'Package_ID -> ref.Package(Package_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ProductPrice_SKU_SKU_ID', N'marketing.ProductPrice', N'SKU_ID -> core.SKU(SKU_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_BrandActivity_Brand_Brand_ID', N'marketing.BrandActivity', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaign_Brand_Brand_ID', N'marketing.MarketingCampaign', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID', N'marketing.MarketingCampaignChannel', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID', N'marketing.MarketingCampaignChannel', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID', N'marketing.MarketingCampaignAudience', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID', N'marketing.MarketingCampaignAudience', N'Campaign_Audience_ID -> marketing.CampaignAudience(Campaign_Audience_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignBudget', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignCost', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignResult', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Promotion_MarketingCampaign_Marketing_Campaign_ID', N'marketing.Promotion', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSegment_Market_Market_ID', N'marketing.MarketSegment', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketResearch_Market_Market_ID', N'marketing.MarketResearch', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_Market_Market_ID', N'marketing.MarketPrice', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Competitor_Market_Market_ID', N'marketing.Competitor', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSurvey_MarketSegment_Market_Segment_ID', N'marketing.MarketSurvey', N'Market_Segment_ID -> marketing.MarketSegment(Market_Segment_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSurvey_MarketResearch_Market_Research_ID', N'marketing.MarketSurvey', N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ResearchResult_MarketResearch_Market_Research_ID', N'marketing.ResearchResult', N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CompetitorProduct_Competitor_Competitor_ID', N'marketing.CompetitorProduct', N'Competitor_ID -> marketing.Competitor(Competitor_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_CompetitorProduct_Competitor_Product_ID', N'marketing.MarketPrice', N'Competitor_Product_ID -> marketing.CompetitorProduct(Competitor_Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID', N'marketing.CampaignBudget', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_CampaignChannel_Campaign_Channel_ID', N'marketing.CampaignCost', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ProductCategory_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'Parent_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignBudget', N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignCost', N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'IX', N'IX_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'NONCLUSTERED|NONUNIQUE|Parent_Category_ID||'),
    (N'IX', N'IX_Product_Product_Category_ID', N'core.Product', N'NONCLUSTERED|NONUNIQUE|Product_Category_ID||'),
    (N'IX', N'IX_Product_Brand_ID', N'core.Product', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_SKU_Product_ID', N'core.SKU', N'NONCLUSTERED|NONUNIQUE|Product_ID||'),
    (N'IX', N'IX_SKU_Package_ID', N'core.SKU', N'NONCLUSTERED|NONUNIQUE|Package_ID||'),
    (N'IX', N'IX_ProductPrice_SKU_ID_Price_Type_Effective_From', N'marketing.ProductPrice', N'NONCLUSTERED|NONUNIQUE|SKU_ID,Price_Type,Effective_From||'),
    (N'IX', N'IX_MarketingCampaign_Brand_ID', N'marketing.MarketingCampaign', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_MarketingCampaignChannel_Campaign_Channel_ID', N'marketing.MarketingCampaignChannel', N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID||'),
    (N'IX', N'IX_MarketingCampaignAudience_Campaign_Audience_ID', N'marketing.MarketingCampaignAudience', N'NONCLUSTERED|NONUNIQUE|Campaign_Audience_ID||'),
    (N'IX', N'IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignBudget', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||'),
    (N'IX', N'IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignCost', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||'),
    (N'IX', N'IX_CampaignCost_Campaign_Channel_ID_Cost_Date', N'marketing.CampaignCost', N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID,Cost_Date|Actual_Spent,Currency|([Campaign_Channel_ID] IS NOT NULL)'),
    (N'IX', N'IX_Promotion_Marketing_Campaign_ID', N'marketing.Promotion', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID||'),
    (N'IX', N'IX_BrandActivity_Brand_ID', N'marketing.BrandActivity', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_MarketSegment_Market_ID', N'marketing.MarketSegment', N'NONCLUSTERED|NONUNIQUE|Market_ID||'),
    (N'IX', N'IX_MarketResearch_Market_ID', N'marketing.MarketResearch', N'NONCLUSTERED|NONUNIQUE|Market_ID||'),
    (N'IX', N'IX_MarketSurvey_Market_Research_ID', N'marketing.MarketSurvey', N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||'),
    (N'IX', N'IX_MarketSurvey_Market_Segment_ID', N'marketing.MarketSurvey', N'NONCLUSTERED|NONUNIQUE|Market_Segment_ID||([Market_Segment_ID] IS NOT NULL)'),
    (N'IX', N'IX_ResearchResult_Market_Research_ID', N'marketing.ResearchResult', N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||'),
    (N'IX', N'IX_Competitor_Market_ID', N'marketing.Competitor', N'NONCLUSTERED|NONUNIQUE|Market_ID||([Market_ID] IS NOT NULL)'),
    (N'IX', N'IX_CompetitorProduct_Competitor_ID', N'marketing.CompetitorProduct', N'NONCLUSTERED|NONUNIQUE|Competitor_ID||'),
    (N'IX', N'IX_MarketPrice_Market_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Market_ID,Price_Date|Competitor_Product_ID,Currency,Price_Value,Product_ID|'),
    (N'IX', N'IX_MarketPrice_Product_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Product_ID,Price_Date||([Product_ID] IS NOT NULL)'),
    (N'IX', N'IX_MarketPrice_Competitor_Product_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Competitor_Product_ID,Price_Date||([Competitor_Product_ID] IS NOT NULL)'),
    (N'TR', N'TR_ProductPrice_NoOverlap', N'marketing.ProductPrice', N'marketing.ProductPrice|AFTER|INSERT,UPDATE|ENABLED'),
    (N'TR', N'TR_ProductCategory_Hierarchy', N'ref.ProductCategory', N'ref.ProductCategory|AFTER|INSERT,UPDATE|ENABLED');
WITH tbl AS (SELECT OBJECT_ID(n) AS object_id, n AS full_name FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n) WHERE OBJECT_ID(n) IS NOT NULL),
icols AS (
    SELECT i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition,
           STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS keys,
           STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS incs
    FROM sys.indexes i
    JOIN tbl t ON t.object_id = i.object_id
    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
    GROUP BY i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition),
act AS (
    SELECT N'TABLE' AS kind, t.full_name AS obj, t.full_name AS parent,
           (SELECT STRING_AGG(CONCAT(CAST(c.name AS nvarchar(max)), N' ', CASE WHEN ty.name IN (N'nvarchar', N'nchar') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length / 2 AS nvarchar(10)) END + N')' WHEN ty.name IN (N'varchar', N'char') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length AS nvarchar(10)) END + N')' WHEN ty.name IN (N'decimal', N'numeric') THEN ty.name + N'(' + CAST(c.precision AS nvarchar(10)) + N',' + CAST(c.scale AS nvarchar(10)) + N')' WHEN ty.name = N'datetime2' THEN N'datetime2(' + CAST(c.scale AS nvarchar(10)) + N')' ELSE ty.name END, IIF(c.is_nullable = 1, N' NULL', N' NOT NULL'), IIF(c.is_identity = 1, N' IDENTITY', N'')), N'; ')
                   WITHIN GROUP (ORDER BY c.column_id)
            FROM sys.columns c JOIN sys.types ty ON ty.user_type_id = c.user_type_id WHERE c.object_id = t.object_id) AS sig
    FROM tbl t
    UNION ALL
    SELECT CASE WHEN x.is_primary_key = 1 THEN N'PK' WHEN x.is_unique_constraint = 1 THEN N'UQ' WHEN x.is_unique = 1 THEN N'UX' ELSE N'IX' END,
           x.name, t.full_name,
           CASE WHEN x.is_primary_key = 1 THEN CONCAT(x.type_desc, N':', x.keys)
                ELSE CONCAT(x.type_desc, N'|', IIF(x.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|', x.keys, N'|', x.incs, N'|', x.filter_definition) END
    FROM icols x JOIN tbl t ON t.object_id = x.object_id
    UNION ALL
    SELECT N'CK', k.name, t.full_name, k.definition FROM sys.check_constraints k JOIN tbl t ON t.object_id = k.parent_object_id
    UNION ALL
    SELECT N'DF', d.name, t.full_name, CONCAT(col.name, N'=', d.definition)
    FROM sys.default_constraints d JOIN tbl t ON t.object_id = d.parent_object_id
    JOIN sys.columns col ON col.object_id = d.parent_object_id AND col.column_id = d.parent_column_id
    UNION ALL
    SELECT N'FK', f.name, t.full_name,
           CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
                  OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
                  STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
                  f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
    FROM sys.foreign_keys f JOIN tbl t ON t.object_id = f.parent_object_id
    JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
    JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
    JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
    GROUP BY f.name, t.full_name, f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc
    UNION ALL
    SELECT N'TR', tr.name, t.full_name,
           CONCAT(t.full_name, N'|', IIF(tr.is_instead_of_trigger = 1, N'INSTEAD OF', N'AFTER'), N'|',
                  (SELECT STRING_AGG(CAST(te.type_desc AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY te.type_desc) FROM sys.trigger_events te WHERE te.object_id = tr.object_id),
                  N'|', IIF(tr.is_disabled = 1, N'DISABLED', N'ENABLED'))
    FROM sys.triggers tr JOIN tbl t ON t.object_id = tr.parent_id)
INSERT #Diff
SELECT COALESCE(e.kind, a.kind), COALESCE(e.obj, a.obj),
       CASE WHEN a.obj IS NULL THEN N'missing'
            WHEN e.obj IS NULL THEN N'unexpected object: ' + a.sig
            ELSE N'expected [' + e.sig + N'] actual [' + a.sig + N']' END
FROM @E e
FULL JOIN act a
  ON a.kind = e.kind AND a.obj COLLATE Latin1_General_BIN2 = e.obj COLLATE Latin1_General_BIN2 AND a.parent COLLATE Latin1_General_BIN2 = e.parent COLLATE Latin1_General_BIN2
WHERE a.obj IS NULL OR e.obj IS NULL OR a.sig COLLATE Latin1_General_BIN2 <> e.sig COLLATE Latin1_General_BIN2;

INSERT #R (id, status, goal, input, expected, actual)
SELECT k.id, IIF(d.n = 0, 'PASS', 'FAIL'), k.goal, N'catalog definition', CONCAT(e.n, N' objects match the design, no extra object'),
       IIF(d.n = 0, CONCAT(e.n, N' of ', e.n, N' match'), CONCAT(d.n, N' difference(s); see DETAIL lines'))
FROM (VALUES ('A01', N'TABLE', N'columns of every table: name, order, data type, length, precision, NULL/NOT NULL, IDENTITY'), ('A02', N'PK', N'primary keys: clustered, exact key columns and order'), ('A03', N'UQ', N'UNIQUE constraints: exact columns'), ('A04', N'UX', N'filtered unique index: column, uniqueness and filter'), ('A05', N'FK', N'foreign keys: child columns, referenced table, referenced columns, column order, NO ACTION'), ('A06', N'CK', N'CHECK constraints: actual expression text'), ('A07', N'DF', N'DEFAULT constraints: column and expression'), ('A08', N'IX', N'nonclustered indexes: key columns and order, INCLUDE columns, uniqueness, type, filter'), ('A09', N'TR', N'integrity triggers: table, AFTER, INSERT and UPDATE events, enabled')) k(id, kind, goal)
CROSS APPLY (SELECT COUNT(*) AS n FROM @E WHERE kind = k.kind) e
CROSS APPLY (SELECT COUNT(*) AS n FROM #Diff WHERE kind = k.kind) d;
GO

DECLARE @n int, @list nvarchar(max);
SELECT @n = COUNT(*), @list = STRING_AGG(CAST(k.name AS nvarchar(max)), N', ')
FROM (SELECT parent_object_id, name, is_disabled, is_not_trusted FROM sys.check_constraints
      UNION ALL SELECT parent_object_id, name, is_disabled, is_not_trusted FROM sys.foreign_keys) k
WHERE (k.is_disabled = 1 OR k.is_not_trusted = 1)
  AND k.parent_object_id IN (SELECT OBJECT_ID(n) FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n));
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('A10', IIF(@n = 0, 'PASS', 'FAIL'), N'every CHECK and FOREIGN KEY is enabled and trusted', N'sys.check_constraints, sys.foreign_keys',
        N'0 disabled or untrusted', IIF(@n = 0, N'0 disabled or untrusted', N'not trusted / disabled: ' + @list));

SELECT @n = COUNT(*), @list = STRING_AGG(CAST(f.name + N'.' + pc.name AS nvarchar(max)), N', ')
FROM sys.foreign_key_columns fc
JOIN sys.foreign_keys f ON f.object_id = fc.constraint_object_id
JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
WHERE fc.parent_object_id IN (SELECT OBJECT_ID(n) FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n))
  AND (pc.user_type_id <> rc.user_type_id OR pc.max_length <> rc.max_length);
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('A11', IIF(@n = 0, 'PASS', 'FAIL'), N'FK column data type equals the referenced column', N'sys.foreign_key_columns', N'0 mismatches',
        IIF(@n = 0, N'0 mismatches', @list));
GO

/* ========================================================================
   Part B - Constraint behaviour with sample data (one transaction, ROLLED BACK at the end).
            A negative test passes only if the expected error number is raised BY THE EXPECTED constraint.
   ======================================================================== */
DECLARE @rows bigint = 0;
SELECT @rows += ISNULL((SELECT SUM(p.rows) FROM sys.partitions p WHERE p.object_id = OBJECT_ID(t.n) AND p.index_id IN (0, 1)), 0)
FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) t(n);
IF @rows > 0
BEGIN
    RAISERROR(N'Parts B and C skipped: Team 2 tables already contain data. Run the behaviour tests on an empty database only.', 16, 1);
    SET NOEXEC ON;
END;
GO

SET XACT_ABORT OFF;
DECLARE @B TABLE (seq int IDENTITY, id varchar(10), status varchar(4), goal nvarchar(400), input nvarchar(1000), expected nvarchar(1000), actual nvarchar(max));
BEGIN TRANSACTION;
DECLARE @cat1 int, @cat2 int, @pkg int, @brand int, @prod int, @sku int, @ch int, @ch2 int, @aud int,
        @camp int, @mkt int, @mkt2 int, @seg int, @res int, @comp int, @cprod int, @t0 datetime2(7), @t1 datetime2(7), @v datetime2(0), @p2 int;
BEGIN TRY

    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status)
    VALUES (NULL, N'CAT-DAIRY', N'لبنیات', 1, N'Active');                         SET @cat1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status)
    VALUES (@cat1, N'CAT-MILK', N'شیر', 2, N'Active');                            SET @cat2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'PKG-1L', N'بطری یک لیتری');      SET @pkg = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status, Brand_Start_Date, Brand_Country)
    VALUES (N'اعتماد', N'BR-ETM', N'Corporate', N'Active', '2020-01-01', 'IR');   SET @brand = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status, Weight, Tax_Rate)
    VALUES (N'PRD-001', N'شیر کم‌چرب', @cat2, @brand, N'Physical', N'LT', N'Active', 1.030, 9.00);   SET @prod = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, Barcode, Weight, Standard_Cost, Currency, SKU_Status)
    VALUES (@prod, @pkg, N'SKU-001', N'شیر کم‌چرب ۱ لیتری', N'6260000000017', 1.030, 250000, 'IRR', N'Active');  SET @sku = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Price_Status)
    VALUES (@sku, N'List', 320000, 'IRR', '2026-10-01', N'Active');
    INSERT marketing.CampaignChannel (Channel_Name, Channel_Type, Channel_Status) VALUES (N'اینستاگرام', N'Social', N'Active');   SET @ch = SCOPE_IDENTITY();
    INSERT marketing.CampaignChannel (Channel_Name, Channel_Type, Channel_Status) VALUES (N'پیامک', N'SMS', N'Active');          SET @ch2 = SCOPE_IDENTITY();
    INSERT marketing.CampaignAudience (Audience_Name, Audience_Type, Audience_Status, Age_Range, Gender) VALUES (N'خانواده‌های تهران', N'Consumer', N'Active', N'25-45', N'All');  SET @aud = SCOPE_IDENTITY();
    INSERT marketing.MarketingCampaign (Brand_ID, Campaign_Name, Campaign_Type, Campaign_Purpose, Start_Date, End_Date, Campaign_Status)
    VALUES (@brand, N'کمپین پاییز', N'Awareness', N'Brand', '2026-10-01', '2026-11-30', N'Active');   SET @camp = SCOPE_IDENTITY();
    INSERT marketing.MarketingCampaignChannel (Marketing_Campaign_ID, Campaign_Channel_ID) VALUES (@camp, @ch);
    INSERT marketing.MarketingCampaignAudience (Marketing_Campaign_ID, Campaign_Audience_ID) VALUES (@camp, @aud);
    INSERT marketing.CampaignBudget (Marketing_Campaign_ID, Campaign_Channel_ID, Total_Allocated_Amount, Currency) VALUES (@camp, @ch, 5000000000, 'IRR');
    INSERT marketing.CampaignBudget (Marketing_Campaign_ID, Campaign_Channel_ID, Total_Allocated_Amount, Currency) VALUES (@camp, NULL, 1000000000, 'IRR');
    INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date) VALUES (@camp, @ch, 1200000000, 'IRR', '2026-10-15');
    INSERT marketing.CampaignResult (Marketing_Campaign_ID, Metric_Name, Metric_Value, Measurement_Date) VALUES (@camp, N'Conversion Rate', 0.0425, '2026-10-31');
    INSERT marketing.Promotion (Marketing_Campaign_ID, Promotion_Code, Promotion_Name, Promotion_Type, Discount_Type, Discount_Value, Start_Date, End_Date, Promotion_Status)
    VALUES (@camp, N'PRM-10', N'ده درصد تخفیف', N'Discount', N'Percentage', 10, '2026-10-01', '2026-10-31', N'Active');
    INSERT marketing.BrandActivity (Brand_ID, Activity_Type, Activity_Title, Activity_Start_Date, Activity_End_Date, Activity_Cost, Currency)
    VALUES (@brand, N'PR', N'رونمایی هویت بصری', '2026-09-01', '2026-09-30', 300000000, 'IRR');
    INSERT marketing.Market (Market_Code, Market_Name, Market_Status) VALUES (N'MKT-THR', N'بازار تهران', N'Active');   SET @mkt = SCOPE_IDENTITY();
    INSERT marketing.Market (Market_Code, Market_Name, Market_Status) VALUES (N'MKT-ISF', N'بازار اصفهان', N'Active');  SET @mkt2 = SCOPE_IDENTITY();
    INSERT marketing.MarketSegment (Market_ID, Segment_Code, Segment_Name, Segmentation_Basis, Segment_Status) VALUES (@mkt, N'RETAIL', N'خرده‌فروشی تهران', N'Behavioral', N'Active');  SET @seg = SCOPE_IDENTITY();
    INSERT marketing.MarketResearch (Market_ID, Research_Title, Research_Type, Start_Date, Research_Status, Responsible_Person, Research_Cost, Currency)
    VALUES (@mkt, N'سنجش سهم بازار لبنیات', N'Quantitative', '2026-09-01', N'In Progress', N'واحد تحقیقات بازار', 900000000, 'IRR');  SET @res = SCOPE_IDENTITY();
    INSERT marketing.MarketSurvey (Market_Research_ID, Market_Segment_ID, Survey_Title, Survey_Date, Survey_Method, Sample_Size, Survey_Status)
    VALUES (@res, @seg, N'پرسشنامه خانوار', '2026-09-10', N'Online', 400, N'Completed');
    INSERT marketing.ResearchResult (Market_Research_ID, Result_Title, Result_Summary, Result_Date) VALUES (@res, N'یافته ۱', N'تقاضای شیر کم‌چرب در حال رشد است.', '2026-09-25');
    INSERT marketing.Competitor (Competitor_Name, Competitor_Type, Market_ID, Competitor_Status) VALUES (N'رقیب نمونه', N'Direct', @mkt, N'Active');   SET @comp = SCOPE_IDENTITY();
    INSERT marketing.CompetitorProduct (Competitor_ID, Competitor_Product_Name, Category) VALUES (@comp, N'شیر کم‌چرب رقیب', N'لبنیات');  SET @cprod = SCOPE_IDENTITY();
    INSERT marketing.MarketPrice (Product_ID, Competitor_Product_ID, Market_ID, Price_Date, Price_Value, Currency, Price_Source)
    VALUES (@prod, NULL, @mkt, '2026-10-05 10:30:00', 330000, 'IRR', N'Field Visit');
    INSERT marketing.MarketPrice (Product_ID, Competitor_Product_ID, Market_ID, Price_Date, Price_Value, Currency, Price_Source)
    VALUES (NULL, @cprod, @mkt, '2026-10-05 10:45:00', 310000, 'IRR', N'Field Visit');
    INSERT @B (id, status, goal, input, expected, actual) VALUES ('B01', 'PASS', N'valid rows in all 24 tables are accepted', N'one valid row per table', N'accepted', N'accepted');
END TRY
BEGIN CATCH
    INSERT @B (id, status, goal, input, expected, actual) VALUES ('B01', 'FAIL', N'valid rows in all 24 tables are accepted', N'one valid row per table', N'accepted', CONCAT(N'Msg ', ERROR_NUMBER(), N': ', ERROR_MESSAGE()));
END CATCH;

-- B40 / B41: the DEFAULT writes the current time only when no value is given
SET @t0 = SYSDATETIME();
INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
VALUES (N'PRD-DF1', N'x', @cat2, @brand, N'Physical', N'LT', N'Active');
SET @p2 = SCOPE_IDENTITY(); SET @t1 = SYSDATETIME();
SELECT @v = Product_Created_Date FROM core.Product WHERE Product_ID = @p2;
INSERT @B (id, status, goal, input, expected, actual)
VALUES ('B40', IIF(@v >= DATEADD(SECOND, -1, @t0) AND @v <= DATEADD(SECOND, 1, @t1), 'PASS', 'FAIL'), N'DEFAULT fills Product_Created_Date with the insert time',
        N'Product without Product_Created_Date', CONCAT(N'between ', CONVERT(nvarchar(19), @t0, 120), N' and ', CONVERT(nvarchar(19), @t1, 120)), ISNULL(CONVERT(nvarchar(19), @v, 120), N'NULL'));
INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status, Product_Created_Date)
VALUES (N'PRD-DF2', N'x', @cat2, @brand, N'Physical', N'LT', N'Active', '2026-01-02 03:04:05');
SELECT @v = Product_Created_Date FROM core.Product WHERE Product_ID = SCOPE_IDENTITY();
INSERT @B (id, status, goal, input, expected, actual)
VALUES ('B41', IIF(@v = '2026-01-02 03:04:05', 'PASS', 'FAIL'), N'an explicit Product_Created_Date is kept', N'Product_Created_Date = 2026-01-02 03:04:05',
        N'2026-01-02 03:04:05', ISNULL(CONVERT(nvarchar(19), @v, 120), N'NULL'));

DECLARE @t TABLE (Id int IDENTITY, TestId varchar(10), Input nvarchar(1000), ExpNo int, ExpName nvarchar(200), Stmt nvarchar(max));
INSERT @t (TestId, Input, ExpNo, ExpName, Stmt) VALUES
 ('B02', N'Product_Code = ''PRD-001'' (تکراری)', 2627, N'UQ_Product_Product_Code', N'INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status) VALUES (N''PRD-001'', N''x'', @cat2, @brand, N''Physical'', N''LT'', N''Active'')'),
 ('B03', N'SKU_Code = ''SKU-001'' با بارکد و محصول دیگر', 2627, N'UQ_SKU_SKU_Code', N'INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@prod, @pkg, N''SKU-001'', N''x'', N''Active'')'),
 ('B04', N'Brand_ID = -1', 547, N'FK_Product_Brand_Brand_ID', N'INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status) VALUES (N''PRD-X'', N''x'', @cat2, -1, N''Physical'', N''LT'', N''Active'')'),
 ('B05', N'Product_Name = NULL', 515, N'Product_Name', N'INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status) VALUES (N''PRD-Y'', NULL, @cat2, @brand, N''Physical'', N''LT'', N''Active'')'),
 ('B06', N'Barcode = ''6260000000017'' (تکراری)', 2601, N'UQ_SKU_Barcode', N'INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, Barcode, SKU_Status) VALUES (@prod, @pkg, N''SKU-009'', N''x'', N''6260000000017'', N''Active'')'),
 ('B07', N'دو SKU جدید بدون بارکد', NULL, NULL, N'INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@prod, @pkg, N''SKU-N1'', N''x'', N''Active''), (@prod, @pkg, N''SKU-N2'', N''y'', N''Active'')'),
 ('B08', N'SKU.Weight = -2.500', 547, N'CK_SKU_Weight', N'INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, Weight, SKU_Status) VALUES (@prod, @pkg, N''SKU-W1'', N''x'', -2.500, N''Active'')'),
 ('B09', N'SKU.Weight = 0', 547, N'CK_SKU_Weight', N'INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, Weight, SKU_Status) VALUES (@prod, @pkg, N''SKU-W2'', N''x'', 0, N''Active'')'),
 ('B10', N'SKU.Weight = NULL', NULL, NULL, N'INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, Weight, SKU_Status) VALUES (@prod, @pkg, N''SKU-W3'', N''x'', NULL, N''Active'')'),
 ('B11', N'Tax_Rate = 101', 547, N'CK_Product_Tax_Rate', N'INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status, Tax_Rate) VALUES (N''PRD-T'', N''x'', @cat2, @brand, N''Physical'', N''LT'', N''Active'', 101)'),
 ('B12', N'Parent_Category_ID = Product_Category_ID', 547, N'CK_ProductCategory_Parent_Category_ID', N'UPDATE ref.ProductCategory SET Parent_Category_ID = Product_Category_ID WHERE Product_Category_ID = @cat1'),
 ('B13', N'هر دو پر', 547, N'CK_MarketPrice_Product_ID_Competitor_Product_ID', N'INSERT marketing.MarketPrice (Product_ID, Competitor_Product_ID, Market_ID, Price_Date, Price_Value, Currency, Price_Source) VALUES (@prod, @cprod, @mkt, SYSDATETIME(), 1, ''IRR'', N''x'')'),
 ('B14', N'هر دو خالی', 547, N'CK_MarketPrice_Product_ID_Competitor_Product_ID', N'INSERT marketing.MarketPrice (Product_ID, Competitor_Product_ID, Market_ID, Price_Date, Price_Value, Currency, Price_Source) VALUES (NULL, NULL, @mkt, SYSDATETIME(), 1, ''IRR'', N''x'')'),
 ('B15', N'Discount_Type = ''Percentage'', Discount_Value = 150', 547, N'CK_Promotion_Discount_Value', N'INSERT marketing.Promotion (Promotion_Code, Promotion_Name, Promotion_Type, Discount_Type, Discount_Value, Start_Date, End_Date, Promotion_Status) VALUES (N''PRM-X'', N''x'', N''Discount'', N''Percentage'', 150, ''2026-10-01'', ''2026-10-02'', N''Active'')'),
 ('B16', N'Discount_Value = 100', NULL, NULL, N'INSERT marketing.Promotion (Promotion_Code, Promotion_Name, Promotion_Type, Discount_Type, Discount_Value, Start_Date, End_Date, Promotion_Status) VALUES (N''PRM-100'', N''x'', N''Discount'', N''Percentage'', 100, ''2026-10-01'', ''2026-10-02'', N''Active'')'),
 ('B17', N'Discount_Type = ''Fixed Amount'', Currency = NULL', 547, N'CK_Promotion_Discount_Type_Currency', N'INSERT marketing.Promotion (Promotion_Code, Promotion_Name, Promotion_Type, Discount_Type, Discount_Value, Start_Date, End_Date, Promotion_Status) VALUES (N''PRM-Y'', N''x'', N''Discount'', N''Fixed Amount'', 50000, ''2026-10-01'', ''2026-10-02'', N''Active'')'),
 ('B18', N'Campaign_Purpose = ''Brand'', Brand_ID = NULL', 547, N'CK_MarketingCampaign_Brand_ID', N'INSERT marketing.MarketingCampaign (Brand_ID, Campaign_Name, Campaign_Type, Campaign_Purpose, Start_Date, Campaign_Status) VALUES (NULL, N''x'', N''Awareness'', N''Brand'', ''2026-10-01'', N''Active'')'),
 ('B19', N'End_Date < Start_Date', 547, N'CK_MarketingCampaign_End_Date', N'INSERT marketing.MarketingCampaign (Brand_ID, Campaign_Name, Campaign_Type, Campaign_Purpose, Start_Date, End_Date, Campaign_Status) VALUES (NULL, N''x'', N''Sales'', N''Marketing'', ''2026-10-10'', ''2026-10-01'', N''Active'')'),
 ('B20', N'کانال پیامک برای کمپینی که فقط اینستاگرام دارد', 547, N'FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'INSERT marketing.CampaignBudget (Marketing_Campaign_ID, Campaign_Channel_ID, Total_Allocated_Amount, Currency) VALUES (@camp, @ch2, 1, ''IRR'')'),
 ('B21', N'کانال پیامک برای همان کمپین', 547, N'FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date) VALUES (@camp, @ch2, 1, ''IRR'', ''2026-10-01'')'),
 ('B22', N'Actual_Spent = -5000', 547, N'CK_CampaignCost_Actual_Spent', N'INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date) VALUES (@camp, @ch, -5000, ''IRR'', ''2026-10-02'')'),
 ('B23', N'Actual_Spent = 0', NULL, NULL, N'INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date) VALUES (@camp, @ch, 0, ''IRR'', ''2026-10-03'')'),
 ('B24', N'همان (کمپین، کانال)', 2627, N'PK_MarketingCampaignChannel', N'INSERT marketing.MarketingCampaignChannel (Marketing_Campaign_ID, Campaign_Channel_ID) VALUES (@camp, @ch)'),
 ('B25', N'همان (کمپین، Metric_Name، Measurement_Date)', 2627, N'UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date', N'INSERT marketing.CampaignResult (Marketing_Campaign_ID, Metric_Name, Metric_Value, Measurement_Date) VALUES (@camp, N''Conversion Rate'', 1, ''2026-10-31'')'),
 ('B26', N'Currency = ''irr''', 547, N'CK_CampaignCost_Currency', N'INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date) VALUES (@camp, @ch, 1, ''irr'', ''2026-10-04'')'),
 ('B27', N'Currency = ''ABC''', NULL, NULL, N'INSERT marketing.CampaignCost (Marketing_Campaign_ID, Campaign_Channel_ID, Actual_Spent, Currency, Cost_Date) VALUES (@camp, @ch, 1, ''ABC'', ''2026-10-05'')'),
 ('B28', N'Unit_Price = -1', 547, N'CK_ProductPrice_Unit_Price', N'INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Price_Status) VALUES (@sku, N''Wholesale'', -1, ''IRR'', ''2026-11-01'', N''Draft'')'),
 ('B29', N'Sample_Size = 0', 547, N'CK_MarketSurvey_Sample_Size', N'INSERT marketing.MarketSurvey (Market_Research_ID, Survey_Title, Survey_Date, Survey_Method, Sample_Size, Survey_Status) VALUES (@res, N''x'', ''2026-09-01'', N''Online'', 0, N''Planned'')'),
 ('B30', N'Segmentation_Basis = ''Income''', 547, N'CK_MarketSegment_Segmentation_Basis', N'INSERT marketing.MarketSegment (Market_ID, Segment_Code, Segment_Name, Segmentation_Basis, Segment_Status) VALUES (@mkt, N''SEG-X'', N''x'', N''Income'', N''Active'')'),
 ('B31', N'Segment_Code = ''RETAIL'' در بازار اصفهان', 2627, N'UQ_MarketSegment_Segment_Code', N'INSERT marketing.MarketSegment (Market_ID, Segment_Code, Segment_Name, Segmentation_Basis, Segment_Status) VALUES (@mkt2, N''RETAIL'', N''x'', N''Behavioral'', N''Active'')'),
 ('B32', N'Activity_Cost = 1000، Currency = NULL', 547, N'CK_BrandActivity_Activity_Cost_Currency', N'INSERT marketing.BrandActivity (Brand_ID, Activity_Cost) VALUES (@brand, 1000)'),
 ('B33', N'Brand_Start_Date = NULL، Brand_End_Date = 2026-12-31', 547, N'CK_Brand_Brand_End_Date', N'INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status, Brand_Start_Date, Brand_End_Date) VALUES (N''x'', N''BR-X1'', N''Product'', N''Inactive'', NULL, ''2026-12-31'')'),
 ('B34', N'Start = 2026-06-01، End = 2026-01-01', 547, N'CK_Brand_Brand_End_Date', N'INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status, Brand_Start_Date, Brand_End_Date) VALUES (N''x'', N''BR-X2'', N''Product'', N''Inactive'', ''2026-06-01'', ''2026-01-01'')'),
 ('B35', N'دو برند: بدون تاریخ؛ فقط Start', NULL, NULL, N'INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status, Brand_Start_Date, Brand_End_Date) VALUES (N''x'', N''BR-X3'', N''Product'', N''Active'', NULL, NULL), (N''y'', N''BR-X4'', N''Product'', N''Active'', ''2024-01-01'', NULL)'),
 ('B36', N'Activity_Start_Date = NULL، Activity_End_Date = 2026-08-31', 547, N'CK_BrandActivity_Activity_End_Date', N'INSERT marketing.BrandActivity (Brand_ID, Activity_Start_Date, Activity_End_Date) VALUES (@brand, NULL, ''2026-08-31'')'),
 ('B37', N'DELETE Brand', 547, N'FK_Product_Brand_Brand_ID', N'DELETE core.Brand WHERE Brand_ID = @brand'),
 ('B38', N'DELETE CampaignChannel', 547, N'FK_%CampaignChannel%', N'DELETE marketing.CampaignChannel WHERE Campaign_Channel_ID = @ch');

DECLARE @i int = 1, @max int = (SELECT MAX(Id) FROM @t), @tid varchar(10), @inp nvarchar(1000), @eno int, @ename nvarchar(200), @stmt nvarchar(max),
        @err int, @msg nvarchar(2048), @ok bit;
DECLARE @params nvarchar(max) = N'@cat1 int, @cat2 int, @pkg int, @brand int, @prod int, @sku int, @ch int, @ch2 int, @camp int, @mkt int, @mkt2 int, @seg int, @res int, @cprod int';
WHILE @i <= @max
BEGIN
    SELECT @tid = TestId, @inp = Input, @eno = ExpNo, @ename = ExpName, @stmt = Stmt FROM @t WHERE Id = @i;
    SET @err = 0; SET @msg = NULL;
    BEGIN TRY
        EXEC sp_executesql @stmt, @params, @cat1, @cat2, @pkg, @brand, @prod, @sku, @ch, @ch2, @camp, @mkt, @mkt2, @seg, @res, @cprod;
    END TRY
    BEGIN CATCH
        SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
    END CATCH;
    SET @ok = CASE WHEN @eno IS NULL THEN IIF(@err = 0, 1, 0)
                   ELSE IIF(@err = @eno AND @msg LIKE N'%' + @ename + N'%', 1, 0) END;
    INSERT @B (id, status, goal, input, expected, actual)
    VALUES (@tid, IIF(@ok = 1, 'PASS', 'FAIL'), N'constraint behaviour', @inp,
            IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno, N' by ', REPLACE(@ename, N'%', N'*'))),
            IIF(@err = 0, N'accepted', CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300))));
    SET @i += 1;
END;
ROLLBACK TRANSACTION;
-- results are kept in a table variable (not affected by ROLLBACK) and copied after it
INSERT #R (id, status, goal, input, expected, actual) SELECT id, status, goal, input, expected, actual FROM @B ORDER BY seq;
GO

/* ========================================================================
   Part C - Rules that depend on several rows (integrity triggers). Each test runs in its own transaction,
            because an error raised in a trigger rolls back the whole transaction. Everything is rolled back.
   ======================================================================== */
SET XACT_ABORT OFF;
GO

-- C01
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51001;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', '2026-12-31', N'Active');
    SET @step = 'test';
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 120000, 'IRR', '2026-06-01', '2027-03-31', N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C01',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'SKU و List یکسان: 2026-01-01..2026-12-31، سپس 2026-06-01..2027-03-31',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C02
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = NULL;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', '2026-05-31', N'Active');
    SET @step = 'test';
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-06-01', NULL, N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C02',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'2026-01-01..2026-05-31، سپس 2026-06-01..باز',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C03
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51001;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', NULL, N'Active');
    SET @step = 'test';
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-09-01', '2026-12-31', N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C03',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'2026-01-01..باز، سپس 2026-09-01..2026-12-31',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C04
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51001;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', '2026-06-01', N'Active');
    SET @step = 'test';
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-06-01', '2026-12-31', N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C04',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'2026-01-01..2026-06-01، سپس 2026-06-01..2026-12-31',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C05
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = NULL;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', '2026-12-31', N'Active');
    SET @step = 'test';
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'Wholesale', 100000, 'IRR', '2026-01-01', '2026-12-31', N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C05',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'List و Wholesale با تاریخ‌های یکسان',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C06
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = NULL;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', '2026-12-31', N'Active');
    SET @step = 'test';
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s2, N'List', 100000, 'IRR', '2026-01-01', '2026-12-31', N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C06',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'دو SKU با بازه‌ی یکسان',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C07
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51001;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    SET @step = 'test';
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', '2026-12-31', N'Active'), (@s1, N'List', 100000, 'IRR', '2026-03-01', '2026-04-30', N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C07',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'یک INSERT با دو ردیف متداخل',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C08
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51001;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-01-01', '2026-05-31', N'Active');
    INSERT marketing.ProductPrice (SKU_ID, Price_Type, Unit_Price, Currency, Effective_From, Effective_To, Price_Status) VALUES (@s1, N'List', 100000, 'IRR', '2026-06-01', NULL, N'Active');
    SET @step = 'test';
    UPDATE marketing.ProductPrice SET Effective_To = '2026-07-31' WHERE SKU_ID = @s1 AND Effective_From = '2026-01-01';
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C08',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'دو بازه‌ی جدا؛ سپس تمدید Effective_To اولی',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C09
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51002;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    SET @step = 'test';
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-L5', N'T-L5', 5, N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C09',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'والد سطح ۱، فرزند سطح ۵',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C10
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51002;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    SET @step = 'test';
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-R2', N'T-R2', 2, N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C10',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'Parent = NULL، Category_Level = 2',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C11
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = NULL;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    SET @step = 'test';
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c2, N'T-L3', N'T-L3', 3, N'Active');
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C11',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'ریشه ۱، فرزند ۲، نوه ۳',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C12
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51003;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c2, N'T-C', N'T-C', 3, N'Active'); SET @c3 = SCOPE_IDENTITY();
    SET @step = 'test';
    UPDATE ref.ProductCategory SET Parent_Category_ID = @c3, Category_Level = 4 WHERE Product_Category_ID = @c1;
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C12',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'A والد B، B والد C؛ سپس C والد A',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C13
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51003;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    SET @step = 'test';
    UPDATE ref.ProductCategory SET Parent_Category_ID = @c2, Category_Level = 3 WHERE Product_Category_ID = @c1;
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C13',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'A والد B؛ سپس B والد A',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C14
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = 51002;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c2, N'T-C', N'T-C', 3, N'Active'); SET @c3 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT2', N'T-ROOT2', 1, N'Active'); SET @r2 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@r2, N'T-MID', N'T-MID', 2, N'Active'); SET @m2 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@m2, N'T-MID2', N'T-MID2', 3, N'Active'); SET @m3 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@m3, N'T-MID3', N'T-MID3', 4, N'Active'); SET @m4 = SCOPE_IDENTITY();
    SET @step = 'test';
    UPDATE ref.ProductCategory SET Parent_Category_ID = @m4, Category_Level = 5 WHERE Product_Category_ID = @c2;
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C14',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'سطح دسته‌ی ۲ به ۵ تغییر کند در حالی که فرزندش سطح ۳ است',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

-- C15
DECLARE @c1 int, @c2 int, @c3 int, @r2 int, @m2 int, @m3 int, @m4 int, @pk int, @b int, @p int, @s1 int, @s2 int,
        @step varchar(10) = 'setup', @err int = 0, @msg nvarchar(2048) = NULL, @eno int = NULL;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT', N'root', 1, N'Active');
    SET @c1 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c1, N'T-SUB', N'sub', 2, N'Active');
    SET @c2 = SCOPE_IDENTITY();
    INSERT ref.Package (Package_Code, Package_Name) VALUES (N'T-PKG', N'pkg');  SET @pk = SCOPE_IDENTITY();
    INSERT core.Brand (Brand_Name, Brand_Code, Brand_Type, Brand_Status) VALUES (N'b', N'T-BR', N'Product', N'Active');  SET @b = SCOPE_IDENTITY();
    INSERT core.Product (Product_Code, Product_Name, Product_Category_ID, Brand_ID, Product_Type, Unit_Of_Measure, Product_Status)
    VALUES (N'T-PRD', N'p', @c2, @b, N'Physical', N'PCS', N'Active');  SET @p = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU1', N's1', N'Active');  SET @s1 = SCOPE_IDENTITY();
    INSERT core.SKU (Product_ID, Package_ID, SKU_Code, SKU_Name, SKU_Status) VALUES (@p, @pk, N'T-SKU2', N's2', N'Active');  SET @s2 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@c2, N'T-C', N'T-C', 3, N'Active'); SET @c3 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (NULL, N'T-ROOT2', N'T-ROOT2', 1, N'Active'); SET @r2 = SCOPE_IDENTITY();
    INSERT ref.ProductCategory (Parent_Category_ID, Category_Code, Category_Name, Category_Level, Category_Status) VALUES (@r2, N'T-MID', N'T-MID', 2, N'Active'); SET @m2 = SCOPE_IDENTITY();
    SET @step = 'test';
    UPDATE ref.ProductCategory SET Parent_Category_ID = CASE WHEN Product_Category_ID = @c2 THEN @m2 ELSE Parent_Category_ID END, Category_Level = Category_Level + 1 WHERE Product_Category_ID IN (@c2, @c3);
    SET @step = 'done';
END TRY
BEGIN CATCH
    SET @err = ERROR_NUMBER(); SET @msg = ERROR_MESSAGE();
END CATCH;
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('C15',
        CASE WHEN @step = 'setup' THEN 'FAIL' WHEN @eno IS NULL THEN IIF(@err = 0, 'PASS', 'FAIL') ELSE IIF(@err = @eno, 'PASS', 'FAIL') END,
        N'trigger rule', N'دسته‌ی ۲ و فرزندش با هم زیر ریشه‌ی دیگر می‌روند',
        IIF(@eno IS NULL, N'accepted', CONCAT(N'rejected: Msg ', @eno)),
        CASE WHEN @step = 'setup' THEN CONCAT(N'setup failed: Msg ', @err, N' ', @msg)
             WHEN @err = 0 THEN N'accepted' ELSE CONCAT(N'rejected: Msg ', @err, N' - ', LEFT(@msg, 300)) END);
GO

/* ========================================================================
   Part D - Clean-up: restore IDENTITY seeds consumed by the rolled-back rows and prove nothing is left
   ======================================================================== */
DECLARE @tbl nvarchar(300), @sql nvarchar(400);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT QUOTENAME(OBJECT_SCHEMA_NAME(ic.object_id)) + N'.' + QUOTENAME(OBJECT_NAME(ic.object_id))
    FROM sys.identity_columns ic
    WHERE ic.last_value IS NOT NULL AND ic.object_id IN (SELECT OBJECT_ID(n) FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n));
OPEN c; FETCH NEXT FROM c INTO @tbl;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF NOT EXISTS (SELECT 1 FROM sys.partitions WHERE object_id = OBJECT_ID(@tbl) AND index_id IN (0, 1) AND rows > 0)
    BEGIN
        SET @sql = N'DBCC CHECKIDENT (''' + @tbl + N''', RESEED, 0) WITH NO_INFOMSGS;';
        EXEC (@sql);
    END;
    FETCH NEXT FROM c INTO @tbl;
END;
CLOSE c; DEALLOCATE c;
GO

DECLARE @rows bigint = 0, @idn int;
SELECT @rows += ISNULL((SELECT SUM(p.rows) FROM sys.partitions p WHERE p.object_id = OBJECT_ID(t.n) AND p.index_id IN (0, 1)), 0)
FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) t(n);
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('D01', IIF(@rows = 0, 'PASS', 'FAIL'), N'no test row is left in the Team 2 tables', N'row count of the 24 tables', N'0 rows', CONCAT(@rows, N' rows'));
SELECT @idn = COUNT(*) FROM sys.identity_columns ic
WHERE ic.object_id IN (SELECT OBJECT_ID(n) FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n)) AND ISNULL(CAST(ic.last_value AS bigint), 0) <> 0;
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('D02', IIF(@idn = 0, 'PASS', 'FAIL'), N'IDENTITY seeds restored', N'sys.identity_columns', N'0 tables with a used seed', CONCAT(@idn, N' tables with a used seed'));
GO
IF OBJECT_ID(N'tempdb..#Diff2') IS NOT NULL DROP TABLE #Diff2;
CREATE TABLE #Diff2 (kind nvarchar(10), obj sysname, problem nvarchar(max));
DECLARE @E TABLE (kind nvarchar(10), obj sysname, parent nvarchar(300), sig nvarchar(max));
INSERT @E VALUES
    (N'TABLE', N'ref.ProductCategory', N'ref.ProductCategory', N'Product_Category_ID int NOT NULL IDENTITY; Parent_Category_ID int NULL; Category_Code nvarchar(30) NOT NULL; Category_Name nvarchar(150) NOT NULL; Category_Level int NOT NULL; Category_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_ProductCategory', N'ref.ProductCategory', N'CLUSTERED:Product_Category_ID'),
    (N'TABLE', N'ref.Package', N'ref.Package', N'Package_ID int NOT NULL IDENTITY; Package_Code nvarchar(30) NOT NULL; Package_Name nvarchar(150) NOT NULL; Package_Description nvarchar(1000) NULL'),
    (N'PK', N'PK_Package', N'ref.Package', N'CLUSTERED:Package_ID'),
    (N'TABLE', N'core.Brand', N'core.Brand', N'Brand_ID int NOT NULL IDENTITY; Brand_Name nvarchar(150) NOT NULL; Brand_Code nvarchar(30) NOT NULL; Brand_Type nvarchar(30) NOT NULL; Brand_Status nvarchar(30) NOT NULL; Brand_Start_Date date NULL; Brand_End_Date date NULL; Brand_Owner nvarchar(150) NULL; Brand_Positioning nvarchar(500) NULL; Target_Market nvarchar(100) NULL; Target_Segment nvarchar(100) NULL; Brand_Tagline nvarchar(250) NULL; Brand_Logo_URL nvarchar(500) NULL; Brand_Website nvarchar(500) NULL; Brand_Country char(2) NULL'),
    (N'PK', N'PK_Brand', N'core.Brand', N'CLUSTERED:Brand_ID'),
    (N'TABLE', N'core.Product', N'core.Product', N'Product_ID int NOT NULL IDENTITY; Product_Code nvarchar(30) NOT NULL; Product_Name nvarchar(150) NOT NULL; Product_Description nvarchar(1000) NULL; Product_Category_ID int NOT NULL; Brand_ID int NOT NULL; Product_Type nvarchar(30) NOT NULL; Unit_Of_Measure nvarchar(20) NOT NULL; Product_Status nvarchar(30) NOT NULL; Launch_Date date NULL; Weight decimal(10,3) NULL; Tax_Rate decimal(5,2) NULL; Product_Created_Date datetime2(0) NOT NULL; Product_Updated_Date datetime2(0) NULL'),
    (N'PK', N'PK_Product', N'core.Product', N'CLUSTERED:Product_ID'),
    (N'TABLE', N'core.SKU', N'core.SKU', N'SKU_ID int NOT NULL IDENTITY; Product_ID int NOT NULL; Package_ID int NOT NULL; SKU_Code nvarchar(30) NOT NULL; SKU_Name nvarchar(150) NOT NULL; Barcode nvarchar(20) NULL; Weight decimal(10,3) NULL; Standard_Cost decimal(18,2) NULL; Currency char(3) NULL; SKU_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_SKU', N'core.SKU', N'CLUSTERED:SKU_ID'),
    (N'TABLE', N'marketing.ProductPrice', N'marketing.ProductPrice', N'Product_Price_ID int NOT NULL IDENTITY; SKU_ID int NOT NULL; Price_Type nvarchar(30) NOT NULL; Unit_Price decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Effective_From date NOT NULL; Effective_To date NULL; Price_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_ProductPrice', N'marketing.ProductPrice', N'CLUSTERED:Product_Price_ID'),
    (N'TABLE', N'marketing.CampaignChannel', N'marketing.CampaignChannel', N'Campaign_Channel_ID int NOT NULL IDENTITY; Channel_Name nvarchar(150) NOT NULL; Channel_Type nvarchar(30) NOT NULL; Channel_Description nvarchar(1000) NULL; Channel_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_CampaignChannel', N'marketing.CampaignChannel', N'CLUSTERED:Campaign_Channel_ID'),
    (N'TABLE', N'marketing.CampaignAudience', N'marketing.CampaignAudience', N'Campaign_Audience_ID int NOT NULL IDENTITY; Audience_Name nvarchar(150) NOT NULL; Audience_Type nvarchar(30) NOT NULL; Audience_Description nvarchar(1000) NULL; Audience_Status nvarchar(30) NOT NULL; Age_Range nvarchar(20) NULL; Gender nvarchar(20) NULL; Geographic_Location nvarchar(150) NULL'),
    (N'PK', N'PK_CampaignAudience', N'marketing.CampaignAudience', N'CLUSTERED:Campaign_Audience_ID'),
    (N'TABLE', N'marketing.MarketingCampaign', N'marketing.MarketingCampaign', N'Marketing_Campaign_ID int NOT NULL IDENTITY; Brand_ID int NULL; Campaign_Name nvarchar(150) NOT NULL; Campaign_Type nvarchar(30) NOT NULL; Campaign_Purpose nvarchar(30) NOT NULL; Campaign_Objective nvarchar(500) NULL; Start_Date date NOT NULL; End_Date date NULL; Campaign_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketingCampaign', N'marketing.MarketingCampaign', N'CLUSTERED:Marketing_Campaign_ID'),
    (N'TABLE', N'marketing.MarketingCampaignChannel', N'marketing.MarketingCampaignChannel', N'Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NOT NULL'),
    (N'PK', N'PK_MarketingCampaignChannel', N'marketing.MarketingCampaignChannel', N'CLUSTERED:Marketing_Campaign_ID,Campaign_Channel_ID'),
    (N'TABLE', N'marketing.MarketingCampaignAudience', N'marketing.MarketingCampaignAudience', N'Marketing_Campaign_ID int NOT NULL; Campaign_Audience_ID int NOT NULL'),
    (N'PK', N'PK_MarketingCampaignAudience', N'marketing.MarketingCampaignAudience', N'CLUSTERED:Marketing_Campaign_ID,Campaign_Audience_ID'),
    (N'TABLE', N'marketing.CampaignBudget', N'marketing.CampaignBudget', N'Campaign_Budget_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NULL; Total_Allocated_Amount decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Approval_Date date NULL'),
    (N'PK', N'PK_CampaignBudget', N'marketing.CampaignBudget', N'CLUSTERED:Campaign_Budget_ID'),
    (N'TABLE', N'marketing.CampaignCost', N'marketing.CampaignCost', N'Campaign_Cost_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Campaign_Channel_ID int NULL; Actual_Spent decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Cost_Date date NOT NULL'),
    (N'PK', N'PK_CampaignCost', N'marketing.CampaignCost', N'CLUSTERED:Campaign_Cost_ID'),
    (N'TABLE', N'marketing.CampaignResult', N'marketing.CampaignResult', N'Campaign_Result_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NOT NULL; Metric_Name nvarchar(100) NOT NULL; Metric_Value decimal(18,4) NOT NULL; Measurement_Date date NOT NULL'),
    (N'PK', N'PK_CampaignResult', N'marketing.CampaignResult', N'CLUSTERED:Campaign_Result_ID'),
    (N'TABLE', N'marketing.Promotion', N'marketing.Promotion', N'Promotion_ID int NOT NULL IDENTITY; Marketing_Campaign_ID int NULL; Promotion_Code nvarchar(30) NOT NULL; Promotion_Name nvarchar(150) NOT NULL; Promotion_Type nvarchar(30) NOT NULL; Discount_Type nvarchar(30) NOT NULL; Discount_Value decimal(18,2) NOT NULL; Currency char(3) NULL; Start_Date date NOT NULL; End_Date date NOT NULL; Promotion_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Promotion', N'marketing.Promotion', N'CLUSTERED:Promotion_ID'),
    (N'TABLE', N'marketing.BrandActivity', N'marketing.BrandActivity', N'Brand_Activity_ID int NOT NULL IDENTITY; Brand_ID int NOT NULL; Activity_Type nvarchar(30) NULL; Activity_Title nvarchar(200) NULL; Activity_Description nvarchar(1000) NULL; Activity_Start_Date date NULL; Activity_End_Date date NULL; Activity_Channel nvarchar(100) NULL; Activity_Status nvarchar(30) NULL; Activity_Owner nvarchar(150) NULL; Activity_Cost decimal(18,2) NULL; Currency char(3) NULL; Activity_Result nvarchar(1000) NULL'),
    (N'PK', N'PK_BrandActivity', N'marketing.BrandActivity', N'CLUSTERED:Brand_Activity_ID'),
    (N'TABLE', N'marketing.Market', N'marketing.Market', N'Market_ID int NOT NULL IDENTITY; Market_Code nvarchar(30) NOT NULL; Market_Name nvarchar(150) NOT NULL; Market_Type nvarchar(30) NULL; Market_Description nvarchar(1000) NULL; Market_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Market', N'marketing.Market', N'CLUSTERED:Market_ID'),
    (N'TABLE', N'marketing.MarketSegment', N'marketing.MarketSegment', N'Market_Segment_ID int NOT NULL IDENTITY; Market_ID int NOT NULL; Segment_Code nvarchar(30) NOT NULL; Segment_Name nvarchar(150) NOT NULL; Segmentation_Basis nvarchar(30) NOT NULL; Segment_Description nvarchar(1000) NULL; Segment_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketSegment', N'marketing.MarketSegment', N'CLUSTERED:Market_Segment_ID'),
    (N'TABLE', N'marketing.MarketResearch', N'marketing.MarketResearch', N'Market_Research_ID int NOT NULL IDENTITY; Market_ID int NOT NULL; Research_Title nvarchar(200) NOT NULL; Research_Type nvarchar(30) NOT NULL; Start_Date date NOT NULL; End_Date date NULL; Research_Status nvarchar(30) NOT NULL; Responsible_Person nvarchar(150) NOT NULL; Research_Cost decimal(18,2) NULL; Currency char(3) NULL'),
    (N'PK', N'PK_MarketResearch', N'marketing.MarketResearch', N'CLUSTERED:Market_Research_ID'),
    (N'TABLE', N'marketing.MarketSurvey', N'marketing.MarketSurvey', N'Market_Survey_ID int NOT NULL IDENTITY; Market_Research_ID int NOT NULL; Market_Segment_ID int NULL; Survey_Title nvarchar(200) NOT NULL; Survey_Date date NOT NULL; Survey_Method nvarchar(30) NOT NULL; Sample_Size int NOT NULL; Survey_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_MarketSurvey', N'marketing.MarketSurvey', N'CLUSTERED:Market_Survey_ID'),
    (N'TABLE', N'marketing.ResearchResult', N'marketing.ResearchResult', N'Research_Result_ID int NOT NULL IDENTITY; Market_Research_ID int NOT NULL; Result_Title nvarchar(200) NOT NULL; Result_Summary nvarchar(2000) NOT NULL; Result_Date date NOT NULL; Recommendation nvarchar(2000) NULL; Opportunity_Identified nvarchar(500) NULL'),
    (N'PK', N'PK_ResearchResult', N'marketing.ResearchResult', N'CLUSTERED:Research_Result_ID'),
    (N'TABLE', N'marketing.Competitor', N'marketing.Competitor', N'Competitor_ID int NOT NULL IDENTITY; Competitor_Name nvarchar(150) NOT NULL; Competitor_Type nvarchar(30) NOT NULL; Market_ID int NULL; Competitor_Status nvarchar(30) NOT NULL'),
    (N'PK', N'PK_Competitor', N'marketing.Competitor', N'CLUSTERED:Competitor_ID'),
    (N'TABLE', N'marketing.CompetitorProduct', N'marketing.CompetitorProduct', N'Competitor_Product_ID int NOT NULL IDENTITY; Competitor_ID int NOT NULL; Competitor_Product_Name nvarchar(150) NOT NULL; Category nvarchar(100) NULL'),
    (N'PK', N'PK_CompetitorProduct', N'marketing.CompetitorProduct', N'CLUSTERED:Competitor_Product_ID'),
    (N'TABLE', N'marketing.MarketPrice', N'marketing.MarketPrice', N'Market_Price_ID int NOT NULL IDENTITY; Product_ID int NULL; Competitor_Product_ID int NULL; Market_ID int NOT NULL; Price_Date datetime2(0) NOT NULL; Price_Value decimal(18,2) NOT NULL; Currency char(3) NOT NULL; Price_Source nvarchar(100) NOT NULL'),
    (N'PK', N'PK_MarketPrice', N'marketing.MarketPrice', N'CLUSTERED:Market_Price_ID'),
    (N'UQ', N'UQ_ProductCategory_Category_Code', N'ref.ProductCategory', N'NONCLUSTERED|UNIQUE|Category_Code||'),
    (N'UQ', N'UQ_Package_Package_Code', N'ref.Package', N'NONCLUSTERED|UNIQUE|Package_Code||'),
    (N'UQ', N'UQ_Brand_Brand_Code', N'core.Brand', N'NONCLUSTERED|UNIQUE|Brand_Code||'),
    (N'UQ', N'UQ_Product_Product_Code', N'core.Product', N'NONCLUSTERED|UNIQUE|Product_Code||'),
    (N'UQ', N'UQ_SKU_SKU_Code', N'core.SKU', N'NONCLUSTERED|UNIQUE|SKU_Code||'),
    (N'UX', N'UQ_SKU_Barcode', N'core.SKU', N'NONCLUSTERED|UNIQUE|Barcode||([Barcode] IS NOT NULL)'),
    (N'UQ', N'UQ_Promotion_Promotion_Code', N'marketing.Promotion', N'NONCLUSTERED|UNIQUE|Promotion_Code||'),
    (N'UQ', N'UQ_Market_Market_Code', N'marketing.Market', N'NONCLUSTERED|UNIQUE|Market_Code||'),
    (N'UQ', N'UQ_MarketSegment_Segment_Code', N'marketing.MarketSegment', N'NONCLUSTERED|UNIQUE|Segment_Code||'),
    (N'UQ', N'UQ_CampaignResult_Marketing_Campaign_ID_Metric_Name_Measurement_Date', N'marketing.CampaignResult', N'NONCLUSTERED|UNIQUE|Marketing_Campaign_ID,Metric_Name,Measurement_Date||'),
    (N'CK', N'CK_Brand_Brand_End_Date', N'core.Brand', N'([Brand_End_Date] IS NULL OR [Brand_Start_Date] IS NOT NULL AND [Brand_End_Date]>=[Brand_Start_Date])'),
    (N'CK', N'CK_Brand_Brand_Country', N'core.Brand', N'(([Brand_Country]) collate Latin1_General_BIN like ''[A-Z][A-Z]'')'),
    (N'CK', N'CK_Product_Weight', N'core.Product', N'([Weight]>(0))'),
    (N'CK', N'CK_Product_Tax_Rate', N'core.Product', N'([Tax_Rate]>=(0) AND [Tax_Rate]<=(100))'),
    (N'CK', N'CK_Product_Product_Updated_Date', N'core.Product', N'([Product_Updated_Date]>=[Product_Created_Date])'),
    (N'CK', N'CK_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'([Parent_Category_ID]<>[Product_Category_ID])'),
    (N'CK', N'CK_ProductCategory_Category_Level', N'ref.ProductCategory', N'([Category_Level]>=(1))'),
    (N'CK', N'CK_SKU_Weight', N'core.SKU', N'([Weight]>(0))'),
    (N'CK', N'CK_SKU_Standard_Cost', N'core.SKU', N'([Standard_Cost]>=(0))'),
    (N'CK', N'CK_SKU_Currency', N'core.SKU', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_SKU_Standard_Cost_Currency', N'core.SKU', N'([Standard_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_ProductPrice_Unit_Price', N'marketing.ProductPrice', N'([Unit_Price]>=(0))'),
    (N'CK', N'CK_ProductPrice_Effective_To', N'marketing.ProductPrice', N'([Effective_To]>=[Effective_From])'),
    (N'CK', N'CK_ProductPrice_Currency', N'marketing.ProductPrice', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_CampaignChannel_Channel_Status', N'marketing.CampaignChannel', N'([Channel_Status]=N''Inactive'' OR [Channel_Status]=N''Active'')'),
    (N'CK', N'CK_CampaignAudience_Audience_Status', N'marketing.CampaignAudience', N'([Audience_Status]=N''Inactive'' OR [Audience_Status]=N''Active'')'),
    (N'CK', N'CK_MarketingCampaign_End_Date', N'marketing.MarketingCampaign', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_MarketingCampaign_Campaign_Purpose', N'marketing.MarketingCampaign', N'([Campaign_Purpose]=N''Marketing'' OR [Campaign_Purpose]=N''Brand'')'),
    (N'CK', N'CK_MarketingCampaign_Brand_ID', N'marketing.MarketingCampaign', N'([Campaign_Purpose]<>N''Brand'' OR [Brand_ID] IS NOT NULL)'),
    (N'CK', N'CK_CampaignBudget_Total_Allocated_Amount', N'marketing.CampaignBudget', N'([Total_Allocated_Amount]>=(0))'),
    (N'CK', N'CK_CampaignBudget_Currency', N'marketing.CampaignBudget', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_CampaignCost_Actual_Spent', N'marketing.CampaignCost', N'([Actual_Spent]>=(0))'),
    (N'CK', N'CK_CampaignCost_Currency', N'marketing.CampaignCost', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_Promotion_End_Date', N'marketing.Promotion', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_Promotion_Discount_Type', N'marketing.Promotion', N'([Discount_Type]=N''Fixed Amount'' OR [Discount_Type]=N''Percentage'')'),
    (N'CK', N'CK_Promotion_Discount_Value', N'marketing.Promotion', N'([Discount_Value]>=(0) AND ([Discount_Type]<>N''Percentage'' OR [Discount_Value]<=(100)))'),
    (N'CK', N'CK_Promotion_Discount_Type_Currency', N'marketing.Promotion', N'([Discount_Type]<>N''Fixed Amount'' OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_Promotion_Currency', N'marketing.Promotion', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_BrandActivity_Activity_End_Date', N'marketing.BrandActivity', N'([Activity_End_Date] IS NULL OR [Activity_Start_Date] IS NOT NULL AND [Activity_End_Date]>=[Activity_Start_Date])'),
    (N'CK', N'CK_BrandActivity_Activity_Cost', N'marketing.BrandActivity', N'([Activity_Cost]>=(0))'),
    (N'CK', N'CK_BrandActivity_Currency', N'marketing.BrandActivity', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_BrandActivity_Activity_Cost_Currency', N'marketing.BrandActivity', N'([Activity_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_MarketSegment_Segmentation_Basis', N'marketing.MarketSegment', N'([Segmentation_Basis]=N''Behavioral'' OR [Segmentation_Basis]=N''Demographic'' OR [Segmentation_Basis]=N''Geographic'')'),
    (N'CK', N'CK_MarketResearch_End_Date', N'marketing.MarketResearch', N'([End_Date]>=[Start_Date])'),
    (N'CK', N'CK_MarketResearch_Research_Cost', N'marketing.MarketResearch', N'([Research_Cost]>=(0))'),
    (N'CK', N'CK_MarketResearch_Currency', N'marketing.MarketResearch', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'CK', N'CK_MarketResearch_Research_Cost_Currency', N'marketing.MarketResearch', N'([Research_Cost] IS NULL OR [Currency] IS NOT NULL)'),
    (N'CK', N'CK_MarketSurvey_Sample_Size', N'marketing.MarketSurvey', N'([Sample_Size]>(0))'),
    (N'CK', N'CK_MarketPrice_Product_ID_Competitor_Product_ID', N'marketing.MarketPrice', N'([Product_ID] IS NOT NULL AND [Competitor_Product_ID] IS NULL OR [Product_ID] IS NULL AND [Competitor_Product_ID] IS NOT NULL)'),
    (N'CK', N'CK_MarketPrice_Price_Value', N'marketing.MarketPrice', N'([Price_Value]>=(0))'),
    (N'CK', N'CK_MarketPrice_Currency', N'marketing.MarketPrice', N'(([Currency]) collate Latin1_General_BIN like ''[A-Z][A-Z][A-Z]'')'),
    (N'DF', N'DF_Product_Product_Created_Date', N'core.Product', N'Product_Created_Date=(sysdatetime())'),
    (N'FK', N'FK_Product_ProductCategory_Product_Category_ID', N'core.Product', N'Product_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Product_Brand_Brand_ID', N'core.Product', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_SKU_Product_Product_ID', N'core.SKU', N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_Product_Product_ID', N'marketing.MarketPrice', N'Product_ID -> core.Product(Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_SKU_Package_Package_ID', N'core.SKU', N'Package_ID -> ref.Package(Package_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ProductPrice_SKU_SKU_ID', N'marketing.ProductPrice', N'SKU_ID -> core.SKU(SKU_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_BrandActivity_Brand_Brand_ID', N'marketing.BrandActivity', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaign_Brand_Brand_ID', N'marketing.MarketingCampaign', N'Brand_ID -> core.Brand(Brand_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignChannel_MarketingCampaign_Marketing_Campaign_ID', N'marketing.MarketingCampaignChannel', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignChannel_CampaignChannel_Campaign_Channel_ID', N'marketing.MarketingCampaignChannel', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignAudience_MarketingCampaign_Marketing_Campaign_ID', N'marketing.MarketingCampaignAudience', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketingCampaignAudience_CampaignAudience_Campaign_Audience_ID', N'marketing.MarketingCampaignAudience', N'Campaign_Audience_ID -> marketing.CampaignAudience(Campaign_Audience_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignBudget', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignCost', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignResult_MarketingCampaign_Marketing_Campaign_ID', N'marketing.CampaignResult', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Promotion_MarketingCampaign_Marketing_Campaign_ID', N'marketing.Promotion', N'Marketing_Campaign_ID -> marketing.MarketingCampaign(Marketing_Campaign_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSegment_Market_Market_ID', N'marketing.MarketSegment', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketResearch_Market_Market_ID', N'marketing.MarketResearch', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_Market_Market_ID', N'marketing.MarketPrice', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_Competitor_Market_Market_ID', N'marketing.Competitor', N'Market_ID -> marketing.Market(Market_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSurvey_MarketSegment_Market_Segment_ID', N'marketing.MarketSurvey', N'Market_Segment_ID -> marketing.MarketSegment(Market_Segment_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketSurvey_MarketResearch_Market_Research_ID', N'marketing.MarketSurvey', N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ResearchResult_MarketResearch_Market_Research_ID', N'marketing.ResearchResult', N'Market_Research_ID -> marketing.MarketResearch(Market_Research_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CompetitorProduct_Competitor_Competitor_ID', N'marketing.CompetitorProduct', N'Competitor_ID -> marketing.Competitor(Competitor_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_MarketPrice_CompetitorProduct_Competitor_Product_ID', N'marketing.MarketPrice', N'Competitor_Product_ID -> marketing.CompetitorProduct(Competitor_Product_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_CampaignChannel_Campaign_Channel_ID', N'marketing.CampaignBudget', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_CampaignChannel_Campaign_Channel_ID', N'marketing.CampaignCost', N'Campaign_Channel_ID -> marketing.CampaignChannel(Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_ProductCategory_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'Parent_Category_ID -> ref.ProductCategory(Product_Category_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignBudget_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignBudget', N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'FK', N'FK_CampaignCost_MarketingCampaignChannel_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignCost', N'Marketing_Campaign_ID,Campaign_Channel_ID -> marketing.MarketingCampaignChannel(Marketing_Campaign_ID,Campaign_Channel_ID)|NO_ACTION|NO_ACTION'),
    (N'IX', N'IX_ProductCategory_Parent_Category_ID', N'ref.ProductCategory', N'NONCLUSTERED|NONUNIQUE|Parent_Category_ID||'),
    (N'IX', N'IX_Product_Product_Category_ID', N'core.Product', N'NONCLUSTERED|NONUNIQUE|Product_Category_ID||'),
    (N'IX', N'IX_Product_Brand_ID', N'core.Product', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_SKU_Product_ID', N'core.SKU', N'NONCLUSTERED|NONUNIQUE|Product_ID||'),
    (N'IX', N'IX_SKU_Package_ID', N'core.SKU', N'NONCLUSTERED|NONUNIQUE|Package_ID||'),
    (N'IX', N'IX_ProductPrice_SKU_ID_Price_Type_Effective_From', N'marketing.ProductPrice', N'NONCLUSTERED|NONUNIQUE|SKU_ID,Price_Type,Effective_From||'),
    (N'IX', N'IX_MarketingCampaign_Brand_ID', N'marketing.MarketingCampaign', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_MarketingCampaignChannel_Campaign_Channel_ID', N'marketing.MarketingCampaignChannel', N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID||'),
    (N'IX', N'IX_MarketingCampaignAudience_Campaign_Audience_ID', N'marketing.MarketingCampaignAudience', N'NONCLUSTERED|NONUNIQUE|Campaign_Audience_ID||'),
    (N'IX', N'IX_CampaignBudget_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignBudget', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||'),
    (N'IX', N'IX_CampaignCost_Marketing_Campaign_ID_Campaign_Channel_ID', N'marketing.CampaignCost', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID,Campaign_Channel_ID||'),
    (N'IX', N'IX_CampaignCost_Campaign_Channel_ID_Cost_Date', N'marketing.CampaignCost', N'NONCLUSTERED|NONUNIQUE|Campaign_Channel_ID,Cost_Date|Actual_Spent,Currency|([Campaign_Channel_ID] IS NOT NULL)'),
    (N'IX', N'IX_Promotion_Marketing_Campaign_ID', N'marketing.Promotion', N'NONCLUSTERED|NONUNIQUE|Marketing_Campaign_ID||'),
    (N'IX', N'IX_BrandActivity_Brand_ID', N'marketing.BrandActivity', N'NONCLUSTERED|NONUNIQUE|Brand_ID||'),
    (N'IX', N'IX_MarketSegment_Market_ID', N'marketing.MarketSegment', N'NONCLUSTERED|NONUNIQUE|Market_ID||'),
    (N'IX', N'IX_MarketResearch_Market_ID', N'marketing.MarketResearch', N'NONCLUSTERED|NONUNIQUE|Market_ID||'),
    (N'IX', N'IX_MarketSurvey_Market_Research_ID', N'marketing.MarketSurvey', N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||'),
    (N'IX', N'IX_MarketSurvey_Market_Segment_ID', N'marketing.MarketSurvey', N'NONCLUSTERED|NONUNIQUE|Market_Segment_ID||([Market_Segment_ID] IS NOT NULL)'),
    (N'IX', N'IX_ResearchResult_Market_Research_ID', N'marketing.ResearchResult', N'NONCLUSTERED|NONUNIQUE|Market_Research_ID||'),
    (N'IX', N'IX_Competitor_Market_ID', N'marketing.Competitor', N'NONCLUSTERED|NONUNIQUE|Market_ID||([Market_ID] IS NOT NULL)'),
    (N'IX', N'IX_CompetitorProduct_Competitor_ID', N'marketing.CompetitorProduct', N'NONCLUSTERED|NONUNIQUE|Competitor_ID||'),
    (N'IX', N'IX_MarketPrice_Market_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Market_ID,Price_Date|Competitor_Product_ID,Currency,Price_Value,Product_ID|'),
    (N'IX', N'IX_MarketPrice_Product_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Product_ID,Price_Date||([Product_ID] IS NOT NULL)'),
    (N'IX', N'IX_MarketPrice_Competitor_Product_ID_Price_Date', N'marketing.MarketPrice', N'NONCLUSTERED|NONUNIQUE|Competitor_Product_ID,Price_Date||([Competitor_Product_ID] IS NOT NULL)'),
    (N'TR', N'TR_ProductPrice_NoOverlap', N'marketing.ProductPrice', N'marketing.ProductPrice|AFTER|INSERT,UPDATE|ENABLED'),
    (N'TR', N'TR_ProductCategory_Hierarchy', N'ref.ProductCategory', N'ref.ProductCategory|AFTER|INSERT,UPDATE|ENABLED');
WITH tbl AS (SELECT OBJECT_ID(n) AS object_id, n AS full_name FROM (VALUES (N'ref.ProductCategory'), (N'ref.Package'), (N'core.Brand'), (N'core.Product'), (N'core.SKU'), (N'marketing.ProductPrice'), (N'marketing.CampaignChannel'), (N'marketing.CampaignAudience'), (N'marketing.MarketingCampaign'), (N'marketing.MarketingCampaignChannel'), (N'marketing.MarketingCampaignAudience'), (N'marketing.CampaignBudget'), (N'marketing.CampaignCost'), (N'marketing.CampaignResult'), (N'marketing.Promotion'), (N'marketing.BrandActivity'), (N'marketing.Market'), (N'marketing.MarketSegment'), (N'marketing.MarketResearch'), (N'marketing.MarketSurvey'), (N'marketing.ResearchResult'), (N'marketing.Competitor'), (N'marketing.CompetitorProduct'), (N'marketing.MarketPrice')) v(n) WHERE OBJECT_ID(n) IS NOT NULL),
icols AS (
    SELECT i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition,
           STRING_AGG(CASE WHEN ic.is_included_column = 0 THEN CAST(col.name AS nvarchar(max)) + IIF(ic.is_descending_key = 1, N' DESC', N'') END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS keys,
           STRING_AGG(CASE WHEN ic.is_included_column = 1 THEN CAST(col.name AS nvarchar(max)) END, N',')
               WITHIN GROUP (ORDER BY ic.key_ordinal, col.name) AS incs
    FROM sys.indexes i
    JOIN tbl t ON t.object_id = i.object_id
    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns col ON col.object_id = ic.object_id AND col.column_id = ic.column_id
    GROUP BY i.object_id, i.index_id, i.name, i.type_desc, i.is_unique, i.is_primary_key, i.is_unique_constraint, i.filter_definition),
act AS (
    SELECT N'TABLE' AS kind, t.full_name AS obj, t.full_name AS parent,
           (SELECT STRING_AGG(CONCAT(CAST(c.name AS nvarchar(max)), N' ', CASE WHEN ty.name IN (N'nvarchar', N'nchar') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length / 2 AS nvarchar(10)) END + N')' WHEN ty.name IN (N'varchar', N'char') THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length AS nvarchar(10)) END + N')' WHEN ty.name IN (N'decimal', N'numeric') THEN ty.name + N'(' + CAST(c.precision AS nvarchar(10)) + N',' + CAST(c.scale AS nvarchar(10)) + N')' WHEN ty.name = N'datetime2' THEN N'datetime2(' + CAST(c.scale AS nvarchar(10)) + N')' ELSE ty.name END, IIF(c.is_nullable = 1, N' NULL', N' NOT NULL'), IIF(c.is_identity = 1, N' IDENTITY', N'')), N'; ')
                   WITHIN GROUP (ORDER BY c.column_id)
            FROM sys.columns c JOIN sys.types ty ON ty.user_type_id = c.user_type_id WHERE c.object_id = t.object_id) AS sig
    FROM tbl t
    UNION ALL
    SELECT CASE WHEN x.is_primary_key = 1 THEN N'PK' WHEN x.is_unique_constraint = 1 THEN N'UQ' WHEN x.is_unique = 1 THEN N'UX' ELSE N'IX' END,
           x.name, t.full_name,
           CASE WHEN x.is_primary_key = 1 THEN CONCAT(x.type_desc, N':', x.keys)
                ELSE CONCAT(x.type_desc, N'|', IIF(x.is_unique = 1, N'UNIQUE', N'NONUNIQUE'), N'|', x.keys, N'|', x.incs, N'|', x.filter_definition) END
    FROM icols x JOIN tbl t ON t.object_id = x.object_id
    UNION ALL
    SELECT N'CK', k.name, t.full_name, k.definition FROM sys.check_constraints k JOIN tbl t ON t.object_id = k.parent_object_id
    UNION ALL
    SELECT N'DF', d.name, t.full_name, CONCAT(col.name, N'=', d.definition)
    FROM sys.default_constraints d JOIN tbl t ON t.object_id = d.parent_object_id
    JOIN sys.columns col ON col.object_id = d.parent_object_id AND col.column_id = d.parent_column_id
    UNION ALL
    SELECT N'FK', f.name, t.full_name,
           CONCAT(STRING_AGG(CAST(pc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N' -> ',
                  OBJECT_SCHEMA_NAME(f.referenced_object_id), N'.', OBJECT_NAME(f.referenced_object_id), N'(',
                  STRING_AGG(CAST(rc.name AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY fc.constraint_column_id), N')|',
                  f.delete_referential_action_desc, N'|', f.update_referential_action_desc)
    FROM sys.foreign_keys f JOIN tbl t ON t.object_id = f.parent_object_id
    JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = f.object_id
    JOIN sys.columns pc ON pc.object_id = fc.parent_object_id AND pc.column_id = fc.parent_column_id
    JOIN sys.columns rc ON rc.object_id = fc.referenced_object_id AND rc.column_id = fc.referenced_column_id
    GROUP BY f.name, t.full_name, f.referenced_object_id, f.delete_referential_action_desc, f.update_referential_action_desc
    UNION ALL
    SELECT N'TR', tr.name, t.full_name,
           CONCAT(t.full_name, N'|', IIF(tr.is_instead_of_trigger = 1, N'INSTEAD OF', N'AFTER'), N'|',
                  (SELECT STRING_AGG(CAST(te.type_desc AS nvarchar(max)), N',') WITHIN GROUP (ORDER BY te.type_desc) FROM sys.trigger_events te WHERE te.object_id = tr.object_id),
                  N'|', IIF(tr.is_disabled = 1, N'DISABLED', N'ENABLED'))
    FROM sys.triggers tr JOIN tbl t ON t.object_id = tr.parent_id)
INSERT #Diff2
SELECT COALESCE(e.kind, a.kind), COALESCE(e.obj, a.obj),
       CASE WHEN a.obj IS NULL THEN N'missing'
            WHEN e.obj IS NULL THEN N'unexpected object: ' + a.sig
            ELSE N'expected [' + e.sig + N'] actual [' + a.sig + N']' END
FROM @E e
FULL JOIN act a
  ON a.kind = e.kind AND a.obj COLLATE Latin1_General_BIN2 = e.obj COLLATE Latin1_General_BIN2 AND a.parent COLLATE Latin1_General_BIN2 = e.parent COLLATE Latin1_General_BIN2
WHERE a.obj IS NULL OR e.obj IS NULL OR a.sig COLLATE Latin1_General_BIN2 <> e.sig COLLATE Latin1_General_BIN2;
DECLARE @chg int = (SELECT COUNT(*) FROM (SELECT kind, obj, problem FROM #Diff EXCEPT SELECT kind, obj, problem FROM #Diff2) x)
                 + (SELECT COUNT(*) FROM (SELECT kind, obj, problem FROM #Diff2 EXCEPT SELECT kind, obj, problem FROM #Diff) y);
INSERT #R (id, status, goal, input, expected, actual)
VALUES ('D03', IIF(@chg = 0, 'PASS', 'FAIL'), N'structure after the tests is identical to the structure before them', N'Part A comparison repeated after Parts B and C', N'0 changes', CONCAT(@chg, N' changes'));
DROP TABLE #Diff2;
GO

SET NOEXEC OFF;
GO

/* ---- Report: one line per test (TEST|id|status|goal|input|expected|actual) and the details of any structural difference ---- */
IF OBJECT_ID(N'tempdb..#R') IS NOT NULL
BEGIN
    DECLARE @line nvarchar(max), @pass int, @fail int;
    DECLARE r CURSOR LOCAL FAST_FORWARD FOR
        SELECT CONCAT('TEST|', id, '|', status, '|', goal, '|', input, '|', expected, '|', REPLACE(REPLACE(actual, CHAR(13), ' '), CHAR(10), ' ')) FROM #R ORDER BY seq;
    OPEN r; FETCH NEXT FROM r INTO @line;
    WHILE @@FETCH_STATUS = 0 BEGIN PRINT @line; FETCH NEXT FROM r INTO @line; END;
    CLOSE r; DEALLOCATE r;
    DECLARE d CURSOR LOCAL FAST_FORWARD FOR SELECT CONCAT(N'  DETAIL ', kind, N' ', obj, N': ', problem) FROM #Diff;
    OPEN d; FETCH NEXT FROM d INTO @line;
    WHILE @@FETCH_STATUS = 0 BEGIN PRINT @line; FETCH NEXT FROM d INTO @line; END;
    CLOSE d; DEALLOCATE d;
    SELECT @pass = SUM(IIF(status = 'PASS', 1, 0)), @fail = SUM(IIF(status = 'FAIL', 1, 0)) FROM #R;
    IF @fail = 0 PRINT CONCAT(N'RESULT: PASS - ', @pass, N' of ', @pass, N' tests passed. All test rows rolled back.');
    ELSE RAISERROR(N'RESULT: FAIL - %d test(s) failed, %d passed.', 16, 1, @fail, @pass);
    DROP TABLE #R; DROP TABLE #Diff;
END;
GO
PRINT N'07-Team2-06-Test-Validation.sql finished.';
GO
